export const seoLandingPages = [
  page('guias', 'Guias para cardápio digital e pedidos | TáPronto', 'Guias práticos para criar cardápio digital, divulgar sua loja e organizar pedidos de delivery, retirada e salão.', 'Guias práticos para organizar e divulgar sua loja', 'Conteúdos diretos para pequenos negócios de alimentação melhorarem cardápio, atendimento e fluxo de pedidos.', ['Criar e revisar seu cardápio digital', 'Divulgar o link e o QR Code nos canais certos', 'Organizar pedidos, adicionais, entrega e pagamento']),
  page('cardapio-digital', 'Cardápio Digital para Restaurantes | TáPronto', 'Crie um cardápio digital profissional com produtos, fotos, adicionais, QR Code e pedidos online. Teste o TáPronto grátis.', 'Seu cardápio digital pronto para vender', 'Troque cardápios desatualizados e pedidos espalhados por uma experiência simples para o cliente e organizada para a equipe.', ['Atualize preços e disponibilidade em tempo real', 'Compartilhe por link, QR Code, Instagram e WhatsApp', 'Receba pedidos sem pagar comissão por venda']),
  page('cardapio-digital-qr-code', 'Cardápio Digital com QR Code | TáPronto', 'Crie um QR Code para seu cardápio digital e permita que clientes vejam produtos, adicionais e preços pelo celular.', 'Cardápio com QR Code, sem PDF desatualizado', 'O cliente aponta a câmera, abre o cardápio e encontra informações legíveis e atualizadas, sem instalar aplicativo.', ['QR Code exclusivo para cada loja', 'Cardápio responsivo para celular', 'Mudanças publicadas sem imprimir novamente']),
  page('sistema-de-pedidos-online', 'Sistema de Pedidos Online para Restaurantes | TáPronto', 'Organize pedidos de delivery, retirada, mesa e comanda em um painel online criado para restaurantes.', 'Pedidos online organizados do início ao fim', 'Centralize novos pedidos, preparo, entrega e conclusão para reduzir anotações perdidas e retrabalho na operação.', ['Painel de pedidos em tempo real', 'Status claros para cozinha e atendimento', 'Histórico, clientes, cupons e formas de pagamento']),
  page('cardapio-digital-para-delivery', 'Cardápio Digital para Delivery | TáPronto', 'Receba pedidos de delivery por um cardápio digital próprio, com bairros, taxas, pagamento e painel de acompanhamento.', 'Um delivery com canal de vendas próprio', 'Venda pelo seu link, controle áreas e taxas de entrega e mantenha o relacionamento com seus clientes.', ['Taxas de entrega por bairro', 'Pedido mínimo e horários configuráveis', 'Pix online, retirada e entrega']),
  page('pedidos-online-whatsapp', 'Pedidos Online com WhatsApp para Restaurantes | TáPronto', 'Receba notificações de novos pedidos no WhatsApp e acompanhe toda a operação pelo painel TáPronto.', 'WhatsApp como alerta, painel como controle', 'Use o WhatsApp para ser avisado rapidamente sem transformar conversas soltas no sistema de gestão dos pedidos.', ['Notificação automática disponível como adicional', 'QR Code para conexão simplificada', 'Pedido completo preservado no painel']),
  page('sistema-para-restaurantes', 'Sistema para Restaurantes com Cardápio e Pedidos | TáPronto', 'Cardápio digital, pedidos, cozinha, mesas, comandas, clientes e pagamentos em uma plataforma para restaurantes.', 'A operação do restaurante em um só lugar', 'Comece com o cardápio e evolua para pedidos, salão, equipe, fidelidade e múltiplas lojas conforme a operação crescer.', ['Delivery, retirada, mesa e comanda', 'Permissões para a equipe', 'Relatórios e visão da operação']),
  segment('cardapio-digital-para-pizzaria', 'pizzaria', 'sabores, tamanhos, bordas e adicionais', 'Organize sabores, tamanhos, bordas e observações sem depender de mensagens longas e sujeitas a erro.'),
  segment('cardapio-digital-para-hamburgueria', 'hamburgueria', 'combos, pontos da carne e adicionais', 'Apresente hambúrgueres com boas fotos, monte combos e permita escolher adicionais de forma clara.'),
  segment('cardapio-digital-para-restaurante', 'restaurante', 'salão, delivery, retirada e cozinha', 'Atenda diferentes canais em um painel e mantenha cardápio, preços e disponibilidade atualizados.'),
  segment('cardapio-digital-para-lanchonete', 'lanchonete', 'lanches, combos, bebidas e retirada', 'Agilize pedidos de balcão, retirada e entrega com produtos fáceis de localizar e personalizar.'),
  segment('cardapio-digital-para-acai', 'loja de açaí', 'tamanhos, frutas, coberturas e complementos', 'Deixe o cliente montar o açaí passo a passo, respeitando quantidades e adicionais disponíveis.'),
  segment('cardapio-digital-para-bar', 'bar', 'porções, bebidas, mesas e comandas', 'Organize pedidos no salão, mesas e comandas e atualize rapidamente itens indisponíveis.'),
  guide('como-criar-cardapio-digital', 'Como criar um cardápio digital', 'Um passo a passo para organizar produtos, fotos, adicionais, preços e publicar um cardápio que funciona bem no celular.', ['Organize categorias conforme a forma de compra do cliente', 'Use fotos leves, descrições objetivas e preços claros', 'Teste o pedido completo antes de divulgar o link']),
  guide('como-criar-qr-code-cardapio', 'Como criar QR Code para cardápio', 'Aprenda a gerar, testar e posicionar o QR Code do cardápio em mesas, balcão, embalagens e redes sociais.', ['Use um link permanente para não reimprimir materiais', 'Teste em celulares diferentes e sob pouca luz', 'Inclua uma chamada clara perto do código']),
  guide('como-organizar-pedidos-delivery', 'Como organizar pedidos de delivery', 'Veja como reduzir erros ao centralizar itens, adicionais, endereço, pagamento e andamento de cada pedido.', ['Defina etapas simples para atendimento e cozinha', 'Configure taxas e bairros antes de divulgar', 'Mantenha o WhatsApp como alerta e o painel como registro']),
  guide('como-tirar-fotos-para-cardapio', 'Como tirar fotos para cardápio', 'Um guia prático para fotografar pratos e lanches com celular, luz natural e enquadramento consistente.', ['Fotografe perto de uma janela e evite misturar luzes', 'Mantenha o mesmo fundo e proporção', 'Comprima as imagens para o cardápio carregar rápido']),
  guide('como-divulgar-cardapio-digital', 'Como divulgar seu cardápio digital', 'Ideias práticas para levar clientes ao cardápio por Instagram, WhatsApp, Google, QR Code e embalagens.', ['Use links com UTM para descobrir a origem das visitas', 'Mostre o produto e facilite o próximo passo', 'Repita a divulgação nos momentos de maior procura']),
  guide('como-aumentar-pedidos-restaurante', 'Como aumentar pedidos no restaurante', 'Melhore conversão com cardápio claro, produtos principais visíveis, adicionais simples e um checkout sem atrito.', ['Coloque os campeões de venda em destaque', 'Evite opções desnecessárias no checkout', 'Acompanhe visitas, inícios de pedido e pedidos concluídos']),
  guide('cardapio-digital-para-hamburgueria-guia', 'Cardápio digital para hamburgueria', 'Organize combos, pontos da carne, remoções e adicionais para o pedido chegar completo à cozinha.', ['Separe escolhas obrigatórias de extras pagos', 'Mostre os campeões de venda primeiro', 'Teste combinações e limites pelo celular']),
  guide('cardapio-digital-para-pizzaria-guia', 'Cardápio digital para pizzaria', 'Estruture tamanhos, sabores, bordas e divisões sem deixar o cliente perdido no momento de pedir.', ['Defina quantos sabores cada tamanho aceita', 'Organize bordas e adicionais por grupo', 'Deixe regras e valores visíveis antes do checkout']),
  guide('cardapio-digital-para-acai-guia', 'Cardápio digital para açaí', 'Monte tamanhos e complementos com limites claros para reduzir erro, desperdício e confirmação por mensagem.', ['Comece pelo tamanho do copo', 'Separe complementos inclusos e pagos', 'Limite escolhas conforme a montagem real']),
  guide('cardapio-digital-para-marmitaria', 'Cardápio digital para marmitaria', 'Atualize o cardápio do dia, organize tamanhos e facilite entrega ou retirada sem reenviar imagens.', ['Destaque pratos disponíveis no dia', 'Informe acompanhamentos e trocas permitidas', 'Configure bairros, horários e pedido mínimo']),
  guide('cardapio-digital-para-bar-com-qr-code', 'Cardápio digital para bar com QR Code', 'Use QR Code, mesas e comandas para organizar pedidos no salão sem depender de papel espalhado.', ['Identifique cada mesa corretamente', 'Separe bebidas, porções e adicionais', 'Defina como atendimento e cozinha acompanham os status']),
  guide('como-receber-pedidos-online-sem-aplicativo', 'Como receber pedidos online sem aplicativo', 'Entenda como o cliente acessa o cardápio pelo navegador, escolhe os itens e conclui o pedido pelo celular.', ['Use um link simples e permanente', 'Evite exigir cadastro antes da escolha', 'Faça um pedido teste em Android e iPhone']),
  guide('como-organizar-adicionais', 'Como organizar adicionais e evitar pedidos errados', 'Crie grupos claros para tamanho, sabor, remoções e extras, respeitando o jeito real de preparar cada produto.', ['Diga quando a escolha é obrigatória', 'Defina quantidade mínima e máxima', 'Mostre o preço de cada extra']),
  guide('como-calcular-taxa-entrega-por-bairro', 'Como calcular taxa de entrega por bairro', 'Organize regiões, valores e pedido mínimo antes de divulgar o delivery e evite negociar frete durante a conversa.', ['Liste os bairros realmente atendidos', 'Considere distância e custo operacional', 'Revise taxas sempre que a rota mudar']),
  guide('como-criar-cupom-desconto-restaurante', 'Como criar cupom de desconto para restaurante', 'Planeje cupons com objetivo, validade e limite para atrair ou recuperar clientes sem comprometer a margem.', ['Defina o comportamento que deseja incentivar', 'Use validade e limite de utilização', 'Compare pedidos com e sem o cupom']),
  guide('como-aumentar-ticket-medio-cardapio', 'Como aumentar o ticket médio no cardápio digital', 'Facilite a escolha de combos, acompanhamentos e adicionais úteis sem empurrar opções demais ao cliente.', ['Apresente complementos relacionados', 'Monte combos fáceis de entender', 'Acompanhe ticket médio e aceitação dos extras']),
  guide('como-usar-pix-online-delivery', 'Como usar Pix online no delivery', 'Configure o pagamento para o pedido avançar somente depois da confirmação e deixe o fluxo claro para cliente e loja.', ['Use uma conta de pagamento da própria empresa', 'Teste geração, expiração e confirmação', 'Defina como tratar pagamento pendente ou expirado']),
  guide('como-organizar-pedidos-por-status', 'Como organizar pedidos por status', 'Crie uma rotina simples para novos pedidos, preparo, retirada, entrega, conclusão e cancelamento.', ['Use poucas etapas compreendidas pela equipe', 'Defina quem age em cada status', 'Evite deixar pedidos concluídos na fila ativa']),
  guide('como-criar-programa-fidelidade-restaurante', 'Como criar programa de fidelidade para restaurante', 'Escolha uma recompensa sustentável e explique com clareza como o cliente avança e recebe o benefício.', ['Defina a ação que gera progresso', 'Escolha uma recompensa simples', 'Acompanhe recorrência e custo do benefício']),
  guide('como-melhorar-experiencia-delivery', 'Como melhorar a experiência do cliente no delivery', 'Revise a jornada do cardápio à entrega para reduzir dúvida, espera e surpresa no fechamento do pedido.', ['Mantenha informações atualizadas', 'Mostre taxa, prazo e pagamento antes de confirmar', 'Comunique mudanças de status importantes']),
  guide('cardapio-proprio-ou-marketplace', 'Cardápio próprio ou marketplace: quando usar cada canal', 'Compare alcance, relacionamento, custos e controle para decidir como combinar marketplace, WhatsApp e canal próprio.', ['Use marketplace para descoberta quando fizer sentido', 'Construa recorrência pelo canal próprio', 'Compare resultado líquido e origem dos pedidos']),
  guide('como-divulgar-restaurante-instagram', 'Como divulgar restaurante no Instagram com link de pedidos', 'Organize perfil, conteúdo e chamadas para transformar interesse em visita ao cardápio e pedido concluído.', ['Explique o que vende na bio', 'Mostre produtos e bastidores reais', 'Use um link rastreável e uma chamada clara']),
  guide('checklist-abrir-delivery-pequeno', 'Checklist para abrir um delivery pequeno', 'Confira cardápio, embalagem, atendimento, entrega, pagamento e testes necessários antes de começar a divulgar.', ['Comece com um cardápio enxuto', 'Teste embalagem e tempo de preparo', 'Simule um pedido completo antes da abertura']),
  guide('indicadores-pedidos-restaurante', 'Indicadores simples para acompanhar pedidos', 'Acompanhe volume, receita, ticket médio, cancelamentos e horários de pico sem transformar a rotina em planilha complicada.', ['Compare períodos equivalentes', 'Investigue mudanças grandes', 'Escolha uma ação por vez para melhorar']),
];

function guide(slug, heading, intro, benefits) {
  return {
    ...page(
    `guias/${slug}`,
    `${heading}: guia prático | TáPronto`,
    `${intro} Confira o guia prático do TáPronto para pequenos negócios de alimentação.`,
    heading,
    intro,
    benefits
    ),
    article: guideDetails(slug, { heading, intro, benefits })
  };
}

function guideDetails(slug, context = {}) {
  const shared = { updatedAt: '11 de agosto de 2026', author: 'Equipe TáPronto' };
  const articles = {
    'como-criar-cardapio-digital': {
      readTime: '6 min', category: 'Cardápio digital', takeaway: 'Você não precisa cadastrar tudo de uma vez. Comece pelos produtos mais vendidos, teste o pedido pelo celular e melhore o cardápio aos poucos.',
      sections: [
        { title: 'O que É um Cardápio Digital?', paragraphs: ['É uma página da sua loja que abre pelo celular e apresenta produtos, preços, fotos e opções de forma atualizada.', 'Diferente de um PDF ou imagem, um cardápio digital pode organizar adicionais, entrega, retirada e pagamento antes de o pedido chegar para a equipe.'] },
        { title: 'Separe as Informações antes de Começar', paragraphs: ['Reúna o que já existe no balcão, no WhatsApp ou no cardápio impresso. Não espere tudo ficar perfeito para iniciar.'], bullets: ['Nome e preço dos produtos', 'Categorias como lanches, pizzas, bebidas e sobremesas', 'Adicionais e observações permitidas', 'Horários, retirada, entrega e bairros atendidos', 'Logo e pelo menos uma boa foto dos campeões de venda'] },
        { title: 'Crie uma Ordem Fácil para o Cliente', paragraphs: ['A pessoa deve entender rapidamente o que sua loja vende. Use categorias curtas e coloque os itens mais procurados primeiro.'], bullets: ['Destaques ou mais pedidos', 'Categorias principais', 'Combos e complementos', 'Bebidas', 'Sobremesas'] },
        { title: 'Cadastre Produtos com Clareza', paragraphs: ['O nome identifica o produto. A descrição deve explicar o que vem nele. Evite repetir frases ou usar nomes que só sua equipe entende.'], example: { bad: 'X-Tudo Especial', good: 'X-Tudo — hambúrguer, queijo, bacon, ovo, presunto, alface e tomate' } },
        { title: 'Configure Adicionais sem Confusão', paragraphs: ['Adicionais claros evitam mensagens de confirmação e erros na cozinha. Informe o que é obrigatório, quantas opções podem ser escolhidas e o valor de cada extra.'], bullets: ['Escolha do tamanho', 'Ponto da carne', 'Borda ou sabor', 'Remoção de ingredientes', 'Extras pagos'] },
        { title: 'Teste Como Se Fosse um Cliente', paragraphs: ['Abra o link em outro celular e faça um pedido completo. Confira se a equipe recebe produto, adicionais, endereço, entrega e pagamento corretamente.'], checklist: ['Os preços estão corretos?', 'As fotos carregam rápido?', 'Os adicionais chegam completos?', 'A taxa de entrega está certa?', 'O pedido aparece no painel?'] },
        { title: 'Publique e Divulgue', paragraphs: ['Depois do teste, coloque o link na bio do Instagram, envie pelo WhatsApp e imprima o QR Code para balcão, mesa ou embalagem. O mesmo link continua funcionando quando você atualizar produtos e preços.'] }
      ]
    },
    'como-criar-qr-code-cardapio': {
      readTime: '5 min', category: 'QR Code e salão', takeaway: 'O QR Code deve abrir um link permanente, ser testado em celulares diferentes e ficar acompanhado de uma instrução clara.',
      sections: [
        { title: 'Como Funciona o QR Code do Cardápio?', paragraphs: ['O cliente aponta a câmera do celular, toca no aviso e abre o cardápio no navegador. Não precisa instalar aplicativo.'] },
        { title: 'Use um Link que Não Muda', paragraphs: ['O QR Code aponta para o endereço da sua loja. Produtos e preços podem mudar sem ser necessário imprimir outro código.'] },
        { title: 'Teste antes de Imprimir', bullets: ['Leia com Android e iPhone', 'Teste sob luz forte e em ambiente escuro', 'Confirme o funcionamento a uma distância normal', 'Faça um pedido completo pelo link'] },
        { title: 'Escolha os Locais Certos', bullets: ['Mesas e balcão', 'Embalagens e sacolas', 'Cartão de visita ou panfleto', 'Vitrine e caixa', 'Posts e destaques do Instagram'] },
        { title: 'Não Deixe o Código Sozinho', paragraphs: ['Escreva uma instrução como “Aponte a câmera e veja o cardápio”. O cliente precisa entender o que vai acontecer antes de escanear.'], checklist: ['Contraste forte', 'Margem branca ao redor', 'Tamanho suficiente', 'Link correto', 'Instrução visível'] }
      ]
    },
    'como-organizar-pedidos-delivery': {
      readTime: '7 min', category: 'Pedidos e delivery', takeaway: 'O WhatsApp pode continuar como apoio, mas cada pedido precisa chegar com os mesmos campos e seguir etapas visíveis para toda a equipe.',
      sections: [
        { title: 'Onde o Pedido Costuma Se Perder?', paragraphs: ['Nos horários de pico, produto, adicional, endereço e pagamento podem ficar espalhados em várias mensagens. O primeiro passo é padronizar o que precisa chegar.'] },
        { title: 'Defina os Dados Obrigatórios', bullets: ['Produto e quantidade', 'Adicionais e observações', 'Nome e telefone', 'Entrega ou retirada', 'Endereço e bairro', 'Forma de pagamento'] },
        { title: 'Crie Etapas Simples', paragraphs: ['Use poucos status que representem o trabalho real. A equipe deve saber quem precisa agir em cada etapa.'], bullets: ['Novo', 'Aceito', 'Em preparo', 'Pronto', 'Saiu para entrega', 'Concluído ou cancelado'] },
        { title: 'Configure Entrega antes de Divulgar', paragraphs: ['Cadastre bairros, taxas, pedido mínimo e horários. Isso evita calcular frete no meio da conversa e reduz surpresa no checkout.'] },
        { title: 'Faça um Pedido Teste', checklist: ['Pedido chegou completo?', 'Cozinha viu as observações?', 'Pagamento ficou claro?', 'Taxa e total conferem?', 'Status funcionam para a equipe?'] }
      ]
    },
    'como-tirar-fotos-para-cardapio': {
      readTime: '5 min', category: 'Fotos e produtos', takeaway: 'Luz natural, fundo simples e enquadramento consistente costumam melhorar mais a foto do que filtros pesados.',
      sections: [
        { title: 'Prepare o Produto e o Ambiente', paragraphs: ['Monte o prato como ele realmente será entregue. Limpe a lente do celular e fotografe perto de uma janela.'] },
        { title: 'Use Luz Lateral e Fundo Simples', bullets: ['Desligue luzes de cores diferentes', 'Evite flash direto', 'Retire objetos que disputam atenção', 'Mantenha o mesmo fundo na sequência'] },
        { title: 'Escolha um Enquadramento Consistente', paragraphs: ['Fotografe produtos semelhantes pelo mesmo ângulo. Para hambúrgueres, um ângulo mais baixo mostra as camadas; para pratos, a foto de cima costuma funcionar.'] },
        { title: 'Edite sem Mudar o Produto', paragraphs: ['Ajuste claridade, corte e contraste com moderação. A foto deve criar expectativa sem mostrar algo diferente do que o cliente receberá.'] },
        { title: 'Otimize antes de Publicar', checklist: ['Imagem nítida', 'Produto centralizado', 'Cores naturais', 'Mesmo formato', 'Arquivo leve para carregar rápido'] }
      ]
    },
    'como-divulgar-cardapio-digital': {
      readTime: '6 min', category: 'Marketing da loja', takeaway: 'Divulgar bem é colocar o link no caminho do cliente e repetir a chamada nos momentos em que ele está mais propenso a pedir.',
      sections: [
        { title: 'Comece pelos Canais que Você Já Tem', bullets: ['Link na bio do Instagram', 'Mensagem de saudação no WhatsApp', 'Perfil da Empresa no Google', 'QR Code em embalagem, mesa e balcão'] },
        { title: 'Mostre o Produto antes do Link', paragraphs: ['Uma foto ou vídeo do prato cria vontade. Depois, use uma chamada direta como “Veja o cardápio e faça seu pedido”.'] },
        { title: 'Publique nos Horários Certos', paragraphs: ['Observe quando seus clientes costumam pedir. Divulgue antes do almoço, do jantar ou do pico de fim de semana, não apenas quando a loja estiver vazia.'] },
        { title: 'Use Links Rastreáveis', paragraphs: ['Links com identificação de origem ajudam a descobrir se os pedidos vieram do Instagram, Google, WhatsApp ou parceiro.'] },
        { title: 'Repita sem Copiar a Mesma Publicação', checklist: ['Produto diferente', 'Dor diferente', 'Formato diferente', 'Mesmo link correto', 'Uma chamada por peça'] }
      ]
    },
    'como-aumentar-pedidos-restaurante': {
      readTime: '7 min', category: 'Vendas e operação', takeaway: 'Antes de dar desconto, remova os atritos que impedem o cliente de encontrar, entender e concluir o pedido.',
      sections: [
        { title: 'Descubra Onde o Cliente para', paragraphs: ['Compare visitas ao cardápio, inícios de pedido e pedidos concluídos. A etapa com maior queda merece atenção primeiro.'] },
        { title: 'Deixe os Campeões de Venda Visíveis', bullets: ['Destaques no topo', 'Fotos claras', 'Descrição objetiva', 'Preço sem surpresa', 'Combos realmente simples'] },
        { title: 'Reduza Escolhas Desnecessárias', paragraphs: ['Muitas opções obrigatórias cansam. Peça apenas o que a cozinha precisa para preparar e entregar corretamente.'] },
        { title: 'Revise Entrega e Pagamento', paragraphs: ['Taxa desconhecida, bairro ausente ou pagamento confuso interrompem o pedido perto do fim. Teste o checkout regularmente.'] },
        { title: 'Trabalhe Recorrência', paragraphs: ['Facilite para o cliente encontrar novamente o link e repetir a compra. Use embalagem, WhatsApp e redes sociais para manter o canal próprio acessível.'], checklist: ['Cardápio atualizado', 'Loja aberta no horário correto', 'Pedido teste concluído', 'Link visível', 'Métricas acompanhadas'] }
      ]
    }
  };
  const generated = {
    readTime: '6 min', category: 'Guia prático',
    takeaway: context.intro || 'Comece pelo básico, teste o fluxo completo e ajuste com base no que acontece na operação real.',
    sections: [
      { title: `Por que ${String(context.heading || 'este tema').toLowerCase()} importa?`, paragraphs: [context.intro || 'Uma operação clara reduz dúvidas para o cliente e retrabalho para a equipe.', 'Descreva como o pedido funciona hoje, onde a informação se perde e quem precisa agir em cada etapa.'] },
      { title: 'Prepare as Informações Necessárias', paragraphs: ['Reúna preços, regras, horários e responsabilidades antes de configurar. Começar com dados confiáveis é mais importante do que cadastrar tudo de uma vez.'], bullets: context.benefits || [] },
      { title: 'Aplique em uma Situação Real', paragraphs: ['Escolha um produto ou fluxo muito usado e configure do início ao fim. O cliente deve conseguir escolher, personalizar e concluir sem a equipe repetir perguntas.'], example: { bad: 'Informações espalhadas e confirmação manual', good: 'Escolhas claras reunidas no mesmo pedido' } },
      { title: 'Teste pelo Ponto de Vista do Cliente', paragraphs: ['Abra o link em outro celular e conclua o processo sem usar informações que só a equipe conhece. Anote qualquer dúvida, etapa repetida ou valor inesperado.'], checklist: ['Informações fáceis de encontrar', 'Valores e limites corretos', 'Boa leitura no celular', 'Pedido recebido completo', 'Próximo passo claro'] },
      { title: 'Acompanhe e Melhore', paragraphs: ['Revise dúvidas, cancelamentos e etapas em que o cliente para. Faça uma mudança por vez e compare o resultado antes de ampliar.'] }
    ]
  };
  return { ...shared, ...(articles[slug] || generated) };
}

function page(slug, title, description, heading, intro, benefits) {
  return {
    slug, title, description, heading, intro, benefits,
    steps: ['Cadastre a loja e personalize sua marca', 'Adicione produtos, categorias e formas de atendimento', 'Publique o link e compartilhe o QR Code'],
    faq: [
      ['Precisa instalar aplicativo?', 'Não. O cliente acessa pelo navegador do celular e a equipe utiliza o painel online.'],
      ['Posso alterar o cardápio depois?', 'Sim. Produtos, preços e disponibilidade podem ser atualizados sempre que necessário.'],
      ['O TáPronto cobra comissão por pedido?', 'Não há taxa percentual por pedido. A contratação segue o plano e os adicionais escolhidos.']
    ]
  };
}

function segment(slug, business, features, intro) {
  const label = business.charAt(0).toUpperCase() + business.slice(1);
  return page(
    slug,
    `Cardápio Digital para ${label} | TáPronto`,
    `Cardápio digital para ${business} com ${features}, pedidos online, QR Code e painel de gestão. Teste o TáPronto grátis.`,
    `Cardápio digital pensado para ${business}`,
    intro,
    [`Configure ${features}`, 'Receba pedidos pelo link próprio da loja', 'Acompanhe atendimento e preparo pelo painel']
  );
}
