import assert from 'node:assert/strict';

let instagramPaidFunnel = null;
try {
  ({ instagramPaidFunnel } = await import('../src/lib/platform-ad-funnel.js'));
} catch {}

assert.equal(typeof instagramPaidFunnel, 'function', 'A Central precisa calcular o funil pago do Instagram separadamente.');

const paid = { utm_source: 'instagram', utm_medium: 'paid_social', utm_campaign: 'delivery_noroeste_rs', utm_content: '52582798716168' };
const events = [
  { id: '1', event_name: 'landing_view', visitor_key: 'v1', attribution: paid },
  { id: '2', event_name: 'landing_view', visitor_key: 'v1', attribution: paid },
  { id: '3', event_name: 'landing_view', visitor_key: 'v2', attribution: paid },
  { id: '4', event_name: 'signup_started', visitor_key: 'v1', attribution: paid },
  { id: '5', event_name: 'whatsapp_click', visitor_key: 'v2', attribution: paid },
  { id: '6', event_name: 'signup_completed', visitor_key: 'v1', company_id: 'company-1', attribution: paid },
  { id: '7', event_name: 'subscription_created', company_id: 'company-1', attribution: paid },
  { id: '8', event_name: 'landing_view', visitor_key: 'organic', attribution: { utm_source: 'instagram', utm_medium: 'organic' } }
  ,{ id: '9', event_name: 'landing_view', visitor_key: 'test-same-campaign', attribution: { utm_source: 'instagram', utm_medium: 'paid_social', utm_campaign: 'delivery_noroeste_rs' } }
  ,{ id: '10', event_name: 'signup_started', visitor_key: 'test-same-campaign', attribution: { utm_source: 'instagram', utm_medium: 'paid_social', utm_campaign: 'delivery_noroeste_rs' } }
  ,{ id: '11', event_name: 'landing_view', visitor_key: 'test-old-campaign', attribution: { utm_source: 'instagram', utm_medium: 'paid_social', utm_campaign: 'noroeste_gaucho_delivery', utm_content: 'criativo_whatsapp_01' } }
  ,{ id: '12', event_name: 'landing_view', visitor_key: 'test-no-campaign', attribution: { utm_source: 'instagram', utm_medium: 'paid_social' } }
];

assert.deepEqual(instagramPaidFunnel(events), {
  landing_views: 2,
  signup_clicks: 1,
  signup_completed: 1,
  whatsapp_clicks: 1,
  subscriptions: 1,
  landing_to_signup_click_rate: 50,
  signup_click_to_completed_rate: 100,
  landing_to_whatsapp_rate: 50,
  landing_to_subscription_rate: 50,
  campaigns: [{ campaign: 'delivery_noroeste_rs', landing_views: 2, signup_clicks: 1, signup_completed: 1, whatsapp_clicks: 1, subscriptions: 1 }]
});

console.log('Platform Instagram funnel smoke: OK');
