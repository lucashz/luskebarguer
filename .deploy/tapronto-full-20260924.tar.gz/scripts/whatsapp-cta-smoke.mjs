import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../public/home.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../public/home.css', import.meta.url), 'utf8');

assert(html.includes('class="whatsapp-float"'), 'CTA flutuante do WhatsApp não existe.');
assert(html.includes('aria-label="Falar com o TáPronto pelo WhatsApp"'), 'CTA do WhatsApp precisa de nome acessível.');
assert(/\.whatsapp-float-icon\s*\{[^}]*background:\s*#25d366;[^}]*color:\s*#fff;/s.test(css), 'O ícone precisa usar o verde oficial do WhatsApp com símbolo branco.');
assert(!/\.whatsapp-float-icon\s*\{[^}]*background:\s*#fff;/s.test(css), 'O ícone oficial do WhatsApp não deve usar disco branco.');
assert(/\.whatsapp-float-icon svg\s*\{[^}]*width:\s*24px;[^}]*height:\s*24px;/s.test(css), 'O símbolo do WhatsApp precisa usar 24px sem distorção.');
assert(/@media\s*\(max-width:\s*640px\)[\s\S]*?\.whatsapp-float\s*\{[^}]*width:\s*52px;[^}]*height:\s*52px;/s.test(css), 'No celular, o botão do WhatsApp precisa ter alvo de toque de 52px.');

console.log('CTA flutuante do WhatsApp validado com sucesso.');
