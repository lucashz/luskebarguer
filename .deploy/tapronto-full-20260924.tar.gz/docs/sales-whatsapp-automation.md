# Automação comercial por WhatsApp

A prospecção reutiliza exclusivamente a Evolution Go já existente no TáPronto. Não há segundo cliente, webhook, QR Code ou credencial do provedor.

## Segurança inicial

O sistema nasce com:

```env
SALES_AUTOMATION_ENABLED=false
SALES_AUTOMATION_MODE=draft
```

Nesse estado, nenhuma mensagem real pode ser enviada. O envio exige simultaneamente:

- instância comercial conectada;
- `SALES_WHATSAPP_STORE_ID` apontando para a loja interna do TáPronto;
- automação habilitada;
- modo `supervised` ou `autonomous`;
- mensagem aprovada;
- lead ativo e fora da lista de supressão;
- horário e limites respeitados.

## Configuração

Use na Central a mesma infraestrutura de QR Code para conectar uma loja interna pertencente ao TáPronto. Copie o UUID dessa loja para:

```env
SALES_WHATSAPP_STORE_ID=uuid-da-loja-interna
SALES_BLOCKED_DATES=2026-09-07,2026-10-12
```

Não adicione URL ou API key da Evolution nesta configuração. Elas continuam em `PlatformWhatsappSetting`; a instância continua em `StoreWhatsappIntegration`.

## Comandos

```powershell
npm run sales:status
npm run sales -- lead:create --business_name "Le Mangiare Pizzaria" --city "Três de Maio" --state RS --segment pizzaria --instagram @lemangiare --score 90
npm run sales -- lead:import --file .\leads.json --dry-run
npm run sales -- lead:list
npm run sales -- lead:show UUID
npm run sales -- message:draft UUID_DO_LEAD
npm run sales -- message:approve UUID_DA_MENSAGEM
npm run sales -- message:send UUID_DA_MENSAGEM --dry-run
npm run sales -- history UUID_DO_LEAD
npm run sales -- inbox:process
npm run sales -- followups:run --dry-run
npm run sales -- handoff:list
npm run sales -- lead:pause UUID_DO_LEAD
npm run sales -- lead:resume UUID_DO_LEAD
npm run sales -- lead:opt-out UUID_DO_LEAD --reason "Solicitação do contato"
npm run sales -- automation:pause
npm run sales -- automation:resume
npm run sales -- metrics
npm run sales -- simulate UUID_DO_LEAD --body "Já usamos o iFood"
```

`message:send --dry-run` nunca chama a Evolution. Sem `--dry-run`, o comando ainda respeita os bloqueios globais e exige `SALES_AUTOMATION_ENABLED=true`.

## Worker

Uma execução:

```powershell
npm run sales:worker:once
```

Execução contínua:

```powershell
npm run sales:worker
```

O worker captura jobs com `FOR UPDATE SKIP LOCKED`, usa chave de idempotência, retry exponencial limitado e encaminha falhas permanentes para atendimento humano.

## Webhook

Respostas entram pelo endpoint já existente:

```text
POST /api/integrations/evolution/webhook
```

O handler valida o segredo existente, identifica a instância, ignora mensagens próprias e grupos, associa o telefone ao lead e apenas enfileira a classificação. O worker interpreta a resposta localmente usando o roteiro comercial e regras determinísticas; a prospecção não usa OpenAI nem outra IA externa.

Mídias não suportadas são registradas e encaminhadas para atendimento humano. Solicitações de opt-out são processadas imediatamente e cancelam jobs pendentes.

## Modos

- `draft`: apenas rascunhos; nunca envia.
- `supervised`: operador aprova e dispara mensagens pelos comandos.
- `autonomous`: somente respostas comuns e de alta confiança podem ser enfileiradas automaticamente. Preço, demonstração, reclamações, ambiguidades e pedidos humanos vão para handoff.

O primeiro contato sempre nasce como rascunho e exige aprovação.

## Testes

```powershell
npm run test:sales
npm run test:syntax
npx prisma validate
```

O smoke test valida o roteiro local e não chama serviços de IA, a Evolution Go ou números reais.
