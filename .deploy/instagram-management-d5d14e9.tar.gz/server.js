﻿import { createServer } from 'node:http';
import { mkdir, readFile, readdir, stat, statfs, unlink, writeFile } from 'node:fs/promises';
import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';
import { createCipheriv, createDecipheriv, createHash, pbkdf2Sync, randomBytes, randomInt, randomUUID, scryptSync, timingSafeEqual } from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
import v8 from 'node:v8';
import { gzipSync } from 'node:zlib';
import { promisify } from 'node:util';
import { gunzip } from 'node:zlib';
import net from 'node:net';
import tls from 'node:tls';
import dns from 'node:dns/promises';
import pg from 'pg';
import { localPostgrestRequest, withLocalTransaction } from './src/lib/local-postgrest-adapter.js';
import { seoLandingPages } from './src/data/seo-pages.js';
import { SOCIAL_CONTENT_STATUSES, SOCIAL_TRANSITIONS, assertSafeMediaUrl, assertTransition, assetsApprovalHash, contentApprovalHash, createOAuthState, decryptSocialSecret, encryptSocialSecret, exchangeInstagramCode, hashText, instagramAuthorizationUrl, metaRequest, publicationIdempotencyKey, socialConfig, socialConfigStatus, validateContentForApproval } from './src/lib/social-publishing.js';
import { autopilotDashboard, generateDailyAutopilotPost, selectAutopilotVersion, updateAutopilotSettings } from './src/lib/marketing-autopilot.js';
import { auditMarketingContent, contentFatigue, repurposeVariants } from './src/lib/marketing-content-intelligence.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, 'public');

loadEnv(path.join(__dirname, '.env'));

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
const DATABASE_URL = process.env.DATABASE_URL || '';
const UPLOAD_DIR = path.resolve(__dirname, process.env.UPLOAD_DIR || 'uploads');
const BACKUP_DIR = path.resolve(__dirname, process.env.BACKUP_DIR || 'backups');
const STORE_WHATSAPP_NUMBER = onlyDigits(process.env.STORE_WHATSAPP_NUMBER || '');
const MAX_JSON_BYTES = 8 * 1024 * 1024;
const COMPANY_LEGAL_ID = 'TáPronto - CNPJ 68.264.239/0001-02';
const REFERRAL_REWARD_CENTS = 1000;
const REFERRAL_MONTHLY_LIMIT_CENTS = 3000;
const ADMIN_COOKIE = 'admin_session';
const CUSTOMER_COOKIE = 'customer_session';
const MARKETING_ATTRIBUTION_COOKIE = 'tapronto_attribution';
const SESSION_MAX_AGE_DAYS = clampNumber(Number(process.env.SESSION_MAX_AGE_DAYS || 30), 1, 90);
const SESSION_MAX_AGE = 60 * 60 * 24 * SESSION_MAX_AGE_DAYS;
const SESSION_RENEW_MS = 1000 * 60 * 60 * 24 * 30;
const COOKIE_SECURE = parseBoolean(process.env.COOKIE_SECURE, false);
const PASSWORD_MIN_LENGTH = clampNumber(Number(process.env.PASSWORD_MIN_LENGTH || 8), 8, 72);
const ADMIN_SETUP_ENABLED = parseBoolean(process.env.ADMIN_SETUP_ENABLED, false);
const ADMIN_2FA_REQUIRED = parseBoolean(process.env.ADMIN_2FA_REQUIRED, true);
const EXPOSE_ERROR_DETAIL = parseBoolean(process.env.EXPOSE_ERROR_DETAIL, false);
const PLATFORM_BILLING_PROVIDER = cleanText(process.env.PLATFORM_BILLING_PROVIDER || 'abacatepay').toLowerCase();
const PLATFORM_BILLING_API_KEY = process.env.PLATFORM_BILLING_API_KEY || process.env.ABACATEPAY_API_KEY || '';
const PLATFORM_BILLING_WEBHOOK_SECRET = process.env.PLATFORM_BILLING_WEBHOOK_SECRET || process.env.ABACATEPAY_WEBHOOK_SECRET || '';
const ABACATEPAY_API_BASE = 'https://api.abacatepay.com/v2';
const BILLING_GRACE_DAYS = clampNumber(Number(process.env.BILLING_GRACE_DAYS || 7), 1, 30);
const PUBLIC_BOOTSTRAP_CACHE_MS = 1000 * 20;
const STORE_SETTINGS_CACHE_MS = 1000 * 10;
const MENU_CACHE_MS = 1000 * 15;
const SESSION_CACHE_MS = 1000 * 30;
const ADMIN_LIST_CACHE_MS = 1000 * 8;
const ADMIN_ACCESS_CACHE_MS = 1000 * 15;
const ADMIN_ORDERS_CACHE_MS = 1000 * 3;
const DEFAULT_STORE_SLUG = 'luske-burguer';
const publicBootstrapCache = new Map();
const storeSettingsCache = new Map();
const menuCache = new Map();
const sessionCache = new Map();
const adminStoreAccessCache = new Map();
const adminOrdersCache = new Map();
const paymentReconciliationCache = new Map();
let adminCustomersCache = null;
let adminPromotionsCache = null;
let adminTablesCache = null;
let adminUsersCache = null;
const rateLimitBuckets = new Map();
const requestMetrics = [];
const MAX_REQUEST_METRICS = 5000;
const allowedUploadTypes = new Set(['image/jpeg', 'image/png', 'image/webp']);
const allowedSocialUploadTypes = new Set(['image/jpeg', 'image/png', 'image/webp', 'video/mp4']);
const gunzipAsync = promisify(gunzip);

const orderStatuses = new Set([
  'new',
  'accepted',
  'preparing',
  'ready',
  'out_for_delivery',
  'completed',
  'cancelled'
]);

const mimeTypes = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.svg', 'image/svg+xml'],
  ['.ico', 'image/x-icon']
]);
const staticFileCache = new Map();
const compressibleStaticExtensions = new Set(['.html', '.css', '.js', '.json', '.svg']);
const inflightDbReads = new Map();
const seoLandingByPath = new Map(seoLandingPages.map((page) => [`/${page.slug}`, page]));

const server = createServer(async (req, res) => {
  const startedAt = performance.now();
  let pathname = '/';
  const originalWriteHead = res.writeHead.bind(res);
  res.writeHead = (...args) => {
    if (!res.headersSent && !res.hasHeader('Server-Timing')) {
      res.setHeader('Server-Timing', `app;dur=${Math.max(0, performance.now() - startedAt).toFixed(1)}`);
    }
    return originalWriteHead(...args);
  };
  res.on('finish', () => {
    recordRequestMetric({
      method: req.method || 'GET',
      pathname,
      status: res.statusCode,
      duration_ms: Math.round(performance.now() - startedAt)
    });
  });
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host || HOST}`);
    pathname = url.pathname;

    if (url.pathname.startsWith('/api/')) {
      await handleApi(req, res, url);
      return;
    }

    await serveStatic(req, res, url.pathname, req.headers['x-forwarded-host'] || req.headers.host, url.search);
  } catch (error) {
    logServerError(error, req);
    const detail = error.detail && typeof error.detail === 'object' ? error.detail : null;
    json(res, error.status || 500, {
      error: error.message || 'Erro interno do servidor.',
      ...(detail?.code ? { code: detail.code, error_code: detail.error_code || detail.code } : {}),
      ...(detail && error.status === 403 ? {
        feature: detail.feature,
        usage_key: detail.usage_key,
        used: detail.used,
        limit: detail.limit
      } : {}),
      detail: EXPOSE_ERROR_DETAIL ? error.detail || undefined : undefined
    });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Servidor Node iniciado em http://${HOST}:${PORT}`);
});

setInterval(cleanExpiredSessions, 1000 * 60 * 60 * 6).unref?.();
setTimeout(cleanExpiredSessions, 1000 * 20).unref?.();
const MARKETING_AUTOMATION_ENABLED = parseBoolean(process.env.MARKETING_AUTOMATION_ENABLED, true);
if (MARKETING_AUTOMATION_ENABLED) {
  setInterval(runMarketingLifecycleAutomations, 1000 * 60 * 60 * 6).unref?.();
  setTimeout(runMarketingLifecycleAutomations, 1000 * 60).unref?.();
  setInterval(runMarketingWeeklyReportAutomation, 1000 * 60 * 60 * 6).unref?.();
  setTimeout(runMarketingWeeklyReportAutomation, 1000 * 60 * 2).unref?.();
}

async function handleApi(req, res, url) {
  const method = req.method || 'GET';

  if (method === 'GET' && url.pathname === '/api/health') {
    json(res, 200, { ok: true });
    return;
  }

  if (!DATABASE_URL) {
    json(res, 500, {
      error: 'Banco local não configurado.',
      detail: 'Preencha DATABASE_URL no arquivo .env.'
    });
    return;
  }

  enforceRateLimit(req, method, url.pathname);
  enforceAuthenticatedRequestOrigin(req, method);

  if (method === 'GET' && url.pathname === '/api/portal/plans') {
    json(res, 200, await listPortalPlans());
    return;
  }

  if (method === 'POST' && url.pathname === '/api/analytics/access') {
    const result = await recordAccessEvent(req, await readJson(req));
    json(res, 202, { ok: true }, result.attribution ? { 'Set-Cookie': marketingAttributionCookie(req, result.attribution) } : {});
    return;
  }

  if (method === 'POST' && url.pathname === '/api/analytics/funnel') {
    await recordPublicMarketingEvent(req, await readJson(req));
    json(res, 202, { ok: true });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/experiments/assignment') {
    json(res, 200, await assignPublicMarketingExperiment(req, url.searchParams.get('surface') || 'home'));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/experiments/event') {
    await recordPublicExperimentEvent(req, await readJson(req));
    json(res, 202, { ok: true });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/portal/slug') {
    json(res, 200, await checkPortalSlug(url.searchParams.get('slug') || ''));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/portal/signup') {
    const result = await createPortalSignup(req, await readJson(req));
    const headers = result.sessionId ? { 'Set-Cookie': sessionCookie(ADMIN_COOKIE, result.sessionId) } : {};
    json(res, 201, result.body, headers);
    return;
  }

  if (method === 'POST' && url.pathname === '/api/portal/resend-activation') {
    json(res, 200, await resendAdminActivationEmail(req, await readJson(req)));
    return;
  }

  const portalActivationMatch = url.pathname.match(/^\/api\/portal\/activate\/([a-f0-9]{32,128})$/i);
  if (portalActivationMatch) {
    if (method === 'GET') {
      json(res, 200, { activation: await getPublicAdminActivation(portalActivationMatch[1]) });
      return;
    }
    if (method === 'POST') {
      const result = await activateAdminAccount(req, portalActivationMatch[1]);
      json(res, 200, result.body, { 'Set-Cookie': sessionCookie(ADMIN_COOKIE, result.sessionId) });
      return;
    }
  }

  if (method === 'GET' && url.pathname === '/api/bootstrap') {
    const context = await resolveTenant(req, url);
    json(res, 200, await getPublicBootstrap(context.store.id, { db: context.db, tenant: context.tenant }), {
      'Cache-Control': 'public, max-age=15, stale-while-revalidate=45'
    });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/coupons/preview') {
    const context = await resolveTenant(req, url);
    json(res, 200, { coupon: await previewCoupon(req, await readJson(req), context.store.id, { db: context.db, tenant: context.tenant }) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/menu') {
    const context = await resolveTenant(req, url);
    json(res, 200, { categories: await getMenu(false, context.store.id, { db: context.db, tenant: context.tenant }) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/store') {
    const context = await resolveTenant(req, url);
    json(res, 200, { store: publicStore(await getStoreSettings(context.store.id, { db: context.db, tenant: context.tenant })) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/tables/resolve') {
    const context = await resolveTenant(req, url);
    json(res, 200, { table: await resolveDiningTable(url.searchParams.get('table') || url.searchParams.get('mesa'), context.store.id, { db: context.db, tenant: context.tenant }) });
    return;
  }

  if (method === 'POST' && (url.pathname === '/api/orders' || url.pathname === '/api/orders/checkout')) {
    const context = await resolveTenant(req, url);
    json(res, 201, await createOrder(req, await readJson(req), { storeId: context.store.id, db: context.db, tenant: context.tenant }));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/payments/order') {
    const context = await resolveTenant(req, url).catch(() => ({ db: dbRequest, tenant: null }));
    json(res, 200, await publicPaymentStatus(url.searchParams.get('code') || url.searchParams.get('order'), { db: context.db, tenant: context.tenant, accessToken: url.searchParams.get('token') || '' }));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/payments/regenerate-pix') {
    const context = await resolveTenant(req, url).catch(() => ({ db: dbRequest, tenant: null }));
    json(res, 200, await regeneratePixPayment(await readJson(req), { db: context.db, tenant: context.tenant }));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/payments/webhook') {
    const payload = await readJson(req);
    json(res, 200, await receivePaymentWebhook(payload, {
      provider: url.searchParams.get('provider') || '',
      webhookSecret: req.headers['x-webhook-secret'] || req.headers['x-abacatepay-secret'] || ''
    }));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/integrations/evolution/webhook') {
    json(res, 200, await receiveEvolutionWebhook(req, await readJson(req)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/customer/register') {
    const context = await resolveTenant(req, url);
    const result = await registerCustomer(await readJson(req), context.store.id, { db: context.db, tenant: context.tenant });
    json(res, 201, result.body, { 'Set-Cookie': sessionCookie(CUSTOMER_COOKIE, result.sessionId) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/customer/login') {
    const context = await resolveTenant(req, url);
    const result = await loginCustomer(await readJson(req), context.store.id, { db: context.db, tenant: context.tenant });
    json(res, 200, result.body, { 'Set-Cookie': sessionCookie(CUSTOMER_COOKIE, result.sessionId) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/customer/reset-password') {
    const context = await resolveTenant(req, url);
    await resetCustomerPassword(await readJson(req), context.store.id, { db: context.db, tenant: context.tenant });
    json(res, 200, { ok: true });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/customer/logout') {
    const cookies = parseCookies(req);
    await deleteSession(cookies[CUSTOMER_COOKIE]);
    json(res, 200, { ok: true }, { 'Set-Cookie': clearCookie(CUSTOMER_COOKIE) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/customer/me') {
    const customer = await requireCustomer(req, res);
    if (!customer) return;
    const context = await resolveTenant(req, url);
    json(res, 200, { customer: await getCustomerProfile(customer.id, context.store.id, { db: context.db, tenant: context.tenant }) });
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/customer/me') {
    const customer = await requireCustomer(req, res);
    if (!customer) return;
    const context = await resolveTenant(req, url);
    json(res, 200, { customer: await updateCustomerProfile(customer.id, await readJson(req), context.store.id, { db: context.db, tenant: context.tenant }) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/customer/orders') {
    const customer = await requireCustomer(req, res);
    if (!customer) return;
    const context = await resolveTenant(req, url);
    json(res, 200, { orders: await listCustomerOrders(customer.id, context.store.id, { db: context.db, tenant: context.tenant }) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/customer/addresses') {
    const customer = await requireCustomer(req, res);
    if (!customer) return;
    const context = await resolveTenant(req, url);
    json(res, 201, { customer: await createCustomerAddressByOwner(customer.id, await readJson(req), context.store.id, { db: context.db, tenant: context.tenant }) });
    return;
  }

  const customerAddressMatch = url.pathname.match(/^\/api\/customer\/addresses\/([a-f0-9-]+)$/i);
  if (customerAddressMatch) {
    const customer = await requireCustomer(req, res);
    if (!customer) return;
    const context = await resolveTenant(req, url);
    if (method === 'PUT' || method === 'PATCH') {
      json(res, 200, { customer: await updateCustomerAddressByOwner(customer.id, customerAddressMatch[1], await readJson(req), context.store.id, { db: context.db, tenant: context.tenant }) });
      return;
    }
    if (method === 'DELETE') {
      json(res, 200, { customer: await deleteCustomerAddressByOwner(customer.id, customerAddressMatch[1], context.store.id, { db: context.db, tenant: context.tenant }) });
      return;
    }
  }

  if (method === 'GET' && url.pathname === '/api/admin/setup-status') {
    const hasAdmin = await hasAdminUser();
    json(res, 200, { has_admin: hasAdmin || !ADMIN_SETUP_ENABLED, setup_enabled: ADMIN_SETUP_ENABLED });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/setup') {
    if (!ADMIN_SETUP_ENABLED) throw httpError(403, 'Criação pública de admin desativada neste ambiente.');
    const result = await setupFirstAdmin(await readJson(req));
    await audit('admin.setup.create', {
      req,
      actor_admin_id: result.body?.admin?.id || null,
      company_id: result.body?.admin?.company_id || null,
      store_id: result.body?.admin?.store_id || null,
      entity_type: 'admin_user',
      entity_id: result.body?.admin?.id || null,
      severity: 'warning',
      after_data: { email: result.body?.admin?.email || null }
    });
    json(res, 201, result.body, { 'Set-Cookie': sessionCookie(ADMIN_COOKIE, result.sessionId) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/login') {
    const result = await loginAdmin(await readJson(req));
    if (result.requiresTwoFactor) {
      await audit('admin.login.2fa_requested', {
        req, actor_admin_id: result.adminId, entity_type: 'admin_user', entity_id: result.adminId,
        after_data: { email: result.email }
      });
      json(res, 202, { requires_2fa: true, challenge: result.challenge, expires_in: 600, email_hint: maskEmailOrToken(result.email) });
      return;
    }
    await audit('admin.login.success', {
      req,
      actor_admin_id: result.body?.admin?.id || null,
      company_id: result.body?.admin?.company_id || null,
      store_id: result.body?.admin?.store_id || null,
      entity_type: 'admin_user',
      entity_id: result.body?.admin?.id || null,
      after_data: { email: result.body?.admin?.email || null }
    });
    json(res, 200, result.body, { 'Set-Cookie': sessionCookie(ADMIN_COOKIE, result.sessionId) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/login/2fa') {
    const result = await verifyAdminTwoFactorLogin(await readJson(req));
    await audit('admin.login.2fa_success', {
      req, actor_admin_id: result.body?.admin?.id || null, entity_type: 'admin_user', entity_id: result.body?.admin?.id || null,
      after_data: { email: result.body?.admin?.email || null }
    });
    json(res, 200, result.body, { 'Set-Cookie': sessionCookie(ADMIN_COOKIE, result.sessionId) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/portal/recover-password') {
    const body = await readJson(req);
    await requestAdminPasswordRecovery(req, body);
    json(res, 200, { ok: true, message: 'Se o e-mail existir, enviaremos as instruções de recuperação. Confira também spam, lixo eletrônico e a aba Promoções.' });
    return;
  }

  const portalPasswordResetMatch = url.pathname.match(/^\/api\/portal\/password-reset\/([a-f0-9]{32,128})$/i);
  if (portalPasswordResetMatch && method === 'GET') {
    json(res, 200, { reset: await getPublicAdminPasswordReset(portalPasswordResetMatch[1]) });
    return;
  }

  if (portalPasswordResetMatch && method === 'POST') {
    const result = await resetAdminPassword(req, portalPasswordResetMatch[1], await readJson(req));
    json(res, 200, { ok: true, message: 'Senha redefinida com sucesso.', admin: result.body?.admin || null }, {
      'Set-Cookie': sessionCookie(ADMIN_COOKIE, result.sessionId)
    });
    return;
  }

  const portalInviteMatch = url.pathname.match(/^\/api\/portal\/invitations\/([a-f0-9]{32,128})$/i);
  if (portalInviteMatch && method === 'GET') {
    json(res, 200, { invitation: await getPublicInvitation(portalInviteMatch[1]) });
    return;
  }

  if (portalInviteMatch && method === 'POST') {
    const result = await acceptAdminInvitation(req, portalInviteMatch[1], await readJson(req));
    json(res, 201, result.body, { 'Set-Cookie': sessionCookie(ADMIN_COOKIE, result.sessionId) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/logout') {
    const cookies = parseCookies(req);
    await deleteSession(cookies[ADMIN_COOKIE]);
    json(res, 200, { ok: true }, { 'Set-Cookie': clearCookie(ADMIN_COOKIE) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/me') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, { admin: publicAdmin(await enrichAdminSessionData(admin)) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/stores') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, { stores: await listAdminStores(admin), active_store: admin.active_store || null });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/stores/switch') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    const nextAdmin = await switchAdminStore(req, await readJson(req), admin);
    await audit('admin.store.switch', {
      req,
      company_id: nextAdmin.company_id,
      store_id: nextAdmin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'store',
      entity_id: nextAdmin.store_id,
      before_data: { store_id: admin.store_id },
      after_data: { store_id: nextAdmin.store_id }
    });
    json(res, 200, { admin: nextAdmin });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/support/tickets') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, await listAdminSupportTickets(admin));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/support/tickets') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 201, { ticket: await createAdminSupportTicket(req, admin, await readJson(req)) });
    return;
  }

  const adminSupportMessageMatch = url.pathname.match(/^\/api\/admin\/support\/tickets\/([a-f0-9-]+)\/messages$/i);
  if (adminSupportMessageMatch && method === 'POST') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 201, { message: await createAdminSupportMessage(req, admin, adminSupportMessageMatch[1], await readJson(req)) });
    return;
  }

  const adminSupportCloseMatch = url.pathname.match(/^\/api\/admin\/support\/tickets\/([a-f0-9-]+)\/close$/i);
  if (adminSupportCloseMatch && method === 'POST') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, { ticket: await closeAdminSupportTicket(req, admin, adminSupportCloseMatch[1]) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/plan') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, await getCompanyPlanOverview(admin.company_id, admin.store_id, admin));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/referrals') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, await getAdminReferralProgram(req, admin));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/referrals/code') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, await createOrRefreshAdminReferralCode(req, admin));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/billing/checkout') {
    const admin = await requireAdminPermission(req, res, 'plan');
    if (!admin) return;
    json(res, 200, await createBillingCheckout(req, admin, await readJson(req)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/billing/addons/checkout') {
    const admin = await requireAdminAnyPermission(req, res, ['plan', 'integrations']);
    if (!admin) return;
    json(res, 200, await createAddonCheckout(req, admin, await readJson(req)));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/billing/addons') {
    const admin = await requireAdminAnyPermission(req, res, ['plan', 'integrations']);
    if (!admin) return;
    json(res, 200, await listAdminBillingAddons(admin));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/integrations/setup-overview') {
    const admin = await requireAdminPermission(req, res, 'integrations');
    if (!admin) return;
    json(res, 200, await getIntegrationSetupOverview(admin));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/integrations/setup-checkout') {
    const admin = await requireAdminPermission(req, res, 'integrations');
    if (!admin) return;
    json(res, 200, await createIntegrationSetupCheckout(req, admin, await readJson(req)));
    return;
  }

  const adminAddonSupportMatch = url.pathname.match(/^\/api\/admin\/billing\/addons\/([a-z0-9_-]+)\/support-request$/i);
  if (adminAddonSupportMatch && method === 'POST') {
    const admin = await requireAdminAnyPermission(req, res, ['plan', 'integrations']);
    if (!admin) return;
    json(res, 201, await requestAssistedAddonSupport(req, admin, adminAddonSupportMatch[1]));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/billing/webhook') {
    const payload = await readJson(req);
    const provider = url.searchParams.get('provider') || '';
    const webhookSecret = req.headers['x-webhook-secret'] || req.headers['x-abacatepay-secret'] || '';
    try {
      json(res, 200, await receiveBillingWebhook(payload, { provider, webhookSecret }));
    } catch (error) {
      await recordBillingWebhookFailure(payload, { provider, error }).catch((logError) => {
        console.error('Falha ao registrar erro de webhook de assinatura:', logError.message || logError);
      });
      throw error;
    }
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/onboarding') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, await getAdminOnboarding(admin));
    return;
  }

  if ((method === 'PUT' || method === 'PATCH') && url.pathname === '/api/admin/onboarding') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, await updateAdminOnboarding(admin, await readJson(req)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/onboarding/publish') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, await publishAdminOnboarding(req, admin));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/onboarding/reopen') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, await reopenAdminOnboarding(req, admin));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/tours') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, await listAdminGuidedTours(admin));
    return;
  }

  const adminTourMatch = url.pathname.match(/^\/api\/admin\/tours\/([a-z0-9-]+)$/i);
  if (adminTourMatch && (method === 'PUT' || method === 'PATCH')) {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, { tour: await upsertAdminGuidedTour(admin, adminTourMatch[1], await readJson(req)) });
    return;
  }

  const adminTourActionMatch = url.pathname.match(/^\/api\/admin\/tours\/([a-z0-9-]+)\/(complete|skip)$/i);
  if (adminTourActionMatch && method === 'POST') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    const tour = adminTourActionMatch[2] === 'complete'
      ? await completeAdminGuidedTour(req, admin, adminTourActionMatch[1])
      : await skipAdminGuidedTour(req, admin, adminTourActionMatch[1]);
    json(res, 200, { tour });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/plans') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await listPlatformPlans());
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/companies') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await listPlatformCompanies(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/summary') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformCommercialSummary());
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/analytics') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformCommercialAnalytics(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/alerts') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformExecutiveAlerts(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/revenue') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformExecutiveRevenue(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/conversion') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformExecutiveConversion(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/billing/summary') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, await platformBillingSummary(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/billing/plans') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, await platformBillingPlans());
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/billing/events') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, await platformBillingEvents(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/billing/subscriptions') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, await platformBillingSubscriptions(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/billing/addons') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, await platformBillingAddons(url.searchParams));
    return;
  }

  const platformCompanyDetailMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/detail$/i);
  if (platformCompanyDetailMatch && method === 'GET') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await getPlatformCompanyDetail(platformCompanyDetailMatch[1]));
    return;
  }

  const platformCompanyScoreMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/score$/i);
  if (platformCompanyScoreMatch && method === 'GET') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await getPlatformCompanyScore(platformCompanyScoreMatch[1]));
    return;
  }

  const platformCompanyTimelineMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/timeline$/i);
  if (platformCompanyTimelineMatch && method === 'GET') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await getPlatformCompanyTimelineAdvanced(platformCompanyTimelineMatch[1]));
    return;
  }

  const platformCompanyInternalStatusMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/internal-status$/i);
  if (platformCompanyInternalStatusMatch && method === 'PATCH') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, { status: await updatePlatformCompanyInternalStatus(req, platformCompanyInternalStatusMatch[1], await readJson(req), admin) });
    return;
  }

  const platformCompanyNoteMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/notes$/i);
  if (platformCompanyNoteMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { note: await createPlatformCompanyNote(platformCompanyNoteMatch[1], await readJson(req), admin, req) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/companies') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { company: await createPlatformCompany(await readJson(req), admin) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/stores') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { store: await createPlatformStore(await readJson(req), admin) });
    return;
  }

  const platformCompanyMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)$/i);
  if (platformCompanyMatch && (method === 'PUT' || method === 'PATCH')) {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, { company: await updatePlatformCompany(platformCompanyMatch[1], await readJson(req), admin) });
    return;
  }

  const platformCompanyStatusMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/status$/i);
  if (platformCompanyStatusMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.customer.suspend');
    if (!admin) return;
    json(res, 200, { company: await setPlatformCompanyStatus(req, platformCompanyStatusMatch[1], await readJson(req), admin) });
    return;
  }

  const platformCompanySuspendMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/suspend$/i);
  if (platformCompanySuspendMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.customer.suspend');
    if (!admin) return;
    json(res, 200, { company: await suspendPlatformCompany(req, platformCompanySuspendMatch[1], await readJson(req), admin) });
    return;
  }

  const platformCompanyActivateMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/activate$/i);
  if (platformCompanyActivateMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.customer.suspend');
    if (!admin) return;
    json(res, 200, { company: await activatePlatformCompany(req, platformCompanyActivateMatch[1], await readJson(req), admin) });
    return;
  }

  const platformCompanyReopenOnboardingMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/reopen-onboarding$/i);
  if (platformCompanyReopenOnboardingMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.customer.suspend');
    if (!admin) return;
    json(res, 200, await reopenPlatformCompanyOnboarding(req, platformCompanyReopenOnboardingMatch[1], await readJson(req), admin));
    return;
  }

  const platformCompanyResendBillingMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/resend-billing$/i);
  if (platformCompanyResendBillingMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, await resendPlatformCompanyBilling(req, platformCompanyResendBillingMatch[1], await readJson(req), admin));
    return;
  }

  const platformCompanyPlanMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/plan$/i);
  if (platformCompanyPlanMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, { subscription: await changePlatformCompanyPlan(platformCompanyPlanMatch[1], await readJson(req), admin) });
    return;
  }

  const platformCompanyChangePlanMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/change-plan$/i);
  if (platformCompanyChangePlanMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, { subscription: await changePlatformCompanyPlanSecure(req, platformCompanyChangePlanMatch[1], await readJson(req), admin) });
    return;
  }

  const platformCompanyCancelSubscriptionMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/cancel-subscription$/i);
  if (platformCompanyCancelSubscriptionMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, await cancelPlatformCompanySubscription(req, platformCompanyCancelSubscriptionMatch[1], await readJson(req), admin));
    return;
  }

  const platformCompanyReactivateSubscriptionMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/reactivate-subscription$/i);
  if (platformCompanyReactivateSubscriptionMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, await reactivatePlatformCompanySubscription(req, platformCompanyReactivateSubscriptionMatch[1], await readJson(req), admin));
    return;
  }

  const platformCompanyOverrideMatch = url.pathname.match(/^\/api\/platform\/companies\/([a-f0-9-]+)\/overrides$/i);
  if (platformCompanyOverrideMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { override: await createCompanyFeatureOverride(platformCompanyOverrideMatch[1], await readJson(req), admin) });
    return;
  }

  const platformOverrideMatch = url.pathname.match(/^\/api\/platform\/overrides\/([a-f0-9-]+)$/i);
  if (platformOverrideMatch && method === 'DELETE') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    await deleteCompanyFeatureOverride(platformOverrideMatch[1], admin);
    json(res, 200, { ok: true });
    return;
  }

  const platformStoreMatch = url.pathname.match(/^\/api\/platform\/stores\/([a-f0-9-]+)$/i);
  if (platformStoreMatch && (method === 'PUT' || method === 'PATCH')) {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, { store: await updatePlatformStore(platformStoreMatch[1], await readJson(req), admin) });
    return;
  }

  const platformStoreStatusMatch = url.pathname.match(/^\/api\/platform\/stores\/([a-f0-9-]+)\/status$/i);
  if (platformStoreStatusMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, { store: await setPlatformStoreStatus(platformStoreStatusMatch[1], await readJson(req), admin) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/audit') {
    const admin = await requirePlatformAdmin(req, res, 'platform.audit.view');
    if (!admin) return;
    json(res, 200, await listAuditLogs(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/health') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformOperationalHealth(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/logs') {
    const admin = await requirePlatformAdmin(req, res, 'platform.audit.view');
    if (!admin) return;
    json(res, 200, await platformOperationalLogs(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/metrics') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformOperationalMetrics(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/alerts/operational') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformOperationalAlertsEndpoint(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/smtp') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.view');
    if (!admin) return;
    json(res, 200, { smtp: await getPlatformSmtpSettings() });
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/platform/smtp') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, { smtp: await updatePlatformSmtpSettings(req, admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/smtp/test') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await sendPlatformSmtpTest(req, admin, await readJson(req)));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/whatsapp/settings') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.view');
    if (!admin) return;
    json(res, 200, { whatsapp: await getPlatformWhatsappSettings() });
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/platform/whatsapp/settings') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, { whatsapp: await updatePlatformWhatsappSettings(req, admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/whatsapp/test') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await testPlatformWhatsappSettings(req, admin));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/whatsapp/instances') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.view');
    if (!admin) return;
    json(res, 200, await listPlatformWhatsappInstances(url.searchParams));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/whatsapp/logs') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.view');
    if (!admin) return;
    json(res, 200, await listPlatformWhatsappLogs(url.searchParams));
    return;
  }

  const platformWhatsappActionMatch = url.pathname.match(/^\/api\/platform\/whatsapp\/([a-f0-9-]+)\/(reconnect|disconnect)$/i);
  if (platformWhatsappActionMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    const action = platformWhatsappActionMatch[2];
    json(res, 200, {
      whatsapp: action === 'reconnect'
        ? await reconnectPlatformWhatsappStore(req, admin, platformWhatsappActionMatch[1])
        : await disconnectPlatformWhatsappStore(req, admin, platformWhatsappActionMatch[1])
    });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/billing/config') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, { billing: await getPlatformBillingSettings() });
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/platform/billing/config') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, { billing: await updatePlatformBillingSettings(req, admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/billing/config/test') {
    const admin = await requirePlatformAdmin(req, res, 'platform.billing.manage');
    if (!admin) return;
    json(res, 200, await testPlatformBillingSettings(req, admin));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/email-templates') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.view');
    if (!admin) return;
    json(res, 200, await listPlatformEmailTemplates());
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/platform/email-templates') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await updatePlatformEmailTemplates(req, admin, await readJson(req)));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/marketing') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformMarketingWorkspace());
    return;
  }

  const marketingRepurposeMatch = url.pathname.match(/^\/api\/platform\/marketing\/content\/([a-f0-9-]+)\/repurpose$/i);
  if (method === 'POST' && marketingRepurposeMatch) {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage'); if (!admin) return;
    const source = (await dbRequest('GET', 'marketing_content_items', { select: '*', id: `eq.${cleanUuid(marketingRepurposeMatch[1])}`, limit: '1' }))[0];
    if (!source) throw httpError(404, 'Publicação não encontrada.');
    const created = [];
    for (const variant of repurposeVariants(source)) created.push(await createPlatformMarketingContent(req, admin, { ...variant, channel: source.channel || 'instagram', pillar: source.pillar || '', funnel_stage: source.funnel_stage || 'consideration', niche: source.niche || '', objective: source.objective || '', cta: source.cta || 'Testar o TáPronto', aspect_ratio: variant.format === 'story' ? '9:16' : '1:1', alt_text: variant.overlay_text, timezone: source.timezone || 'America/Sao_Paulo', hashtags: Array.isArray(source.hashtags) ? source.hashtags : [], assets: [], utm_url: source.utm_url || 'https://taprontomenu.com.br/', status: 'draft' }));
    json(res, 201, { content: created }); return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/marketing/autopilot') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await autopilotDashboard());
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/autopilot/generate') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    const data = await readJson(req);
    const run = await generateDailyAutopilotPost({ force: data.regenerate === true, createdBy: admin.id });
    await audit('platform.marketing.autopilot.generate', { req, actor_admin_id: admin.id, entity_type: 'marketing_autopilot_run', entity_id: run?.id, after_data: { provider: run?.provider, status: run?.status } });
    json(res, 201, { run });
    return;
  }

  if (method === 'PATCH' && url.pathname === '/api/platform/marketing/autopilot/settings') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    const settings = await updateAutopilotSettings(await readJson(req), admin.id);
    await audit('platform.marketing.autopilot.settings', { req, actor_admin_id: admin.id, entity_type: 'marketing_autopilot_settings', entity_id: '1', after_data: { enabled: settings.enabled, generation_time: settings.generation_time, publication_time: settings.publication_time } });
    json(res, 200, { settings });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/autopilot/approve') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    const data = await readJson(req);
    const runRows = await dbRequest('GET', 'marketing_autopilot_runs', { select: '*', id: `eq.${cleanUuid(data.run_id)}`, status: 'eq.ready', limit: '1' });
    const run = runRows[0];
    if (!run?.content_id) throw httpError(404, 'Post do dia não encontrado ou já aprovado.');
    const accountId = cleanUuid(data.social_account_id);
    const scheduledAt = data.scheduled_at ? new Date(data.scheduled_at).toISOString() : new Date(Date.now() + 15 * 60 * 1000).toISOString();
    let context = await socialContentContext(run.content_id);
    if (context.content.status === 'draft') await transitionPlatformSocialContent(req, admin, run.content_id, { status: 'review', note: 'Enviado pelo piloto automático.' });
    context = await socialContentContext(run.content_id);
    if (context.content.status === 'review') await transitionPlatformSocialContent(req, admin, run.content_id, { status: 'approved', social_account_id: accountId, scheduled_at: scheduledAt, note: 'Aprovado pelo administrador no post do dia.' });
    context = await socialContentContext(run.content_id);
    if (context.content.status === 'approved') await transitionPlatformSocialContent(req, admin, run.content_id, { status: 'scheduled', social_account_id: accountId, scheduled_at: scheduledAt });
    await dbRequest('PATCH', 'marketing_autopilot_runs', { id: `eq.${run.id}` }, { status: 'approved', updated_at: new Date().toISOString() }, ['Prefer: return=minimal']);
    json(res, 200, { ok: true, content: (await socialContentContext(run.content_id)).content });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/autopilot/select') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    const data = await readJson(req);
    const run = await selectAutopilotVersion(cleanUuid(data.run_id));
    await audit('platform.marketing.autopilot.select', { req, actor_admin_id: admin.id, entity_type: 'marketing_autopilot_run', entity_id: run.id });
    json(res, 200, { run }); return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/campaigns') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { campaign: await createPlatformMarketingCampaign(req, admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/leads') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { lead: await createPlatformMarketingLead(req, admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/leads/import') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await importPlatformMarketingLeads(req, admin, await readJson(req)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/content') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { content: await createPlatformMarketingContent(req, admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/experiments') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { experiment: await createPlatformMarketingExperiment(req, admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/pilots') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { pilot: await createPlatformMarketingPilot(req, admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/marketing/weekly-report') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, { report: await generatePlatformMarketingWeeklyReport(req, admin) });
    return;
  }

  const platformMarketingItemMatch = url.pathname.match(/^\/api\/platform\/marketing\/(campaigns|leads|content|experiments)\/([a-f0-9-]+)$/i);
  if (platformMarketingItemMatch && method === 'PATCH') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, { item: await updatePlatformMarketingItem(req, admin, platformMarketingItemMatch[1], platformMarketingItemMatch[2], await readJson(req)) });
    return;
  }

  const platformPilotMatch = url.pathname.match(/^\/api\/platform\/marketing\/pilots\/([a-f0-9-]+)$/i);
  if (platformPilotMatch && method === 'PATCH') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, { pilot: await updatePlatformMarketingPilot(req, admin, platformPilotMatch[1], await readJson(req)) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/social') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await platformSocialWorkspace());
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/social/connect') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await beginPlatformSocialConnection(req, admin));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/social/oauth/callback') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    await completePlatformSocialConnection(req, admin, url.searchParams);
    res.writeHead(302, { Location: `${platformBaseUrl()}/?view=marketing&social=connected`, 'Cache-Control': 'no-store' }); res.end();
    return;
  }

  const socialAccountAction = url.pathname.match(/^\/api\/platform\/social\/accounts\/([a-f0-9-]+)\/(test|pause|resume|disconnect)$/i);
  if (socialAccountAction && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await platformSocialAccountAction(req, admin, socialAccountAction[1], socialAccountAction[2], await readJson(req)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/social/assets') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 201, { asset: await uploadPlatformSocialAsset(req, admin, await readJson(req)) });
    return;
  }

  const socialContentAssetMatch = url.pathname.match(/^\/api\/platform\/social\/content\/([a-f0-9-]+)\/assets$/i);
  if (socialContentAssetMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await attachPlatformSocialAsset(req, admin, socialContentAssetMatch[1], await readJson(req)));
    return;
  }

  const socialContentActionMatch = url.pathname.match(/^\/api\/platform\/social\/content\/([a-f0-9-]+)\/(transition|publish-now)$/i);
  if (socialContentActionMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    const data = await readJson(req);
    const result = socialContentActionMatch[2] === 'publish-now'
      ? await publishPlatformSocialContentNow(req, admin, socialContentActionMatch[1], data)
      : await transitionPlatformSocialContent(req, admin, socialContentActionMatch[1], data);
    json(res, 200, result);
    return;
  }

  const socialPublicationActionMatch = url.pathname.match(/^\/api\/platform\/social\/publications\/([a-f0-9-]+)\/(retry|cancel)$/i);
  if (socialPublicationActionMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await platformSocialPublicationAction(req, admin, socialPublicationActionMatch[1], socialPublicationActionMatch[2]));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/support/tickets') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, await listPlatformSupportTickets(url.searchParams));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/support/tickets') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { ticket: await createPlatformSupportTicket(req, admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/support/impersonate') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    const result = await startPlatformSupportImpersonation(req, admin, await readJson(req));
    json(res, 200, { ok: true, admin: publicAdmin(result.admin), expires_at: result.expires_at }, { 'Set-Cookie': sessionCookie(ADMIN_COOKIE, result.token) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/support/impersonate/end') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    const result = await endPlatformSupportImpersonation(req, admin);
    const headers = { 'Set-Cookie': result.restore_token ? sessionCookie(ADMIN_COOKIE, result.restore_token) : clearCookie(ADMIN_COOKIE) };
    json(res, 200, { ok: true, restored: Boolean(result.restore_token) }, headers);
    return;
  }

  const platformSupportMessageMatch = url.pathname.match(/^\/api\/platform\/support\/tickets\/([a-f0-9-]+)\/messages$/i);
  if (platformSupportMessageMatch && method === 'POST') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 201, { message: await createPlatformSupportMessage(req, admin, platformSupportMessageMatch[1], await readJson(req)) });
    return;
  }

  const platformSupportTicketMatch = url.pathname.match(/^\/api\/platform\/support\/tickets\/([a-f0-9-]+)$/i);
  if (platformSupportTicketMatch && method === 'PATCH') {
    const admin = await requirePlatformAdmin(req, res, 'platform.view');
    if (!admin) return;
    json(res, 200, { ticket: await updatePlatformSupportTicket(req, admin, platformSupportTicketMatch[1], await readJson(req)) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/backups') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.view');
    if (!admin) return;
    json(res, 200, await platformBackupStatus());
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/services/status') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.view');
    if (!admin) return;
    json(res, 200, await platformServicesStatus());
    return;
  }

  if (method === 'GET' && url.pathname === '/api/platform/services/logs') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.view');
    if (!admin) return;
    json(res, 200, await platformServicesLogs(url.searchParams));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/services/backup') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await runPlatformBackup(req, admin, await readJson(req)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/services/backup/restore') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await restorePlatformBackup(req, admin, await readJson(req)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/services/jobs/trial-cleanup') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await runPlatformTrialCleanup(req, admin, await readJson(req)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/services/log-cleanup/preview') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.view');
    if (!admin) return;
    json(res, 200, await runPlatformLogCleanup(req, admin, { apply: false }));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/services/log-cleanup') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 200, await runPlatformLogCleanup(req, admin, { ...(await readJson(req)), apply: true }));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/platform/services/app/restart') {
    const admin = await requirePlatformAdmin(req, res, 'platform.services.manage');
    if (!admin) return;
    json(res, 202, await restartPlatformApplication(req, admin, await readJson(req)));
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/admin/me') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    json(res, 200, { admin: await updateAdminAccount(admin, await readJson(req)) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/change-password') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    await changeAdminPassword(admin, await readJson(req));
    json(res, 200, { ok: true });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/account/delete') {
    const admin = await requireAdminPermission(req, res, 'account');
    if (!admin) return;
    const result = await deleteCurrentCompanyAccount(req, admin, await readJson(req));
    json(res, 200, result, { 'Set-Cookie': clearCookie(ADMIN_COOKIE) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/users') {
    const session = await requireAdminPermission(req, res, 'admin_users');
    if (!session) return;
    json(res, 200, { admins: await listAdminUsers(session) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/users') {
    const session = await requireAdminPermission(req, res, 'admin_users');
    if (!session) return;
    const created = await createAdminUser(await readJson(req), session);
    await audit('admin_user.create', {
      req,
      company_id: session.company_id,
      store_id: session.store_id,
      actor_admin_id: session.id,
      entity_type: 'admin_user',
      entity_id: created.id,
      after_data: created
    });
    json(res, 201, { admin: created });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/invitations') {
    const session = await requireAdminPermission(req, res, 'admin_users');
    if (!session) return;
    json(res, 201, { invitation: await createAdminInvitation(req, await readJson(req), session) });
    return;
  }

  const adminUserMatch = url.pathname.match(/^\/api\/admin\/users\/([a-f0-9-]+)$/i);
  if (adminUserMatch && (method === 'PUT' || method === 'PATCH')) {
    const session = await requireAdminPermission(req, res, 'admin_users');
    if (!session) return;
    const updated = await updateAdminUser(adminUserMatch[1], await readJson(req), session);
    await audit('admin_user.update', {
      req,
      company_id: session.company_id,
      store_id: session.store_id,
      actor_admin_id: session.id,
      entity_type: 'admin_user',
      entity_id: updated.id,
      after_data: updated
    });
    json(res, 200, { admin: updated });
    return;
  }

  if (adminUserMatch && method === 'DELETE') {
    const session = await requireAdminPermission(req, res, 'admin_users');
    if (!session) return;
    const deleted = await deleteAdminUser(adminUserMatch[1], session);
    await audit('admin_user.delete', {
      req,
      company_id: session.company_id,
      store_id: session.store_id,
      actor_admin_id: session.id,
      entity_type: 'admin_user',
      entity_id: deleted.id,
      before_data: deleted
    });
    json(res, 200, { ok: true });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/summary') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    const startedAt = Date.now();
    const permissions = adminPermissions(admin);
    const op = await adminOperationalOptions(admin);
    const [store, orders] = await Promise.all([
      getStoreSettings(admin.store_id, op),
      permissions.includes('orders') ? listOrders(admin.store_id, op) : Promise.resolve([])
    ]);
    const elapsed = Date.now() - startedAt;
    if (elapsed > 1200) {
      console.warn(`Resumo admin lento: ${elapsed}ms`);
    }
    json(res, 200, {
      store,
      orders,
      permissions,
      plan_access: admin.company_id ? await getCompanyPlanAccess(admin.company_id) : {}
    });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/menu-data') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    const permissions = adminPermissions(admin);
    if (!permissions.includes('menu') && !permissions.includes('tables') && !permissions.includes('promotions')) {
      throw httpError(403, 'Sem permissão para acessar o cardápio.');
    }
    const op = await adminOperationalOptions(admin);
    json(res, 200, { categories: await getMenu(true, admin.store_id, op) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/customers') {
    const admin = await requireAdminPermission(req, res, 'customers');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    json(res, 200, { customers: await listCustomers(admin.store_id, op) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/promotions') {
    const admin = await requireAdminPermission(req, res, 'promotions');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    json(res, 200, { promotions: await listPromotions(admin.store_id, op) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/store') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    json(res, 200, { store: adminStore(await getStoreSettings(admin.store_id, op)) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/tables') {
    const admin = await requireAdminPermission(req, res, 'tables');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    json(res, 200, await listAdminTablesData(admin.store_id, op));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/tables') {
    const admin = await requireAdminPermission(req, res, 'tables');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    await assertCompanyUsageLimit(admin, 'tables', 'dining_tables');
    const table = await createDiningTable(await readJson(req), admin.store_id, op);
    await recordCompanyUsage(admin, 'tables', 'dining_tables');
    clearAdminTablesCache();
    json(res, 201, { table });
    return;
  }

  const tableMatch = url.pathname.match(/^\/api\/admin\/tables\/([a-f0-9-]+)$/i);
  if (tableMatch) {
    const admin = await requireAdminPermission(req, res, 'tables');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    if (method === 'PATCH' || method === 'PUT') {
      const table = await updateDiningTable(tableMatch[1], await readJson(req), admin.store_id, op);
      clearAdminTablesCache();
      json(res, 200, { table });
      return;
    }
    if (method === 'DELETE') {
      await deleteDiningTable(tableMatch[1], admin.store_id, op);
      clearAdminTablesCache();
      json(res, 200, { ok: true });
      return;
    }
  }

  if (method === 'POST' && url.pathname === '/api/admin/tabs') {
    const admin = await requireAdminPermission(req, res, 'tables');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const tab = await openCustomerTab(await readJson(req), admin.store_id, op);
    clearAdminTablesCache();
    json(res, 201, { tab });
    return;
  }

  const tabItemMatch = url.pathname.match(/^\/api\/admin\/tabs\/([a-f0-9-]+)\/items$/i);
  if (tabItemMatch && method === 'POST') {
    const admin = await requireAdminPermission(req, res, 'tables');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const result = await addItemToCustomerTab(req, tabItemMatch[1], await readJson(req), admin.store_id, op);
    clearAdminTablesCache();
    json(res, 201, result);
    return;
  }

  const tabMatch = url.pathname.match(/^\/api\/admin\/tabs\/([a-f0-9-]+)\/(close|transfer)$/i);
  if (tabMatch) {
    const admin = await requireAdminPermission(req, res, 'tables');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const body = await readJson(req);
    const tab = tabMatch[2] === 'close'
      ? await closeCustomerTab(tabMatch[1], body, admin.store_id, op)
      : await transferCustomerTab(tabMatch[1], body, admin.store_id, op);
    clearAdminTablesCache();
    json(res, 200, { tab });
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/admin/store') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const result = await updateStoreSettings(await readJson(req), admin.store_id, op);
    await audit('store_settings.update', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'store_settings',
      entity_id: admin.store_id,
      after_data: Array.isArray(result) ? result[0] : result
    });
    clearStoreSettingsCache();
    json(res, 200, { store: adminStore(Array.isArray(result) ? result[0] : result) });
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/admin/loyalty') {
    const admin = await requireAdminPermission(req, res, 'promotions');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const store = await updateLoyaltyProgram(await readJson(req), admin.store_id, op);
    await audit('loyalty.update', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'store_settings',
      entity_id: admin.store_id,
      after_data: { loyalty_program: store.loyalty_program || null }
    });
    clearStoreSettingsCache();
    json(res, 200, { store: adminStore(store) });
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/admin/print-settings') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const store = await updatePrintSettings(await readJson(req), admin.store_id, op);
    await audit('print_settings.update', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'store_settings',
      entity_id: admin.store_id,
      after_data: { print_settings: store.print_settings || null }
    });
    clearStoreSettingsCache();
    json(res, 200, { store: adminStore(store) });
    return;
  }

  if (method === 'PUT' && url.pathname === '/api/admin/integrations') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const store = await updateIntegrationSettings(await readJson(req), admin.store_id, op);
    await audit('integrations.update', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'store_settings',
      entity_id: admin.store_id,
      severity: 'warning',
      after_data: { integration_settings: store.integration_settings || null }
    });
    clearStoreSettingsCache();
    json(res, 200, { store: adminStore(store) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/integrations/test') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    json(res, 200, { result: await testIntegrations(await readJson(req), admin.store_id, op) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/integrations/payment-setup-request') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 201, await requestPaymentSetupSupport(req, admin));
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/integrations/payment-setup') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, { payment_setup: await getAdminPaymentSetupAssistance(admin) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/integrations/whatsapp') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, { whatsapp: await getAdminWhatsappIntegration(admin) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/integrations/whatsapp/connect') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, { whatsapp: await connectAdminWhatsappIntegration(req, admin) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/integrations/whatsapp/qrcode') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, { whatsapp: await refreshAdminWhatsappQrCode(admin) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/integrations/whatsapp/status') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, { whatsapp: await refreshAdminWhatsappStatus(admin) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/integrations/whatsapp/test') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, await sendAdminWhatsappTest(admin, await readJson(req)));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/integrations/whatsapp/disconnect') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, { whatsapp: await disconnectAdminWhatsappIntegration(req, admin) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/domains') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, { domains: await listStoreDomains(admin.store_id) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/domains') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    const domain = await createStoreDomain(await readJson(req), admin);
    json(res, 201, { domain });
    return;
  }

  const adminDomainMatch = url.pathname.match(/^\/api\/admin\/domains\/([a-f0-9-]+)$/i);
  if (adminDomainMatch && method === 'DELETE') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    await deleteStoreDomain(adminDomainMatch[1], admin);
    json(res, 200, { ok: true });
    return;
  }

  const adminDomainVerifyMatch = url.pathname.match(/^\/api\/admin\/domains\/([a-f0-9-]+)\/verify$/i);
  if (adminDomainVerifyMatch && method === 'POST') {
    const admin = await requireAdminPermission(req, res, 'store');
    if (!admin) return;
    json(res, 200, { domain: await verifyStoreDomain(adminDomainVerifyMatch[1], admin) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/operation/start') {
    const admin = await requireAdminPermission(req, res, 'operation');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const queue = await clearOrderQueue({ mode: 'close_open', storeId: admin.store_id }, op);
    const store = await setStoreOpen(true, admin.store_id, op);
    await audit('operation.start', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'store',
      entity_id: admin.store_id,
      after_data: { queue }
    });
    clearStoreSettingsCache();
    json(res, 200, { store, queue });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/operation/stop') {
    const admin = await requireAdminPermission(req, res, 'operation');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const store = await setStoreOpen(false, admin.store_id, op);
    await audit('operation.stop', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'store',
      entity_id: admin.store_id
    });
    clearStoreSettingsCache();
    json(res, 200, { store });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/orders') {
    const admin = await requireAdminPermission(req, res, 'orders');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    json(res, 200, { orders: await listOrders(admin.store_id, op) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/print-logs') {
    const admin = await requireAdminPermission(req, res, 'orders');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const body = await readJson(req);
    if (body.order_id) await assertOrderBelongsToStore(body.order_id, admin.store_id, op);
    await assertPlanLimit(admin, 'print_kitchen', 'print_jobs');
    const log = await createPrintLog({ ...body, store_id: admin.store_id }, op);
    await recordCompanyUsage({ ...admin, entity_type: 'order', entity_id: body.order_id || null }, 'print_kitchen', 'print_jobs');
    await audit('order.print', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'order',
      entity_id: body.order_id || null,
      after_data: { print_log_id: log?.id || null, print_type: body.print_type || body.type || null }
    });
    json(res, 201, { log });
    return;
  }

  const orderStatusMatch = url.pathname.match(/^\/api\/admin\/orders\/([a-f0-9-]+)\/status$/i);
  if (orderStatusMatch && method === 'PATCH') {
    const admin = await requireAdminPermission(req, res, 'orders');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const body = await readJson(req);
    if (!orderStatuses.has(body.status)) {
      throw httpError(422, 'Status de pedido inválido.');
    }
    const patch = { status: body.status };
    if (body.status === 'cancelled') {
      patch.financial_status = 'cancelled';
      patch.payment_access_expires_at = new Date().toISOString();
    }
    const updated = await op.db('PATCH', 'orders', {
      id: `eq.${orderStatusMatch[1]}`,
      ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
    }, patch, ['Prefer: return=representation']);
    if (!updated[0]) throw httpError(404, 'Pedido não encontrado nesta loja.');
    if (body.status === 'cancelled') await updatePromotionRedemptionStatus(updated[0], 'released', op.db);
    clearAdminOrdersCache(admin.store_id);
    let whatsappLog = null;
    try {
      whatsappLog = await sendOrderStatusWhatsapp(orderStatusMatch[1], body.status, { manual: false, ...op });
    } catch (error) {
      console.error('Falha ao enviar WhatsApp de status:', error.message || error);
      whatsappLog = {
        delivery_status: 'skipped',
        order_status: body.status,
        error_message: error.message || 'Não foi possível enviar o WhatsApp automático.'
      };
    }
    await audit('order.status.update', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'order',
      entity_id: updated[0].id,
      after_data: { status: body.status, financial_status: patch.financial_status || updated[0].financial_status }
    });
    json(res, 200, { order: updated[0] || null, whatsapp_log: whatsappLog });
    return;
  }

  const orderWhatsappMatch = url.pathname.match(/^\/api\/admin\/orders\/([a-f0-9-]+)\/whatsapp$/i);
  if (orderWhatsappMatch && method === 'POST') {
    const admin = await requireAdminPermission(req, res, 'orders');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    await assertOrderBelongsToStore(orderWhatsappMatch[1], admin.store_id, op);
    const body = await readJson(req);
    const manual = body.manual !== false;
    const log = await sendOrderStatusWhatsapp(orderWhatsappMatch[1], body.status, { manual, ...op });
    await audit('order.whatsapp.resend', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'order',
      entity_id: orderWhatsappMatch[1],
      after_data: { status: body.status, log_id: log?.id || null }
    });
    json(res, 200, { log });
    return;
  }

  const orderRefundMatch = url.pathname.match(/^\/api\/admin\/orders\/([a-f0-9-]+)\/refund$/i);
  if (orderRefundMatch && method === 'POST') {
    const admin = await requireAdminPermission(req, res, 'orders');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    await assertOrderBelongsToStore(orderRefundMatch[1], admin.store_id, op);
    const order = await refundOrderPayment(orderRefundMatch[1], await readJson(req), op);
    await audit('order.payment.refund', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'order',
      entity_id: orderRefundMatch[1],
      severity: 'warning',
      after_data: { financial_status: order.financial_status, total: order.total }
    });
    json(res, 200, { order });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/payments/reconcile') {
    const admin = await requireAdminPermission(req, res, 'reports');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    json(res, 200, await reconcileOnlinePayments({ ...(await readJson(req)), storeId: admin.store_id }, op));
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/orders/clear-queue') {
    const admin = await requireAdminPermission(req, res, 'operation');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const result = await clearOrderQueue({ ...(await readJson(req)), storeId: admin.store_id }, op);
    await audit('orders.clear_queue', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'orders',
      severity: 'warning',
      after_data: result
    });
    json(res, 200, result);
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/reports/daily') {
    const admin = await requireAdminPermission(req, res, 'reports');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const date = cleanText(url.searchParams.get('date') || '');
    const report = await dailyOrderReport(date, admin.store_id, op);
    json(res, 200, { report: await applyReportPlanAccess(report, admin.company_id) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/reports/range') {
    const admin = await requireAdminPermission(req, res, 'reports');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const report = await rangeOrderReport({
        days: url.searchParams.get('days'),
        start: url.searchParams.get('start'),
        end: url.searchParams.get('end'),
        storeId: admin.store_id,
        ...op
      });
    json(res, 200, { report: await applyReportPlanAccess(report, admin.company_id) });
    return;
  }

  if (method === 'GET' && url.pathname === '/api/admin/customers') {
    const admin = await requireAdminPermission(req, res, 'customers');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    json(res, 200, { customers: await listCustomers(admin.store_id, op) });
    return;
  }

  const adminCustomerMatch = url.pathname.match(/^\/api\/admin\/customers\/([a-f0-9-]+)$/i);
  if (adminCustomerMatch && (method === 'PUT' || method === 'PATCH')) {
    const admin = await requireAdminPermission(req, res, 'customers');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const customer = await updateCustomerByAdmin(adminCustomerMatch[1], await readJson(req), admin.store_id, op);
    await audit('customer.update', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'customer',
      entity_id: adminCustomerMatch[1],
      after_data: { id: customer.id, phone: customer.phone, email: customer.email || null }
    });
    clearAdminCustomersCache();
    json(res, 200, { customer });
    return;
  }

  if (adminCustomerMatch && method === 'DELETE') {
    const admin = await requireAdminPermission(req, res, 'customers');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    await deleteCustomerByAdmin(adminCustomerMatch[1], admin.store_id, op);
    await audit('customer.delete', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'customer',
      entity_id: adminCustomerMatch[1],
      severity: 'warning'
    });
    clearAdminCustomersCache();
    json(res, 200, { ok: true });
    return;
  }

  const adminCustomerAddressCreateMatch = url.pathname.match(/^\/api\/admin\/customers\/([a-f0-9-]+)\/addresses$/i);
  if (adminCustomerAddressCreateMatch && method === 'POST') {
    const admin = await requireAdminPermission(req, res, 'customers');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const customer = await createCustomerAddressByAdmin(adminCustomerAddressCreateMatch[1], await readJson(req), admin.store_id, op);
    clearAdminCustomersCache();
    json(res, 201, { customer });
    return;
  }

  const adminCustomerAddressMatch = url.pathname.match(/^\/api\/admin\/customers\/([a-f0-9-]+)\/addresses\/([a-f0-9-]+)$/i);
  if (adminCustomerAddressMatch) {
    const admin = await requireAdminPermission(req, res, 'customers');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    if (method === 'PUT' || method === 'PATCH') {
      const customer = await updateCustomerAddressByAdmin(adminCustomerAddressMatch[1], adminCustomerAddressMatch[2], await readJson(req), admin.store_id, op);
      clearAdminCustomersCache();
      json(res, 200, { customer });
      return;
    }
    if (method === 'DELETE') {
      const customer = await deleteCustomerAddressByAdmin(adminCustomerAddressMatch[1], adminCustomerAddressMatch[2], admin.store_id, op);
      clearAdminCustomersCache();
      json(res, 200, { customer });
      return;
    }
  }

  if (method === 'GET' && url.pathname === '/api/admin/promotions') {
    const admin = await requireAdminPermission(req, res, 'promotions');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    json(res, 200, { promotions: await listPromotions(admin.store_id, op) });
    return;
  }

  if (method === 'POST' && url.pathname === '/api/admin/promotions') {
    const admin = await requireAdminPermission(req, res, 'promotions');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    await assertCompanyUsageLimit(admin, 'promotions', 'promotions');
    const [promotion] = await op.db('POST', 'promotions', {}, {
      ...sanitizePromotion(await readJson(req), true),
      store_id: admin.store_id || null
    }, ['Prefer: return=representation']);
    await recordCompanyUsage(admin, 'promotions', 'promotions');
    await audit('promotion.create', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'promotion',
      entity_id: promotion.id,
      after_data: promotion
    });
    clearAdminPromotionsCache();
    json(res, 201, { promotion });
    return;
  }

  const promotionMatch = url.pathname.match(/^\/api\/admin\/promotions\/([a-f0-9-]+)$/i);
  if (promotionMatch) {
    const admin = await requireAdminPermission(req, res, 'promotions');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    if (method === 'PUT' || method === 'PATCH') {
      const [promotion] = await op.db('PATCH', 'promotions', {
        id: `eq.${promotionMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, sanitizePromotion(await readJson(req), false), ['Prefer: return=representation']);
      if (!promotion) throw httpError(404, 'Promoção não encontrada nesta loja.');
      clearAdminPromotionsCache();
      json(res, 200, { promotion });
      return;
    }
    if (method === 'DELETE') {
      await op.db('DELETE', 'promotions', {
        id: `eq.${promotionMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, undefined, ['Prefer: return=minimal']);
      clearAdminPromotionsCache();
      json(res, 200, { ok: true });
      return;
    }
  }

  if (method === 'POST' && url.pathname === '/api/admin/uploads') {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
    if (!adminCan(admin, 'menu') && !adminCan(admin, 'store')) {
      json(res, 403, { error: 'Sua conta não tem permissão para enviar imagens.' });
      return;
    }
    json(res, 201, await uploadImage(await readJson(req)));
    return;
  }

  if (url.pathname === '/api/categories' && method === 'POST') {
    const admin = await requireAdminPermission(req, res, 'menu');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    await assertPlanLimit(admin, 'menu_categories', 'menu_categories');
    const result = await op.db('POST', 'menu_categories', {}, {
      ...sanitizeCategory(await readJson(req), true),
      store_id: admin.store_id || null
    }, ['Prefer: return=representation']);
    await audit('menu_category.create', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'menu_category',
      entity_id: result[0]?.id || null,
      after_data: result[0] || null
    });
    await recordCompanyUsage(admin, 'menu_categories', 'menu_categories');
    clearMenuCache();
    json(res, 201, result);
    return;
  }

  const categoryMatch = url.pathname.match(/^\/api\/categories\/([a-f0-9-]+)$/i);
  if (categoryMatch) {
    const admin = await requireAdminPermission(req, res, 'menu');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    if (method === 'PUT' || method === 'PATCH') {
      const result = await op.db('PATCH', 'menu_categories', {
        id: `eq.${categoryMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, sanitizeCategory(await readJson(req), false), ['Prefer: return=representation']);
      clearMenuCache();
      json(res, 200, result);
      return;
    }
    if (method === 'DELETE') {
      const result = await op.db('DELETE', 'menu_categories', {
        id: `eq.${categoryMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, undefined, ['Prefer: return=representation']);
      clearMenuCache();
      json(res, 200, result);
      return;
    }
  }

  if (url.pathname === '/api/items' && method === 'POST') {
    const admin = await requireAdminPermission(req, res, 'menu');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    await assertCompanyUsageLimit(admin, 'digital_menu', 'menu_items');
    const result = await op.db('POST', 'menu_items', {}, {
      ...sanitizeItem(await readJson(req), true),
      store_id: admin.store_id || null
    }, ['Prefer: return=representation']);
    await recordCompanyUsage(admin, 'digital_menu', 'menu_items');
    await audit('menu_item.create', {
      req,
      company_id: admin.company_id,
      store_id: admin.store_id,
      actor_admin_id: admin.id,
      entity_type: 'menu_item',
      entity_id: result[0]?.id || null,
      after_data: result[0] || null
    });
    await recordMarketingMilestone('first_product_created', {
      companyId: admin.company_id,
      storeId: admin.store_id,
      idempotencyKey: `first_product_created:${admin.store_id}`,
      properties: { source: 'admin' }
    });
    clearMenuCache();
    json(res, 201, result);
    return;
  }

  const itemMatch = url.pathname.match(/^\/api\/items\/([a-f0-9-]+)$/i);
  if (itemMatch) {
    const admin = await requireAdminPermission(req, res, 'menu');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    if (method === 'PUT' || method === 'PATCH') {
      const result = await op.db('PATCH', 'menu_items', {
        id: `eq.${itemMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, sanitizeItem(await readJson(req), false), ['Prefer: return=representation']);
      clearMenuCache();
      json(res, 200, result);
      return;
    }
    if (method === 'DELETE') {
      const result = await op.db('DELETE', 'menu_items', {
        id: `eq.${itemMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, undefined, ['Prefer: return=representation']);
      clearMenuCache();
      json(res, 200, result);
      return;
    }
  }

  const modifierGroupMatch = url.pathname.match(/^\/api\/items\/([a-f0-9-]+)\/modifier-groups$/i);
  if (modifierGroupMatch && method === 'POST') {
    const admin = await requireAdminPermission(req, res, 'menu');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const payload = sanitizeModifierGroup(await readJson(req), true);
    await ensureUniqueModifierGroupName(modifierGroupMatch[1], payload.name, op);
    const result = await op.db('POST', 'menu_modifier_groups', {}, {
      ...payload,
      store_id: admin.store_id || null,
      menu_item_id: modifierGroupMatch[1]
    }, ['Prefer: return=representation']);
    clearMenuCache();
    json(res, 201, result);
    return;
  }

  const modifierGroupIdMatch = url.pathname.match(/^\/api\/modifier-groups\/([a-f0-9-]+)$/i);
  if (modifierGroupIdMatch) {
    const admin = await requireAdminPermission(req, res, 'menu');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    if (method === 'PUT' || method === 'PATCH') {
      const result = await op.db('PATCH', 'menu_modifier_groups', {
        id: `eq.${modifierGroupIdMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, sanitizeModifierGroup(await readJson(req), false), ['Prefer: return=representation']);
      clearMenuCache();
      json(res, 200, result);
      return;
    }
    if (method === 'DELETE') {
      const result = await op.db('DELETE', 'menu_modifier_groups', {
        id: `eq.${modifierGroupIdMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, undefined, ['Prefer: return=representation']);
      clearMenuCache();
      json(res, 200, result);
      return;
    }
  }

  const modifierCreateMatch = url.pathname.match(/^\/api\/modifier-groups\/([a-f0-9-]+)\/modifiers$/i);
  if (modifierCreateMatch && method === 'POST') {
    const admin = await requireAdminPermission(req, res, 'menu');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    const payload = sanitizeModifier(await readJson(req), true);
    await ensureUniqueModifierName(modifierCreateMatch[1], payload.name, op);
    const result = await op.db('POST', 'menu_modifiers', {}, {
      ...payload,
      store_id: admin.store_id || null,
      group_id: modifierCreateMatch[1]
    }, ['Prefer: return=representation']);
    clearMenuCache();
    json(res, 201, result);
    return;
  }

  const modifierMatch = url.pathname.match(/^\/api\/modifiers\/([a-f0-9-]+)$/i);
  if (modifierMatch) {
    const admin = await requireAdminPermission(req, res, 'menu');
    if (!admin) return;
    const op = await adminOperationalOptions(admin);
    if (method === 'PUT' || method === 'PATCH') {
      const result = await op.db('PATCH', 'menu_modifiers', {
        id: `eq.${modifierMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, sanitizeModifier(await readJson(req), false), ['Prefer: return=representation']);
      clearMenuCache();
      json(res, 200, result);
      return;
    }
    if (method === 'DELETE') {
      const result = await op.db('DELETE', 'menu_modifiers', {
        id: `eq.${modifierMatch[1]}`,
        ...(admin.store_id ? { store_id: `eq.${admin.store_id}` } : {})
      }, undefined, ['Prefer: return=representation']);
      clearMenuCache();
      json(res, 200, result);
      return;
    }
  }

  json(res, 404, { error: 'Rota não encontrada.' });
}

async function hasAdminUser() {
  const rows = await dbRequest('GET', 'admin_users', {
    select: 'id',
    limit: '1'
  });
  return rows.length > 0;
}

async function setupFirstAdmin(data) {
  if (await hasAdminUser()) {
    throw httpError(409, 'A primeira conta admin já foi criada.');
  }

  const admin = sanitizeAdminUser(data);
  const password = validatePassword(data.password);
  const [created] = await dbRequest('POST', 'admin_users', {}, {
    ...admin,
    password_hash: hashPassword(password),
    role: 'owner',
    is_active: true
  }, ['Prefer: return=representation']);
  await ensureAdminDefaultStoreAccess(created);
  clearAdminUsersCache();

  return createAdminSession(created);
}

async function ensureAdminDefaultStoreAccess(admin) {
  const store = await getDefaultStore();
  if (!store?.id) return;
  const access = await getAdminStoreAccess(admin);
  if (!access.length && normalizeAdminRole(admin.role) !== 'superadmin') {
    await ensureAdminDefaultStoreAccess(admin);
    clearAdminStoreAccessCache(admin.id);
  }

  await dbRequest('PATCH', 'admin_users', { id: `eq.${admin.id}` }, {
    company_id: store.company_id
  }, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('POST', 'admin_user_store_access', {}, {
    admin_user_id: admin.id,
    company_id: store.company_id,
    store_id: store.id,
    role: normalizeAdminRole(admin.role),
    permissions: [],
    is_active: true
  }, ['Prefer: return=minimal']).catch(() => {});
}

async function loginAdmin(data) {
  const email = cleanEmail(data.email);
  const password = String(data.password || '');

  if (!email || !password) throw httpError(422, 'Informe e-mail e senha.');

  const rows = await dbRequest('GET', 'admin_users', {
    select: '*',
    email: `eq.${email}`,
    limit: '1'
  });

  const admin = rows[0];
  if (!admin) {
    throw httpError(404, 'Não existe uma conta administrativa com este e-mail.');
  }
  if (admin.is_active === false) {
    const pendingActivation = await hasPendingAdminActivation(admin.id).catch(() => false);
    throw httpError(403, pendingActivation
      ? 'Sua conta ainda não foi ativada. Confira seu e-mail e clique no link de ativação. Verifique também spam, lixo eletrônico e a aba Promoções.'
      : 'Esta conta administrativa está desativada.');
  }
  if (!verifyPassword(password, admin.password_hash)) {
    throw httpError(401, 'Senha incorreta.');
  }

  if (ADMIN_2FA_REQUIRED && normalizeAdminRole(admin.role) === 'superadmin') {
    const challenge = await createAdminTwoFactorChallenge(admin);
    return { requiresTwoFactor: true, adminId: admin.id, email: admin.email, ...challenge };
  }

  await markAdminLogin(admin.id);

  return createAdminSession(admin);
}

async function markAdminLogin(adminId) {
  await dbRequest('PATCH', 'admin_users', { id: `eq.${cleanUuid(adminId)}` }, {
    last_login_at: new Date().toISOString()
  }, ['Prefer: return=minimal']);
}

async function createAdminTwoFactorChallenge(admin) {
  const token = randomBytes(32).toString('base64url');
  const tokenHash = createHash('sha256').update(token).digest('hex');
  const code = String(randomInt(0, 1000000)).padStart(6, '0');
  const codeHash = createHash('sha256').update(`${tokenHash}:${code}`).digest('hex');
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
  await dbRequest('DELETE', 'admin_2fa_challenges', { admin_user_id: `eq.${admin.id}` }, undefined, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('POST', 'admin_2fa_challenges', {}, {
    admin_user_id: admin.id, token_hash: tokenHash, code_hash: codeHash, expires_at: expiresAt
  }, ['Prefer: return=minimal']);
  try {
    await sendPlatformEmail({
      to: admin.email,
      templateKey: 'admin_2fa_code',
      subject: 'Código de segurança da Central TáPronto',
      body: `Seu código para entrar na Central é: ${code}\n\nEle expira em 10 minutos e pode ser usado apenas uma vez.\n\nSe você não tentou entrar, troque sua senha imediatamente.`
    });
  } catch (error) {
    await dbRequest('DELETE', 'admin_2fa_challenges', { token_hash: `eq.${tokenHash}` }, undefined, ['Prefer: return=minimal']).catch(() => {});
    throw httpError(502, 'Não foi possível enviar o código de segurança.');
  }
  return { challenge: token };
}

async function verifyAdminTwoFactorLogin(data = {}) {
  const token = String(data.challenge || '');
  const code = String(data.code || '').replace(/\D/g, '');
  if (!token || !/^\d{6}$/.test(code)) throw httpError(422, 'Informe o código de 6 dígitos.');
  const tokenHash = createHash('sha256').update(token).digest('hex');
  const [challenge] = await dbRequest('GET', 'admin_2fa_challenges', { select: '*', token_hash: `eq.${tokenHash}`, limit: '1' });
  if (!challenge || challenge.consumed_at || new Date(challenge.expires_at).getTime() <= Date.now()) throw httpError(401, 'Código expirado. Entre novamente.');
  if (Number(challenge.attempts || 0) >= 5) throw httpError(429, 'Limite de tentativas atingido. Entre novamente.');
  const actual = createHash('sha256').update(`${tokenHash}:${code}`).digest('hex');
  if (!safeSecretEquals(actual, challenge.code_hash)) {
    await dbRequest('PATCH', 'admin_2fa_challenges', { id: `eq.${challenge.id}` }, { attempts: Number(challenge.attempts || 0) + 1 }, ['Prefer: return=minimal']);
    throw httpError(401, 'Código de segurança incorreto.');
  }
  const [admin] = await dbRequest('GET', 'admin_users', { select: '*', id: `eq.${challenge.admin_user_id}`, is_active: 'eq.true', limit: '1' });
  if (!admin || normalizeAdminRole(admin.role) !== 'superadmin') throw httpError(403, 'Conta Admin Master indisponível.');
  await dbRequest('PATCH', 'admin_2fa_challenges', { id: `eq.${challenge.id}` }, { consumed_at: new Date().toISOString() }, ['Prefer: return=minimal']);
  await markAdminLogin(admin.id);
  return createAdminSession(admin);
}

async function hasPendingAdminActivation(adminId) {
  const [token] = await dbRequest('GET', 'admin_activation_tokens', {
    select: 'id,expires_at',
    admin_user_id: `eq.${cleanUuid(adminId, 'admin')}`,
    status: 'eq.pending',
    order: 'created_at.desc',
    limit: '1'
  });
  return Boolean(token && new Date(token.expires_at).getTime() > Date.now());
}

async function requestAdminPasswordRecovery(req, data = {}) {
  const email = cleanEmail(data.email || '');
  if (!email) throw httpError(422, 'Informe um e-mail válido.');
  const [admin] = await dbRequest('GET', 'admin_users', {
    select: 'id,company_id,name,email,is_active',
    email: `eq.${email}`,
    limit: '1'
  });
  if (admin?.id && admin.is_active !== false) {
    const token = randomBytes(24).toString('hex');
    const tokenHash = hashPasswordResetToken(token);
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString();
    await dbRequest('PATCH', 'admin_password_reset_tokens', {
      admin_user_id: `eq.${admin.id}`,
      status: 'eq.pending'
    }, {
      status: 'cancelled'
    }, ['Prefer: return=minimal']).catch(() => {});
    await dbRequest('POST', 'admin_password_reset_tokens', {}, {
      admin_user_id: admin.id,
      token_hash: tokenHash,
      status: 'pending',
      expires_at: expiresAt
    }, ['Prefer: return=minimal']);
    await sendAdminPasswordRecoveryEmail(req, admin, token, expiresAt).catch(async (error) => {
      await audit('admin.password_recovery.email_failed', {
        req,
        actor_admin_id: admin.id,
        company_id: admin.company_id || null,
        entity_type: 'admin_user',
        entity_id: admin.id,
        severity: 'warning',
        after_data: { email: maskEmailOrToken(email), message: error.message || 'Falha ao enviar recuperação.' }
      });
      throw httpError(502, 'Não foi possível enviar o e-mail de recuperação. Verifique a configuração SMTP.');
    });
    await audit('admin.password_recovery.request', {
      req,
      actor_admin_id: admin.id,
      company_id: admin.company_id || null,
      entity_type: 'admin_user',
      entity_id: admin.id,
      severity: 'info',
      after_data: { email }
    });
  }
  return { ok: true };
}

async function sendAdminPasswordRecoveryEmail(req, admin, token, expiresAt) {
  const resetUrl = absoluteAppUrl(req, `/redefinir-senha?token=${token}`);
  const variables = {
    customer_name: admin.name || admin.email,
    company_name: '',
    store_name: '',
    due_date: formatDateTimePt(expiresAt),
    dashboard_url: resetUrl,
    reset_url: resetUrl,
    support_url: absolutePanelUrl('/?tab=support'),
    payment_url: absolutePanelUrl('/?tab=plan'),
    platform_url: absolutePlatformUrl('/')
  };
  await sendPlatformTemplateEmail({
    to: admin.email,
    templateKey: 'password_recovery',
    variables,
    requireActive: true
  });
}

async function getPublicAdminPasswordReset(token) {
  const reset = await findAdminPasswordResetByToken(token);
  const [admin] = await dbRequest('GET', 'admin_users', {
    select: 'email,name',
    id: `eq.${reset.admin_user_id}`,
    limit: '1'
  });
  if (!admin) throw httpError(404, 'Link de recuperação inválido.');
  return {
    email: admin.email,
    name: admin.name || '',
    expires_at: reset.expires_at
  };
}

async function resetAdminPassword(req, token, data = {}) {
  const reset = await findAdminPasswordResetByToken(token);
  const password = validatePassword(data.password);
  const confirmPassword = String(data.confirm_password || data.confirmPassword || '');
  if (confirmPassword && confirmPassword !== password) throw httpError(422, 'A confirmação de senha não confere.');
  const [admin] = await dbRequest('PATCH', 'admin_users', { id: `eq.${reset.admin_user_id}` }, {
    password_hash: hashPassword(password),
    updated_at: new Date().toISOString()
  }, ['Prefer: return=representation']);
  if (!admin) throw httpError(404, 'Conta administrativa não encontrada.');
  await dbRequest('PATCH', 'admin_password_reset_tokens', { id: `eq.${reset.id}` }, {
    status: 'used',
    used_at: new Date().toISOString()
  }, ['Prefer: return=minimal']);
  await dbRequest('PATCH', 'admin_password_reset_tokens', {
    admin_user_id: `eq.${admin.id}`,
    status: 'eq.pending'
  }, {
    status: 'cancelled'
  }, ['Prefer: return=minimal']).catch(() => {});
  clearSessionCacheByOwner('admin', admin.id);
  await audit('admin.password_recovery.reset', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id || null,
    entity_type: 'admin_user',
    entity_id: admin.id,
    severity: 'info',
    after_data: { email: maskEmailOrToken(admin.email) }
  });
  const session = await createAdminSession(admin);
  return {
    sessionId: session.sessionId,
    body: {
      ...session.body,
      message: 'Conta ativada com sucesso.',
      redirect: absolutePanelUrl('/')
    }
  };
}

async function findAdminPasswordResetByToken(token) {
  const value = String(token || '').trim();
  if (!/^[a-f0-9]{32,128}$/i.test(value)) throw httpError(404, 'Link de recuperação inválido.');
  const tokenHash = hashPasswordResetToken(value);
  const [reset] = await dbRequest('GET', 'admin_password_reset_tokens', {
    select: '*',
    token_hash: `eq.${tokenHash}`,
    status: 'eq.pending',
    limit: '1'
  });
  if (!reset) throw httpError(404, 'Link de recuperação inválido ou já utilizado.');
  if (new Date(reset.expires_at).getTime() < Date.now()) {
    await dbRequest('PATCH', 'admin_password_reset_tokens', { id: `eq.${reset.id}` }, {
      status: 'expired'
    }, ['Prefer: return=minimal']).catch(() => {});
    throw httpError(410, 'Este link de recuperação expirou.');
  }
  return reset;
}

async function getAdminById(adminId) {
  const rows = await dbRequest('GET', 'admin_users', {
    select: '*',
    id: `eq.${adminId}`,
    limit: '1'
  });

  if (!rows[0]) throw httpError(404, 'Admin não encontrado.');
  return rows[0];
}

async function listAdminUsers(session = null) {
  const now = Date.now();
  const companyId = cleanUuid(session?.company_id);
  const cacheKey = companyId ? `company:${companyId}` : `admin:${cleanUuid(session?.id) || 'default'}`;
  if (adminUsersCache?.[cacheKey]?.expiresAt > now) return adminUsersCache[cacheKey].data;
  const rows = await dbRequest('GET', 'admin_users', {
    select: 'id,name,email,role,is_active,last_login_at,created_at',
    ...(companyId ? { company_id: `eq.${companyId}` } : { id: `eq.${cleanUuid(session?.id)}` }),
    order: 'name.asc',
    limit: '200'
  });
  const data = rows.map(publicAdmin);
  adminUsersCache = adminUsersCache && typeof adminUsersCache === 'object' ? adminUsersCache : {};
  adminUsersCache[cacheKey] = {
    data,
    expiresAt: now + ADMIN_LIST_CACHE_MS
  };
  return data;
}

async function createAdminUser(data, session = null) {
  await assertCompanyUsageLimit(session, 'admin_users', 'admin_users');
  const admin = sanitizeAdminUser(data);
  const role = sanitizeAdminRole(data.role);
  if (role === 'superadmin') {
    throw httpError(403, 'Contas superadmin não podem ser criadas pelo painel da loja.');
  }
  const password = validatePassword(data.password);
  const [created] = await dbRequest('POST', 'admin_users', {}, {
    ...admin,
    company_id: session?.company_id || admin.company_id || null,
    password_hash: hashPassword(password),
    role,
    is_active: data.is_active === undefined ? true : Boolean(data.is_active)
  }, ['Prefer: return=representation']);
  if (session?.company_id && session?.store_id) {
    await dbRequest('POST', 'admin_user_store_access', {}, {
      admin_user_id: created.id,
      company_id: session.company_id,
      store_id: session.store_id,
      role,
      permissions: [],
      is_active: true
    }, ['Prefer: return=minimal']).catch((error) => {
      console.warn('Falha ao vincular usuário admin à loja:', error.message || error);
    });
  }
  await recordCompanyUsage(session, 'admin_users', 'admin_users');
  clearAdminStoreAccessCache(created.id);
  clearAdminUsersCache();
  return publicAdmin(created);
}

async function createAdminInvitation(req, data = {}, session = null) {
  await assertCompanyUsageLimit(session, 'admin_users', 'admin_users');
  const email = cleanEmail(data.email || '');
  const phone = onlyDigits(data.phone || '');
  const name = cleanText(data.name || '');
  const role = sanitizeInviteRole(data.role || 'attendant');
  if (!email) throw httpError(422, 'Informe o e-mail do funcionario.');
  if (!session?.company_id || !session?.store_id) throw httpError(422, 'Loja ativa não encontrada.');
  const existing = await dbRequest('GET', 'admin_users', {
    select: 'id',
    email: `eq.${email}`,
    limit: '1'
  });
  if (existing[0]) throw httpError(409, 'Este e-mail já possui conta administrativa.');
  const token = randomBytes(24).toString('hex');
  const tokenHash = hashInviteToken(token);
  const [created] = await dbRequest('POST', 'admin_invitations', {}, {
    company_id: session.company_id,
    store_id: session.store_id,
    email,
    phone: phone || null,
    name: name || null,
    role,
    token_hash: tokenHash,
    status: 'pending',
    invited_by: session.id,
    expires_at: new Date(Date.now() + 7 * 86400000).toISOString()
  }, ['Prefer: return=representation']);
  await audit('admin.invitation.create', {
    req,
    actor_admin_id: session.id,
    company_id: session.company_id,
    store_id: session.store_id,
    entity_type: 'admin_invitation',
    entity_id: created.id,
    after_data: { email, role }
  });
  const inviteLink = `/convite?token=${token}`;
  const whatsapp = await sendAdminInvitationWhatsapp(session.store_id, phone, {
    name,
    role,
    inviteLink: absoluteUrl(req, inviteLink)
  });
  return {
    id: created.id,
    email,
    phone,
    name,
    role,
    status: created.status,
    expires_at: created.expires_at,
    invite_link: inviteLink,
    whatsapp_status: whatsapp.status,
    whatsapp_error: whatsapp.error || null
  };
}

async function sendAdminInvitationWhatsapp(storeId, phone, invitation) {
  const recipient = whatsappRecipientPhone(phone || '');
  if (!recipient) return { status: 'skipped', error: 'Telefone não informado.' };
  const store = await getStoreSettings(storeId);
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  if (!integrations.whatsapp.enabled) return { status: 'skipped', error: 'WhatsApp automático desativado.' };
  const role = adminRoleLabel(invitation.role).toLowerCase();
  const message = [
    `Olá${invitation.name ? `, ${invitation.name}` : ''}!`,
    `Você recebeu um convite para acessar o painel de ${store.name || 'sua loja'} como ${role}.`,
    `Crie sua senha aqui: ${invitation.inviteLink}`
  ].join('\n');
  try {
    await sendWhatsappViaProvider(integrations.whatsapp, recipient, message);
    return { status: 'sent' };
  } catch (error) {
    return { status: 'failed', error: error.message || 'Falha ao enviar WhatsApp.' };
  }
}

async function getPublicInvitation(token) {
  const invitation = await findInvitationByToken(token);
  return {
    email: invitation.email,
    name: invitation.name || '',
    role: invitation.role,
    expires_at: invitation.expires_at
  };
}

async function acceptAdminInvitation(req, token, data = {}) {
  const invitation = await findInvitationByToken(token);
  const password = validatePassword(data.password);
  const confirmPassword = String(data.confirm_password || data.confirmPassword || '');
  if (confirmPassword && confirmPassword !== password) throw httpError(422, 'A confirmação de senha não confere.');
  const name = cleanText(data.name || invitation.name || invitation.email.split('@')[0]);
  const [admin] = await dbRequest('POST', 'admin_users', {}, {
    company_id: invitation.company_id,
    name,
    email: invitation.email,
    password_hash: hashPassword(password),
    role: invitation.role,
    is_active: true
  }, ['Prefer: return=representation']);
  await dbRequest('POST', 'admin_user_store_access', {}, {
    admin_user_id: admin.id,
    company_id: invitation.company_id,
    store_id: invitation.store_id,
    role: invitation.role,
    permissions: [],
    is_active: true
  }, ['Prefer: return=minimal']);
  await dbRequest('PATCH', 'admin_invitations', { id: `eq.${invitation.id}` }, {
    status: 'accepted',
    accepted_by: admin.id,
    accepted_at: new Date().toISOString()
  }, ['Prefer: return=minimal']);
  await recordCompanyUsage({ company_id: invitation.company_id, store_id: invitation.store_id, id: admin.id }, 'admin_users', 'admin_users');
  await audit('admin.invitation.accept', {
    req,
    actor_admin_id: admin.id,
    company_id: invitation.company_id,
    store_id: invitation.store_id,
    entity_type: 'admin_invitation',
    entity_id: invitation.id,
    after_data: { email: invitation.email, role: invitation.role }
  });
  clearAdminStoreAccessCache(admin.id);
  clearAdminUsersCache();
  return createAdminSession(admin);
}

async function findInvitationByToken(token) {
  const value = String(token || '').trim();
  if (!/^[a-f0-9]{32,128}$/i.test(value)) throw httpError(404, 'Convite inválido.');
  const tokenHash = hashInviteToken(value);
  const [invitation] = await dbRequest('GET', 'admin_invitations', {
    select: '*',
    token_hash: `eq.${tokenHash}`,
    status: 'eq.pending',
    limit: '1'
  });
  if (!invitation) throw httpError(404, 'Convite inválido ou já utilizado.');
  if (new Date(invitation.expires_at).getTime() < Date.now()) {
    await dbRequest('PATCH', 'admin_invitations', { id: `eq.${invitation.id}` }, { status: 'expired' }, ['Prefer: return=minimal']).catch(() => {});
    throw httpError(410, 'Este convite expirou.');
  }
  return invitation;
}

function sanitizeInviteRole(role) {
  const value = cleanSlug(role || 'attendant');
  if (['admin', 'waiter', 'attendant', 'delivery', 'kitchen'].includes(value)) return value;
  return 'attendant';
}

function hashInviteToken(token) {
  return pbkdf2Sync(String(token || ''), 'admin_invitation', 120000, 32, 'sha256').toString('hex');
}

function hashPasswordResetToken(token) {
  return pbkdf2Sync(String(token || ''), 'admin_password_reset', 120000, 32, 'sha256').toString('hex');
}

function hashAdminActivationToken(token) {
  return pbkdf2Sync(String(token || ''), 'admin_account_activation', 120000, 32, 'sha256').toString('hex');
}

async function updateAdminUser(id, data, session) {
  const target = await getAdminById(id);
  if (target.company_id !== session.company_id) {
    throw httpError(403, 'Você não pode editar uma conta de outra empresa.');
  }
  const payload = {};
  if ('name' in data) payload.name = cleanText(data.name);
  if ('email' in data) payload.email = cleanEmail(data.email);
  if ('role' in data) {
    payload.role = sanitizeAdminRole(data.role);
    if (payload.role === 'superadmin' && normalizeAdminRole(target.role) !== 'superadmin') {
      throw httpError(403, 'Contas da loja não podem ser promovidas para superadmin.');
    }
  }
  if ('is_active' in data) payload.is_active = Boolean(data.is_active);
  if ('password' in data && String(data.password || '').trim()) {
    payload.password_hash = hashPassword(validatePassword(data.password));
  }
  if (!Object.keys(payload).length) throw httpError(422, 'Informe algum dado para atualizar.');

  if (target.id === session.id && payload.is_active === false) {
    throw httpError(422, 'Você não pode desativar sua própria conta.');
  }
  if (target.id === session.id && payload.role && !isFullAdminRole(payload.role)) {
    throw httpError(422, 'Você não pode remover seu próprio acesso de administrador.');
  }

  const [updated] = await dbRequest('PATCH', 'admin_users', { id: `eq.${id}` }, payload, ['Prefer: return=representation']);
  if (!updated) throw httpError(404, 'Conta admin não encontrada.');
  clearSessionCacheByOwner('admin', id);
  clearAdminStoreAccessCache(id);
  clearAdminUsersCache();
  return publicAdmin(updated);
}

async function deleteAdminUser(id, session) {
  const target = await getAdminById(id);
  if (target.company_id !== session.company_id) {
    throw httpError(403, 'Você não pode excluir uma conta de outra empresa.');
  }
  if (target.id === session.id) {
    throw httpError(422, 'Você não pode excluir sua própria conta.');
  }

  if (isFullAdminRole(target.role)) {
    const activeAdmins = await dbRequest('GET', 'admin_users', {
      select: 'id,role,is_active',
      ...(target.company_id ? { company_id: `eq.${target.company_id}` } : { company_id: 'is.null' }),
      is_active: 'eq.true',
      limit: '200'
    });
    const otherFullAdmins = activeAdmins.filter((admin) => admin.id !== target.id && isFullAdminRole(admin.role));
    if (!otherFullAdmins.length) {
      throw httpError(422, 'Mantenha pelo menos uma conta administradora ativa.');
    }
  }

  await dbRequest('DELETE', 'app_sessions', {
    type: 'eq.admin',
    owner_id: `eq.${id}`
  }, undefined, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('DELETE', 'admin_user_store_access', {
    admin_user_id: `eq.${id}`
  }, undefined, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('DELETE', 'admin_users', {
    id: `eq.${id}`
  }, undefined, ['Prefer: return=minimal']);

  clearSessionCacheByOwner('admin', id);
  clearAdminStoreAccessCache(id);
  clearAdminUsersCache();
  return publicAdmin(target);
}

async function updateAdminAccount(session, data) {
  const payload = {};
  if ('name' in data) payload.name = cleanText(data.name);
  if ('email' in data) payload.email = cleanEmail(data.email);

  if (!payload.name && !payload.email) {
    throw httpError(422, 'Informe nome ou e-mail para atualizar.');
  }

  const [updated] = await dbRequest('PATCH', 'admin_users', { id: `eq.${session.id}` }, payload, ['Prefer: return=representation']);
  session.name = updated.name;
  session.email = updated.email;
  session.role = updated.role;
  clearSessionCacheByOwner('admin', session.id);
  clearAdminUsersCache();
  return publicAdmin(updated);
}

async function changeAdminPassword(session, data) {
  const currentPassword = String(data.current_password || '');
  const newPassword = validatePassword(data.new_password);
  const admin = await getAdminById(session.id);

  if (!verifyPassword(currentPassword, admin.password_hash)) {
    throw httpError(401, 'Senha atual inválida.');
  }

  await dbRequest('PATCH', 'admin_users', { id: `eq.${session.id}` }, {
    password_hash: hashPassword(newPassword)
  }, ['Prefer: return=representation']);
  clearSessionCacheByOwner('admin', session.id);
  clearAdminUsersCache();
}

async function deleteCurrentCompanyAccount(req, session, data = {}) {
  if (!isFullAdminRole(session.role)) {
    throw httpError(403, 'Apenas uma conta administradora pode excluir a empresa.');
  }
  if (String(data.confirmation || '').trim() !== 'EXCLUIR CONTA') {
    throw httpError(422, 'Digite EXCLUIR CONTA para confirmar.');
  }
  const admin = await getAdminById(session.id);
  if (!verifyPassword(String(data.password || ''), admin.password_hash)) {
    throw httpError(401, 'Senha atual inválida.');
  }
  const companyId = session.company_id ? cleanUuid(session.company_id, 'empresa') : null;
  if (!companyId) throw httpError(422, 'Empresa ativa não encontrada.');
  const stores = await dbRequest('GET', 'stores', {
    select: 'id',
    company_id: `eq.${companyId}`,
    limit: '1000'
  }).catch(() => []);
  const storeIds = cleanUuidArray(stores.map((store) => store.id), 'loja');
  for (const storeId of storeIds) {
    await deleteStoreOperationalData(dbRequest, storeId);
  }
  await audit('company.delete_account', {
    req,
    company_id: companyId,
    store_id: session.store_id || null,
    actor_admin_id: session.id,
    entity_type: 'company',
    entity_id: companyId,
    severity: 'critical',
    before_data: { stores: storeIds.length }
  });
  await dbRequest('DELETE', 'app_sessions', { company_id: `eq.${companyId}` }, undefined, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('DELETE', 'admin_user_store_access', { company_id: `eq.${companyId}` }, undefined, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('DELETE', 'admin_users', { company_id: `eq.${companyId}` }, undefined, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('DELETE', 'stores', { company_id: `eq.${companyId}` }, undefined, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('DELETE', 'companies', { id: `eq.${companyId}` }, undefined, ['Prefer: return=minimal']);
  clearAdminUsersCache();
  sessionCache.clear();
  clearStoreSettingsCache();
  clearMenuCache();
  adminOrdersCache.clear();
  adminCustomersCache = null;
  adminPromotionsCache = null;
  adminTablesCache = null;
  return { ok: true, deleted_stores: storeIds.length };
}

async function deleteStoreOperationalData(db, storeId) {
  const resolvedStoreId = cleanUuid(storeId, 'loja');
  const tables = [
    'payment_refunds',
    'payment_attempts',
    'order_payment_events',
    'order_whatsapp_logs',
    'order_print_logs',
    'order_items',
    'orders',
    'customer_addresses',
    'customers',
    'menu_modifiers',
    'menu_modifier_groups',
    'menu_items',
    'menu_categories',
    'customer_tabs',
    'dining_tables',
    'promotions',
    'store_settings',
    'payment_transaction_index'
  ];
  for (const table of tables) {
    await db('DELETE', table, { store_id: `eq.${resolvedStoreId}` }, undefined, ['Prefer: return=minimal']).catch(() => {});
  }
}

async function createAdminSession(admin) {
  const access = await getAdminStoreAccess(admin);
  const activeStore = access[0]?.store || null;
  const sessionAdmin = {
    session_version: 2,
    id: admin.id,
    name: admin.name,
    email: admin.email,
    role: normalizeAdminRole(admin.role),
    company_id: activeStore?.company_id || admin.company_id || access[0]?.company_id || null,
    store_id: activeStore?.id || null,
    active_store: activeStore ? publicStoreRef(activeStore) : null,
    stores: access.map((entry) => publicStoreRef(entry.store)).filter(Boolean)
  };
  const sessionId = await createPersistentSession('admin', admin.id, sessionAdmin);
  return { sessionId, body: { admin: publicAdmin(sessionAdmin) } };
}

async function getAdminStoreAccess(adminId) {
  const admin = typeof adminId === 'object' && adminId ? adminId : null;
  const cleanAdminId = cleanUuid(admin?.id || adminId);
  if (!cleanAdminId) return [];
  const role = admin ? normalizeAdminRole(admin.role) : '';
  const companyId = admin?.company_id ? cleanUuid(admin.company_id) : '';
  const cacheKey = `${cleanAdminId}:${role || 'any'}:${companyId || 'any'}`;
  const cached = adminStoreAccessCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.data;
  let access = await dbRequest('GET', 'admin_user_store_access', {
    select: '*',
    admin_user_id: `eq.${cleanAdminId}`,
    is_active: 'eq.true',
    order: 'created_at.asc'
  });
  if (admin) {
    access = access.filter((entry) => {
      if (role === 'superadmin') return true;
      return !companyId || entry.company_id === companyId;
    });
  }
  const storeIds = cleanUuidArray(access.map((entry) => entry.store_id));
  if (!storeIds.length) return [];
  const stores = await dbRequest('GET', 'stores', {
    select: '*',
    id: uuidInFilter(storeIds),
    is_active: 'eq.true',
    order: 'name.asc'
  });
  const storesById = new Map(stores.map((store) => [store.id, store]));
  const data = access
    .map((entry) => ({ ...entry, store: storesById.get(entry.store_id) || null }))
    .filter((entry) => entry.store);
  adminStoreAccessCache.set(cacheKey, {
    data,
    expiresAt: Date.now() + ADMIN_ACCESS_CACHE_MS
  });
  return data;
}

async function listAdminStores(admin) {
  const access = await getAdminStoreAccess(admin);
  return access.map((entry) => ({
    ...publicStoreRef(entry.store),
    role: normalizeAdminRole(entry.role),
    permissions: Array.isArray(entry.permissions) ? entry.permissions : []
  }));
}

async function switchAdminStore(req, data, admin) {
  const storeId = cleanUuid(data.store_id || data.id, 'loja');
  const access = await getAdminStoreAccess(admin);
  const selected = access.find((entry) => entry.store_id === storeId);
  if (!selected) throw httpError(403, 'Sua conta não possui acesso a esta loja.');

  const nextAdmin = {
    ...admin,
    session_version: 2,
    company_id: selected.company_id,
    store_id: selected.store_id,
    role: normalizeAdminRole(selected.role || admin.role),
    active_store: publicStoreRef(selected.store),
    stores: access.map((entry) => publicStoreRef(entry.store)).filter(Boolean)
  };

  const cookies = parseCookies(req);
  const token = cookies[ADMIN_COOKIE];
  if (token) {
    await dbRequest('PATCH', 'app_sessions', { token: `eq.${token}`, type: 'eq.admin' }, {
      company_id: selected.company_id,
      store_id: selected.store_id,
      data: nextAdmin
    }, ['Prefer: return=minimal']);
    clearSessionCacheToken(token);
  }

  return publicAdmin(nextAdmin);
}

async function listPlatformCompanies(params = new URLSearchParams()) {
  const page = Math.max(1, Number.parseInt(params.get?.('page') || '1', 10) || 1);
  const perPage = clampNumber(Number(params.get?.('per_page') || 200), 25, 300);
  const offset = (page - 1) * perPage;
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const [companies, features] = await Promise.all([
    dbRequest('GET', 'companies', {
      select: '*',
      order: 'created_at.desc',
      limit: String(perPage),
      offset: String(offset)
    }),
    dbRequest('GET', 'platform_features', {
      select: '*',
      order: 'sort_order.asc',
      limit: '300'
    })
  ]);
  const companyIds = companies.map((company) => company.id);
  const companyFilter = `in.(${companyIds.join(',')})`;
  const [stores, admins, subscriptions, overrides] = companyIds.length ? await Promise.all([
    dbRequest('GET', 'stores', {
      select: '*',
      company_id: companyFilter,
      order: 'name.asc',
      limit: '3000'
    }),
    dbRequest('GET', 'admin_users', {
      select: 'id,company_id,name,email,role,is_active,last_login_at,created_at',
      company_id: companyFilter,
      order: 'created_at.asc',
      limit: '3000'
    }).catch(() => []),
    dbRequest('GET', 'company_subscriptions', {
      select: '*',
      company_id: companyFilter,
      order: 'created_at.desc',
      limit: '3000'
    }),
    dbRequest('GET', 'company_feature_overrides', {
      select: '*',
      company_id: companyFilter,
      order: 'created_at.desc',
      limit: '5000'
    })
  ]) : [[], [], [], []];
  const storeIds = stores.map((store) => store.id);
  const storeFilter = `in.(${storeIds.join(',')})`;
  const [domains, orders, products, settings] = storeIds.length ? await Promise.all([
    dbRequest('GET', 'store_domains', {
      select: 'id,store_id,domain,status,verified_at',
      store_id: storeFilter,
      order: 'created_at.desc',
      limit: '5000'
    }).catch(() => []),
    dbRequest('GET', 'orders', {
      select: 'id,store_id,total,status,created_at',
      store_id: storeFilter,
      created_at: `gte.${monthStart.toISOString()}`,
      order: 'created_at.desc',
      limit: '10000'
    }).catch(() => []),
    dbRequest('GET', 'menu_items', {
      select: 'id,store_id,is_active',
      store_id: storeFilter,
      limit: '10000'
    }).catch(() => []),
    dbRequest('GET', 'store_settings', {
      select: 'store_id,whatsapp_number,onboarding_completed,is_open',
      store_id: storeFilter,
      limit: '2000'
    }).catch(() => [])
  ]) : [[], [], [], []];
  const featureById = new Map(features.map((feature) => [feature.id, feature]));
  const domainsByStore = new Map();
  for (const domain of domains) {
    if (!domainsByStore.has(domain.store_id)) domainsByStore.set(domain.store_id, []);
    domainsByStore.get(domain.store_id).push(domain);
  }
  const storesByCompany = new Map();
  const storeCompanyById = new Map();
  for (const store of stores) {
    storeCompanyById.set(store.id, store.company_id);
    if (!storesByCompany.has(store.company_id)) storesByCompany.set(store.company_id, []);
    storesByCompany.get(store.company_id).push({
      ...publicStoreRef(store),
      domains: domainsByStore.get(store.id) || []
    });
  }
  const subscriptionByCompany = new Map();
  for (const subscription of subscriptions) {
    if (!subscriptionByCompany.has(subscription.company_id)) subscriptionByCompany.set(subscription.company_id, subscription);
  }
  const overridesByCompany = new Map();
  for (const override of overrides) {
    if (!overridesByCompany.has(override.company_id)) overridesByCompany.set(override.company_id, []);
    overridesByCompany.get(override.company_id).push({
      ...override,
      feature: featureById.get(override.feature_id) || null
    });
  }
  const adminsByCompany = new Map();
  for (const admin of admins) {
    if (!admin.company_id) continue;
    if (!adminsByCompany.has(admin.company_id)) adminsByCompany.set(admin.company_id, []);
    adminsByCompany.get(admin.company_id).push({
      id: admin.id,
      name: admin.name,
      email: admin.email,
      role: normalizeAdminRole(admin.role),
      is_active: admin.is_active !== false,
      last_login_at: admin.last_login_at || null,
      created_at: admin.created_at
    });
  }
  const ordersByCompany = new Map();
  for (const order of orders) {
    const companyId = storeCompanyById.get(order.store_id);
    if (!companyId) continue;
    if (!ordersByCompany.has(companyId)) ordersByCompany.set(companyId, []);
    ordersByCompany.get(companyId).push(order);
  }
  const productsByCompany = new Map();
  for (const product of products) {
    const companyId = storeCompanyById.get(product.store_id);
    if (!companyId) continue;
    if (!productsByCompany.has(companyId)) productsByCompany.set(companyId, []);
    productsByCompany.get(companyId).push(product);
  }
  const settingsByStore = new Map(settings.map((setting) => [setting.store_id, setting]));
  return {
    pagination: {
      page,
      per_page: perPage,
      returned: companies.length,
      has_more: companies.length === perPage
    },
    features,
    companies: companies.map((company) => {
      const companyStores = storesByCompany.get(company.id) || [];
      const companyAdmins = adminsByCompany.get(company.id) || [];
      const companyOrders = ordersByCompany.get(company.id) || [];
      const billableOrders = companyOrders.filter((order) => order.status !== 'cancelled');
      const companyProducts = productsByCompany.get(company.id) || [];
      const lastOrder = companyOrders[0] || null;
      const lastAccessAt = companyAdmins
        .map((admin) => admin.last_login_at)
        .filter(Boolean)
        .sort((a, b) => new Date(b).getTime() - new Date(a).getTime())[0] || null;
      return {
        ...company,
        stores: companyStores,
        admins: companyAdmins,
        subscription: subscriptionByCompany.get(company.id) || null,
        overrides: overridesByCompany.get(company.id) || [],
        metrics: {
          stores_count: companyStores.length,
          unpublished_stores_count: companyStores.filter((store) => store.is_active === false).length,
          orders_month: billableOrders.length,
          revenue_month: roundMoney(billableOrders.reduce((sum, order) => sum + moneyNumber(order.total), 0)),
          revenue_month_cents: moneyToCents(billableOrders.reduce((sum, order) => sum + moneyNumber(order.total), 0)),
          last_order_at: lastOrder?.created_at || null,
          last_access_at: lastAccessAt,
          products_count: companyProducts.length,
          active_products_count: companyProducts.filter((item) => item.is_active !== false).length,
          stores_without_whatsapp_count: companyStores.filter((store) => !settingsByStore.get(store.id)?.whatsapp_number).length,
          incomplete_onboarding_count: companyStores.filter((store) => settingsByStore.get(store.id)?.onboarding_completed === false).length
        }
      };
    })
  };
}

async function getPlatformCompanyDetail(companyId) {
  const resolvedCompanyId = cleanUuid(companyId, 'empresa');
  const [company] = await dbRequest('GET', 'companies', {
    select: '*',
    id: `eq.${resolvedCompanyId}`,
    limit: '1'
  });
  if (!company) throw httpError(404, 'Cliente não encontrado.');

  const [stores, admins, subscriptions, plans, billingHistory, auditLogs, usageCounters] = await Promise.all([
    dbRequest('GET', 'stores', {
      select: 'id,company_id,name,slug,public_url,is_active,created_at,updated_at',
      company_id: `eq.${resolvedCompanyId}`,
      order: 'name.asc',
      limit: '200'
    }).catch(() => []),
    dbRequest('GET', 'admin_users', {
      select: 'id,name,email,role,is_active,last_login_at,created_at',
      company_id: `eq.${resolvedCompanyId}`,
      order: 'created_at.asc',
      limit: '200'
    }).catch(() => []),
    listCompanySubscriptions(resolvedCompanyId, 50),
    dbRequest('GET', 'subscription_plans', { select: '*', limit: '100' }).catch(() => []),
    listBillingHistory(resolvedCompanyId),
    dbRequest('GET', 'audit_logs', {
      select: 'id,action,severity,entity_type,entity_id,store_id,actor_admin_id,after_data,created_at',
      company_id: `eq.${resolvedCompanyId}`,
      order: 'created_at.desc',
      limit: '80'
    }).catch(() => []),
    dbRequest('GET', 'company_usage_counters', {
      select: '*',
      company_id: `eq.${resolvedCompanyId}`,
      order: 'updated_at.desc',
      limit: '100'
    }).catch(() => [])
  ]);

  const storeIds = cleanUuidArray(stores.map((store) => store.id));
  const [orders, settings, domains, products, customers] = storeIds.length ? await Promise.all([
    dbRequest('GET', 'orders', {
      select: 'id,store_id,total,status,financial_status,payment_method,fulfillment_method,created_at',
      store_id: uuidInFilter(storeIds),
      order: 'created_at.desc',
      limit: '2000'
    }).catch(() => []),
    dbRequest('GET', 'store_settings', {
      select: 'store_id,whatsapp_number,onboarding_completed,is_open,updated_at',
      store_id: uuidInFilter(storeIds),
      limit: '200'
    }).catch(() => []),
    dbRequest('GET', 'store_domains', {
      select: 'id,store_id,domain,status,verified_at',
      store_id: uuidInFilter(storeIds),
      limit: '200'
    }).catch(() => []),
    dbRequest('GET', 'menu_items', {
      select: 'id,store_id,is_active,created_at',
      store_id: uuidInFilter(storeIds),
      limit: '5000'
    }).catch(() => []),
    dbRequest('GET', 'customers', {
      select: 'id,store_id,created_at,last_login_at',
      store_id: uuidInFilter(storeIds),
      limit: '5000'
    }).catch(() => [])
  ]) : [[], [], [], [], []];

  const planById = new Map(plans.map((plan) => [plan.id, plan]));
  const subscription = pickCurrentCompanySubscription(subscriptions);
  const plan = subscription?.plan_id ? planById.get(subscription.plan_id) || null : null;
  const settingsByStore = new Map(settings.map((row) => [row.store_id, row]));
  const domainsByStore = new Map();
  for (const domain of domains) {
    if (!domainsByStore.has(domain.store_id)) domainsByStore.set(domain.store_id, []);
    domainsByStore.get(domain.store_id).push(domain);
  }
  const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000);
  const sevenDaysAgo = new Date(Date.now() - 7 * 86400000);
  const billableOrders = orders.filter((order) => order.status !== 'cancelled');
  const orders30 = billableOrders.filter((order) => new Date(order.created_at) >= thirtyDaysAgo);
  const orders7 = billableOrders.filter((order) => new Date(order.created_at) >= sevenDaysAgo);
  const lastOrder = orders[0] || null;
  const timeline = buildPlatformCompanyTimeline({ company, stores, orders, billingHistory, auditLogs, subscription });
  const attention = platformCompanyAttention({ company, stores, settingsByStore, orders, subscription, products });

  return {
    company,
    stores: stores.map((store) => ({
      ...publicStoreRef(store),
      domains: domainsByStore.get(store.id) || [],
      settings: settingsByStore.get(store.id) || null,
      products_count: products.filter((item) => item.store_id === store.id).length,
      active_products_count: products.filter((item) => item.store_id === store.id && item.is_active !== false).length,
      customers_count: customers.filter((customer) => customer.store_id === store.id).length
    })),
    admins: admins.map((admin) => ({
      id: admin.id,
      name: admin.name,
      email: admin.email,
      role: normalizeAdminRole(admin.role),
      is_active: admin.is_active !== false,
      last_login_at: admin.last_login_at || null,
      created_at: admin.created_at
    })),
    subscription,
    plan,
    billing_history: billingHistory,
    usage_counters: usageCounters,
    metrics: {
      stores_count: stores.length,
      products_count: products.length,
      active_products_count: products.filter((item) => item.is_active !== false).length,
      customers_count: customers.length,
      orders_7d: orders7.length,
      revenue_7d: roundMoney(orders7.reduce((sum, order) => sum + moneyNumber(order.total), 0)),
      orders_30d: orders30.length,
      revenue_30d: roundMoney(orders30.reduce((sum, order) => sum + moneyNumber(order.total), 0)),
      average_ticket_30d: orders30.length ? roundMoney(orders30.reduce((sum, order) => sum + moneyNumber(order.total), 0) / orders30.length) : 0,
      last_order_at: lastOrder?.created_at || null,
      last_access_at: admins.map((admin) => admin.last_login_at).filter(Boolean).sort((a, b) => new Date(b) - new Date(a))[0] || null,
      mrr: moneyNumber(plan?.monthly_price || 0),
      mrr_cents: moneyToCents(plan?.monthly_price || 0)
    },
    recent_orders: orders.slice(0, 8).map((order) => ({
      id: order.id,
      store_id: order.store_id,
      total: moneyNumber(order.total),
      total_cents: moneyToCents(order.total),
      status: order.status,
      financial_status: order.financial_status,
      payment_method: order.payment_method,
      fulfillment_method: order.fulfillment_method,
      created_at: order.created_at
    })),
    attention,
    score: await getPlatformCompanyScore(resolvedCompanyId),
    internal_status: latestPlatformInternalStatus(auditLogs),
    timeline,
    audit_logs: auditLogs.slice(0, 30)
  };
}

async function createPlatformCompanyNote(companyId, data, admin, req) {
  const resolvedCompanyId = cleanUuid(companyId, 'empresa');
  const text = cleanText(data.note || data.text || '');
  if (!text || text.length < 3) throw httpError(422, 'Informe uma nota interna com pelo menos 3 caracteres.');
  const status = cleanText(data.status || '').slice(0, 80);
  const nextContactAt = data.next_contact_at ? new Date(data.next_contact_at) : null;
  const payload = {
    note: text.slice(0, 1000),
    support_status: status || null,
    next_contact_at: nextContactAt && !Number.isNaN(nextContactAt.getTime()) ? nextContactAt.toISOString() : null,
    responsible: cleanText(data.responsible || admin?.name || '').slice(0, 120) || null,
    priority: supportPriority(data.priority || 'medium'),
    tags: cleanSupportTags(data.tags || data.tag || '')
  };
  await audit('platform.client.note', {
    req,
    company_id: resolvedCompanyId,
    actor_admin_id: admin.id,
    entity_type: 'company',
    entity_id: resolvedCompanyId,
    severity: 'info',
    after_data: payload
  });
  return {
    ...payload,
    created_at: new Date().toISOString(),
    actor_admin_id: admin.id
  };
}

async function updatePlatformCompanyInternalStatus(req, companyId, data, admin) {
  const resolvedCompanyId = cleanUuid(companyId, 'empresa');
  await getCompanyById(resolvedCompanyId);
  const note = cleanText(data.note || data.text || '').slice(0, 1000);
  const nextContactAt = data.next_contact_at ? new Date(data.next_contact_at) : null;
  const payload = {
    support_status: cleanText(data.status || data.support_status || '').slice(0, 80) || null,
    responsible: cleanText(data.responsible || admin?.name || '').slice(0, 120) || null,
    next_contact_at: nextContactAt && !Number.isNaN(nextContactAt.getTime()) ? nextContactAt.toISOString() : null,
    priority: supportPriority(data.priority || 'medium'),
    tags: cleanSupportTags(data.tags || data.tag || ''),
    note: note || null
  };
  await audit('platform.client.internal_status', {
    req,
    company_id: resolvedCompanyId,
    actor_admin_id: admin.id,
    entity_type: 'company',
    entity_id: resolvedCompanyId,
    severity: payload.priority === 'critical' || payload.priority === 'critica' ? 'warning' : 'info',
    after_data: payload
  });
  return {
    ...payload,
    created_at: new Date().toISOString(),
    actor_admin_id: admin.id
  };
}

function latestPlatformInternalStatus(auditLogs = []) {
  const log = auditLogs.find((entry) => ['platform.client.internal_status', 'platform.client.note'].includes(entry.action));
  if (!log) return null;
  return {
    ...(log.after_data || {}),
    action: log.action,
    created_at: log.created_at,
    actor_admin_id: log.actor_admin_id || null
  };
}

function cleanSupportTags(value) {
  const source = Array.isArray(value) ? value : String(value || '').split(',');
  return source
    .map((item) => cleanSlug(item).slice(0, 40))
    .filter(Boolean)
    .slice(0, 8);
}

async function getPlatformCompanyScore(companyId) {
  const detail = await getPlatformCompanyScoreContext(companyId);
  const { company, stores, settings, products, orders, admins, subscription, plan, tickets } = detail;
  const billableOrders = orders.filter((order) => order.status !== 'cancelled');
  const now = Date.now();
  const orders7 = billableOrders.filter((order) => now - new Date(order.created_at).getTime() <= 7 * 86400000);
  const orders30 = billableOrders.filter((order) => now - new Date(order.created_at).getTime() <= 30 * 86400000);
  const revenue30 = roundMoney(orders30.reduce((sum, order) => sum + moneyNumber(order.total), 0));
  const lastAccessAt = admins.map((admin) => admin.last_login_at).filter(Boolean).sort((a, b) => new Date(b) - new Date(a))[0] || null;
  const lastOrderAt = orders[0]?.created_at || null;
  const incompleteOnboarding = stores.some((store) => settings.get(store.id)?.onboarding_completed === false);
  const hasWhatsapp = stores.some((store) => settings.get(store.id)?.whatsapp_number);
  const openTickets = tickets.filter((ticket) => !['resolved', 'closed'].includes(ticket.status));
  const subscriptionStatus = subscription?.status || company.status || '';
  const planCode = plan?.code || '';
  const reasons = [];
  const recommendations = [];
  let points = 55;

  if (['past_due', 'payment_pending', 'grace_period', 'blocked', 'suspended'].includes(subscriptionStatus)) {
    points -= 30;
    reasons.push('Pagamento ou assinatura exige atenção.');
    recommendations.push(platformRecommendation('cobrar_pendencia', 'Cobrar pendência', 'Validar pagamento, webhook e orientar regularização.'));
  }
  if (!stores.length || incompleteOnboarding || !products.length) {
    points -= 25;
    reasons.push('Ativação inicial incompleta.');
    recommendations.push(platformRecommendation('ajudar_onboarding', 'Ajudar onboarding', 'Guiar o cliente até loja, WhatsApp e primeiro produto.'));
  }
  if (!hasWhatsapp && stores.length) {
    points -= 10;
    reasons.push('WhatsApp da loja não configurado.');
    recommendations.push(platformRecommendation('ativar_whatsapp', 'Ativar WhatsApp', 'Completar o WhatsApp para reduzir abandono de pedidos.'));
  }
  if (!orders30.length && stores.length) {
    points -= 20;
    reasons.push('Sem pedidos nos últimos 30 dias.');
    recommendations.push(platformRecommendation('verificar_sem_pedidos', 'Verificar loja sem pedidos', 'Conferir loja aberta, cardápio publicado e divulgação.'));
  } else {
    points += Math.min(25, orders30.length);
  }
  if (lastAccessAt && now - new Date(lastAccessAt).getTime() > 5 * 86400000) {
    points -= 12;
    reasons.push('Admin sem acesso recente.');
    recommendations.push(platformRecommendation('ligar_cliente', 'Ligar para cliente', 'Entender bloqueios e oferecer ajuda prática.'));
  }
  if (openTickets.length) {
    points -= Math.min(18, openTickets.length * 6);
    reasons.push(`${openTickets.length} chamado(s) aberto(s).`);
  }
  if (revenue30 >= 3000 || orders30.length >= 60) {
    points += 18;
    reasons.push('Uso forte nos últimos 30 dias.');
    if (['trial', 'free', 'essential'].includes(planCode)) {
      recommendations.push(platformRecommendation('oferecer_upgrade', 'Oferecer upgrade', 'Cliente tem volume para recursos de planos superiores.'));
    }
  }
  if (products.length && orders30.length) {
    recommendations.push(platformRecommendation('revisar_cardapio', 'Revisar cardápio', 'Sugerir fotos, combos, adicionais e produtos campeões.'));
  }

  points = Math.max(0, Math.min(100, Math.round(points)));
  const score = platformScoreBucket({ points, subscriptionStatus, stores, products, orders30, revenue30, planCode, incompleteOnboarding });
  return {
    company_id: company.id,
    score: score.key,
    label: score.label,
    tone: score.tone,
    points,
    reasons: reasons.length ? reasons : ['Cliente sem sinais críticos no momento.'],
    recommendations: dedupeRecommendations(recommendations),
    metrics: {
      plan_name: plan?.name || 'Sem plano',
      plan_code: planCode || null,
      subscription_status: subscriptionStatus || null,
      orders_7d: orders7.length,
      orders_30d: orders30.length,
      revenue_30d: revenue30,
      revenue_30d_cents: moneyToCents(revenue30),
      last_access_at: lastAccessAt,
      last_order_at: lastOrderAt,
      stores_count: stores.length,
      products_count: products.length,
      open_tickets: openTickets.length,
      onboarding_completed: stores.length ? !incompleteOnboarding : false
    }
  };
}

async function getPlatformCompanyScoreContext(companyId) {
  const resolvedCompanyId = cleanUuid(companyId, 'empresa');
  const [company] = await dbRequest('GET', 'companies', { select: '*', id: `eq.${resolvedCompanyId}`, limit: '1' });
  if (!company) throw httpError(404, 'Cliente não encontrado.');
  const [stores, admins, subscriptions, plans, tickets] = await Promise.all([
    dbRequest('GET', 'stores', { select: 'id,company_id,name,slug,is_active,created_at', company_id: `eq.${resolvedCompanyId}`, limit: '200' }).catch(() => []),
    dbRequest('GET', 'admin_users', { select: 'id,name,email,role,is_active,last_login_at,created_at', company_id: `eq.${resolvedCompanyId}`, limit: '200' }).catch(() => []),
    listCompanySubscriptions(resolvedCompanyId, 50),
    dbRequest('GET', 'subscription_plans', { select: '*', limit: '100' }).catch(() => []),
    dbRequest('GET', 'support_tickets', { select: 'id,status,priority,created_at,updated_at', company_id: `eq.${resolvedCompanyId}`, limit: '500' }).catch(() => [])
  ]);
  const storeIds = cleanUuidArray(stores.map((store) => store.id));
  const [orders, settingsRows, products] = storeIds.length ? await Promise.all([
    dbRequest('GET', 'orders', { select: 'id,store_id,total,status,created_at', store_id: uuidInFilter(storeIds), order: 'created_at.desc', limit: '5000' }).catch(() => []),
    dbRequest('GET', 'store_settings', { select: 'store_id,whatsapp_number,onboarding_completed,is_open', store_id: uuidInFilter(storeIds), limit: '200' }).catch(() => []),
    dbRequest('GET', 'menu_items', { select: 'id,store_id,is_active,created_at', store_id: uuidInFilter(storeIds), limit: '5000' }).catch(() => [])
  ]) : [[], [], []];
  const subscription = pickCurrentCompanySubscription(subscriptions);
  const plan = subscription?.plan_id ? plans.find((entry) => entry.id === subscription.plan_id) || null : null;
  return {
    company,
    stores,
    admins,
    subscription,
    plan,
    tickets,
    orders,
    products,
    settings: new Map(settingsRows.map((row) => [row.store_id, row]))
  };
}

function platformScoreBucket(context) {
  if (['past_due', 'payment_pending', 'grace_period', 'blocked', 'suspended'].includes(context.subscriptionStatus)) {
    return { key: 'inadimplente', label: 'Inadimplente', tone: 'danger' };
  }
  if (!context.stores.length || !context.products.length || context.incompleteOnboarding) {
    return { key: 'sem_ativacao', label: 'Sem ativação', tone: 'warning' };
  }
  if (context.orders30.length >= 80 || context.revenue30 >= 5000) {
    return { key: 'cliente_campeao', label: 'Cliente campeão', tone: 'success' };
  }
  if (['trial', 'free', 'essential'].includes(context.planCode) && (context.orders30.length >= 30 || context.revenue30 >= 2000)) {
    return { key: 'potencial_upgrade', label: 'Potencial upgrade', tone: 'info' };
  }
  if (context.points < 55 || !context.orders30.length) {
    return { key: 'em_risco', label: 'Em risco', tone: 'warning' };
  }
  return { key: 'saudavel', label: 'Saudável', tone: 'success' };
}

function platformRecommendation(key, title, action) {
  return { key, title, action };
}

function dedupeRecommendations(items) {
  const seen = new Set();
  return items.filter((item) => {
    if (!item?.key || seen.has(item.key)) return false;
    seen.add(item.key);
    return true;
  }).slice(0, 6);
}

async function getPlatformCompanyTimelineAdvanced(companyId) {
  const resolvedCompanyId = cleanUuid(companyId, 'empresa');
  const detail = await getPlatformCompanyDetail(resolvedCompanyId);
  const storeIds = cleanUuidArray((detail.stores || []).map((store) => store.id));
  const [products, tickets, ticketMessages, auditLogs] = await Promise.all([
    storeIds.length ? dbRequest('GET', 'menu_items', {
      select: 'id,store_id,name,created_at',
      store_id: uuidInFilter(storeIds),
      order: 'created_at.asc',
      limit: '50'
    }).catch(() => []) : Promise.resolve([]),
    dbRequest('GET', 'support_tickets', {
      select: 'id,subject,status,priority,created_at,updated_at',
      company_id: `eq.${resolvedCompanyId}`,
      order: 'created_at.desc',
      limit: '100'
    }).catch(() => []),
    dbRequest('GET', 'support_ticket_messages', {
      select: 'id,ticket_id,author_type,created_at',
      order: 'created_at.desc',
      limit: '200'
    }).catch(() => []),
    dbRequest('GET', 'audit_logs', {
      select: 'id,action,severity,entity_type,entity_id,store_id,actor_admin_id,after_data,created_at',
      company_id: `eq.${resolvedCompanyId}`,
      order: 'created_at.desc',
      limit: '120'
    }).catch(() => [])
  ]);
  const events = [...(detail.timeline || [])];
  const firstProduct = products[0];
  if (firstProduct?.created_at) {
    events.push({
      type: 'menu',
      title: 'Primeiro produto',
      description: firstProduct.name || 'Produto cadastrado',
      created_at: firstProduct.created_at
    });
  }
  for (const store of detail.stores || []) {
    if (store.settings?.onboarding_completed) {
      events.push({
        type: 'onboarding',
        title: 'Onboarding concluído',
        description: store.name,
        created_at: store.settings.updated_at || store.created_at || new Date().toISOString()
      });
    }
  }
  for (const ticket of tickets) {
    events.push({
      type: 'support',
      title: `Chamado ${subscriptionEventLabel(ticket.status)}`,
      description: ticket.subject || 'Chamado de suporte',
      created_at: ['resolved', 'closed'].includes(ticket.status) ? ticket.updated_at || ticket.created_at : ticket.created_at
    });
  }
  const ticketIds = new Set(tickets.map((ticket) => ticket.id));
  for (const message of ticketMessages.filter((entry) => ticketIds.has(entry.ticket_id)).slice(0, 30)) {
    events.push({
      type: 'support',
      title: message.author_type === 'platform' ? 'Suporte respondeu' : 'Cliente respondeu',
      description: 'Mensagem registrada no chamado.',
      created_at: message.created_at
    });
  }
  for (const log of auditLogs) {
    if (!/support|impersonate|suspend|activate|billing|subscription|onboarding|note|internal_status/i.test(log.action || '')) continue;
    events.push({
      type: String(log.action || '').includes('support') ? 'support' : 'audit',
      title: auditActionLabel(log.action),
      description: platformTimelineDescription(log),
      created_at: log.created_at
    });
  }
  return {
    company_id: resolvedCompanyId,
    timeline: uniqueTimelineEvents(events)
  };
}

function uniqueTimelineEvents(events = []) {
  const seen = new Set();
  return events
    .filter((event) => event.created_at)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .filter((event) => {
      const key = `${event.type}:${event.title}:${event.created_at}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 60);
}

async function platformCommercialSummary() {
  const now = new Date();
  const todayStart = startOfLocalDay(now);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 86400000);
  const [companies, stores, subscriptions, plans, orders, settings, subscriptionEvents, products, backup, operationalLogs] = await Promise.all([
    dbRequest('GET', 'companies', { select: '*', limit: '1000' }),
    dbRequest('GET', 'stores', { select: 'id,company_id,name,slug,is_active,created_at', limit: '2000' }),
    dbRequest('GET', 'company_subscriptions', { select: '*', order: 'created_at.desc', limit: '1000' }),
    dbRequest('GET', 'subscription_plans', { select: '*', limit: '100' }),
    dbRequest('GET', 'orders', {
      select: 'id,store_id,total,status,financial_status,payment_method,fulfillment_method,created_at',
      created_at: `gte.${thirtyDaysAgo.toISOString()}`,
      limit: '5000'
    }).catch(() => []),
    dbRequest('GET', 'store_settings', {
      select: 'store_id,whatsapp_number,onboarding_completed,is_open',
      limit: '2000'
    }).catch(() => []),
    dbRequest('GET', 'subscription_events', {
      select: 'id,company_id,event_type,created_at,metadata',
      created_at: `gte.${thirtyDaysAgo.toISOString()}`,
      limit: '1000'
    }).catch(() => []),
    dbRequest('GET', 'menu_items', {
      select: 'id,store_id,is_active',
      limit: '10000'
    }).catch(() => []),
    platformBackupStatus().catch(() => ({ status: 'unknown' })),
    listOperationalLogs(thirtyDaysAgo).catch(() => [])
  ]);
  const context = platformAnalyticsContext({ companies, stores, subscriptions, plans, orders, settings, products });
  const todayOrders = orders.filter((order) => new Date(order.created_at) >= todayStart && order.status !== 'cancelled');
  const monthOrders = orders.filter((order) => new Date(order.created_at) >= monthStart && order.status !== 'cancelled');
  const activeStatuses = new Set(['active']);
  const trialStatuses = new Set(['trial']);
  const delinquentStatuses = new Set(['payment_pending', 'grace_period', 'past_due']);
  const churnStatuses = new Set(['cancelled', 'archived']);
  const suspendedStatuses = new Set(['suspended']);
  const alerts = platformCommercialAlerts(companies, stores, context, { backup, operationalLogs });
  const delayedBackups = alerts.filter((alert) => alert.type === 'backup').length;
  const webhookErrors = alerts.filter((alert) => alert.type === 'webhook').length;
  const trialsEnding = alerts.filter((alert) => alert.type === 'trial').length;
  const revenueToday = roundMoney(todayOrders.reduce((sum, order) => sum + moneyNumber(order.total), 0));
  const mrrEstimated = platformEstimatedMrr(companies, context.subscriptionByCompany, context.planById);
  const cards = {
    active_clients: companies.filter((company) => activeStatuses.has(company.status)).length,
    trial_clients: companies.filter((company) => trialStatuses.has(company.status)).length,
    delinquent_clients: companies.filter((company) => delinquentStatuses.has(company.status)).length,
    suspended_clients: companies.filter((company) => suspendedStatuses.has(company.status)).length,
    published_stores: stores.filter((store) => store.is_active !== false).length,
    unpublished_stores: stores.filter((store) => store.is_active === false).length,
    orders_today: todayOrders.length,
    revenue_today: revenueToday,
    revenue_today_cents: moneyToCents(revenueToday),
    mrr_estimated: mrrEstimated,
    mrr_estimated_cents: moneyToCents(mrrEstimated),
    trials_ending: trialsEnding,
    webhook_errors: webhookErrors,
    delayed_backups: delayedBackups,
    churn_clients: companies.filter((company) => churnStatuses.has(company.status)).length,
    generated_without_nan: true
  };
  return {
    generated_at: new Date().toISOString(),
    cards,
    billing: platformBillingMetrics({ companies, subscriptions, plans, subscriptionEvents, monthOrders }),
    alerts
  };
}

async function platformCommercialAnalytics(params = new URLSearchParams()) {
  const period = platformAnalyticsPeriod(params.get?.('period') || '30d');
  const [companies, stores, subscriptions, plans, orders, settings, subscriptionEvents, products, accessEvents, marketingEvents] = await Promise.all([
    dbRequest('GET', 'companies', { select: '*', limit: '1000' }),
    dbRequest('GET', 'stores', { select: 'id,company_id,name,slug,is_active,created_at', limit: '2000' }),
    dbRequest('GET', 'company_subscriptions', { select: '*', order: 'created_at.desc', limit: '1000' }),
    dbRequest('GET', 'subscription_plans', { select: '*', limit: '100' }),
    dbRequest('GET', 'orders', {
      select: 'id,store_id,total,status,financial_status,payment_method,fulfillment_method,created_at',
      created_at: `gte.${period.since.toISOString()}`,
      limit: '8000'
    }).catch(() => []),
    dbRequest('GET', 'store_settings', {
      select: 'store_id,whatsapp_number,onboarding_completed,is_open',
      limit: '2000'
    }).catch(() => []),
    dbRequest('GET', 'subscription_events', {
      select: 'id,company_id,event_type,created_at,metadata',
      created_at: `gte.${period.since.toISOString()}`,
      limit: '2000'
    }).catch(() => []),
    dbRequest('GET', 'menu_items', {
      select: 'id,store_id,is_active',
      limit: '10000'
    }).catch(() => []),
    dbRequest('GET', 'access_events', {
      select: 'id,store_id,page_type,path,referrer_host,device_type,visitor_key,created_at',
      created_at: `gte.${period.since.toISOString()}`,
      limit: '10000'
    }).catch(() => []),
    dbRequest('GET', 'marketing_events', {
      select: 'id,company_id,store_id,event_name,visitor_key,attribution,properties,created_at',
      created_at: `gte.${period.since.toISOString()}`,
      limit: '10000'
    }).catch(() => [])
  ]);
  const context = platformAnalyticsContext({ companies, stores, subscriptions, plans, orders, settings, products });
  const revenue = platformRevenueSnapshot({ companies, subscriptions, plans, orders, period });
  const conversion = platformConversionSnapshot({ companies, subscriptions, subscriptionEvents, period });
  return {
    period: period.label,
    generated_at: new Date().toISOString(),
    daily: platformDailySeries(orders, period),
    ranking: platformStoreRanking(orders, context.storeById).slice(0, 8),
    by_payment: platformGroupOrders(orders.filter((order) => order.status !== 'cancelled'), 'payment_method'),
    by_status: platformGroupOrders(orders, 'status'),
    company_metrics: platformCompanyMetrics(companies, context),
    comparison: platformAnalyticsComparison(orders, period),
    revenue,
    conversion,
    new_clients_daily: platformNewClientsDaily(companies, period),
    mrr_by_plan: revenue.mrr_by_plan,
    marketing: platformMarketingFunnelSnapshot(marketingEvents, subscriptionEvents),
    access: platformAccessSnapshot(accessEvents, period, context.storeById)
  };
}

function platformMarketingFunnelSnapshot(events = [], subscriptionEvents = []) {
  const names = ['demo_started', 'signup_started', 'signup_completed', 'first_product_created', 'menu_published', 'first_order_received'];
  const eventCompanies = (name) => new Set(events.filter((event) => event.event_name === name).map((event) => event.company_id || event.visitor_key || event.id));
  const counts = Object.fromEntries(names.map((name) => [name, eventCompanies(name).size]));
  counts.subscription_activated = new Set(subscriptionEvents
    .filter((event) => /(paid|payment_approved|activate|active)/i.test(event.event_type || ''))
    .map((event) => event.company_id).filter(Boolean)).size;
  const sources = new Map();
  for (const event of events.filter((entry) => entry.event_name === 'signup_completed')) {
    const source = cleanText(event.attribution?.utm_source || event.attribution?.referrer_host || 'Direto');
    sources.set(source, (sources.get(source) || 0) + 1);
  }
  const rate = (part, total) => total ? Number(((part / total) * 100).toFixed(1)) : 0;
  return {
    stages: counts,
    rates: {
      signup_to_publish: rate(counts.menu_published, counts.signup_completed),
      publish_to_first_order: rate(counts.first_order_received, counts.menu_published),
      signup_to_paid: rate(counts.subscription_activated, counts.signup_completed)
    },
    attributed_signups: events.filter((event) => event.event_name === 'signup_completed' && hasMarketingAttribution(event.attribution || {})).length,
    by_source: [...sources.entries()].map(([source, count]) => ({ source, count })).sort((a, b) => b.count - a.count).slice(0, 8)
  };
}

function platformAnalyticsContext({ companies, stores, subscriptions, plans, orders, settings, products = [] }) {
  const storeById = new Map(stores.map((store) => [store.id, store]));
  const settingsByStore = new Map(settings.map((row) => [row.store_id, row]));
  const planById = new Map(plans.map((plan) => [plan.id, plan]));
  const productsByStore = new Map();
  for (const product of products || []) {
    if (!productsByStore.has(product.store_id)) productsByStore.set(product.store_id, []);
    productsByStore.get(product.store_id).push(product);
  }
  const subscriptionByCompany = new Map();
  for (const subscription of subscriptions) {
    if (!subscriptionByCompany.has(subscription.company_id)) subscriptionByCompany.set(subscription.company_id, subscription);
  }
  const storesByCompany = new Map();
  for (const store of stores) {
    if (!storesByCompany.has(store.company_id)) storesByCompany.set(store.company_id, []);
    storesByCompany.get(store.company_id).push(store);
  }
  const ordersByCompany = new Map();
  for (const order of orders) {
    const store = storeById.get(order.store_id);
    if (!store?.company_id) continue;
    if (!ordersByCompany.has(store.company_id)) ordersByCompany.set(store.company_id, []);
    ordersByCompany.get(store.company_id).push(order);
  }
  return { storeById, settingsByStore, productsByStore, planById, subscriptionByCompany, storesByCompany, ordersByCompany };
}

async function platformExecutiveAlerts(params = new URLSearchParams()) {
  const period = platformAnalyticsPeriod(params.get?.('period') || '30d');
  const [companies, stores, subscriptions, plans, orders, settings, products, backup, operationalLogs] = await Promise.all([
    dbRequest('GET', 'companies', { select: '*', limit: '1000' }),
    dbRequest('GET', 'stores', { select: 'id,company_id,name,slug,is_active,created_at', limit: '2000' }),
    dbRequest('GET', 'company_subscriptions', { select: '*', order: 'created_at.desc', limit: '1000' }),
    dbRequest('GET', 'subscription_plans', { select: '*', limit: '100' }),
    dbRequest('GET', 'orders', {
      select: 'id,store_id,total,status,created_at',
      created_at: `gte.${period.since.toISOString()}`,
      limit: '8000'
    }).catch(() => []),
    dbRequest('GET', 'store_settings', { select: 'store_id,whatsapp_number,onboarding_completed,is_open', limit: '2000' }).catch(() => []),
    dbRequest('GET', 'menu_items', { select: 'id,store_id,is_active', limit: '10000' }).catch(() => []),
    platformBackupStatus().catch(() => ({ status: 'unknown' })),
    listOperationalLogs(period.since).catch(() => [])
  ]);
  const context = platformAnalyticsContext({ companies, stores, subscriptions, plans, orders, settings, products });
  return {
    period: period.label,
    generated_at: new Date().toISOString(),
    alerts: platformCommercialAlerts(companies, stores, context, { backup, operationalLogs })
  };
}

async function platformExecutiveRevenue(params = new URLSearchParams()) {
  const period = platformAnalyticsPeriod(params.get?.('period') || '30d');
  const [companies, subscriptions, plans, orders] = await Promise.all([
    dbRequest('GET', 'companies', { select: '*', limit: '1000' }),
    dbRequest('GET', 'company_subscriptions', { select: '*', order: 'created_at.desc', limit: '1000' }),
    dbRequest('GET', 'subscription_plans', { select: '*', limit: '100' }),
    dbRequest('GET', 'orders', {
      select: 'id,store_id,total,status,created_at',
      created_at: `gte.${period.since.toISOString()}`,
      limit: '8000'
    }).catch(() => [])
  ]);
  return {
    period: period.label,
    generated_at: new Date().toISOString(),
    ...platformRevenueSnapshot({ companies, subscriptions, plans, orders, period })
  };
}

async function platformExecutiveConversion(params = new URLSearchParams()) {
  const period = platformAnalyticsPeriod(params.get?.('period') || '30d');
  const [companies, subscriptions, subscriptionEvents] = await Promise.all([
    dbRequest('GET', 'companies', { select: '*', limit: '1000' }),
    dbRequest('GET', 'company_subscriptions', { select: '*', order: 'created_at.desc', limit: '1000' }),
    dbRequest('GET', 'subscription_events', {
      select: 'id,company_id,event_type,created_at,metadata',
      created_at: `gte.${period.since.toISOString()}`,
      limit: '2000'
    }).catch(() => [])
  ]);
  return {
    period: period.label,
    generated_at: new Date().toISOString(),
    ...platformConversionSnapshot({ companies, subscriptions, subscriptionEvents, period })
  };
}

async function platformBillingDataset(params = new URLSearchParams()) {
  const period = platformAnalyticsPeriod(params.get?.('period') || '30d');
  const since = period.since.toISOString();
  const [companies, subscriptions, plans, events, stores, orders] = await Promise.all([
    dbRequest('GET', 'companies', { select: '*', limit: '1500' }),
    dbRequest('GET', 'company_subscriptions', { select: '*', order: 'created_at.desc', limit: '2000' }).catch(() => []),
    dbRequest('GET', 'subscription_plans', { select: '*', order: 'sort_order.asc', limit: '200' }).catch(() => []),
    dbRequest('GET', 'subscription_events', {
      select: '*',
      created_at: `gte.${since}`,
      order: 'created_at.desc',
      limit: '2000'
    }).catch(() => []),
    dbRequest('GET', 'stores', { select: 'id,company_id', limit: '3000' }).catch(() => []),
    dbRequest('GET', 'orders', {
      select: 'id,store_id,total,status,created_at',
      created_at: `gte.${since}`,
      limit: '10000'
    }).catch(() => [])
  ]);
  const planById = new Map(plans.map((plan) => [plan.id, plan]));
  const companyById = new Map(companies.map((company) => [company.id, company]));
  const subscriptionsByCompany = new Map();
  for (const subscription of subscriptions) {
    if (!subscriptionsByCompany.has(subscription.company_id)) subscriptionsByCompany.set(subscription.company_id, []);
    subscriptionsByCompany.get(subscription.company_id).push(subscription);
  }
  const subscriptionById = new Map(subscriptions.map((subscription) => [subscription.id, subscription]));
  const storeCompanyById = new Map(stores.map((store) => [store.id, store.company_id]));
  const billableOrders = orders.filter((order) => order.status !== 'cancelled');
  return {
    period,
    companies,
    subscriptions,
    plans,
    events,
    stores,
    orders,
    billableOrders,
    planById,
    companyById,
    subscriptionsByCompany,
    subscriptionById,
    storeCompanyById
  };
}

async function platformBillingSummary(params = new URLSearchParams()) {
  const data = await platformBillingDataset(params);
  const rows = data.companies.map((company) => {
    const subscription = pickCurrentCompanySubscription(data.subscriptionsByCompany.get(company.id) || []);
    const plan = subscription?.plan_id ? data.planById.get(subscription.plan_id) || null : null;
    return { company, subscription, plan, status: platformSubscriptionStatus(subscription, company), price_cents: moneyToCents(plan?.monthly_price || 0) };
  });
  const activeRows = rows.filter((row) => ['active', 'trial', 'grace_period', 'payment_pending', 'past_due'].includes(row.status));
  const riskRows = rows.filter((row) => ['trial', 'grace_period', 'payment_pending', 'past_due'].includes(row.status));
  const lostRows = rows.filter((row) => ['cancelled', 'expired', 'suspended', 'blocked', 'archived'].includes(row.status));
  const pendingRows = rows.filter((row) => ['payment_pending', 'grace_period', 'past_due'].includes(row.status));
  const orderRevenueCents = data.billableOrders.reduce((sum, order) => sum + moneyToCents(order.total), 0);
  const payingClients = rows.filter((row) => ['active', 'grace_period', 'payment_pending', 'past_due'].includes(row.status) && row.price_cents > 0);
  const eventCounts = billingEventCounts(data.events);
  const statusCounts = rows.reduce((acc, row) => {
    const key = billingDisplayStatus(row.status);
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
  return {
    period: data.period.label,
    generated_at: new Date().toISOString(),
    mrr_total_cents: activeRows.reduce((sum, row) => sum + row.price_cents, 0),
    mrr_active_cents: rows.filter((row) => row.status === 'active').reduce((sum, row) => sum + row.price_cents, 0),
    mrr_at_risk_cents: riskRows.reduce((sum, row) => sum + row.price_cents, 0),
    pending_revenue_cents: pendingRows.reduce((sum, row) => sum + row.price_cents, 0),
    lost_revenue_cents: lostRows.reduce((sum, row) => sum + row.price_cents, 0),
    delinquency: {
      clients: pendingRows.length,
      rate: rows.length ? Number(((pendingRows.length / rows.length) * 100).toFixed(1)) : 0
    },
    average_ticket_per_client_cents: payingClients.length ? Math.round(orderRevenueCents / payingClients.length) : 0,
    order_revenue_cents: orderRevenueCents,
    subscriptions_by_status: statusCounts,
    events: eventCounts,
    alerts: platformBillingAlerts(rows)
  };
}

async function platformBillingPlans() {
  const data = await platformBillingDataset(new URLSearchParams('period=30d'));
  const rows = data.plans.map((plan) => {
    const subscriptions = data.subscriptions.filter((subscription) => subscription.plan_id === plan.id);
    const current = subscriptions.filter((subscription) => ['active', 'trial', 'grace_period', 'payment_pending', 'past_due'].includes(subscription.status));
    return {
      id: plan.id,
      code: plan.code,
      name: plan.name,
      description: plan.description,
      monthly_price: moneyNumber(plan.monthly_price || 0),
      monthly_price_cents: moneyToCents(plan.monthly_price || 0),
      is_active: plan.is_active !== false,
      sort_order: Number(plan.sort_order || 0),
      active_subscriptions: current.length,
      mrr_cents: current.length * moneyToCents(plan.monthly_price || 0)
    };
  });
  return { plans: rows };
}

async function platformBillingEvents(params = new URLSearchParams()) {
  const data = await platformBillingDataset(params);
  const statusFilter = cleanSlug(params.get?.('status') || '');
  const planFilter = cleanSlug(params.get?.('plan') || '');
  const events = data.events.map((event) => {
    const subscription = event.subscription_id ? data.subscriptionById.get(event.subscription_id) || null : null;
    const company = data.companyById.get(event.company_id) || null;
    const plan = subscription?.plan_id ? data.planById.get(subscription.plan_id) || null : null;
    const metadata = event.metadata || {};
    return {
      id: event.id,
      company_id: event.company_id,
      company_name: company?.name || 'Cliente',
      subscription_id: event.subscription_id,
      event_type: event.event_type,
      label: billingEventLabel(event.event_type),
      status: cleanSlug(metadata.status || event.event_type || ''),
      amount_cents: Number(metadata.amount_cents || metadata.price_cents || 0),
      provider: metadata.provider || subscription?.billing_provider || 'manual',
      external_reference: metadata.provider_event_id || metadata.external_reference || subscription?.external_subscription_id || null,
      plan_code: metadata.plan_code || plan?.code || null,
      plan_name: metadata.plan_name || plan?.name || null,
      description: event.description || '',
      created_at: event.created_at
    };
  }).filter((event) => {
    if (statusFilter && !String(event.status || event.event_type || '').includes(statusFilter)) return false;
    if (planFilter && event.plan_code !== planFilter) return false;
    return true;
  });
  return { events };
}

async function platformBillingSubscriptions(params = new URLSearchParams()) {
  const data = await platformBillingDataset(params);
  const statusFilter = cleanSlug(params.get?.('status') || '');
  const planFilter = cleanSlug(params.get?.('plan') || '');
  const rows = data.companies.map((company) => {
    const subscription = pickCurrentCompanySubscription(data.subscriptionsByCompany.get(company.id) || []);
    const plan = subscription?.plan_id ? data.planById.get(subscription.plan_id) || null : null;
    const status = platformSubscriptionStatus(subscription, company);
    return {
      company_id: company.id,
      company_name: company.name,
      company_status: company.status,
      billing_email: company.billing_email || null,
      phone: company.phone || null,
      subscription_id: subscription?.id || null,
      status,
      display_status: billingDisplayStatus(status),
      plan_id: plan?.id || null,
      plan_code: plan?.code || null,
      plan_name: plan?.name || 'Sem plano',
      started_at: subscription?.current_period_starts_at || subscription?.created_at || company.created_at || null,
      trial_ends_at: subscription?.trial_ends_at || null,
      current_period_ends_at: subscription?.current_period_ends_at || null,
      next_renewal_at: subscription?.next_renewal_at || null,
      payment_due_at: subscription?.payment_due_at || null,
      cancelled_at: subscription?.cancelled_at || null,
      value_cents: moneyToCents(plan?.monthly_price || 0),
      provider: subscription?.billing_provider || 'manual',
      external_reference: subscription?.external_subscription_id || null,
      metadata: sanitizeBillingMetadata(subscription?.metadata || {})
    };
  }).filter((row) => {
    if (statusFilter && row.status !== statusFilter && row.display_status !== statusFilter) return false;
    if (planFilter && row.plan_code !== planFilter) return false;
    return true;
  });
  return { subscriptions: rows };
}

async function platformBillingAddons(params = new URLSearchParams()) {
  const statusFilter = cleanSlug(params.get?.('status') || '');
  const rows = await dbRequest('GET', 'store_subscription_addons', {
    select: '*',
    order: 'created_at.desc',
    limit: '500'
  }).catch(() => []);
  const companyIds = cleanUuidArray(rows.map((entry) => entry.company_id));
  const storeIds = cleanUuidArray(rows.map((entry) => entry.store_id));
  const addonIds = cleanUuidArray(rows.map((entry) => entry.addon_id));
  const subscriptionIds = cleanUuidArray(rows.map((entry) => entry.subscription_id));
  const [companies, stores, addonsRows, subscriptions] = await Promise.all([
    companyIds.length ? dbRequest('GET', 'companies', { select: 'id,name,status,billing_email,phone', id: uuidInFilter(companyIds), limit: '500' }).catch(() => []) : [],
    storeIds.length ? dbRequest('GET', 'stores', { select: 'id,name,slug,is_active', id: uuidInFilter(storeIds), limit: '500' }).catch(() => []) : [],
    addonIds.length ? dbRequest('GET', 'plan_addons', { select: '*', id: uuidInFilter(addonIds), limit: '100' }).catch(() => []) : [],
    subscriptionIds.length ? dbRequest('GET', 'company_subscriptions', { select: 'id,status,plan_id', id: uuidInFilter(subscriptionIds), limit: '500' }).catch(() => []) : []
  ]);
  const planIds = cleanUuidArray(subscriptions.map((entry) => entry.plan_id));
  const plans = planIds.length ? await dbRequest('GET', 'subscription_plans', { select: 'id,code,name,monthly_price', id: uuidInFilter(planIds), limit: '100' }).catch(() => []) : [];
  const companyById = new Map(companies.map((entry) => [entry.id, entry]));
  const storeById = new Map(stores.map((entry) => [entry.id, entry]));
  const addonById = new Map(addonsRows.map((entry) => [entry.id, entry]));
  const subscriptionById = new Map(subscriptions.map((entry) => [entry.id, entry]));
  const planById = new Map(plans.map((entry) => [entry.id, entry]));
  const addons = rows.map((entry) => ({
    id: entry.id,
    company_id: entry.company_id,
    company_name: companyById.get(entry.company_id)?.name || 'Cliente',
    store_id: entry.store_id,
    store_name: storeById.get(entry.store_id)?.name || 'Loja',
    store_slug: storeById.get(entry.store_id)?.slug || '',
    addon_id: entry.addon_id,
    addon_code: addonById.get(entry.addon_id)?.code || '',
    addon_name: addonById.get(entry.addon_id)?.name || 'Adicional',
    status: entry.status || 'unknown',
    provider: entry.provider || 'manual',
    price_cents: Number(addonById.get(entry.addon_id)?.monthly_price_cents || 0),
    provider_cost_cents: Number(addonById.get(entry.addon_id)?.provider_cost_cents || 0),
    estimated_margin_cents: Number(addonById.get(entry.addon_id)?.monthly_price_cents || 0) - Number(addonById.get(entry.addon_id)?.provider_cost_cents || 0),
    external_transaction_id: entry.external_transaction_id || null,
    current_period_ends_at: entry.current_period_ends_at || null,
    next_renewal_at: entry.next_renewal_at || null,
    activated_at: entry.activated_at || null,
    plan_name: planById.get(subscriptionById.get(entry.subscription_id)?.plan_id)?.name || null,
    plan_code: planById.get(subscriptionById.get(entry.subscription_id)?.plan_id)?.code || null
  })).filter((entry) => !statusFilter || entry.status === statusFilter);
  const active = addons.filter((entry) => entry.status === 'active');
  return {
    addons,
    summary: {
      active_count: active.length,
      active_revenue_cents: active.reduce((sum, entry) => sum + entry.price_cents, 0),
      provider_cost_cents: active.reduce((sum, entry) => sum + entry.provider_cost_cents, 0),
      estimated_margin_cents: active.reduce((sum, entry) => sum + entry.estimated_margin_cents, 0)
    }
  };
}

function platformSubscriptionStatus(subscription, company) {
  const raw = cleanSlug(subscription?.status || company?.status || 'unknown');
  if (raw === 'suspended') return 'blocked';
  if (raw === 'payment_pending') return 'past_due';
  return raw || 'unknown';
}

function billingDisplayStatus(status) {
  const value = cleanSlug(status || '');
  if (value === 'suspended') return 'blocked';
  return value;
}

function billingEventCounts(events = []) {
  const count = (patterns) => events.filter((event) => patterns.some((pattern) => pattern.test(String(event.event_type || '')))).length;
  return {
    payment_approved: count([/paid/i, /payment_approved/i, /billing\.active/i, /subscription_reactivated/i]),
    payment_refused: count([/refused/i, /rejected/i, /failed/i, /webhook_failed/i]),
    webhook_received: count([/billing\./i, /webhook/i]),
    webhook_error: count([/webhook_failed/i, /failed/i]),
    plan_changed: count([/plan/i, /change/i]),
    upgrades: count([/upgrade/i]),
    downgrades: count([/downgrade/i]),
    cancellations: count([/cancel/i]),
    reactivations: count([/reactivat/i])
  };
}

function platformBillingAlerts(rows = []) {
  const alerts = [];
  const now = Date.now();
  const graceExpired = rows.filter((row) => {
    const due = row.subscription?.payment_due_at || row.subscription?.current_period_ends_at;
    return row.status === 'grace_period' && due && new Date(due).getTime() < now;
  });
  const pastDue = rows.filter((row) => ['past_due', 'payment_pending'].includes(row.status));
  const trialsEnding = rows.filter((row) => {
    if (row.status !== 'trial' || !row.subscription?.trial_ends_at) return false;
    const days = Math.ceil((new Date(row.subscription.trial_ends_at).getTime() - now) / 86400000);
    return days >= 0 && days <= 3;
  });
  if (graceExpired.length) alerts.push({ type: 'grace_period', severity: 'critical', title: `${graceExpired.length} cliente(s) passaram do grace period`, action: 'Bloquear recursos pagos ou reativar após pagamento.' });
  if (pastDue.length) alerts.push({ type: 'past_due', severity: 'warning', title: `${pastDue.length} cobrança(s) pendente(s)`, action: 'Conferir Abacate Pay e reenviar cobrança.' });
  if (trialsEnding.length) alerts.push({ type: 'trial', severity: 'attention', title: `${trialsEnding.length} trial(s) perto do fim`, action: 'Acionar comercial para conversão.' });
  return alerts;
}

function billingEventLabel(type) {
  const value = String(type || '');
  const labels = {
    'checkout_created': 'Checkout criado',
    'billing.active': 'Pagamento aprovado',
    'billing.past_due': 'Pagamento vencido',
    'billing.payment_pending': 'Pagamento pendente',
    'billing.webhook_failed': 'Webhook com erro',
    'platform.upgrade': 'Upgrade',
    'platform.downgrade': 'Downgrade',
    'platform.same_plan': 'Plano mantido',
    'platform.subscription_cancelled': 'Cancelamento',
    'platform.subscription_reactivated': 'Reativação',
    'billing.resend_requested': 'Reenvio solicitado'
  };
  return labels[value] || subscriptionEventLabel(value || 'Evento financeiro');
}

function sanitizeBillingMetadata(metadata = {}) {
  const allowed = {};
  for (const key of ['source', 'plan_code', 'plan_name', 'change_type', 'amount_cents', 'status', 'provider']) {
    if (metadata[key] !== undefined) allowed[key] = metadata[key];
  }
  if (Array.isArray(metadata.downgrade_warnings)) allowed.downgrade_warnings = metadata.downgrade_warnings;
  return allowed;
}

function platformCompanyMetrics(companies, context) {
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  return companies.map((company) => {
    const subscription = context.subscriptionByCompany.get(company.id) || null;
    const plan = subscription?.plan_id ? context.planById.get(subscription.plan_id) : null;
    const stores = context.storesByCompany.get(company.id) || [];
    const orders = context.ordersByCompany.get(company.id) || [];
    const products = stores.flatMap((store) => context.productsByStore?.get(store.id) || []);
    const settings = stores.map((store) => context.settingsByStore?.get(store.id)).filter(Boolean);
    const monthOrders = orders.filter((order) => new Date(order.created_at) >= monthStart && order.status !== 'cancelled');
    const lastOrder = orders.slice().sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0] || null;
    const lastAccessAt = company.last_login_at || null;
    return {
      company_id: company.id,
      stores_count: stores.length,
      active_stores_count: stores.filter((store) => store.is_active !== false).length,
      unpublished_stores_count: stores.filter((store) => store.is_active === false).length,
      plan_name: plan?.name || 'Sem plano',
      plan_code: plan?.code || '',
      subscription_status: subscription?.status || company.status || 'unknown',
      mrr: moneyNumber(plan?.monthly_price || 0),
      mrr_cents: moneyToCents(plan?.monthly_price || 0),
      orders_month: monthOrders.length,
      revenue_month: roundMoney(monthOrders.reduce((sum, order) => sum + moneyNumber(order.total), 0)),
      revenue_month_cents: moneyToCents(monthOrders.reduce((sum, order) => sum + moneyNumber(order.total), 0)),
      last_order_at: lastOrder?.created_at || null,
      last_access_at: lastAccessAt,
      products_count: products.length,
      active_products_count: products.filter((item) => item.is_active !== false).length,
      stores_without_whatsapp_count: stores.length - settings.filter((setting) => setting.whatsapp_number).length,
      incomplete_onboarding_count: settings.filter((setting) => setting.onboarding_completed === false).length,
      has_orders: orders.length > 0
    };
  });
}

function platformDailySeries(orders, period) {
  const days = [];
  for (let cursor = new Date(period.start); cursor <= period.end; cursor.setDate(cursor.getDate() + 1)) {
    days.push({ date: cursor.toISOString().slice(0, 10), orders: 0, revenue: 0, revenue_cents: 0 });
  }
  const byDate = new Map(days.map((day) => [day.date, day]));
  for (const order of orders) {
    const key = new Date(order.created_at).toISOString().slice(0, 10);
    const row = byDate.get(key);
    if (!row) continue;
    row.orders += 1;
    if (order.status !== 'cancelled') {
      row.revenue = roundMoney(row.revenue + moneyNumber(order.total));
      row.revenue_cents = moneyToCents(row.revenue);
    }
  }
  return days;
}

function platformStoreRanking(orders, storeById) {
  const grouped = new Map();
  for (const order of orders) {
    const store = storeById.get(order.store_id);
    if (!store) continue;
    const current = grouped.get(order.store_id) || {
      store_id: order.store_id,
      store_name: store.name || store.slug || 'Loja',
      slug: store.slug || '',
      orders: 0,
      revenue: 0,
      revenue_cents: 0
    };
    current.orders += 1;
    if (order.status !== 'cancelled') {
      current.revenue = roundMoney(current.revenue + moneyNumber(order.total));
      current.revenue_cents = moneyToCents(current.revenue);
    }
    grouped.set(order.store_id, current);
  }
  return [...grouped.values()].sort((a, b) => b.orders - a.orders || b.revenue - a.revenue);
}

async function recordAccessEvent(req, data = {}) {
  const pageType = accessPageType(data.page_type || data.pageType);
  const pathValue = cleanPublicPath(data.path || data.pathname || '');
  const referrerHost = referrerHostFromValue(data.referrer || data.referrer_host || req.headers.referer || '');
  const visitorKey = accessVisitorKey(req, data.visitor_key || data.visitorKey || '');
  const attribution = sanitizeMarketingAttribution({
    ...(isPlainObject(data.attribution) ? data.attribution : {}),
    utm_source: data.utm_source,
    utm_medium: data.utm_medium,
    utm_campaign: data.utm_campaign,
    utm_content: data.utm_content,
    utm_term: data.utm_term,
    landing_path: pathValue,
    referrer_host: referrerHost,
    visitor_key: visitorKey
  });
  const store = await resolveAccessStore(req, data, pathValue).catch(() => null);
  await dbRequest('POST', 'access_events', {}, {
    company_id: store?.company_id || null,
    store_id: store?.id || null,
    page_type: pageType,
    path: pathValue,
    referrer_host: referrerHost,
    device_type: accessDeviceType(data.device_type || data.deviceType || req.headers['user-agent'] || ''),
    visitor_key: visitorKey,
    metadata: {
      title: cleanText(data.title || '').slice(0, 120),
      source: cleanText(data.source || 'web').slice(0, 40),
      attribution
    }
  }, ['Prefer: return=minimal']);
  return { attribution: hasMarketingAttribution(attribution) ? attribution : null };
}

async function recordPublicMarketingEvent(req, data = {}) {
  const eventName = cleanMarketingEventName(data.event_name || data.eventName || '');
  const allowed = new Set(['content_view', 'landing_view', 'demo_started', 'signup_started']);
  if (!allowed.has(eventName)) throw httpError(422, 'Evento de marketing inválido.');
  const attribution = marketingAttributionFromRequest(req, data.attribution);
  await recordMarketingMilestone(eventName, {
    visitorKey: attribution.visitor_key || accessVisitorKey(req, data.visitor_key || ''),
    attribution,
    properties: {
      path: cleanPublicPath(data.path || '/'),
      content_id: cleanText(data.content_id || '').slice(0, 100),
      placement: cleanText(data.placement || '').slice(0, 80)
    }
  });
}

async function recordMarketingMilestone(eventName, options = {}) {
  const database = options.db || dbRequest;
  const payload = {
    company_id: cleanUuid(options.companyId) || null,
    store_id: cleanUuid(options.storeId) || null,
    event_name: cleanMarketingEventName(eventName),
    visitor_key: cleanText(options.visitorKey || '').slice(0, 80) || null,
    idempotency_key: cleanText(options.idempotencyKey || '').slice(0, 180) || null,
    attribution: sanitizeMarketingAttribution(options.attribution),
    properties: sanitizeMarketingProperties(options.properties)
  };
  if (!payload.event_name) return null;
  if (payload.idempotency_key) {
    const existing = await database('GET', 'marketing_events', {
      select: 'id', idempotency_key: `eq.${payload.idempotency_key}`, limit: '1'
    }).catch(() => []);
    if (existing[0]) return existing[0];
  }
  const rows = await database('POST', 'marketing_events', {}, payload, ['Prefer: return=representation']).catch((error) => {
    if (isUniqueViolation(error)) return [];
    throw error;
  });
  return rows[0] || null;
}

function cleanMarketingEventName(value = '') {
  return String(value || '').trim().toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 80);
}

function sanitizeMarketingAttribution(value = {}) {
  const data = isPlainObject(value) ? value : {};
  const limited = (key, max = 100) => cleanText(data[key] || '').slice(0, max);
  return {
    utm_source: limited('utm_source', 80),
    utm_medium: limited('utm_medium', 80),
    utm_campaign: limited('utm_campaign', 120),
    utm_content: limited('utm_content', 120),
    utm_term: limited('utm_term', 120),
    landing_path: cleanPublicPath(data.landing_path || '/').slice(0, 220),
    referrer_host: referrerHostFromValue(data.referrer_host || ''),
    visitor_key: limited('visitor_key', 80)
  };
}

async function marketingAttributionJourney(current = {}) {
  const fallback = sanitizeMarketingAttribution(current);
  if (!fallback.visitor_key) return { first: fallback, last: fallback };
  const events = await dbRequest('GET', 'marketing_events', {
    select: 'attribution,created_at',
    visitor_key: `eq.${fallback.visitor_key}`,
    order: 'created_at.asc',
    limit: '500'
  }).catch(() => []);
  const touches = events.map((event) => sanitizeMarketingAttribution(event.attribution)).filter(hasMarketingAttribution);
  return { first: touches[0] || fallback, last: touches[touches.length - 1] || fallback };
}

function sanitizeMarketingProperties(value = {}) {
  if (!isPlainObject(value)) return {};
  return Object.fromEntries(Object.entries(value).slice(0, 20).map(([key, item]) => [
    cleanSlug(key).slice(0, 60),
    typeof item === 'number' || typeof item === 'boolean' ? item : cleanText(item || '').slice(0, 240)
  ]).filter(([key]) => key));
}

function hasMarketingAttribution(value = {}) {
  return Boolean(value.utm_source || value.utm_medium || value.utm_campaign || value.referrer_host);
}

function marketingAttributionFromRequest(req, explicit = {}) {
  let stored = {};
  const raw = parseCookies(req || { headers: {} })[MARKETING_ATTRIBUTION_COOKIE] || '';
  if (raw) {
    try { stored = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8')); } catch {}
  }
  return sanitizeMarketingAttribution({ ...stored, ...(isPlainObject(explicit) ? explicit : {}) });
}

function marketingAttributionCookie(req, attribution = {}) {
  const secure = COOKIE_SECURE ? '; Secure' : '';
  const hostname = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].split(':')[0].toLowerCase();
  const domain = hostname === 'taprontomenu.com.br' || hostname.endsWith('.taprontomenu.com.br') ? '; Domain=taprontomenu.com.br' : '';
  const encoded = Buffer.from(JSON.stringify(sanitizeMarketingAttribution(attribution)), 'utf8').toString('base64url');
  return `${MARKETING_ATTRIBUTION_COOKIE}=${encodeURIComponent(encoded)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${60 * 60 * 24 * 90}${domain}${secure}`;
}

async function resolveAccessStore(req, data = {}, pathValue = '') {
  const hostStore = await getStoreByHost(req).catch(() => null);
  if (hostStore) return hostStore;
  const slug = cleanSlug(data.store_slug || data.storeSlug || firstPublicPathSegment(pathValue));
  return slug ? await getStoreBySlug(slug).catch(() => null) : null;
}

function accessPageType(value) {
  const type = cleanSlug(value || 'page');
  if (['home', 'cardapio', 'ajuda', 'checkout', 'pedido', 'conta'].includes(type)) return type;
  return 'page';
}

function cleanPublicPath(value) {
  const text = String(value || '/').split('#')[0].slice(0, 220);
  return text.startsWith('/') ? text : `/${text}`;
}

function referrerHostFromValue(value) {
  try {
    const text = String(value || '').trim();
    if (!text) return '';
    return new URL(text, 'https://taprontomenu.com.br').hostname.replace(/^www\./i, '').slice(0, 120);
  } catch {
    return '';
  }
}

function accessVisitorKey(req, explicitKey = '') {
  const explicit = cleanText(explicitKey || '').slice(0, 80);
  if (explicit) return explicit;
  const raw = `${clientKey(req)}|${String(req.headers['user-agent'] || '').slice(0, 180)}`;
  return createHash('sha256').update(raw).digest('hex').slice(0, 32);
}

function accessDeviceType(value) {
  const text = String(value || '').toLowerCase();
  if (['desktop', 'mobile', 'tablet'].includes(text)) return text;
  if (/ipad|tablet/.test(text)) return 'tablet';
  if (/android|iphone|mobile|windows phone/.test(text)) return 'mobile';
  return 'desktop';
}

function platformAccessSnapshot(events = [], period, storeById = new Map()) {
  const totalViews = events.length;
  const visitors = new Set(events.map((event) => event.visitor_key).filter(Boolean));
  const groupedByDate = new Map();
  for (let cursor = new Date(period.start); cursor <= period.end; cursor.setDate(cursor.getDate() + 1)) {
    groupedByDate.set(cursor.toISOString().slice(0, 10), { date: cursor.toISOString().slice(0, 10), views: 0, visitors: new Set() });
  }
  const byPage = new Map();
  const byDevice = new Map();
  const byReferrer = new Map();
  const byChannel = new Map();
  const byStore = new Map();
  for (const event of events) {
    const dateKey = new Date(event.created_at).toISOString().slice(0, 10);
    const dateRow = groupedByDate.get(dateKey);
    if (dateRow) {
      dateRow.views += 1;
      if (event.visitor_key) dateRow.visitors.add(event.visitor_key);
    }
    const page = event.page_type || 'page';
    byPage.set(page, (byPage.get(page) || 0) + 1);
    const device = event.device_type || 'desktop';
    byDevice.set(device, (byDevice.get(device) || 0) + 1);
    const referrer = event.referrer_host || 'Direto';
    byReferrer.set(referrer, (byReferrer.get(referrer) || 0) + 1);
    const channel = accessAcquisitionChannel(event.referrer_host);
    byChannel.set(channel, (byChannel.get(channel) || 0) + 1);
    if (event.store_id) {
      const store = storeById.get(event.store_id) || {};
      const current = byStore.get(event.store_id) || {
        store_id: event.store_id,
        store_name: store.name || store.slug || 'Loja',
        slug: store.slug || '',
        views: 0,
        visitors: new Set()
      };
      current.views += 1;
      if (event.visitor_key) current.visitors.add(event.visitor_key);
      byStore.set(event.store_id, current);
    }
  }
  const mapped = (map, keyName = 'key') => [...map.entries()]
    .map(([key, count]) => ({ [keyName]: key, count }))
    .sort((a, b) => b.count - a.count);
  return {
    total_views: totalViews,
    unique_visitors: visitors.size,
    average_views_per_visitor: visitors.size ? Number((totalViews / visitors.size).toFixed(1)) : 0,
    daily: [...groupedByDate.values()].map((row) => ({ date: row.date, views: row.views, visitors: row.visitors.size })),
    by_page: mapped(byPage, 'page_type'),
    by_device: mapped(byDevice, 'device_type'),
    by_referrer: mapped(byReferrer, 'referrer'),
    by_channel: mapped(byChannel, 'channel'),
    top_stores: [...byStore.values()]
      .map((row) => ({ ...row, visitors: row.visitors.size }))
      .sort((a, b) => b.views - a.views)
      .slice(0, 8)
  };
}

function accessAcquisitionChannel(referrerHost = '') {
  const host = String(referrerHost || '').trim().toLowerCase().replace(/^www\./, '');
  if (!host) return 'Direto';
  if (/(^|\.)(google\.|bing\.com$|yahoo\.|duckduckgo\.com$|ecosia\.org$)/.test(host)) return 'Busca orgânica';
  if (/(^|\.)(instagram\.com$|facebook\.com$|fb\.com$|tiktok\.com$|youtube\.com$|linkedin\.com$)/.test(host)) return 'Redes sociais';
  if (host === 'taprontomenu.com.br' || host.endsWith('.taprontomenu.com.br')) return 'Interno';
  return 'Referência';
}

function platformGroupOrders(orders, field) {
  const grouped = new Map();
  for (const order of orders) {
    const key = order[field] || 'Não informado';
    const current = grouped.get(key) || { key, count: 0, revenue: 0, revenue_cents: 0 };
    current.count += 1;
    current.revenue = roundMoney(current.revenue + moneyNumber(order.total));
    current.revenue_cents = moneyToCents(current.revenue);
    grouped.set(key, current);
  }
  return [...grouped.values()].sort((a, b) => b.count - a.count || b.revenue - a.revenue);
}

function platformAnalyticsComparison(orders, period) {
  const midpoint = new Date(period.end.getTime() - Math.floor((period.end - period.start) / 2));
  const previous = orders.filter((order) => new Date(order.created_at) < midpoint);
  const current = orders.filter((order) => new Date(order.created_at) >= midpoint);
  const totals = (rows) => ({
    orders: rows.length,
    revenue: roundMoney(rows.filter((order) => order.status !== 'cancelled').reduce((sum, order) => sum + moneyNumber(order.total), 0)),
    revenue_cents: moneyToCents(rows.filter((order) => order.status !== 'cancelled').reduce((sum, order) => sum + moneyNumber(order.total), 0))
  });
  return { previous: totals(previous), current: totals(current) };
}

function platformBillingMetrics({ companies, subscriptions, plans, subscriptionEvents, monthOrders }) {
  const planById = new Map(plans.map((plan) => [plan.id, plan]));
  const subscriptionByCompany = new Map();
  for (const subscription of subscriptions) {
    if (!subscriptionByCompany.has(subscription.company_id)) subscriptionByCompany.set(subscription.company_id, subscription);
  }
  const revenueByPlan = new Map();
  let mrr = 0;
  for (const company of companies) {
    const subscription = subscriptionByCompany.get(company.id);
    const plan = subscription?.plan_id ? planById.get(subscription.plan_id) : null;
    const price = moneyNumber(plan?.monthly_price || 0);
    if (['active', 'trial', 'grace_period', 'payment_pending'].includes(subscription?.status || company.status)) mrr += price;
    const key = plan?.name || 'Sem plano';
    revenueByPlan.set(key, roundMoney((revenueByPlan.get(key) || 0) + price));
  }
  const eventCount = (patterns) => subscriptionEvents.filter((event) => patterns.some((pattern) => String(event.event_type || '').includes(pattern))).length;
  return {
    mrr: roundMoney(mrr),
    mrr_cents: moneyToCents(mrr),
    monthly_order_revenue: roundMoney(monthOrders.reduce((sum, order) => sum + moneyNumber(order.total), 0)),
    monthly_order_revenue_cents: moneyToCents(monthOrders.reduce((sum, order) => sum + moneyNumber(order.total), 0)),
    trials_started: eventCount(['trial']),
    upgrades: eventCount(['upgrade']),
    downgrades: eventCount(['downgrade']),
    cancellations: eventCount(['cancel']),
    paid_events: eventCount(['paid', 'payment_approved']),
    refused_events: eventCount(['failed', 'refused', 'rejected']),
    revenue_by_plan: [...revenueByPlan.entries()].map(([plan, revenue]) => ({ plan, revenue, revenue_cents: moneyToCents(revenue) }))
  };
}

function platformRevenueSnapshot({ companies, subscriptions, plans, orders, period }) {
  const planById = new Map(plans.map((plan) => [plan.id, plan]));
  const subscriptionByCompany = new Map();
  for (const subscription of subscriptions) {
    if (!subscriptionByCompany.has(subscription.company_id)) subscriptionByCompany.set(subscription.company_id, subscription);
  }
  const mrrByPlan = new Map();
  let mrr = 0;
  for (const company of companies) {
    const subscription = subscriptionByCompany.get(company.id);
    const plan = subscription?.plan_id ? planById.get(subscription.plan_id) : null;
    const status = subscription?.status || company.status || '';
    if (!['active', 'trial', 'grace_period', 'payment_pending'].includes(status)) continue;
    const price = moneyNumber(plan?.monthly_price || 0);
    mrr += price;
    const key = plan?.name || 'Sem plano';
    const current = mrrByPlan.get(key) || { plan: key, clients: 0, mrr: 0, mrr_cents: 0 };
    current.clients += 1;
    current.mrr = roundMoney(current.mrr + price);
    current.mrr_cents = moneyToCents(current.mrr);
    mrrByPlan.set(key, current);
  }
  const billableOrders = orders.filter((order) => order.status !== 'cancelled');
  const orderRevenue = roundMoney(billableOrders.reduce((sum, order) => sum + moneyNumber(order.total), 0));
  return {
    mrr: roundMoney(mrr),
    mrr_cents: moneyToCents(mrr),
    order_revenue: orderRevenue,
    order_revenue_cents: moneyToCents(orderRevenue),
    average_daily_revenue_cents: moneyToCents(orderRevenue / Math.max(1, period.days || 1)),
    mrr_by_plan: [...mrrByPlan.values()].sort((a, b) => b.mrr_cents - a.mrr_cents)
  };
}

function platformConversionSnapshot({ companies, subscriptions, subscriptionEvents, period }) {
  const subscriptionByCompany = new Map();
  for (const subscription of subscriptions) {
    if (!subscriptionByCompany.has(subscription.company_id)) subscriptionByCompany.set(subscription.company_id, subscription);
  }
  const since = period.since.getTime();
  const companiesInPeriod = companies.filter((company) => new Date(company.created_at || 0).getTime() >= since);
  const trialsStarted = companiesInPeriod.filter((company) => (subscriptionByCompany.get(company.id)?.status || company.status) === 'trial').length
    + subscriptionEvents.filter((event) => /trial/i.test(event.event_type || '')).length;
  const converted = subscriptionEvents.filter((event) => /(paid|payment_approved|upgrade|activate|active)/i.test(event.event_type || '')).length;
  const churn = companies.filter((company) => ['cancelled', 'archived'].includes(company.status)).length
    + subscriptionEvents.filter((event) => /(cancel|churn)/i.test(event.event_type || '')).length;
  const upgrades = subscriptionEvents.filter((event) => /upgrade/i.test(event.event_type || '')).length;
  const downgrades = subscriptionEvents.filter((event) => /downgrade/i.test(event.event_type || '')).length;
  return {
    new_clients: companiesInPeriod.length,
    trials_started: trialsStarted,
    trials_converted: converted,
    conversion_rate: trialsStarted ? Number(((converted / trialsStarted) * 100).toFixed(1)) : 0,
    churn,
    upgrades,
    downgrades
  };
}

function platformNewClientsDaily(companies, period) {
  const days = [];
  for (let cursor = new Date(period.start); cursor <= period.end; cursor.setDate(cursor.getDate() + 1)) {
    days.push({ date: cursor.toISOString().slice(0, 10), clients: 0 });
  }
  const byDate = new Map(days.map((day) => [day.date, day]));
  for (const company of companies) {
    const key = new Date(company.created_at || 0).toISOString().slice(0, 10);
    const row = byDate.get(key);
    if (row) row.clients += 1;
  }
  return days;
}

function platformEstimatedMrr(companies, subscriptionByCompany, planById) {
  return roundMoney(companies.reduce((sum, company) => {
    const subscription = subscriptionByCompany.get(company.id);
    if (!['active', 'trial', 'grace_period', 'payment_pending'].includes(subscription?.status || company.status)) return sum;
    const plan = subscription?.plan_id ? planById.get(subscription.plan_id) : null;
    return sum + moneyNumber(plan?.monthly_price || 0);
  }, 0));
}

function platformCommercialAlerts(companies, stores, context, options = {}) {
  const alerts = [];
  const now = Date.now();
  const backup = options.backup || {};
  const operationalLogs = options.operationalLogs || [];
  if (backup.latest?.created_at && (now - new Date(backup.latest.created_at).getTime()) > 86400000) {
    alerts.push({ type: 'backup', severity: 'critical', title: 'Backup atrasado', action: 'Executar backup manual e conferir agendamento.' });
  } else if (!backup.latest?.created_at) {
    alerts.push({ type: 'backup', severity: 'warning', title: 'Backup sem registro recente', action: 'Validar diretório e rotina de backup.' });
  }
  const webhookFailures = operationalLogs.filter((log) => log.type === 'webhook' && ['failed', 'attention'].includes(log.status));
  if (webhookFailures.length) {
    alerts.push({ type: 'webhook', severity: 'critical', title: `${webhookFailures.length} falha(s) recente(s) de webhook`, action: 'Conferir provedor, assinatura e logs.' });
  }
  const apiMetric = platformMetricsSnapshot(platformHealthPeriod('24h')).api;
  if (Number(apiMetric?.p95_ms || 0) > 1200) {
    alerts.push({ type: 'performance', severity: 'warning', title: 'API com latência alta', action: 'Verificar banco, logs e tráfego recente.' });
  }
  for (const company of companies) {
    const subscription = context.subscriptionByCompany.get(company.id);
    const companyStores = context.storesByCompany.get(company.id) || [];
    const orders = context.ordersByCompany.get(company.id) || [];
    if (subscription?.trial_ends_at) {
      const daysLeft = Math.ceil((new Date(subscription.trial_ends_at).getTime() - now) / 86400000);
      if (daysLeft >= 0 && daysLeft <= 3) alerts.push({ type: 'trial', severity: 'warning', company_id: company.id, title: `${company.name}: trial acaba em ${daysLeft} dia(s)`, action: 'Entrar em contato ou orientar upgrade.' });
    }
    if (['payment_pending', 'past_due', 'grace_period'].includes(subscription?.status || company.status)) {
      alerts.push({ type: 'billing', severity: 'critical', company_id: company.id, title: `${company.name}: cobrança pendente`, action: 'Verificar pagamento e webhook.' });
    }
    if (!orders.length && companyStores.length) alerts.push({ type: 'sales', severity: 'attention', company_id: company.id, title: `${company.name}: sem pedidos recentes`, action: 'Acompanhar onboarding e divulgação.' });
    for (const store of companyStores) {
      const setting = context.settingsByStore.get(store.id);
      const products = context.productsByStore?.get(store.id) || [];
      if (setting && !setting.whatsapp_number) alerts.push({ type: 'setup', severity: 'warning', company_id: company.id, store_id: store.id, title: `${store.name}: WhatsApp não configurado`, action: 'Completar configurações da loja.' });
      if (setting && setting.onboarding_completed === false) alerts.push({ type: 'setup', severity: 'attention', company_id: company.id, store_id: store.id, title: `${store.name}: onboarding incompleto`, action: 'Reabrir onboarding ou orientar cliente.' });
      if (!products.length) alerts.push({ type: 'menu', severity: 'critical', company_id: company.id, store_id: store.id, title: `${store.name}: sem produtos`, action: 'Ajudar o cliente a cadastrar o cardápio.' });
      if (store.is_active === false) alerts.push({ type: 'store', severity: 'attention', company_id: company.id, store_id: store.id, title: `${store.name}: loja suspensa/inativa`, action: 'Validar se foi bloqueio comercial.' });
    }
  }
  return alerts.slice(0, 12);
}

function platformCompanyAttention({ company, stores, settingsByStore, orders, subscription, products }) {
  const alerts = [];
  const now = Date.now();
  const lastOrder = orders[0] || null;
  const subscriptionStatus = subscription?.status || company.status || '';
  if (subscription?.trial_ends_at) {
    const daysLeft = Math.ceil((new Date(subscription.trial_ends_at).getTime() - now) / 86400000);
    if (daysLeft >= 0 && daysLeft <= 3) {
      alerts.push({ type: 'trial', severity: 'warning', title: `Trial acaba em ${daysLeft} dia(s)`, action: 'Entrar em contato e orientar upgrade.' });
    }
  }
  if (['payment_pending', 'past_due', 'grace_period', 'suspended'].includes(subscriptionStatus)) {
    alerts.push({ type: 'billing', severity: 'critical', title: 'Pagamento pendente ou cliente suspenso', action: 'Verificar cobrança, webhook e status comercial.' });
  }
  if (!stores.length) {
    alerts.push({ type: 'setup', severity: 'critical', title: 'Cliente sem loja/cardápio', action: 'Criar uma loja para o cliente.' });
  }
  if (stores.some((store) => store.is_active === false)) {
    alerts.push({ type: 'store', severity: 'attention', title: 'Existe loja inativa', action: 'Confirmar se a suspensão foi intencional.' });
  }
  const storesWithoutWhatsapp = stores.filter((store) => !settingsByStore.get(store.id)?.whatsapp_number);
  if (storesWithoutWhatsapp.length) {
    alerts.push({ type: 'setup', severity: 'warning', title: `${storesWithoutWhatsapp.length} loja(s) sem WhatsApp`, action: 'Completar configuração da loja.' });
  }
  const incompleteStores = stores.filter((store) => settingsByStore.get(store.id)?.onboarding_completed === false);
  if (incompleteStores.length) {
    alerts.push({ type: 'onboarding', severity: 'attention', title: 'Onboarding incompleto', action: 'Reabrir onboarding ou orientar o cliente.' });
  }
  const closedStores = stores.filter((store) => settingsByStore.get(store.id)?.is_open === false);
  if (closedStores.length) {
    alerts.push({ type: 'operation', severity: 'attention', title: `${closedStores.length} loja(s) fechada(s)`, action: 'Validar horário/status de operação.' });
  }
  if (!products.length && stores.length) {
    alerts.push({ type: 'menu', severity: 'critical', title: 'Cliente sem produtos cadastrados', action: 'Ajudar a criar o cardápio inicial.' });
  }
  if (!lastOrder && stores.length) {
    alerts.push({ type: 'sales', severity: 'attention', title: 'Nenhum pedido registrado', action: 'Acompanhar ativação comercial.' });
  } else if (lastOrder && Date.now() - new Date(lastOrder.created_at).getTime() > 7 * 86400000) {
    alerts.push({ type: 'sales', severity: 'warning', title: 'Mais de 7 dias sem pedidos', action: 'Verificar divulgação, loja aberta e cardápio.' });
  }
  return alerts;
}

function buildPlatformCompanyTimeline({ company, stores, orders, billingHistory, auditLogs, subscription }) {
  const events = [];
  if (company?.created_at) {
    events.push({
      type: 'company',
      title: 'Conta criada',
      description: company.name,
      created_at: company.created_at
    });
  }
  for (const store of stores || []) {
    if (store.created_at) {
      events.push({
        type: 'store',
        title: 'Loja criada',
        description: `${store.name} /${store.slug}`,
        created_at: store.created_at
      });
    }
  }
  if (subscription?.created_at) {
    events.push({
      type: 'billing',
      title: 'Assinatura iniciada',
      description: subscription.status || 'assinatura',
      created_at: subscription.created_at
    });
  }
  const firstOrder = (orders || []).slice().sort((a, b) => new Date(a.created_at) - new Date(b.created_at))[0];
  if (firstOrder?.created_at) {
    events.push({
      type: 'order',
      title: 'Primeiro pedido',
      description: `${moneyNumber(firstOrder.total).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`,
      created_at: firstOrder.created_at
    });
  }
  for (const event of billingHistory || []) {
    events.push({
      type: 'billing',
      title: subscriptionEventLabel(event.event_type),
      description: event.status || event.provider || 'billing',
      created_at: event.created_at
    });
  }
  for (const log of auditLogs || []) {
    events.push({
      type: String(log.action || '').includes('note') ? 'note' : 'audit',
      title: auditActionLabel(log.action),
      description: platformTimelineDescription(log),
      created_at: log.created_at
    });
  }
  return events
    .filter((event) => event.created_at)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(0, 30);
}

function subscriptionEventLabel(type) {
  const value = String(type || '').replaceAll('_', ' ');
  if (!value) return 'Evento de cobrança';
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function auditActionLabel(action) {
  const labels = {
    'platform.client.note': 'Nota interna',
    'platform.client.internal_status': 'Acompanhamento atualizado',
    'platform.support.impersonate.start': 'Acesso suporte iniciado',
    'platform.support.impersonate.end': 'Acesso suporte encerrado',
    'platform.support.impersonate.expired': 'Acesso suporte expirou',
    'platform.company.update': 'Cliente atualizado',
    'platform.company.status': 'Status alterado',
    'platform.company.plan': 'Plano alterado',
    'platform.store.update': 'Loja atualizada',
    'platform.store.status': 'Status da loja alterado',
    'admin.setup.create': 'Conta criada',
    'admin.login.success': 'Login no admin',
    'order.status.update': 'Pedido atualizado'
  };
  return labels[action] || subscriptionEventLabel(action || 'Evento');
}

function platformTimelineDescription(log) {
  if (log?.action === 'platform.client.note') {
    return cleanText(log.after_data?.note || 'Nota registrada.');
  }
  return cleanText(log.after_data?.status || log.after_data?.reason || log.entity_type || '').slice(0, 180) || 'Evento registrado.';
}

function platformAnalyticsPeriod(value) {
  const days = ({ '7d': 7, '15d': 15, '30d': 30 })[value] || 30;
  const end = startOfLocalDay(new Date());
  const start = new Date(end);
  start.setDate(start.getDate() - days + 1);
  end.setHours(23, 59, 59, 999);
  return { label: `${days}d`, days, start, end, since: start };
}

function startOfLocalDay(date) {
  const value = new Date(date);
  value.setHours(0, 0, 0, 0);
  return value;
}

async function createPlatformCompany(data, admin) {
  const name = cleanText(data.name || data.company?.name || '');
  if (!name) throw httpError(422, 'Informe o nome da empresa.');
  const payload = {
    name,
    document: cleanText(data.document || '') || null,
    billing_email: cleanEmail(data.billing_email || data.email || '') || null,
    phone: onlyDigits(data.phone || ''),
    status: ['active', 'trial', 'past_due', 'suspended', 'cancelled', 'archived'].includes(data.status) ? data.status : 'trial'
  };
  const [company] = await dbRequest('POST', 'companies', {}, payload, ['Prefer: return=representation']);
  await createDefaultSubscription(company.id, data.plan_code || 'essential');
  await audit('platform.company.create', { company_id: company.id, actor_admin_id: admin.id, after_data: payload });
  return company;
}

async function createPlatformStore(data, admin) {
  const companyId = cleanUuid(data.company_id, 'empresa');
  const name = cleanText(data.name || '');
  const slug = cleanSlug(data.slug || name);
  if (!name) throw httpError(422, 'Informe o nome da loja.');
  if (!slug) throw httpError(422, 'Informe um endereço público válido para a loja.');
  const [company] = await dbRequest('GET', 'companies', { select: 'id', id: `eq.${companyId}`, limit: '1' });
  if (!company) throw httpError(404, 'Empresa não encontrada.');
  const storeCount = await currentUsageForKey({ company_id: companyId }, 'stores');
  if (storeCount >= 1) {
    await assertCompanyUsageLimit({ company_id: companyId }, 'multi_store', 'stores');
  }
  const [store] = await dbRequest('POST', 'stores', {}, {
    company_id: companyId,
    name,
    slug,
    description: cleanText(data.description || '') || null,
    public_url: `/${slug}`,
    is_active: data.is_active !== false
  }, ['Prefer: return=representation']);
  await dbRequest('POST', 'store_settings', {}, {
    store_id: store.id,
    name,
    slug,
    description: cleanText(data.description || 'Pedido rápido pelo TáPronto.'),
    whatsapp_number: onlyDigits(data.whatsapp_number || ''),
    address: cleanText(data.address || ''),
    payment_methods: ['Pix', 'Cartao na entrega', 'Dinheiro'],
    theme_settings: defaultThemeSettings(),
    business_hours: defaultBusinessHours()
  }, ['Prefer: return=minimal']);
  if (admin?.id && cleanUuid(admin.company_id) === companyId) {
    await dbRequest('POST', 'admin_user_store_access', {}, {
      admin_user_id: admin.id,
      company_id: companyId,
      store_id: store.id,
      role: normalizeAdminRole(admin.role),
      permissions: [],
      is_active: true
    }, ['Prefer: return=minimal']);
    clearAdminStoreAccessCache(admin.id);
  }
  await audit('platform.store.create', { company_id: companyId, store_id: store.id, actor_admin_id: admin.id, after_data: { name, slug } });
  await recordCompanyUsage({ ...admin, company_id: companyId }, 'multi_store', 'stores');
  return publicStoreRef(store);
}

async function listPlatformPlans() {
  const [plans, features, planFeatures] = await Promise.all([
    dbRequest('GET', 'subscription_plans', {
      select: '*',
      order: 'sort_order.asc',
      limit: '100'
    }),
    listPlatformFeaturesSafe(),
    dbRequest('GET', 'plan_features', {
      select: '*',
      limit: '1000'
    })
  ]);
  const featuresById = new Map(features.map((feature) => [feature.id, feature]));
  const planFeaturesByPlan = new Map();
  for (const entry of planFeatures) {
    if (!planFeaturesByPlan.has(entry.plan_id)) planFeaturesByPlan.set(entry.plan_id, []);
    planFeaturesByPlan.get(entry.plan_id).push({
      ...entry,
      feature: featuresById.get(entry.feature_id) || null
    });
  }
  return {
    plans: plans.map((plan) => ({
      ...plan,
      features: planFeaturesByPlan.get(plan.id) || []
    })),
    features
  };
}

async function listPlatformFeaturesSafe() {
  return dbRequest('GET', 'platform_features', {
    select: '*',
    order: 'sort_order.asc',
    limit: '200'
  }).catch(() => dbRequest('GET', 'platform_features', {
    select: '*',
    order: 'name.asc',
    limit: '200'
  }).catch(() => []));
}

async function listPortalPlans(options = {}) {
  const includeInternal = options.includeInternal === true;
  const data = await listPlatformPlans();
  return {
    plans: data.plans
      .filter((plan) => plan.is_active !== false)
      .filter((plan) => includeInternal || !isInternalTestPlan(plan))
      .map((plan) => ({
        code: plan.code,
        name: plan.name,
        description: plan.description,
        monthly_price: plan.monthly_price,
        annual_price: plan.annual_price,
        sort_order: plan.sort_order,
        features: plan.features
          .filter((entry) => entry.is_enabled !== false && entry.feature)
          .map((entry) => ({
            code: entry.feature.code,
            name: entry.feature.name,
            description: entry.feature.description,
            limit_value: entry.limit_value
          }))
      }))
  };
}

function isInternalTestPlan(plan = {}) {
  const settings = isPlainObject(plan.settings) ? plan.settings : {};
  return settings.internal_test === true || settings.hide_public === true || cleanSlug(plan.code || '') === 'payment_test';
}

function canSeeInternalTestPlans(admin = {}) {
  return Boolean(admin?.id || admin?.email);
}

async function checkPortalSlug(value) {
  const slug = cleanSlug(value || '');
  const reserved = reservedPublicSlugs();
  if (!slug || slug.length < 3) {
    return { slug, available: false, reason: 'Use pelo menos 3 caracteres.' };
  }
  if (reserved.has(slug)) {
    return { slug, available: false, reason: 'Este endereço é reservado.' };
  }
  const rows = await dbRequest('GET', 'stores', {
    select: 'id',
    slug: `eq.${slug}`,
    limit: '1'
  });
  return {
    slug,
    available: rows.length === 0,
    reason: rows.length ? 'Este endereço já está em uso.' : ''
  };
}

async function createPortalSignup(req, data = {}) {
  const parsed = sanitizePortalSignup(data, req);
  const slugStatus = await checkPortalSlug(parsed.store.slug);
  if (!slugStatus.available) throw httpError(409, slugStatus.reason || 'Endereço público indisponível.');

  const existingAdmin = await dbRequest('GET', 'admin_users', {
    select: 'id',
    email: `eq.${parsed.owner.email}`,
    limit: '1'
  });
  if (existingAdmin[0]) throw httpError(409, 'Este e-mail já possui uma conta. Use a tela de entrar.');

  const created = { company: null, admin: null, store: null };
  try {
    const attributionJourney = await marketingAttributionJourney(parsed.attribution);
    const [company] = await dbRequest('POST', 'companies', {}, {
      name: parsed.company.name,
      document: parsed.company.document || null,
      billing_email: parsed.owner.email,
      phone: parsed.owner.phone,
      marketing_attribution: parsed.attribution,
      marketing_first_touch: attributionJourney.first,
      marketing_last_touch: attributionJourney.last,
      marketing_opt_in: parsed.marketingOptIn,
      status: 'trial'
    }, ['Prefer: return=representation']);
    created.company = company;

    const [admin] = await dbRequest('POST', 'admin_users', {}, {
      company_id: company.id,
      name: parsed.owner.name,
      email: parsed.owner.email,
      password_hash: hashPassword(parsed.owner.password),
      role: 'owner',
      is_active: false
    }, ['Prefer: return=representation']);
    created.admin = admin;

    const [store] = await dbRequest('POST', 'stores', {}, {
      company_id: company.id,
      name: parsed.store.name,
      slug: parsed.store.slug,
      description: parsed.store.description,
      public_url: `/${parsed.store.slug}`,
      is_active: false
    }, ['Prefer: return=representation']);
    created.store = store;

    await dbRequest('POST', 'admin_user_store_access', {}, {
      admin_user_id: admin.id,
      company_id: company.id,
      store_id: store.id,
      role: 'owner',
      permissions: [],
      is_active: true
    }, ['Prefer: return=minimal']);

    await createDefaultSubscription(company.id, parsed.planCode);
    await createPortalStoreSettings(store.id, parsed);
    await createStarterMenu(store.id, parsed.businessType);
    await createOnboardingProgress(company.id, store.id, parsed);
    await recordMarketingMilestone('signup_completed', {
      companyId: company.id,
      storeId: store.id,
      visitorKey: parsed.attribution.visitor_key,
      attribution: parsed.attribution,
      properties: { plan_code: parsed.planCode, business_type: parsed.businessType },
      idempotencyKey: `signup_completed:${company.id}`
    });
    await recordReferralSignup(req, parsed.referralCode, {
      company,
      store,
      admin,
      ownerEmail: parsed.owner.email
    }).catch((error) => {
      console.warn('Não foi possível registrar indicação:', error.message || error);
    });

    await audit('portal.signup.create', {
      req,
      actor_admin_id: admin.id,
      company_id: company.id,
      store_id: store.id,
      entity_type: 'company',
      entity_id: company.id,
      severity: 'info',
      after_data: {
        plan_code: parsed.planCode,
        business_type: parsed.businessType,
        slug: parsed.store.slug,
        marketing_opt_in: parsed.marketingOptIn
      }
    });

    clearAdminUsersCache();
    const activation = await createAdminActivationToken(admin.id);
    if (shouldSendSignupActivationEmail()) {
      await sendAdminActivationEmail(req, { admin, company, store, token: activation.token, expiresAt: activation.expiresAt }).catch(async (error) => {
        await audit('portal.signup.activation_email_failed', {
          req,
          actor_admin_id: admin.id,
          company_id: company.id,
          store_id: store.id,
          entity_type: 'admin_user',
          entity_id: admin.id,
          severity: 'warning',
          after_data: { email: maskEmailOrToken(admin.email), message: error.message || 'Falha ao enviar ativação.' }
        });
        throw httpError(502, 'Não foi possível enviar o e-mail de ativação. Verifique a configuração SMTP.');
      });
    }
    return {
      body: {
        ok: true,
        needs_activation: true,
        message: 'Conta criada. Enviamos um link de ativação para o e-mail informado. Confira também spam, lixo eletrônico e a aba Promoções.',
        admin: {
          id: admin.id,
          company_id: company.id,
          store_id: store.id,
          name: admin.name,
          email: admin.email,
          role: admin.role,
          is_active: false
        },
        company: { id: company.id, name: company.name, status: company.status },
        store: publicStoreRef(store),
        redirect: absolutePanelUrl('/')
      }
    };
  } catch (error) {
    await rollbackPortalSignup(created).catch(() => {});
    throw error;
  }
}

async function createAdminActivationToken(adminId) {
  const token = randomBytes(24).toString('hex');
  const tokenHash = hashAdminActivationToken(token);
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
  await dbRequest('PATCH', 'admin_activation_tokens', {
    admin_user_id: `eq.${cleanUuid(adminId, 'admin')}`,
    status: 'eq.pending'
  }, {
    status: 'cancelled'
  }, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('POST', 'admin_activation_tokens', {}, {
    admin_user_id: cleanUuid(adminId, 'admin'),
    token_hash: tokenHash,
    status: 'pending',
    expires_at: expiresAt
  }, ['Prefer: return=minimal']);
  return { token, expiresAt };
}

function shouldSendSignupActivationEmail() {
  return process.env.NODE_ENV !== 'test' && process.env.SKIP_SIGNUP_ACTIVATION_EMAIL !== 'true';
}

async function resendAdminActivationEmail(req, data = {}) {
  const email = cleanEmail(data.email || data.owner_email || '');
  if (!email) throw httpError(422, 'Informe o e-mail cadastrado para reenviar a ativação.');
  if (!shouldSendSignupActivationEmail()) {
    return { ok: true, message: 'Ambiente de teste: envio de ativação desativado.' };
  }
  const [admin] = await dbRequest('GET', 'admin_users', {
    select: 'id,name,email,company_id,is_active',
    email: `eq.${email}`,
    limit: '1'
  });
  if (!admin) {
    return { ok: true, message: 'Se existir uma conta pendente com este e-mail, enviaremos um novo link de ativação. Confira também spam, lixo eletrônico e a aba Promoções.' };
  }
  if (admin.is_active !== false) {
    return { ok: true, message: 'Esta conta já está ativa. Você já pode entrar no painel.' };
  }
  const recentTokens = await dbRequest('GET', 'admin_activation_tokens', {
    select: 'id,created_at',
    admin_user_id: `eq.${admin.id}`,
    status: 'eq.pending',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  const latest = recentTokens[0];
  if (latest && Date.now() - new Date(latest.created_at).getTime() < 2 * 60 * 1000) {
    throw httpError(429, 'Aguarde 2 minutos antes de reenviar o e-mail de ativação.');
  }
  const [company] = admin.company_id ? await dbRequest('GET', 'companies', {
    select: 'id,name,status',
    id: `eq.${admin.company_id}`,
    limit: '1'
  }).catch(() => []) : [];
  const [store] = admin.company_id ? await dbRequest('GET', 'stores', {
    select: 'id,company_id,name,slug',
    company_id: `eq.${admin.company_id}`,
    order: 'created_at.asc',
    limit: '1'
  }).catch(() => []) : [];
  const activation = await createAdminActivationToken(admin.id);
  await sendAdminActivationEmail(req, {
    admin,
    company: company || { name: '' },
    store: store || { name: '' },
    token: activation.token,
    expiresAt: activation.expiresAt
  }).catch(async (error) => {
    await audit('portal.signup.activation_resend_failed', {
      req,
      actor_admin_id: admin.id,
      company_id: admin.company_id || null,
      store_id: store?.id || null,
      entity_type: 'admin_user',
      entity_id: admin.id,
      severity: 'warning',
      after_data: { email: maskEmailOrToken(admin.email), message: error.message || 'Falha ao reenviar ativação.' }
    });
    throw httpError(502, 'Não foi possível reenviar o e-mail de ativação. Verifique a configuração SMTP.');
  });
  await audit('portal.signup.activation_resend', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id || null,
    store_id: store?.id || null,
    entity_type: 'admin_user',
    entity_id: admin.id,
    severity: 'info',
    after_data: { email: maskEmailOrToken(admin.email) }
  });
  return { ok: true, message: 'Enviamos um novo link de ativação. Ele expira em 24 horas. Confira também spam, lixo eletrônico e a aba Promoções.' };
}

async function sendAdminActivationEmail(req, { admin, company, store, token, expiresAt }) {
  const activationUrl = absoluteAppUrl(req, `/ativar-conta?token=${token}`);
  const variables = {
    customer_name: admin.name || admin.email,
    company_name: company.name || '',
    store_name: store.name || '',
    due_date: formatDateTimePt(expiresAt),
    dashboard_url: activationUrl,
    activation_url: activationUrl,
    support_url: absolutePanelUrl('/'),
    payment_url: absolutePublicUrl('/planos'),
    platform_url: absolutePlatformUrl('/')
  };
  await sendPlatformTemplateEmail({
    to: admin.email,
    templateKey: 'account_activation',
    variables,
    requireActive: true
  });
}

async function getPublicAdminActivation(token) {
  const activation = await findAdminActivationByToken(token);
  const [admin] = await dbRequest('GET', 'admin_users', {
    select: 'email,name,is_active',
    id: `eq.${activation.admin_user_id}`,
    limit: '1'
  });
  if (!admin) throw httpError(404, 'Link de ativação inválido.');
  return {
    email: admin.email,
    name: admin.name || '',
    is_active: admin.is_active === true,
    expires_at: activation.expires_at
  };
}

async function activateAdminAccount(req, token) {
  const activation = await findAdminActivationByToken(token);
  const [admin] = await dbRequest('PATCH', 'admin_users', { id: `eq.${activation.admin_user_id}` }, {
    is_active: true,
    updated_at: new Date().toISOString()
  }, ['Prefer: return=representation']);
  if (!admin) throw httpError(404, 'Conta administrativa não encontrada.');
  await dbRequest('PATCH', 'admin_activation_tokens', { id: `eq.${activation.id}` }, {
    status: 'used',
    used_at: new Date().toISOString()
  }, ['Prefer: return=minimal']);
  await dbRequest('PATCH', 'admin_activation_tokens', {
    admin_user_id: `eq.${admin.id}`,
    status: 'eq.pending'
  }, {
    status: 'cancelled'
  }, ['Prefer: return=minimal']).catch(() => {});
  if (admin.company_id) {
    await dbRequest('PATCH', 'stores', { company_id: `eq.${admin.company_id}` }, {
      is_active: true,
      updated_at: new Date().toISOString()
    }, ['Prefer: return=minimal']).catch(() => {});
  }
  clearAdminUsersCache();
  await audit('portal.signup.activate', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id || null,
    entity_type: 'admin_user',
    entity_id: admin.id,
    severity: 'info',
    after_data: { email: maskEmailOrToken(admin.email) }
  });
  return createAdminSession(admin);
}

async function findAdminActivationByToken(token) {
  const value = String(token || '').trim();
  if (!/^[a-f0-9]{32,128}$/i.test(value)) throw httpError(404, 'Link de ativação inválido.');
  const tokenHash = hashAdminActivationToken(value);
  const [activation] = await dbRequest('GET', 'admin_activation_tokens', {
    select: '*',
    token_hash: `eq.${tokenHash}`,
    status: 'eq.pending',
    limit: '1'
  });
  if (!activation) throw httpError(404, 'Link de ativação inválido ou já utilizado.');
  if (new Date(activation.expires_at).getTime() < Date.now()) {
    await dbRequest('PATCH', 'admin_activation_tokens', { id: `eq.${activation.id}` }, {
      status: 'expired'
    }, ['Prefer: return=minimal']).catch(() => {});
    throw httpError(410, 'Este link de ativação expirou.');
  }
  return activation;
}

function sanitizePortalSignup(data = {}, req = null) {
  const owner = data.owner || {};
  const business = data.business || {};
  const signupUrl = req?.url ? new URL(req.url, `http://${req.headers?.host || HOST}`) : null;
  const planCode = 'trial';
  const ownerName = cleanText(owner.name || data.name || '');
  const ownerEmail = cleanEmail(owner.email || data.email || '');
  const ownerPhone = onlyDigits(owner.phone || data.phone || '');
  const password = validatePassword(owner.password || data.password);
  const confirmPassword = String(owner.confirm_password || owner.confirmPassword || data.confirm_password || data.confirmPassword || '');
  if (confirmPassword && confirmPassword !== password) throw httpError(422, 'A confirmação de senha não confere.');
  if (!ownerName) throw httpError(422, 'Informe seu nome completo.');
  if (!ownerEmail) throw httpError(422, 'Informe um e-mail válido.');
  if (ownerPhone.length < 10) throw httpError(422, 'Informe um WhatsApp válido.');
  if (data.accept_terms !== true && data.acceptTerms !== true) throw httpError(422, 'Aceite o EULA, os Termos de Uso e a Política de Privacidade para continuar.');

  const displayName = cleanText(business.display_name || business.displayName || business.name || '');
  const companyName = cleanText(business.company_name || business.companyName || business.name || displayName);
  const slug = cleanSlug(business.slug || displayName || companyName);
  if (!companyName || !displayName) throw httpError(422, 'Informe o nome do estabelecimento.');
  if (!slug) throw httpError(422, 'Informe o endereço público do cardápio.');

  return {
    planCode,
    referralCode: cleanReferralCode(data.referral_code || data.referralCode || data.ref || signupUrl?.searchParams.get('ref') || ''),
    businessType: cleanSlug(business.type || 'outro') || 'outro',
    marketingOptIn: Boolean(data.marketing_opt_in || data.marketingOptIn),
    attribution: marketingAttributionFromRequest(req, data.attribution),
    owner: {
      name: ownerName,
      email: ownerEmail,
      phone: ownerPhone,
      password
    },
    company: {
      name: companyName,
      document: cleanText(business.document || '')
    },
    store: {
      name: displayName,
      slug,
      description: cleanText(business.description || `Loja online de ${displayName} no TáPronto.`)
    },
    business: {
      city: cleanText(business.city || ''),
      state: cleanText(business.state || '').slice(0, 2).toUpperCase(),
      address: cleanText(business.address || ''),
      phone: onlyDigits(business.phone || ownerPhone),
      document: cleanText(business.document || '')
    }
  };
}

function cleanReferralCode(value = '') {
  return String(value || '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '')
    .slice(0, 32);
}

function referralPublicUrl(req, code) {
  const query = code ? `?ref=${encodeURIComponent(code)}` : '';
  return `${absolutePublicUrl('/cadastro')}${query}`;
}

async function getAdminReferralProgram(req, admin) {
  const companyId = cleanUuid(admin.company_id, 'empresa');
  const storeId = cleanOptionalUuid(admin.store_id || admin.active_store?.id || '', 'loja');
  const code = await ensureReferralCode(admin);
  const referrals = await dbRequest('GET', 'referrals', {
    select: '*',
    referrer_company_id: `eq.${companyId}`,
    order: 'created_at.desc',
    limit: '50'
  }).catch(() => []);
  const rewards = await dbRequest('GET', 'referral_rewards', {
    select: '*',
    referrer_company_id: `eq.${companyId}`,
    order: 'created_at.desc',
    limit: '50'
  }).catch(() => []);
  const availableCents = rewards
    .filter((reward) => reward.status === 'available')
    .reduce((sum, reward) => sum + Number(reward.amount_cents || 0), 0);
  const monthStart = startOfCurrentMonthIso();
  const monthRewardCents = rewards
    .filter((reward) => new Date(reward.created_at || 0).toISOString() >= monthStart && ['available', 'applied'].includes(reward.status))
    .reduce((sum, reward) => sum + Number(reward.amount_cents || 0), 0);
  return {
    program: {
      reward_cents: REFERRAL_REWARD_CENTS,
      monthly_limit_cents: REFERRAL_MONTHLY_LIMIT_CENTS,
      monthly_used_cents: monthRewardCents,
      available_cents: availableCents,
      rules: [
        'Convide outro estabelecimento pelo seu link.',
        'A recompensa é liberada quando a indicação paga o primeiro plano.',
        'O limite mensal evita abusos e mantém o programa sustentável.'
      ]
    },
    code: {
      id: code.id,
      code: code.code,
      url: referralPublicUrl(req, code.code),
      store_id: code.store_id || storeId || null
    },
    stats: {
      total: referrals.length,
      signed_up: referrals.filter((item) => item.status === 'signed_up').length,
      paid: referrals.filter((item) => item.status === 'paid').length,
      rewards_available_cents: availableCents
    },
    referrals: referrals.map(publicReferral),
    rewards: rewards.map(publicReferralReward)
  };
}

async function createOrRefreshAdminReferralCode(req, admin) {
  const current = await ensureReferralCode(admin, { forceNew: true });
  await audit('admin.referral_code.refresh', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id,
    store_id: admin.store_id || null,
    entity_type: 'referral_code',
    entity_id: current.id,
    severity: 'info',
    after_data: { code: current.code }
  });
  return { code: { id: current.id, code: current.code, url: referralPublicUrl(req, current.code) } };
}

async function ensureReferralCode(admin, options = {}) {
  const companyId = cleanUuid(admin.company_id, 'empresa');
  const storeId = cleanOptionalUuid(admin.store_id || admin.active_store?.id || '', 'loja');
  if (!options.forceNew) {
    const [existing] = await dbRequest('GET', 'referral_codes', {
      select: '*',
      company_id: `eq.${companyId}`,
      is_active: 'eq.true',
      order: 'created_at.desc',
      limit: '1'
    }).catch(() => []);
    if (existing) return existing;
  }
  if (options.forceNew) {
    await dbRequest('PATCH', 'referral_codes', {
      company_id: `eq.${companyId}`,
      is_active: 'eq.true'
    }, {
      is_active: false,
      updated_at: new Date().toISOString()
    }, ['Prefer: return=minimal']).catch(() => {});
  }
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const suffix = randomBytes(3).toString('hex');
    const base = cleanReferralCode(admin.active_store?.slug || admin.active_store?.name || admin.name || 'tapronto') || 'tapronto';
    const code = cleanReferralCode(`${base}${suffix}`);
    try {
      const [created] = await dbRequest('POST', 'referral_codes', {}, {
        company_id: companyId,
        store_id: storeId || null,
        code,
        is_active: true
      }, ['Prefer: return=representation']);
      return created;
    } catch (error) {
      if (!String(error.message || '').includes('duplicate')) throw error;
    }
  }
  throw httpError(500, 'Não foi possível gerar um código de indicação agora.');
}

async function recordReferralSignup(req, referralCode, context = {}) {
  const code = cleanReferralCode(referralCode);
  if (!code) return null;
  const [refCode] = await dbRequest('GET', 'referral_codes', {
    select: '*',
    code: `eq.${code}`,
    is_active: 'eq.true',
    limit: '1'
  }).catch(() => []);
  if (!refCode?.company_id || refCode.company_id === context.company?.id) return null;
  const referredEmail = cleanEmail(context.ownerEmail || context.admin?.email || '');
  const [referrerCompany] = await dbRequest('GET', 'companies', {
    select: 'id,billing_email,name',
    id: `eq.${refCode.company_id}`,
    limit: '1'
  }).catch(() => []);
  if (cleanEmail(referrerCompany?.billing_email || '') && cleanEmail(referrerCompany.billing_email) === referredEmail) return null;
  const [existing] = await dbRequest('GET', 'referrals', {
    select: 'id',
    referred_company_id: `eq.${context.company.id}`,
    limit: '1'
  }).catch(() => []);
  if (existing) return existing;
  const [row] = await dbRequest('POST', 'referrals', {}, {
    referral_code_id: refCode.id,
    code,
    referrer_company_id: refCode.company_id,
    referrer_store_id: refCode.store_id || null,
    referred_company_id: context.company.id,
    referred_store_id: context.store.id,
    referred_email: referredEmail || null,
    status: 'signed_up',
    metadata: {
      referred_company_name: context.company.name || '',
      referred_store_name: context.store.name || '',
      referred_admin_name: context.admin?.name || ''
    }
  }, ['Prefer: return=representation']);
  await audit('referral.signup', {
    req,
    actor_admin_id: context.admin?.id || null,
    company_id: context.company.id,
    store_id: context.store.id,
    entity_type: 'referral',
    entity_id: row?.id || null,
    severity: 'info',
    after_data: { referral_code: code, referrer_company_id: refCode.company_id }
  });
  await sendReferralReceivedEmail(row).catch(() => {});
  return row;
}

async function processReferralPayment(req, { companyId, transactionId, amountCents }) {
  const paidCompanyId = cleanOptionalUuid(companyId || '', 'empresa');
  if (!paidCompanyId) return null;
  const [referral] = await dbRequest('GET', 'referrals', {
    select: '*',
    referred_company_id: `eq.${paidCompanyId}`,
    status: 'in.(signed_up,trial,pending)',
    limit: '1'
  }).catch(() => []);
  if (!referral?.id || !referral.referrer_company_id) return null;
  const [existingReward] = await dbRequest('GET', 'referral_rewards', {
    select: 'id',
    referral_id: `eq.${referral.id}`,
    limit: '1'
  }).catch(() => []);
  if (existingReward) return null;
  const monthStart = startOfCurrentMonthIso();
  const monthRewards = await dbRequest('GET', 'referral_rewards', {
    select: 'amount_cents,status,created_at',
    referrer_company_id: `eq.${referral.referrer_company_id}`,
    created_at: `gte.${monthStart}`,
    status: 'in.(available,applied)',
    limit: '200'
  }).catch(() => []);
  const used = monthRewards.reduce((sum, reward) => sum + Number(reward.amount_cents || 0), 0);
  const amount = Math.max(0, Math.min(REFERRAL_REWARD_CENTS, REFERRAL_MONTHLY_LIMIT_CENTS - used));
  if (amount <= 0) {
    await dbRequest('PATCH', 'referrals', { id: `eq.${referral.id}` }, {
      status: 'paid_limit_reached',
      first_paid_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }, ['Prefer: return=minimal']).catch(() => {});
    return null;
  }
  const [reward] = await dbRequest('POST', 'referral_rewards', {}, {
    referral_id: referral.id,
    referrer_company_id: referral.referrer_company_id,
    referrer_store_id: referral.referrer_store_id || null,
    amount_cents: amount,
    status: 'available',
    reason: 'Primeira assinatura paga por indicação.',
    metadata: {
      payment_transaction_id: transactionId || null,
      paid_company_id: paidCompanyId,
      paid_amount_cents: amountCents || 0
    }
  }, ['Prefer: return=representation']);
  await dbRequest('PATCH', 'referrals', { id: `eq.${referral.id}` }, {
    status: 'paid',
    first_paid_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }, ['Prefer: return=minimal']).catch(() => {});
  await audit('referral.reward.available', {
    req,
    company_id: referral.referrer_company_id,
    store_id: referral.referrer_store_id || null,
    entity_type: 'referral_reward',
    entity_id: reward?.id || null,
    severity: 'info',
    after_data: { amount_cents: amount, referral_id: referral.id }
  });
  await sendReferralRewardEmail(referral, reward).catch(() => {});
  return reward;
}

function startOfCurrentMonthIso() {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)).toISOString();
}

function publicReferral(row = {}) {
  const meta = row.metadata || {};
  return {
    id: row.id,
    code: row.code,
    status: row.status || 'signed_up',
    referred_email: maskEmailOrToken(row.referred_email || ''),
    referred_company_name: meta.referred_company_name || '',
    referred_store_name: meta.referred_store_name || '',
    signed_up_at: row.signed_up_at || row.created_at || null,
    first_paid_at: row.first_paid_at || null
  };
}

function publicReferralReward(row = {}) {
  return {
    id: row.id,
    referral_id: row.referral_id || null,
    amount_cents: Number(row.amount_cents || 0),
    status: row.status || 'available',
    reason: row.reason || '',
    created_at: row.created_at || null
  };
}

async function sendReferralReceivedEmail(referral = {}) {
  const [admin] = await dbRequest('GET', 'admin_users', {
    select: 'email,name',
    company_id: `eq.${referral.referrer_company_id}`,
    role: 'in.(owner,admin,superadmin)',
    order: 'created_at.asc',
    limit: '1'
  }).catch(() => []);
  if (!admin?.email) return;
  const variables = {
    customer_name: admin.name || admin.email,
    company_name: referral.metadata?.referred_company_name || 'uma nova loja',
    store_name: referral.metadata?.referred_store_name || '',
    referral_code: referral.code || '',
    referral_reward: formatMoney(REFERRAL_REWARD_CENTS / 100),
    referral_url: absolutePanelUrl('/'),
    dashboard_url: absolutePanelUrl('/')
  };
  await sendPlatformTemplateEmail({
    to: admin.email,
    templateKey: 'referral_received',
    variables
  });
}

async function sendReferralRewardEmail(referral = {}, reward = {}) {
  const [admin] = await dbRequest('GET', 'admin_users', {
    select: 'email,name',
    company_id: `eq.${referral.referrer_company_id}`,
    role: 'in.(owner,admin,superadmin)',
    order: 'created_at.asc',
    limit: '1'
  }).catch(() => []);
  if (!admin?.email) return;
  const variables = {
    customer_name: admin.name || admin.email,
    company_name: referral.metadata?.referred_company_name || 'sua indicação',
    store_name: referral.metadata?.referred_store_name || '',
    referral_code: referral.code || '',
    referral_reward: formatMoney(Number(reward.amount_cents || 0) / 100),
    referral_url: absolutePanelUrl('/'),
    dashboard_url: absolutePanelUrl('/')
  };
  await sendPlatformTemplateEmail({
    to: admin.email,
    templateKey: 'referral_reward_unlocked',
    variables
  });
}

async function createPortalStoreSettings(storeId, parsed) {
  await dbRequest('POST', 'store_settings', {}, {
    store_id: storeId,
    name: parsed.store.name,
    slug: parsed.store.slug,
    description: parsed.store.description,
    whatsapp_number: normalizeBrazilLocalPhone(parsed.business.phone || parsed.owner.phone),
    address: parsed.business.address,
    payment_methods: ['Pix', 'Cartao na entrega', 'Dinheiro'],
    business_hours: defaultBusinessHours(),
    theme_settings: defaultThemeSettings(),
    onboarding_completed: false,
    is_open: false
  }, ['Prefer: return=minimal']);
}

async function getAdminOnboarding(admin) {
  const storeId = cleanUuid(admin.store_id);
  const companyId = cleanUuid(admin.company_id);
  if (!storeId || !companyId) throw httpError(422, 'Loja ativa não encontrada.');

  const [progressRows, store, categories, items] = await Promise.all([
    dbRequest('GET', 'onboarding_progress', {
      select: '*',
      company_id: `eq.${companyId}`,
      store_id: `eq.${storeId}`,
      limit: '1'
    }).catch(() => []),
    getStoreSettings(storeId),
    getMenu(true, storeId),
    dbRequest('GET', 'menu_items', {
      select: 'id,is_available',
      store_id: `eq.${storeId}`,
      limit: '1'
    }).catch(() => [])
  ]);

  const progress = progressRows[0] || await ensureOnboardingProgress(companyId, storeId);
  const computed = computeOnboardingSteps({ store, categories, items });
  const savedCompleted = new Set(Array.isArray(progress.completed_steps) ? progress.completed_steps : []);
  for (const step of computed.steps) {
    if (step.auto_completed) savedCompleted.add(step.key);
  }
  const completedSteps = [...savedCompleted];
  const total = computed.steps.length;
  const completedCount = computed.steps.filter((step) => completedSteps.includes(step.key)).length;
  const percent = total ? Math.round((completedCount / total) * 100) : 0;
  const blockers = computed.steps
    .filter((step) => !['appearance', 'publish'].includes(step.key) && !completedSteps.includes(step.key))
    .map((step) => step.title);

  return {
    progress: {
      ...progress,
      completed_steps: completedSteps,
      is_completed: progress.is_completed === true,
      store_published: store.onboarding_completed === true
    },
    store: publicStore(store),
    steps: computed.steps.map((step) => ({
      ...step,
      completed: completedSteps.includes(step.key)
    })),
    percent,
    can_publish: blockers.length === 0,
    blockers,
    public_url: `/${admin.active_store?.slug || store.slug || ''}`
  };
}

async function updateAdminOnboarding(admin, data = {}) {
  const storeId = cleanUuid(admin.store_id);
  const companyId = cleanUuid(admin.company_id);
  if (!storeId || !companyId) throw httpError(422, 'Loja ativa não encontrada.');
  const progress = await ensureOnboardingProgress(companyId, storeId);
  const requested = Array.isArray(data.completed_steps) ? data.completed_steps : [];
  const nextCompleted = [...new Set([
    ...(Array.isArray(progress.completed_steps) ? progress.completed_steps : []),
    ...requested.map((step) => cleanSlug(step)).filter(Boolean)
  ])];
  const currentStep = cleanSlug(data.current_step || progress.current_step || 'welcome');
  await dbRequest('PATCH', 'onboarding_progress', { id: `eq.${progress.id}` }, {
    current_step: currentStep,
    completed_steps: nextCompleted,
    metadata: isPlainObject(data.metadata) ? data.metadata : progress.metadata || {}
  }, ['Prefer: return=minimal']);
  return getAdminOnboarding(admin);
}

async function publishAdminOnboarding(req, admin) {
  const overview = await getAdminOnboarding(admin);
  if (!overview.can_publish) {
    throw httpError(422, `Antes de publicar: ${overview.blockers.join(', ')}.`);
  }
  const current = await getStoreSettings(admin.store_id);
  await dbRequest('PATCH', 'store_settings', { id: `eq.${current.id}` }, {
    onboarding_completed: true,
    is_open: true
  }, ['Prefer: return=minimal']);
  await ensureOnboardingProgress(admin.company_id, admin.store_id);
  await dbRequest('PATCH', 'onboarding_progress', {
    company_id: `eq.${admin.company_id}`,
    store_id: `eq.${admin.store_id}`
  }, {
    is_completed: false,
    current_step: 'tour',
    completed_steps: overview.steps.map((step) => step.key)
  }, ['Prefer: return=minimal']);
  clearStoreSettingsCache();
  await audit('onboarding.publish', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id,
    store_id: admin.store_id,
    entity_type: 'store_settings',
    entity_id: current.id,
    after_data: { onboarding_completed: true, is_open: true }
  });
  await recordMarketingMilestone('menu_published', {
    companyId: admin.company_id,
    storeId: admin.store_id,
    idempotencyKey: `menu_published:${admin.store_id}`,
    properties: { source: 'onboarding' }
  });
  return getAdminOnboarding(admin);
}

async function reopenAdminOnboarding(req, admin) {
  const storeId = cleanUuid(admin.store_id);
  const companyId = cleanUuid(admin.company_id);
  if (!storeId || !companyId) throw httpError(422, 'Loja ativa não encontrada.');
  const current = await getStoreSettings(storeId);
  const now = new Date().toISOString();
  await dbRequest('PATCH', 'store_settings', { id: `eq.${current.id}` }, {
    onboarding_completed: false,
    is_open: false
  }, ['Prefer: return=minimal']);
  const progress = await ensureOnboardingProgress(companyId, storeId);
  await dbRequest('PATCH', 'onboarding_progress', { id: `eq.${progress.id}` }, {
    is_completed: false,
    current_step: 'welcome',
    completed_steps: [],
    metadata: {
      ...(isPlainObject(progress.metadata) ? progress.metadata : {}),
      reopened_at: now,
      reopened_by: admin.id
    }
  }, ['Prefer: return=minimal']);
  await dbRequest('DELETE', 'admin_tour_progress', {
    admin_user_id: `eq.${admin.id}`,
    store_id: `eq.${storeId}`,
    tour_key: 'eq.admin-panel'
  }, null, ['Prefer: return=minimal']).catch(() => {});
  clearStoreSettingsCache(storeId);
  clearPublicBootstrapCache(storeId);
  await audit('admin.onboarding.reopen', {
    req,
    actor_admin_id: admin.id,
    company_id: companyId,
    store_id: storeId,
    entity_type: 'store_settings',
    entity_id: current.id,
    severity: 'warning',
    before_data: { onboarding_completed: current.onboarding_completed, is_open: current.is_open },
    after_data: { onboarding_completed: false, is_open: false }
  });
  return getAdminOnboarding(admin);
}

async function listAdminGuidedTours(admin) {
  const adminUserId = cleanUuid(admin.id, 'admin_user_id');
  const storeId = cleanUuid(admin.store_id, 'store_id');
  try {
    const tours = await dbRequest('GET', 'admin_tour_progress', {
      select: '*',
      admin_user_id: `eq.${adminUserId}`,
      store_id: `eq.${storeId}`,
      order: 'updated_at.desc'
    });
    return { tours: tours.map(publicAdminGuidedTour) };
  } catch (error) {
    if (isMissingTableError(error)) return { tours: [] };
    throw error;
  }
}

async function upsertAdminGuidedTour(admin, tourKey, data = {}) {
  const parsedTourKey = cleanAdminTourKey(tourKey);
  const adminUserId = cleanUuid(admin.id, 'admin_user_id');
  const storeId = cleanUuid(admin.store_id, 'store_id');
  const currentStep = cleanAdminTourStep(data.current_step || 'operation');
  const metadata = isPlainObject(data.metadata) ? data.metadata : {};
  const existing = await findAdminGuidedTour(adminUserId, storeId, parsedTourKey);
  const now = new Date().toISOString();
  const payload = {
    admin_user_id: adminUserId,
    store_id: storeId,
    tour_key: parsedTourKey,
    current_step: currentStep,
    completed_at: null,
    skipped_at: null,
    metadata,
    updated_at: now
  };
  try {
    if (existing) {
      const [updated] = await dbRequest('PATCH', 'admin_tour_progress', { id: `eq.${existing.id}` }, payload, ['Prefer: return=representation']);
      return publicAdminGuidedTour(updated || { ...existing, ...payload });
    }
    const [created] = await dbRequest('POST', 'admin_tour_progress', {}, {
      ...payload,
      created_at: now
    }, ['Prefer: return=representation']);
    return publicAdminGuidedTour(created);
  } catch (error) {
    if (isMissingTableError(error)) return publicAdminGuidedTour({ ...payload, created_at: now, updated_at: now });
    throw error;
  }
}

async function completeAdminGuidedTour(req, admin, tourKey) {
  const tour = await updateAdminGuidedTourAction(admin, tourKey, {
    completed_at: new Date().toISOString(),
    skipped_at: null
  });
  await markAdminOnboardingTourFinished(admin, 'tour_completed').catch(() => {});
  await audit('admin.tour.complete', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id,
    store_id: admin.store_id,
    entity_type: 'admin_tour_progress',
    entity_id: tour.id,
    after_data: { tour_key: tour.tour_key, current_step: tour.current_step }
  }).catch(() => {});
  return tour;
}

async function skipAdminGuidedTour(req, admin, tourKey) {
  const tour = await updateAdminGuidedTourAction(admin, tourKey, {
    skipped_at: new Date().toISOString()
  });
  await markAdminOnboardingTourFinished(admin, 'tour_skipped').catch(() => {});
  await audit('admin.tour.skip', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id,
    store_id: admin.store_id,
    entity_type: 'admin_tour_progress',
    entity_id: tour.id,
    after_data: { tour_key: tour.tour_key, current_step: tour.current_step }
  }).catch(() => {});
  return tour;
}

async function markAdminOnboardingTourFinished(admin, currentStep) {
  const companyId = cleanUuid(admin.company_id, 'company_id');
  const storeId = cleanUuid(admin.store_id, 'store_id');
  const progress = await ensureOnboardingProgress(companyId, storeId);
  const completedSteps = [...new Set([
    ...(Array.isArray(progress.completed_steps) ? progress.completed_steps : []),
    'training',
    'publish',
    'tour'
  ])];
  await dbRequest('PATCH', 'onboarding_progress', {
    company_id: `eq.${companyId}`,
    store_id: `eq.${storeId}`
  }, {
    is_completed: true,
    current_step: currentStep,
    completed_steps: completedSteps
  }, ['Prefer: return=minimal']);
}

async function updateAdminGuidedTourAction(admin, tourKey, payload = {}) {
  const parsedTourKey = cleanAdminTourKey(tourKey);
  const adminUserId = cleanUuid(admin.id, 'admin_user_id');
  const storeId = cleanUuid(admin.store_id, 'store_id');
  const existing = await findAdminGuidedTour(adminUserId, storeId, parsedTourKey);
  const now = new Date().toISOString();
  try {
    if (existing) {
      const [updated] = await dbRequest('PATCH', 'admin_tour_progress', { id: `eq.${existing.id}` }, {
        ...payload,
        updated_at: now
      }, ['Prefer: return=representation']);
      return publicAdminGuidedTour(updated || { ...existing, ...payload, updated_at: now });
    }
    const [created] = await dbRequest('POST', 'admin_tour_progress', {}, {
      admin_user_id: adminUserId,
      store_id: storeId,
      tour_key: parsedTourKey,
      current_step: 'operation',
      metadata: {},
      ...payload,
      created_at: now,
      updated_at: now
    }, ['Prefer: return=representation']);
    return publicAdminGuidedTour(created);
  } catch (error) {
    if (isMissingTableError(error)) {
      return publicAdminGuidedTour({
        admin_user_id: adminUserId,
        store_id: storeId,
        tour_key: parsedTourKey,
        current_step: 'operation',
        metadata: {},
        ...payload,
        created_at: now,
        updated_at: now
      });
    }
    throw error;
  }
}

async function findAdminGuidedTour(adminUserId, storeId, tourKey) {
  try {
    const [existing] = await dbRequest('GET', 'admin_tour_progress', {
      select: '*',
      admin_user_id: `eq.${adminUserId}`,
      store_id: `eq.${storeId}`,
      tour_key: `eq.${tourKey}`,
      limit: '1'
    });
    return existing || null;
  } catch (error) {
    if (isMissingTableError(error)) return null;
    throw error;
  }
}

function cleanAdminTourKey(value) {
  const tourKey = cleanSlug(value || '');
  if (tourKey !== 'admin-panel') throw httpError(422, 'Tour inválido.');
  return tourKey;
}

function cleanAdminTourStep(value) {
  const step = cleanSlug(value || 'operation');
  const allowed = new Set(['operation', 'orders', 'menu', 'tables', 'reports', 'store', 'plan', 'support']);
  if (!allowed.has(step)) throw httpError(422, 'Etapa do tour inválida.');
  return step;
}

function publicAdminGuidedTour(row = {}) {
  return {
    id: row.id,
    tour_key: row.tour_key,
    current_step: row.current_step,
    completed_at: row.completed_at || null,
    skipped_at: row.skipped_at || null,
    updated_at: row.updated_at || null
  };
}

function isMissingTableError(error) {
  const text = `${error?.message || ''} ${error?.detail || ''} ${JSON.stringify(error?.cause || {})}`;
  return /relation .* does not exist|schema cache|PGRST205|42P01|not found in the schema/i.test(text);
}

async function ensureOnboardingProgress(companyId, storeId) {
  const [existing] = await dbRequest('GET', 'onboarding_progress', {
    select: '*',
    company_id: `eq.${companyId}`,
    store_id: `eq.${storeId}`,
    limit: '1'
  }).catch(() => []);
  if (existing) return existing;
  const [created] = await dbRequest('POST', 'onboarding_progress', {}, {
    company_id: companyId,
    store_id: storeId,
    current_step: 'welcome',
    completed_steps: ['welcome'],
    is_completed: false,
    metadata: {}
  }, ['Prefer: return=representation']);
  return created;
}

function computeOnboardingSteps({ store, categories, items }) {
  const steps = [
    {
      key: 'welcome',
      title: 'Boas-vindas',
      description: 'Entenda o que será configurado antes de publicar.',
      auto_completed: true
    },
    {
      key: 'store',
      title: 'Dados da loja',
      description: 'Nome, endereço público e WhatsApp de pedidos.',
      auto_completed: Boolean(store.name && store.slug && store.whatsapp_number)
    },
    {
      key: 'operation',
      title: 'Operação',
      description: 'Defina atendimento, horários e canais de pedido.',
      auto_completed: Boolean(store.business_hours && Object.keys(store.business_hours).length)
    },
    {
      key: 'payments',
      title: 'Pagamentos',
      description: 'Adicione Pix, cartão, dinheiro ou pagamento online.',
      auto_completed: Array.isArray(store.payment_methods) && store.payment_methods.length > 0
    },
    {
      key: 'delivery',
      title: 'Entrega',
      description: 'Defina taxa, pedido mínimo e bairros atendidos.',
      auto_completed: store.delivery_fee !== undefined && store.minimum_order !== undefined
    },
    {
      key: 'category',
      title: 'Primeira categoria',
      description: 'Crie pelo menos uma categoria do cardápio.',
      auto_completed: Array.isArray(categories) && categories.length > 0
    },
    {
      key: 'product',
      title: 'Primeiro produto',
      description: 'Cadastre pelo menos um produto ativo.',
      auto_completed: Array.isArray(items) && items.length > 0
    },
    {
      key: 'appearance',
      title: 'Aparência',
      description: 'Adicione logo, capa ou cores para personalizar a loja.',
      auto_completed: Boolean(store.logo_url || store.cover_url || Object.keys(store.theme_settings || {}).length)
    },
    {
      key: 'training',
      title: 'Treinamento rápido',
      description: 'Conheça as áreas principais do painel administrativo.',
      auto_completed: false
    },
    {
      key: 'publish',
      title: 'Publicar cardápio',
      description: 'Libere a loja para receber pedidos.',
      auto_completed: store.onboarding_completed === true
    }
  ];
  const blockers = steps
    .filter((step) => !['appearance', 'publish'].includes(step.key) && !step.auto_completed)
    .map((step) => step.title);
  return {
    steps,
    blockers,
    canPublish: blockers.length === 0
  };
}

async function createOnboardingProgress(companyId, storeId, parsed) {
  await dbRequest('POST', 'onboarding_progress', {}, {
    company_id: companyId,
    store_id: storeId,
    current_step: 'welcome',
    completed_steps: ['welcome'],
    is_completed: false,
    metadata: {
      business_type: parsed.businessType,
      selected_plan: parsed.planCode,
      marketing_opt_in: parsed.marketingOptIn
    }
  }, ['Prefer: return=minimal']).catch(() => null);
}

async function createStarterMenu(storeId, businessType) {
  const names = starterCategoriesForBusiness(businessType).slice(0, 1);
  let sort = 1;
  for (const name of names) {
    await dbRequest('POST', 'menu_categories', {}, {
      store_id: storeId,
      name,
      sort_order: sort,
      is_active: true
    }, ['Prefer: return=minimal']).catch(() => null);
    sort += 1;
  }
}

function starterCategoriesForBusiness(type) {
  return ({
    hamburgueria: ['Hambúrgueres', 'Combos', 'Porções', 'Bebidas', 'Sobremesas'],
    pizzaria: ['Pizzas', 'Bordas', 'Combos', 'Bebidas', 'Sobremesas'],
    restaurante: ['Pratos', 'Entradas', 'Bebidas', 'Sobremesas'],
    lancheria: ['Lanches', 'Porções', 'Bebidas', 'Sobremesas'],
    cafeteria: ['Cafés', 'Salgados', 'Doces', 'Bebidas'],
    marmitaria: ['Marmitas', 'Guarnições', 'Bebidas', 'Sobremesas'],
    acai: ['Açaí', 'Complementos', 'Vitaminas', 'Bebidas'],
    confeitaria: ['Bolos', 'Doces', 'Salgados', 'Bebidas']
  })[cleanSlug(type)] || ['Principais', 'Combos', 'Bebidas'];
}

async function rollbackPortalSignup(created) {
  if (created.company?.id) {
    await dbRequest('DELETE', 'companies', { id: `eq.${created.company.id}` }, undefined, ['Prefer: return=minimal']).catch(() => {});
    return;
  }
  if (created.admin?.id) await dbRequest('DELETE', 'admin_users', { id: `eq.${created.admin.id}` }, undefined, ['Prefer: return=minimal']).catch(() => {});
}

function reservedPublicSlugs() {
  return new Set([
    'admin',
    'api',
    'login',
    'entrar',
    'cadastro',
    'criar-conta',
    'onboarding',
    'planos',
    'recursos',
    'demonstracao',
    'demo',
    'suporte',
    'dashboard',
    'platform',
    'plataform',
    'plataforma',
    'central',
    'cardapio',
    'cozinha',
    'pagamento',
    'pedidos',
    'conta',
    'cliente',
    'ajuda',
    'help',
    'termos',
    'privacidade',
    'confirmar-email',
    'ativar-conta',
    'redefinir-senha',
    'convite',
    ...seoLandingPages.map((page) => page.slug)
  ]);
}

async function updatePlatformCompany(id, data, admin) {
  const companyId = cleanUuid(id, 'empresa');
  const before = await getCompanyById(companyId);
  const payload = {};
  if ('name' in data) payload.name = cleanText(data.name);
  if ('document' in data) payload.document = cleanText(data.document || '') || null;
  if ('billing_email' in data || 'email' in data) payload.billing_email = cleanEmail(data.billing_email || data.email || '') || null;
  if ('phone' in data) payload.phone = onlyDigits(data.phone || '');
  if ('status' in data) payload.status = sanitizeCompanyStatus(data.status);
  if (!Object.keys(payload).length) throw httpError(422, 'Informe algum dado para atualizar.');
  if (!payload.name && 'name' in payload) throw httpError(422, 'Informe o nome da empresa.');
  const [company] = await dbRequest('PATCH', 'companies', { id: `eq.${companyId}` }, payload, ['Prefer: return=representation']);
  if (!company) throw httpError(404, 'Empresa não encontrada.');
  await audit('platform.company.update', {
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company',
    entity_id: company.id,
    before_data: before,
    after_data: payload
  });
  return company;
}

async function setPlatformCompanyStatus(req, id, data, admin) {
  const status = sanitizeCompanyStatus(data.status);
  if (['suspended', 'cancelled', 'archived'].includes(status)) {
    await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  }
  return updatePlatformCompany(id, { status }, admin);
}

async function suspendPlatformCompany(req, id, data, admin) {
  await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  const company = await updatePlatformCompany(id, { status: 'suspended' }, admin);
  await audit('platform.company.suspend', {
    req,
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company',
    entity_id: company.id,
    severity: 'warning',
    after_data: { status: 'suspended', reason: cleanText(data.reason || '') || null }
  });
  return company;
}

async function activatePlatformCompany(req, id, data, admin) {
  const company = await updatePlatformCompany(id, { status: 'active' }, admin);
  await audit('platform.company.activate', {
    req,
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company',
    entity_id: company.id,
    severity: 'info',
    after_data: { status: 'active', reason: cleanText(data.reason || '') || null }
  });
  return company;
}

async function reopenPlatformCompanyOnboarding(req, id, data, admin) {
  const companyId = cleanUuid(id, 'empresa');
  const company = await getCompanyById(companyId);
  const stores = await dbRequest('GET', 'stores', {
    select: 'id,name,slug',
    company_id: `eq.${companyId}`,
    limit: '200'
  }).catch(() => []);
  for (const store of stores) {
    await dbRequest('PATCH', 'store_settings', { store_id: `eq.${store.id}` }, {
      onboarding_completed: false
    }, ['Prefer: return=minimal']).catch(() => {});
    await dbRequest('PATCH', 'onboarding_progress', {
      company_id: `eq.${companyId}`,
      store_id: `eq.${store.id}`
    }, {
      is_completed: false,
      current_step: 'welcome',
      completed_steps: [],
      metadata: {
        reopened_at: new Date().toISOString(),
        reopened_by: admin.id,
        source: 'platform'
      }
    }, ['Prefer: return=minimal']).catch(() => {});
    await dbRequest('DELETE', 'admin_tour_progress', {
      store_id: `eq.${store.id}`,
      tour_key: 'eq.admin-panel'
    }, null, ['Prefer: return=minimal']).catch(() => {});
    clearStoreSettingsCache(store.id);
    clearPublicBootstrapCache(store.id);
  }
  await audit('platform.company.reopen_onboarding', {
    req,
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company',
    entity_id: company.id,
    severity: 'warning',
    after_data: {
      stores: stores.map((store) => ({ id: store.id, slug: store.slug })),
      reason: cleanText(data.reason || '') || null
    }
  });
  return { ok: true, stores_updated: stores.length };
}

async function resendPlatformCompanyBilling(req, id, data, admin) {
  const companyId = cleanUuid(id, 'empresa');
  const company = await getCompanyById(companyId);
  const subscriptions = await listCompanySubscriptions(companyId, 10);
  const subscription = pickCurrentCompanySubscription(subscriptions);
  await dbRequest('POST', 'subscription_events', {}, {
    company_id: company.id,
    subscription_id: subscription?.id || null,
    event_type: 'billing.resend_requested',
    description: 'Reenvio de cobrança solicitado pelo Admin Master.',
    created_by: admin.id,
    metadata: {
      status: 'pending',
      provider: PLATFORM_BILLING_PROVIDER || 'manual',
      requested_by: admin.id,
      target_email: company.billing_email || null,
      note: cleanText(data.note || data.reason || '').slice(0, 300) || null
    }
  }, ['Prefer: return=minimal']).catch(() => {});
  await audit('platform.company.resend_billing', {
    req,
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company',
    entity_id: company.id,
    severity: 'info',
    after_data: {
      status: 'requested',
      provider: PLATFORM_BILLING_PROVIDER || 'manual',
      target_email: company.billing_email || null
    }
  });
  return {
    ok: true,
    message: 'Solicitação de reenvio de cobrança registrada para o suporte financeiro.'
  };
}

async function changePlatformCompanyPlan(id, data, admin) {
  const companyId = cleanUuid(id, 'empresa');
  const planCode = cleanSlug(data.plan_code || data.code || '');
  if (!planCode) throw httpError(422, 'Informe o plano.');
  const company = await getCompanyById(companyId);
  const [plan] = await dbRequest('GET', 'subscription_plans', {
    select: '*',
    code: `eq.${planCode}`,
    is_active: 'eq.true',
    limit: '1'
  });
  if (!plan) throw httpError(404, 'Plano não encontrado.');
  const startsAt = new Date().toISOString();
  const endsAt = data.current_period_ends_at || new Date(Date.now() + 30 * 86400000).toISOString();
  const payload = {
    company_id: companyId,
    plan_id: plan.id,
    status: sanitizeSubscriptionStatus(data.status || company.status || 'active'),
    current_period_starts_at: startsAt,
    current_period_ends_at: endsAt,
    next_renewal_at: endsAt,
    billing_provider: 'manual',
    metadata: { source: 'platform_plan_change', changed_by: admin.id }
  };
  await dbRequest('PATCH', 'company_subscriptions', {
    company_id: `eq.${companyId}`,
    status: 'in.(active,trial,past_due)'
  }, { status: 'expired' }, ['Prefer: return=minimal']).catch(() => {});
  const [subscription] = await dbRequest('POST', 'company_subscriptions', {}, payload, ['Prefer: return=representation']);
  await audit('platform.subscription.change', {
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company_subscription',
    entity_id: subscription.id,
    after_data: { plan_code: plan.code, status: payload.status }
  });
  return { ...subscription, plan };
}

async function changePlatformCompanyPlanSecure(req, id, data, admin) {
  const companyId = cleanUuid(id, 'empresa');
  const planCode = cleanSlug(data.plan_code || data.code || '');
  if (!planCode) throw httpError(422, 'Informe o plano.');
  const company = await getCompanyById(companyId);
  const [plan] = await dbRequest('GET', 'subscription_plans', {
    select: '*',
    code: `eq.${planCode}`,
    is_active: 'eq.true',
    limit: '1'
  });
  if (!plan) throw httpError(404, 'Plano não encontrado.');
  const currentSubscription = pickCurrentCompanySubscription(await listCompanySubscriptions(companyId, 100));
  const currentPlan = currentSubscription?.plan_id
    ? (await dbRequest('GET', 'subscription_plans', { select: '*', id: `eq.${currentSubscription.plan_id}`, limit: '1' }).catch(() => []))[0] || null
    : null;
  const changeType = billingPlanChangeType(currentPlan, plan);
  if (['downgrade'].includes(changeType) || data.require_confirmation === true) {
    await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  }
  const warnings = await planLimitWarnings(companyId, null, plan).catch(() => []);
  const subscription = await changePlatformCompanyPlan(companyId, {
    plan_code: plan.code,
    status: data.status || 'active',
    current_period_ends_at: data.current_period_ends_at
  }, admin);
  await dbRequest('POST', 'subscription_events', {}, {
    company_id: company.id,
    subscription_id: subscription.id,
    event_type: `platform.${changeType}`,
    description: `Plano alterado no Platform para ${plan.name}.`,
    created_by: admin.id,
    metadata: {
      provider: 'manual',
      plan_code: plan.code,
      plan_name: plan.name,
      previous_plan_code: currentPlan?.code || null,
      amount_cents: moneyToCents(plan.monthly_price || 0),
      change_type: changeType,
      downgrade_warnings: warnings
    }
  }, ['Prefer: return=minimal']).catch(() => {});
  await audit('platform.billing.change_plan', {
    req,
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company_subscription',
    entity_id: subscription.id,
    severity: changeType === 'downgrade' ? 'warning' : 'info',
    after_data: { plan_code: plan.code, previous_plan_code: currentPlan?.code || null, change_type: changeType, warnings }
  });
  return { ...subscription, plan, change_type: changeType, downgrade_warnings: warnings };
}

async function cancelPlatformCompanySubscription(req, id, data, admin) {
  await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  const companyId = cleanUuid(id, 'empresa');
  const company = await getCompanyById(companyId);
  const current = pickCurrentCompanySubscription(await listCompanySubscriptions(companyId, 100));
  if (!current) throw httpError(404, 'Assinatura não encontrada para este cliente.');
  const now = new Date().toISOString();
  const [subscription] = await dbRequest('PATCH', 'company_subscriptions', { id: `eq.${current.id}` }, {
    status: 'cancelled',
    cancelled_at: now,
    metadata: { ...(current.metadata || {}), cancelled_by: admin.id, cancelled_reason: cleanText(data.reason || '').slice(0, 300) || null }
  }, ['Prefer: return=representation']);
  await dbRequest('PATCH', 'companies', { id: `eq.${companyId}` }, { status: 'cancelled' }, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('POST', 'subscription_events', {}, {
    company_id: companyId,
    subscription_id: subscription.id,
    event_type: 'platform.subscription_cancelled',
    description: 'Assinatura cancelada manualmente pelo Admin Master.',
    created_by: admin.id,
    metadata: {
      provider: subscription.billing_provider || 'manual',
      status: 'cancelled',
      external_reference: subscription.external_subscription_id || null,
      reason: cleanText(data.reason || '').slice(0, 300) || null
    }
  }, ['Prefer: return=minimal']).catch(() => {});
  await audit('platform.billing.cancel_subscription', {
    req,
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company_subscription',
    entity_id: subscription.id,
    severity: 'warning',
    after_data: { status: 'cancelled', reason: cleanText(data.reason || '') || null }
  });
  return { ok: true, subscription };
}

async function reactivatePlatformCompanySubscription(req, id, data, admin) {
  const companyId = cleanUuid(id, 'empresa');
  const company = await getCompanyById(companyId);
  const subscriptions = await listCompanySubscriptions(companyId, 100);
  let current = pickCurrentCompanySubscription(subscriptions);
  let plan = null;
  const planCode = cleanSlug(data.plan_code || data.code || '');
  if (planCode) {
    [plan] = await dbRequest('GET', 'subscription_plans', {
      select: '*',
      code: `eq.${planCode}`,
      is_active: 'eq.true',
      limit: '1'
    });
  } else if (current?.plan_id) {
    [plan] = await dbRequest('GET', 'subscription_plans', {
      select: '*',
      id: `eq.${current.plan_id}`,
      limit: '1'
    }).catch(() => []);
  }
  if (!plan) throw httpError(422, 'Informe um plano ativo para reativar a assinatura.');
  const now = new Date();
  const periodEnd = new Date(now.getTime() + 30 * 86400000).toISOString();
  if (!current || current.status === 'expired') {
    const [created] = await dbRequest('POST', 'company_subscriptions', {}, {
      company_id: companyId,
      plan_id: plan.id,
      status: 'active',
      current_period_starts_at: now.toISOString(),
      current_period_ends_at: periodEnd,
      next_renewal_at: periodEnd,
      billing_provider: 'manual',
      last_payment_at: now.toISOString(),
      metadata: { source: 'platform_reactivation', reactivated_by: admin.id, amount_cents: moneyToCents(plan.monthly_price || 0) }
    }, ['Prefer: return=representation']);
    current = created;
  } else {
    [current] = await dbRequest('PATCH', 'company_subscriptions', { id: `eq.${current.id}` }, {
      plan_id: plan.id,
      status: 'active',
      current_period_starts_at: now.toISOString(),
      current_period_ends_at: periodEnd,
      next_renewal_at: periodEnd,
      last_payment_at: now.toISOString(),
      payment_due_at: null,
      cancelled_at: null,
      suspended_at: null,
      metadata: { ...(current.metadata || {}), reactivated_by: admin.id, amount_cents: moneyToCents(plan.monthly_price || 0) }
    }, ['Prefer: return=representation']);
  }
  await dbRequest('PATCH', 'companies', { id: `eq.${companyId}` }, { status: 'active' }, ['Prefer: return=minimal']).catch(() => {});
  await dbRequest('POST', 'subscription_events', {}, {
    company_id: companyId,
    subscription_id: current.id,
    event_type: 'platform.subscription_reactivated',
    description: `Assinatura reativada no plano ${plan.name}.`,
    created_by: admin.id,
    metadata: {
      provider: current.billing_provider || 'manual',
      status: 'active',
      plan_code: plan.code,
      plan_name: plan.name,
      amount_cents: moneyToCents(plan.monthly_price || 0)
    }
  }, ['Prefer: return=minimal']).catch(() => {});
  await audit('platform.billing.reactivate_subscription', {
    req,
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company_subscription',
    entity_id: current.id,
    after_data: { status: 'active', plan_code: plan.code }
  });
  return { ok: true, subscription: current, plan };
}

async function updatePlatformStore(id, data, admin) {
  const storeId = cleanUuid(id, 'loja');
  const before = await getStoreById(storeId);
  const payload = {};
  if ('name' in data) payload.name = cleanText(data.name);
  if ('slug' in data) payload.slug = cleanSlug(data.slug);
  if ('description' in data) payload.description = cleanText(data.description || '') || null;
  if ('is_active' in data) payload.is_active = Boolean(data.is_active);
  if (!Object.keys(payload).length) throw httpError(422, 'Informe algum dado para atualizar.');
  if (!payload.name && 'name' in payload) throw httpError(422, 'Informe o nome da loja.');
  if (!payload.slug && 'slug' in payload) throw httpError(422, 'Informe um endereço público válido.');
  if (payload.slug) payload.public_url = `/${payload.slug}`;
  const [store] = await dbRequest('PATCH', 'stores', { id: `eq.${storeId}` }, payload, ['Prefer: return=representation']);
  if (!store) {
    throw httpError(404, 'Loja não encontrada ou indisponível.', { code: 'STORE_NOT_FOUND' });
  }
  if (payload.name || payload.slug || payload.description) {
    await dbRequest('PATCH', 'store_settings', { store_id: `eq.${storeId}` }, {
      ...(payload.name ? { name: payload.name } : {}),
      ...(payload.slug ? { slug: payload.slug } : {}),
      ...(payload.description !== undefined ? { description: payload.description } : {})
    }, ['Prefer: return=minimal']).catch(() => {});
  }
  clearStoreSettingsCache(storeId);
  clearPublicBootstrapCache(storeId);
  await audit('platform.store.update', {
    company_id: store.company_id,
    store_id: store.id,
    actor_admin_id: admin.id,
    entity_type: 'store',
    entity_id: store.id,
    before_data: before,
    after_data: payload
  });
  return publicStoreRef(store);
}

async function setPlatformStoreStatus(id, data, admin) {
  return updatePlatformStore(id, { is_active: data.is_active !== false }, admin);
}

async function createCompanyFeatureOverride(companyId, data, admin) {
  const resolvedCompanyId = cleanUuid(companyId, 'empresa');
  const featureCode = cleanSlug(data.feature_code || data.code || '');
  const overrideType = cleanSlug(data.override_type || data.type || '');
  if (!featureCode) throw httpError(422, 'Informe o recurso.');
  if (!['allow', 'block', 'limit'].includes(overrideType)) throw httpError(422, 'Informe o tipo de exceção.');
  const company = await getCompanyById(resolvedCompanyId);
  const [feature] = await dbRequest('GET', 'platform_features', {
    select: '*',
    code: `eq.${featureCode}`,
    limit: '1'
  });
  if (!feature) throw httpError(404, 'Recurso não encontrado.');
  const payload = {
    company_id: company.id,
    feature_id: feature.id,
    override_type: overrideType,
    limit_value: overrideType === 'limit' ? Math.max(0, Number(data.limit_value || 0)) : null,
    starts_at: data.starts_at || new Date().toISOString(),
    ends_at: data.ends_at || null,
    reason: cleanText(data.reason || '') || null,
    created_by: admin.id
  };
  const [override] = await dbRequest('POST', 'company_feature_overrides', {}, payload, ['Prefer: return=representation']);
  await audit('platform.feature_override.create', {
    company_id: company.id,
    actor_admin_id: admin.id,
    entity_type: 'company_feature_override',
    entity_id: override.id,
    after_data: { feature_code: feature.code, override_type: overrideType, limit_value: payload.limit_value }
  });
  return { ...override, feature };
}

async function deleteCompanyFeatureOverride(id, admin) {
  const overrideId = cleanUuid(id, 'exceção');
  const [before] = await dbRequest('GET', 'company_feature_overrides', {
    select: '*',
    id: `eq.${overrideId}`,
    limit: '1'
  });
  if (!before) throw httpError(404, 'Exceção não encontrada.');
  await dbRequest('DELETE', 'company_feature_overrides', { id: `eq.${overrideId}` }, null, ['Prefer: return=minimal']);
  await audit('platform.feature_override.delete', {
    company_id: before.company_id,
    actor_admin_id: admin.id,
    entity_type: 'company_feature_override',
    entity_id: overrideId,
    before_data: before
  });
}

async function listCompanySubscriptions(companyId, limit = 20) {
  const resolvedCompanyId = cleanUuid(companyId);
  if (!resolvedCompanyId) return [];
  return dbRequest('GET', 'company_subscriptions', {
    select: '*',
    company_id: `eq.${resolvedCompanyId}`,
    order: 'created_at.desc',
    limit: String(limit)
  }).catch(() => []);
}

function pickCurrentCompanySubscription(subscriptions = []) {
  const list = Array.isArray(subscriptions) ? subscriptions : [];
  return list.find((entry) => ['active', 'trial', 'grace_period'].includes(entry.status))
    || list.find((entry) => ['past_due', 'suspended', 'expired'].includes(entry.status))
    || list.find((entry) => entry.status === 'payment_pending')
    || list[0]
    || null;
}

async function getCompanyPlanOverview(companyId, storeId, admin = null) {
  const resolvedCompanyId = cleanUuid(companyId);
  if (!resolvedCompanyId) {
    return { company: null, subscription: null, pending_subscription: null, plan: null, features: [], available_plans: [], usage: await companyUsageSnapshot(companyId, storeId) };
  }
  const [company, subscriptions, availablePlans, billingHistory, storeAddons] = await Promise.all([
    getCompanyById(resolvedCompanyId).catch(() => null),
    listCompanySubscriptions(resolvedCompanyId),
    listPortalPlans({ includeInternal: canSeeInternalTestPlans(admin) }).then((data) => data.plans || []).catch(() => []),
    listBillingHistory(resolvedCompanyId),
    listStoreSubscriptionAddons(storeId)
  ]);
  const subscription = pickCurrentCompanySubscription(subscriptions);
  const pendingSubscription = subscriptions.find((entry) => entry.status === 'payment_pending') || null;
  let plan = null;
  let features = [];
  if (subscription?.plan_id) {
    plan = (await dbRequest('GET', 'subscription_plans', {
      select: '*',
      id: `eq.${subscription.plan_id}`,
      limit: '1'
    }).catch(() => []))[0] || null;
    features = await listCompanyPlanFeatures(subscription.plan_id);
  }
  return {
    company,
    subscription,
    pending_subscription: pendingSubscription,
    plan,
    features,
    available_plans: availablePlans,
    addons: storeAddons.map((entry) => ({
      id: entry.id,
      code: entry.addon?.code || '',
      name: entry.addon?.name || 'Adicional',
      status: entry.status,
      price_cents: Number(entry.addon?.monthly_price_cents || 0),
      provider_cost_cents: Number(entry.addon?.provider_cost_cents || 0),
      next_renewal_at: entry.next_renewal_at || null
    })),
    billing_history: billingHistory,
    usage: await companyUsageSnapshot(resolvedCompanyId, storeId)
  };
}

async function listBillingHistory(companyId) {
  const resolvedCompanyId = cleanUuid(companyId);
  if (!resolvedCompanyId) return [];
  const [subscriptionEvents, addonEvents] = await Promise.all([
    dbRequest('GET', 'subscription_events', {
      select: '*',
      company_id: `eq.${resolvedCompanyId}`,
      order: 'created_at.desc',
      limit: '20'
    }).catch(() => []),
    dbRequest('GET', 'addon_billing_events', {
      select: '*',
      company_id: `eq.${resolvedCompanyId}`,
      order: 'created_at.desc',
      limit: '20'
    }).catch(() => [])
  ]);
  return [
    ...subscriptionEvents.map((entry) => ({ ...entry, billing_type: 'plan' })),
    ...addonEvents.map((entry) => ({
      ...entry,
      billing_type: 'addon',
      event_type: entry.event_type,
      metadata: {
        ...(entry.metadata || {}),
        amount_cents: entry.amount_cents,
        provider: entry.provider,
        description: entry.description
      }
    }))
  ].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).slice(0, 20);
}

async function assertTrialCanBeActivated(companyId, plan) {
  if (plan?.code !== 'trial' && moneyCents(plan?.monthly_price || 0) > 0) return;
  const subscriptions = await listCompanySubscriptions(companyId, 100);
  const usedTrial = subscriptions.some((entry) => entry.status === 'trial' || entry.trial_ends_at || entry.metadata?.source === 'free_plan');
  if (usedTrial) throw httpError(409, 'Esta empresa já utilizou o período de teste.');
}

function billingPlanChangeType(currentPlan, nextPlan) {
  if (!currentPlan?.code) return 'activation';
  const currentOrder = Number(currentPlan.sort_order || 0);
  const nextOrder = Number(nextPlan.sort_order || 0);
  if (nextOrder > currentOrder) return 'upgrade';
  if (nextOrder < currentOrder) return 'downgrade';
  return 'same_plan';
}

async function planLimitWarnings(companyId, storeId, plan) {
  if (!plan?.id) return [];
  const [features, usage] = await Promise.all([
    listCompanyPlanFeatures(plan.id),
    companyUsageSnapshot(companyId, storeId)
  ]);
  const labels = {
    digital_menu: ['products', 'Produtos'],
    menu_categories: ['categories', 'Categorias'],
    orders: ['orders_month', 'Pedidos no mês'],
    admin_users: ['users', 'Usuários da equipe'],
    tables: ['tables', 'Mesas'],
    customers: ['customers', 'Clientes']
  };
  return features.flatMap((entry) => {
    const code = entry.feature?.code;
    const limit = Number(entry.limit_value || 0);
    const [usageKey, label] = labels[code] || [];
    if (!usageKey || !limit) return [];
    const used = Number(usage[usageKey] ?? usage[usageKey.replace('_month', '')] ?? 0);
    return used > limit ? [{ feature: code, usage_key: usageKey, label, used, limit }] : [];
  });
}

async function createBillingCheckout(req, admin, data = {}) {
  const companyId = cleanUuid(admin.company_id, 'empresa');
  const planCode = cleanPlanCode(data.plan_code || data.planCode || '');
  const billingCycle = normalizeBillingCycle(data.billing_cycle || data.billingCycle || 'monthly');
  if (!planCode) throw httpError(422, 'Informe o plano desejado.');
  const [plan] = await dbRequest('GET', 'subscription_plans', {
    select: '*',
    code: `eq.${planCode}`,
    is_active: 'eq.true',
    limit: '1'
  });
  if (!plan) throw httpError(404, 'Plano não encontrado.');
  if (isInternalTestPlan(plan) && !canSeeInternalTestPlans(admin)) {
    throw httpError(404, 'Plano não encontrado.');
  }
  const [company] = await dbRequest('GET', 'companies', {
    select: '*',
    id: `eq.${companyId}`,
    limit: '1'
  });
  if (!company) throw httpError(404, 'Empresa não encontrada.');
  await assertTrialCanBeActivated(companyId, plan);
  const currentSubscription = pickCurrentCompanySubscription(await listCompanySubscriptions(companyId, 100));
  const currentPlan = currentSubscription?.plan_id
    ? (await dbRequest('GET', 'subscription_plans', { select: '*', id: `eq.${currentSubscription.plan_id}`, limit: '1' }).catch(() => []))[0] || null
    : null;
  const changeType = billingPlanChangeType(currentPlan, plan);
  const downgradeWarnings = await planLimitWarnings(companyId, admin.store_id, plan);
  const amount = planBillingAmountCents(plan, billingCycle);
  const billingConfig = await privatePlatformBillingSettings();
  const reusableCheckout = await findReusablePendingBillingCheckout(companyId, plan.id, billingCycle);
  if (reusableCheckout?.checkout_url) {
    return {
      subscription: reusableCheckout.subscription,
      plan,
      payment_transaction: reusableCheckout.transaction,
      checkout_url: reusableCheckout.checkout_url,
      provider: reusableCheckout.subscription?.billing_provider || billingConfig.provider,
      reused: true,
      billing_cycle: reusableCheckout.subscription?.metadata?.billing_cycle || billingCycle,
      change_type: reusableCheckout.subscription?.metadata?.change_type || changeType,
      downgrade_warnings: reusableCheckout.subscription?.metadata?.downgrade_warnings || downgradeWarnings
    };
  }
  if (amount > 0 && billingConfig.provider !== 'mock' && !billingConfig.api_key) {
    throw httpError(503, 'Checkout indisponível: configure ABACATEPAY_API_KEY ou PLATFORM_BILLING_API_KEY no servidor.');
  }
  if (amount <= 0) {
    const activated = await activateCompanyPlan(req, admin, company, plan, {
      source: 'free_plan',
      provider: 'manual',
      currentPlan,
      changeType,
      billingCycle,
      amountCents: amount,
      downgradeWarnings
    });
    return {
      ...activated,
      checkout_url: null,
      provider: 'manual',
      activated: true,
      billing_cycle: billingCycle,
      change_type: changeType,
      downgrade_warnings: downgradeWarnings
    };
  }
  const checkout = await createProviderSubscriptionCheckout({ company, plan, admin, amount, billingCycle, billingConfig });
  if (!checkout.checkoutUrl) {
    throw httpError(502, 'O provedor de pagamento não retornou a URL do checkout. Confira a configuração da Abacate Pay.');
  }
  const [subscription] = await dbRequest('POST', 'company_subscriptions', {}, {
    company_id: companyId,
    plan_id: plan.id,
    status: 'payment_pending',
    billing_provider: billingConfig.provider,
    external_subscription_id: checkout.subscriptionId || checkout.transactionId || null,
    payment_due_at: new Date(Date.now() + 3 * 86400000).toISOString(),
    metadata: {
      source: 'admin_billing_checkout',
      checkout_url: checkout.checkoutUrl || null,
      external_id: checkout.transactionId || null,
      plan_code: plan.code,
      billing_cycle: billingCycle,
      amount_cents: amount,
      change_type: changeType,
      downgrade_warnings: downgradeWarnings
    }
  }, ['Prefer: return=representation']);
  const transaction = await createSubscriptionPaymentTransaction({
    companyId,
    subscriptionId: subscription.id,
    planId: plan.id,
    provider: billingConfig.provider,
    externalTransactionId: checkout.subscriptionId || checkout.transactionId || null,
    status: 'pending',
    amountCents: amount,
    checkoutUrl: checkout.checkoutUrl || null,
    expiresAt: new Date(Date.now() + 3 * 86400000).toISOString(),
    metadata: {
      source: 'admin_billing_checkout',
      plan_code: plan.code,
      plan_name: plan.name,
      billing_cycle: billingCycle,
      checkout_external_id: checkout.transactionId || null,
      change_type: changeType,
      downgrade_warnings: downgradeWarnings
    }
  });
  await dbRequest('POST', 'subscription_events', {}, {
    company_id: companyId,
    subscription_id: subscription.id,
    event_type: 'checkout_created',
    description: `Cobrança criada para o plano ${plan.name}.`,
    metadata: {
      provider: billingConfig.provider,
      provider_event_id: checkout.subscriptionId || checkout.transactionId || `checkout_${Date.now()}`,
      payment_transaction_id: transaction?.id || null,
      plan_code: plan.code,
      billing_cycle: billingCycle,
      checkout_url: checkout.checkoutUrl || null,
      amount_cents: amount,
      change_type: changeType,
      downgrade_warnings: downgradeWarnings
    },
    created_by: admin.id
  }, ['Prefer: return=minimal']).catch(() => {});
  await audit('billing.checkout.create', {
    req,
    actor_admin_id: admin.id,
    company_id: companyId,
    store_id: admin.store_id,
    entity_type: 'company_subscription',
    entity_id: subscription.id,
    after_data: { plan_code: plan.code, billing_cycle: billingCycle, provider: billingConfig.provider }
  });
  return {
    subscription,
    plan,
    payment_transaction: transaction,
    checkout_url: checkout.checkoutUrl || null,
    provider: billingConfig.provider,
    billing_cycle: billingCycle,
    change_type: changeType,
    downgrade_warnings: downgradeWarnings
  };
}

async function createAddonCheckout(req, admin, data = {}) {
  const companyId = cleanUuid(admin.company_id, 'empresa');
  const storeId = cleanUuid(admin.store_id, 'loja');
  const addonCode = cleanAddonCode(data.addon_code || data.addonCode || 'whatsapp_automatic');
  const addon = await getPlanAddonByCode(addonCode);
  if (!addon) throw httpError(404, 'Adicional não encontrado.');
  const access = await getStoreAddonAccess(admin, addonCode);
  if (access.included) {
    return { addon, active_addon: access.active_addon || null, included: true, activated: true, checkout_url: null };
  }
  if (!access.available) {
    throw httpError(403, access.message, planErrorPayload('FEATURE_NOT_AVAILABLE', access.message, { addon: addonCode }));
  }
  if (access.active) {
    return { addon, active_addon: access.active_addon, activated: true, checkout_url: access.active_addon?.checkout_url || null };
  }
  const amount = Number(addon.monthly_price_cents || 0);
  const billingConfig = await privatePlatformBillingSettings();
  if (amount > 0 && billingConfig.provider !== 'mock' && !billingConfig.api_key) {
    throw httpError(503, 'Checkout indisponível: configure Abacate Pay na Central antes de vender adicionais.');
  }
  const [company] = await dbRequest('GET', 'companies', {
    select: '*',
    id: `eq.${companyId}`,
    limit: '1'
  });
  if (!company) throw httpError(404, 'Empresa não encontrada.');
  const currentSubscription = pickCurrentCompanySubscription(await listCompanySubscriptions(companyId, 100));

  if (billingConfig.provider === 'mock' || amount <= 0) {
    const activated = await activateStoreAddon(req, admin, {
      companyId,
      storeId,
      subscriptionId: currentSubscription?.id || null,
      addon,
      provider: 'manual',
      externalTransactionId: null,
      checkoutUrl: null,
      source: amount <= 0 ? 'free_addon' : 'manual_activation'
    });
    return { addon, active_addon: activated, checkout_url: null, provider: 'manual', activated: true };
  }

  const checkout = await createProviderAddonCheckout({ company, admin, addon, amount, billingConfig });
  if (!checkout.checkoutUrl) {
    throw httpError(502, 'O provedor de pagamento não retornou a URL do checkout do adicional.');
  }
  const [subscriptionAddon] = await dbRequest('POST', 'store_subscription_addons', {}, {
    company_id: companyId,
    store_id: storeId,
    subscription_id: currentSubscription?.id || null,
    addon_id: addon.id,
    status: 'payment_pending',
    provider: billingConfig.provider,
    external_transaction_id: checkout.subscriptionId || checkout.transactionId || null,
    checkout_url: checkout.checkoutUrl,
    metadata: {
      source: 'admin_addon_checkout',
      addon_code: addon.code,
      amount_cents: amount,
      provider_cost_cents: Number(addon.provider_cost_cents || 0),
      billing_type: addonBillingType(addon),
      service_type: isAssistedServiceAddon(addon) ? 'assisted_setup' : null,
      service_status: isAssistedServiceAddon(addon) ? 'payment_pending' : null
    }
  }, ['Prefer: return=representation']);
  const transaction = await createSubscriptionPaymentTransaction({
    companyId,
    subscriptionId: currentSubscription?.id || null,
    planId: null,
    provider: billingConfig.provider,
    externalTransactionId: checkout.subscriptionId || checkout.transactionId || null,
    status: 'pending',
    amountCents: amount,
    checkoutUrl: checkout.checkoutUrl,
    expiresAt: new Date(Date.now() + 3 * 86400000).toISOString(),
    metadata: {
      source: 'admin_addon_checkout',
      kind: 'addon',
      addon_code: addon.code,
      addon_id: addon.id,
      store_id: storeId,
      store_subscription_addon_id: subscriptionAddon.id
    }
  });
  await recordAddonBillingEvent({
    companyId,
    storeId,
    subscriptionAddonId: subscriptionAddon.id,
    addonId: addon.id,
    eventType: 'addon.checkout_created',
    status: 'pending',
    amountCents: amount,
    provider: billingConfig.provider,
    externalTransactionId: checkout.subscriptionId || checkout.transactionId || null,
    description: `Cobrança criada para o adicional ${addon.name}.`,
    metadata: { checkout_url: checkout.checkoutUrl, payment_transaction_id: transaction?.id || null }
  });
  await audit('billing.addon.checkout.create', {
    req,
    actor_admin_id: admin.id,
    company_id: companyId,
    store_id: storeId,
    entity_type: 'store_subscription_addon',
    entity_id: subscriptionAddon.id,
    after_data: { addon_code: addon.code, provider: billingConfig.provider, amount_cents: amount }
  });
  return {
    addon,
    active_addon: subscriptionAddon,
    payment_transaction: transaction,
    checkout_url: checkout.checkoutUrl,
    provider: billingConfig.provider
  };
}

const INTEGRATION_SETUP_ADDON_CODES = ['payment_setup_assisted'];

async function getIntegrationSetupOverview(admin) {
  const [payment, storeAddons] = await Promise.all([
    getAdminPaymentSetupAssistance(admin).catch(() => ({})),
    listStoreSubscriptionAddons(admin.store_id).catch(() => [])
  ]);
  const integrations = [];
  for (const code of INTEGRATION_SETUP_ADDON_CODES) {
    const addon = await getPlanAddonByCode(code);
    if (!addon) continue;
    const configured = payment.configured === true;
    const rows = storeAddons.filter((row) => row.addon?.code === code);
    const current = rows.find((row) => ['active', 'payment_pending'].includes(row.status)) || null;
    const serviceStatus = cleanSlug(current?.metadata?.service_status || '');
    const paymentPending = current?.status === 'payment_pending';
    const inProgress = paymentPending || Boolean(current?.metadata?.support_ticket_id) || ['awaiting_support', 'in_progress'].includes(serviceStatus);
    const access = await getStoreAddonAccess(admin, code).catch(() => ({ available: false, included: false }));
    const status = configured ? 'configured' : inProgress ? 'in_progress' : 'pending';
    integrations.push({
      code,
      name: 'Pix com Abacate Pay',
      status,
      status_label: status === 'configured' ? 'Configurada' : status === 'in_progress' ? 'Em configuração' : 'Pendente',
      checkout_pending: paymentPending,
      checkout_url: paymentPending ? cleanText(current.checkout_url || '') : '',
      available: Boolean(access.available || access.included),
      included: Boolean(access.included),
      price_cents: access.included ? 0 : Number(addon.monthly_price_cents || 0),
      price_label: access.included ? 'Incluso no plano' : addonPriceLabel(addon)
    });
  }
  const pending = integrations.filter((entry) => entry.status === 'pending');
  const hasInProgress = integrations.some((entry) => entry.status === 'in_progress');
  return {
    integrations,
    pending,
    pending_count: pending.length,
    has_in_progress: hasInProgress,
    show_banner: pending.length > 0 && !hasInProgress
  };
}

async function createIntegrationSetupCheckout(req, admin, data = {}) {
  const requestedCodes = [...new Set((Array.isArray(data.addon_codes) ? data.addon_codes : [])
    .map((code) => cleanAddonCode(code))
    .filter((code) => INTEGRATION_SETUP_ADDON_CODES.includes(code)))];
  if (!requestedCodes.length) throw httpError(422, 'Selecione ao menos uma configuração.');
  const overview = await getIntegrationSetupOverview(admin);
  if (overview.has_in_progress) throw httpError(409, 'Já existe uma configuração em andamento para esta loja.');
  const allowed = new Set(overview.pending.filter((entry) => entry.available).map((entry) => entry.code));
  const codes = requestedCodes.filter((code) => allowed.has(code));
  if (!codes.length) throw httpError(409, 'As configurações selecionadas já foram contratadas ou não estão disponíveis para seu plano.');
  const companyId = cleanUuid(admin.company_id, 'empresa');
  const storeId = cleanUuid(admin.store_id, 'loja');
  const [company] = await dbRequest('GET', 'companies', { select: '*', id: `eq.${companyId}`, limit: '1' });
  if (!company) throw httpError(404, 'Empresa não encontrada.');
  const selections = (await Promise.all(codes.map(async (code) => ({ addon: await getPlanAddonByCode(code), access: await getStoreAddonAccess(admin, code) })))).filter((entry) => entry.addon);
  const includedSelections = selections.filter((entry) => entry.access.included);
  const addons = selections.filter((entry) => !entry.access.included).map((entry) => entry.addon);
  const amount = addons.reduce((total, addon) => total + Number(addon.monthly_price_cents || 0), 0);
  const billingConfig = await privatePlatformBillingSettings();
  if (amount > 0 && billingConfig.provider !== 'mock' && !billingConfig.api_key) {
    throw httpError(503, 'Checkout indisponível: configure Abacate Pay na Central antes de vender configurações.');
  }
  const currentSubscription = pickCurrentCompanySubscription(await listCompanySubscriptions(companyId, 100));
  const activatedIncluded = [];
  for (const { addon } of includedSelections) {
    activatedIncluded.push(await activateStoreAddon(req, admin, {
      companyId, storeId, subscriptionId: currentSubscription?.id || null, addon,
      provider: 'included', source: 'included_setup_bundle'
    }));
  }
  if (!addons.length) {
    return { activated: true, addons: includedSelections.map((entry) => publicPlanAddon(entry.addon)), active_addons: activatedIncluded.map(publicStoreAddon), checkout_url: null };
  }
  if (billingConfig.provider === 'mock' || amount <= 0) {
    const activated = [...activatedIncluded];
    for (const addon of addons) {
      activated.push(await activateStoreAddon(req, admin, {
        companyId, storeId, subscriptionId: currentSubscription?.id || null, addon,
        provider: 'manual', source: amount <= 0 ? 'free_setup_bundle' : 'mock_setup_bundle'
      }));
    }
    return { activated: true, addons: selections.map((entry) => publicPlanAddon(entry.addon)), active_addons: activated.map(publicStoreAddon), checkout_url: null };
  }
  const checkout = await createProviderIntegrationSetupCheckout({ company, admin, addons, amount, billingConfig });
  const rows = [];
  for (const addon of addons) {
    const [row] = await dbRequest('POST', 'store_subscription_addons', {}, {
      company_id: companyId, store_id: storeId, subscription_id: currentSubscription?.id || null,
      addon_id: addon.id, status: 'payment_pending', provider: billingConfig.provider,
      external_transaction_id: checkout.subscriptionId || checkout.transactionId || null,
      checkout_url: checkout.checkoutUrl,
      metadata: { source: 'integration_setup_bundle', addon_code: addon.code, amount_cents: Number(addon.monthly_price_cents || 0), billing_type: 'one_time', service_type: 'assisted_setup', service_status: 'payment_pending' }
    }, ['Prefer: return=representation']);
    rows.push({ row, addon });
  }
  const transaction = await createSubscriptionPaymentTransaction({
    companyId, subscriptionId: currentSubscription?.id || null, planId: null,
    provider: billingConfig.provider, externalTransactionId: checkout.subscriptionId || checkout.transactionId || null,
    status: 'pending', amountCents: amount, checkoutUrl: checkout.checkoutUrl,
    expiresAt: new Date(Date.now() + 3 * 86400000).toISOString(),
    metadata: {
      source: 'integration_setup_bundle', kind: 'addon_bundle', store_id: storeId,
      addon_items: rows.map(({ row, addon }) => ({ addon_code: addon.code, addon_id: addon.id, store_subscription_addon_id: row.id, amount_cents: Number(addon.monthly_price_cents || 0) }))
    }
  });
  await audit('billing.integration_setup_bundle.checkout.create', {
    req, actor_admin_id: admin.id, company_id: companyId, store_id: storeId,
    entity_type: 'subscription_payment_transaction', entity_id: transaction?.id || null,
    after_data: { addon_codes: codes, amount_cents: amount, provider: billingConfig.provider }
  });
  return { addons: addons.map(publicPlanAddon), checkout_url: checkout.checkoutUrl, provider: billingConfig.provider, payment_transaction: transaction };
}

async function createProviderIntegrationSetupCheckout({ company, admin, addons, amount, billingConfig }) {
  const config = billingConfig || await privatePlatformBillingSettings();
  const origin = cleanText(config.public_url || panelBaseUrl() || process.env.APP_URL || 'http://127.0.0.1:3000').replace(/\/+$/, '');
  const items = [];
  for (const addon of addons) {
    items.push({ id: await ensureAbacateAddonProduct({ addon, amount: Number(addon.monthly_price_cents || 0), token: config.api_key }), quantity: 1 });
  }
  const customerId = await createAbacateSubscriptionCustomer({ company, admin, token: config.api_key }).catch(() => '');
  const externalId = cleanExternalId(`tapronto-setup-${company.id}-${Date.now()}`);
  const body = {
    items, methods: ['PIX', 'CARD'], returnUrl: `${origin}/?billing=addon-cancelled`, completionUrl: `${origin}/?billing=addon-success`, externalId,
    metadata: { companyId: company.id, storeId: admin.store_id, addonCodes: addons.map((addon) => addon.code).join(','), kind: 'platform_addon_bundle_charge' }
  };
  if (customerId) body.customerId = customerId;
  const data = await createAbacateCheckoutWithPixAutomaticFallback(body, config.api_key, 'configurações');
  const payload = data.data || data;
  const checkoutUrl = payload.url || payload.checkoutUrl || payload.paymentUrl || payload.subscription?.url || '';
  if (!checkoutUrl) throw httpError(502, 'A Abacate Pay criou a cobrança, mas não retornou a URL de checkout.');
  return { subscriptionId: String(payload.id || payload.checkoutId || payload.billingId || ''), transactionId: externalId, checkoutUrl, amount };
}

async function listAdminBillingAddons(admin) {
  const storeId = cleanUuid(admin.store_id || '');
  const rows = await dbRequest('GET', 'plan_addons', {
    select: '*',
    is_active: 'eq.true',
    order: 'sort_order.asc,name.asc',
    limit: '200'
  }).catch(() => []);
  const addons = [];
  for (const addon of rows) {
    const assisted = isAssistedServiceAddon(addon);
    const commercial = ['whatsapp_automatic'].includes(addon.code);
    if (!assisted && !commercial) continue;
    const access = await getStoreAddonAccess(admin, addon.code).catch(() => ({ addon, available: false, active: false, included: false }));
    const activeAddon = access.active_addon || null;
    addons.push({
      addon: publicPlanAddon(addon),
      available: Boolean(access.available),
      included: Boolean(access.included),
      active: Boolean(access.active),
      active_addon: activeAddon ? publicStoreAddon(activeAddon) : null,
      service_status: activeAddon?.metadata?.service_status || (access.included ? 'included' : ''),
      support_ticket_id: activeAddon?.metadata?.support_ticket_id || null,
      message: access.message || '',
      store_id: storeId || null
    });
  }
  return { addons };
}

function publicPlanAddon(addon = {}) {
  return {
    id: addon.id || null,
    code: addon.code || '',
    name: addon.name || '',
    description: addon.description || '',
    price_cents: Number(addon.monthly_price_cents || 0),
    price_label: addonPriceLabel(addon),
    billing_type: addonBillingType(addon),
    service_type: addon.settings?.service_type || '',
    support_category: addon.settings?.support_category || '',
    sort_order: Number(addon.sort_order || 0)
  };
}

function publicStoreAddon(row = {}) {
  return {
    id: row.id || null,
    status: row.status || '',
    checkout_url: row.checkout_url || '',
    activated_at: row.activated_at || null,
    current_period_ends_at: row.current_period_ends_at || null,
    next_renewal_at: row.next_renewal_at || null,
    metadata: {
      billing_type: row.metadata?.billing_type || '',
      service_type: row.metadata?.service_type || '',
      service_status: row.metadata?.service_status || '',
      support_ticket_id: row.metadata?.support_ticket_id || null
    }
  };
}

async function getPlanAddonByCode(code) {
  const addonCode = cleanAddonCode(code || '');
  if (!addonCode) return null;
  const [addon] = await dbRequest('GET', 'plan_addons', {
    select: '*',
    code: `eq.${addonCode}`,
    is_active: 'eq.true',
    limit: '1'
  }).catch(() => []);
  return addon || null;
}

async function listStoreSubscriptionAddons(storeId) {
  const resolvedStoreId = cleanUuid(storeId);
  if (!resolvedStoreId) return [];
  const rows = await dbRequest('GET', 'store_subscription_addons', {
    select: '*',
    store_id: `eq.${resolvedStoreId}`,
    status: 'in.(active,payment_pending,grace_period,past_due)',
    order: 'created_at.desc',
    limit: '50'
  }).catch(() => []);
  const addonIds = cleanUuidArray(rows.map((entry) => entry.addon_id));
  const addons = addonIds.length
    ? await dbRequest('GET', 'plan_addons', { select: '*', id: uuidInFilter(addonIds), limit: '50' }).catch(() => [])
    : [];
  const addonById = new Map(addons.map((entry) => [entry.id, entry]));
  return rows.map((entry) => ({ ...entry, addon: addonById.get(entry.addon_id) || null }));
}

async function getActiveStoreAddon(storeId, addonCode) {
  const resolvedStoreId = cleanUuid(storeId);
  const code = cleanAddonCode(addonCode || '');
  if (!resolvedStoreId || !code) return null;
  const rows = (await listStoreSubscriptionAddons(resolvedStoreId)).filter((entry) => entry.status === 'active');
  return rows.find((entry) => entry.addon?.code === code) || null;
}

async function getStoreAddonAccess(admin, addonCode) {
  const addon = await getPlanAddonByCode(addonCode);
  if (!addon) return { active: false, available: false, included: false, message: 'Adicional não encontrado.' };
  const { subscription, plan } = await getCurrentPlan(admin.company_id);
  const planCode = cleanSlug(plan?.code || '');
  const includedPlans = Array.isArray(addon.included_plan_codes) ? addon.included_plan_codes.map(cleanSlug) : [];
  const availablePlans = Array.isArray(addon.available_plan_codes) ? addon.available_plan_codes.map(cleanSlug) : [];
  const activeAddon = await getActiveStoreAddon(admin.store_id, addon.code);
  const included = includedPlans.includes(planCode);
  const available = availablePlans.includes(planCode);
  const active = Boolean(activeAddon) || included;
  const priceLabel = addonPriceLabel(addon);
  const availableLabel = availablePlans.length
    ? availablePlans.map((code) => code === 'essential' ? 'Essencial' : code === 'professional' ? 'Profissional' : code === 'premium' ? 'Premium' : code).join(', ')
    : 'planos superiores';
  const message = included
    ? `${addon.name} já está incluso no seu plano.`
    : available
      ? `${addon.name} pode ser contratado como adicional por ${priceLabel}.`
      : `${addon.name} está disponível em: ${availableLabel}.`;
  return {
    addon,
    plan,
    subscription,
    active,
    available,
    included,
    active_addon: activeAddon,
    message
  };
}

function addonBillingType(addon = {}) {
  const settings = isPlainObject(addon.settings) ? addon.settings : {};
  return cleanAddonCode(settings.billing_type || settings.billingType || 'monthly') || 'monthly';
}

function isOneTimeAddon(addon = {}) {
  return addonBillingType(addon) === 'one_time';
}

function addonPriceLabel(addon = {}) {
  const amount = Number(addon.monthly_price_cents || 0) / 100;
  if (!amount) return 'R$ 0,00';
  return isOneTimeAddon(addon) ? `${formatMoney(amount)} uma vez` : `${formatMoney(amount)}/mês`;
}

function isAssistedServiceAddon(addon = {}) {
  const settings = isPlainObject(addon.settings) ? addon.settings : {};
  return cleanAddonCode(settings.service_type || settings.serviceType || '') === 'assisted_setup';
}

function assistedServiceTicketInfo(addon = {}) {
  const settings = isPlainObject(addon.settings) ? addon.settings : {};
  return {
    category: cleanText(settings.support_category || settings.supportCategory || 'Serviço assistido') || 'Serviço assistido',
    subject: cleanText(settings.support_subject || settings.supportSubject || addon.name || 'Serviço assistido TáPronto') || 'Serviço assistido TáPronto'
  };
}

async function assertAutomaticWhatsappAccess(admin) {
  const planAccess = await getCompanyFeatureAccess(admin.company_id, 'automatic_whatsapp').catch(() => ({ enabled: false }));
  if (planAccess.enabled) return { ...planAccess, source: 'plan' };
  const addonAccess = await getStoreAddonAccess(admin, 'whatsapp_automatic').catch(() => null);
  if (addonAccess?.active) return { enabled: true, source: addonAccess.included ? 'included_addon' : 'addon', addon: addonAccess.active_addon || null };
  const message = addonAccess?.message || featureBlockedMessage('automatic_whatsapp');
  throw httpError(403, message, planErrorPayload('FEATURE_NOT_AVAILABLE', message, { feature: 'automatic_whatsapp', source: 'addon' }));
}

async function createProviderAddonCheckout({ company, admin, addon, amount, billingConfig = null }) {
  const config = billingConfig || await privatePlatformBillingSettings();
  if (config.provider === 'mock') {
    return {
      subscriptionId: `mock_addon_${company.id}_${Date.now()}`,
      checkoutUrl: absolutePanelUrl(`/?billing=mock&addon=${encodeURIComponent(addon.code)}`)
    };
  }
  if (config.provider !== 'abacatepay') throw httpError(422, 'Provedor de adicional não suportado.');
  const origin = cleanText(config.public_url || panelBaseUrl() || process.env.APP_URL || 'http://127.0.0.1:3000').replace(/\/+$/, '');
  const productId = await ensureAbacateAddonProduct({ addon, amount, token: config.api_key });
  const customerId = await createAbacateSubscriptionCustomer({ company, admin, token: config.api_key }).catch(() => '');
  const externalId = cleanExternalId(`tapronto-addon-${company.id}-${addon.code}-${Date.now()}`);
  const body = {
    items: [{ id: productId, quantity: 1 }],
    methods: ['PIX', 'CARD'],
    returnUrl: `${origin}/?billing=addon-cancelled`,
    completionUrl: `${origin}/?billing=addon-success`,
    externalId,
    metadata: {
      companyId: company.id,
      storeId: admin.store_id,
      addonCode: addon.code,
      addonId: addon.id,
      kind: 'platform_addon_charge'
    }
  };
  if (customerId) body.customerId = customerId;
  const data = await createAbacateCheckoutWithPixAutomaticFallback(body, config.api_key, 'adicional');
  const payload = data.data || data;
  const checkoutUrl = payload.url || payload.checkoutUrl || payload.paymentUrl || payload.subscription?.url || '';
  if (!checkoutUrl) throw httpError(502, 'A Abacate Pay criou a cobrança do adicional, mas não retornou a URL de checkout.');
  return {
    subscriptionId: String(payload.id || payload.checkoutId || payload.billingId || ''),
    transactionId: externalId,
    checkoutUrl
  };
}

async function ensureAbacateAddonProduct({ addon, amount, token }) {
  const externalId = cleanExternalId(`tapronto-addon-${addon.code}-${amount}`);
  const existing = await findAbacateProductByExternalId(externalId, token).catch(() => null);
  if (existing?.id) return String(existing.id);
  const data = await providerFetch(`${ABACATEPAY_API_BASE}/products/create`, {
    method: 'POST',
    token,
    body: {
      externalId,
      name: `Adicional ${addon.name}`,
      description: addon.description || (isOneTimeAddon(addon) ? 'Serviço adicional da plataforma TáPronto' : 'Adicional mensal da plataforma TáPronto'),
      price: amount,
      currency: 'BRL',
      ...(isOneTimeAddon(addon) ? {} : { cycle: 'MONTHLY' })
    }
  });
  const payload = data.data || data;
  const productId = payload.id || payload.product?.id || '';
  if (!productId) throw httpError(502, 'A Abacate Pay não retornou o identificador do produto adicional.');
  return String(productId);
}

async function activateStoreAddon(req, admin, data = {}) {
  const companyId = cleanUuid(data.companyId || admin.company_id, 'empresa');
  const storeId = cleanUuid(data.storeId || admin.store_id, 'loja');
  const addon = data.addon || await getPlanAddonByCode(data.addonCode || data.addon_code);
  if (!addon) throw httpError(404, 'Adicional não encontrado.');
  const now = new Date();
  const periodEnd = new Date(now.getTime() + 30 * 86400000);
  const oneTime = isOneTimeAddon(addon);
  const existing = await getActiveStoreAddon(storeId, addon.code);
  if (existing) return existing;
  const [row] = await dbRequest('POST', 'store_subscription_addons', {}, {
    company_id: companyId,
    store_id: storeId,
    subscription_id: data.subscriptionId || data.subscription_id || null,
    addon_id: addon.id,
    status: 'active',
    provider: data.provider || 'manual',
    external_transaction_id: data.externalTransactionId || data.external_transaction_id || null,
    checkout_url: data.checkoutUrl || data.checkout_url || null,
    current_period_starts_at: now.toISOString(),
    current_period_ends_at: oneTime ? null : periodEnd.toISOString(),
    next_renewal_at: oneTime ? null : periodEnd.toISOString(),
    activated_at: now.toISOString(),
    metadata: {
      source: data.source || 'addon_activation',
      amount_cents: Number(addon.monthly_price_cents || 0),
      provider_cost_cents: Number(addon.provider_cost_cents || 0),
      billing_type: addonBillingType(addon)
    }
  }, ['Prefer: return=representation']);
  await recordAddonBillingEvent({
    companyId,
    storeId,
    subscriptionAddonId: row.id,
    addonId: addon.id,
    eventType: 'addon.activated',
    status: 'active',
    amountCents: Number(addon.monthly_price_cents || 0),
    provider: data.provider || 'manual',
    externalTransactionId: data.externalTransactionId || data.external_transaction_id || null,
    description: oneTime ? `${addon.name} contratado para a loja.` : `${addon.name} ativado para a loja.`
  }).catch(() => {});
  await audit('billing.addon.activate', {
    req,
    actor_admin_id: admin.id,
    company_id: companyId,
    store_id: storeId,
    entity_type: 'store_subscription_addon',
    entity_id: row.id,
    after_data: { addon_code: addon.code, status: 'active' }
  }).catch(() => {});
  if (isAssistedServiceAddon(addon)) {
    return ensureAssistedAddonSupportTicket(req, admin, row, addon).catch(() => row);
  }
  return row;
}

async function ensureAssistedAddonSupportTicket(req, admin, subscriptionAddon, addon) {
  if (!isAssistedServiceAddon(addon) || !subscriptionAddon?.id) return subscriptionAddon;
  const companyId = cleanUuid(subscriptionAddon.company_id || admin.company_id || '', 'empresa');
  const storeId = cleanUuid(subscriptionAddon.store_id || admin.store_id || '', 'loja');
  const metadata = subscriptionAddon.metadata || {};
  if (metadata.support_ticket_id) return subscriptionAddon;
  const info = assistedServiceTicketInfo(addon);
  const existingTickets = await dbRequest('GET', 'support_tickets', {
    select: '*',
    company_id: `eq.${companyId}`,
    store_id: `eq.${storeId}`,
    category: `eq.${info.category}`,
    order: 'updated_at.desc',
    limit: '20'
  }).catch(() => []);
  let ticket = existingTickets.find((entry) => !['closed', 'resolved'].includes(entry.status) && cleanText(entry.subject || '').toLowerCase() === info.subject.toLowerCase());

  const [company, store, subscription] = await Promise.all([
    dbRequest('GET', 'companies', { select: 'id,name,billing_email,phone', id: `eq.${companyId}`, limit: '1' }).then((rows) => rows[0] || null).catch(() => null),
    dbRequest('GET', 'stores', { select: 'id,name,slug', id: `eq.${storeId}`, limit: '1' }).then((rows) => rows[0] || null).catch(() => null),
    dbRequest('GET', 'company_subscriptions', { select: '*', company_id: `eq.${companyId}`, order: 'created_at.desc', limit: '20' })
      .then((rows) => pickCurrentCompanySubscription(rows) || rows[0] || null)
      .catch(() => null)
  ]);
  const plan = subscription?.plan_id
    ? await dbRequest('GET', 'subscription_plans', { select: 'id,name,code,slug,monthly_price', id: `eq.${subscription.plan_id}`, limit: '1' })
      .then((rows) => rows[0] || null)
      .catch(() => null)
    : null;

  if (!ticket) {
    const now = new Date().toISOString();
    const message = [
      `Contato: ${admin.name || company?.name || 'Administrador'}`,
      '',
      `Serviço contratado: ${addon.name}`,
      addon.description ? `Descrição: ${addon.description}` : '',
      `Valor: ${addonPriceLabel(addon)}`,
      '',
      `Empresa: ${company?.name || 'Não identificada'}`,
      `Loja: ${store?.name || 'Loja atual'}`,
      `Slug: ${store?.slug || '-'}`,
      `Plano atual: ${plan?.name || 'Sem plano identificado'}`,
      `Status da assinatura: ${subscription?.status || 'Sem assinatura'}`,
      `E-mail do administrador: ${admin.email || '-'}`,
      `Contato financeiro: ${company?.billing_email || company?.phone || '-'}`,
      '',
      'Observação interna para a Central: serviço assistido já está pago/liberado. Entrar em contato com o cliente para combinar a configuração.'
    ].filter((line) => line !== '').join('\n');
    [ticket] = await dbRequest('POST', 'support_tickets', {}, {
      company_id: companyId,
      store_id: storeId,
      admin_user_id: admin.id || null,
      created_by_admin_id: admin.id || null,
      subject: info.subject,
      category: info.category,
      priority: planCodeIsPremium(plan) || addon.code === 'full_implementation_package' ? 'high' : 'medium',
      status: 'open',
      source: 'admin',
      last_message_at: now
    }, ['Prefer: return=representation']);
    await dbRequest('POST', 'support_ticket_messages', {}, {
      ticket_id: ticket.id,
      author_admin_id: admin.id || null,
      author_type: 'admin',
      message,
      is_internal: false
    }, ['Prefer: return=minimal']);
    await notifyPlatformSupportActivity(ticket, 'internal_support_ticket_opened', {
      messagePreview: `Serviço assistido contratado: ${addon.name}.`,
      company,
      store,
      req
    }).catch(() => {});
  }

  const [updated] = await dbRequest('PATCH', 'store_subscription_addons', { id: `eq.${subscriptionAddon.id}` }, {
    metadata: {
      ...(metadata || {}),
      service_type: 'assisted_setup',
      service_status: 'awaiting_support',
      support_ticket_id: ticket.id
    },
    updated_at: new Date().toISOString()
  }, ['Prefer: return=representation']);
  await audit('billing.addon.support_ticket.create', {
    req,
    actor_admin_id: admin.id || null,
    company_id: companyId,
    store_id: storeId,
    entity_type: 'support_ticket',
    entity_id: ticket.id,
    after_data: { addon_code: addon.code, subscription_addon_id: subscriptionAddon.id }
  }).catch(() => {});
  return updated || subscriptionAddon;
}

async function requestAssistedAddonSupport(req, admin, addonCode) {
  const addon = await getPlanAddonByCode(addonCode);
  if (!addon || !isAssistedServiceAddon(addon)) throw httpError(404, 'Serviço assistido não encontrado.');
  const access = await getStoreAddonAccess(admin, addon.code);
  if (!access.active && !access.included) {
    throw httpError(402, `Contrate ${addon.name} para abrir a solicitação com a equipe TáPronto.`, planErrorPayload('ADDON_REQUIRED', 'Serviço assistido não contratado.', { addon: addon.code }));
  }
  let row = access.active_addon;
  if (!row && access.included) {
    row = await activateStoreAddon(req, admin, {
      addon,
      provider: 'included',
      source: 'included_assisted_service'
    });
  } else {
    row = await ensureAssistedAddonSupportTicket(req, admin, row, addon);
  }
  return {
    addon: publicPlanAddon(addon),
    active_addon: publicStoreAddon(row),
    support_ticket_id: row?.metadata?.support_ticket_id || null,
    message: 'Solicitação aberta para a equipe TáPronto acompanhar.'
  };
}

async function recordAddonBillingEvent(data = {}) {
  const payload = {
    company_id: cleanUuid(data.companyId || data.company_id, 'empresa'),
    store_id: cleanUuid(data.storeId || data.store_id || '') || null,
    subscription_addon_id: cleanUuid(data.subscriptionAddonId || data.subscription_addon_id || '') || null,
    addon_id: cleanUuid(data.addonId || data.addon_id || '') || null,
    event_type: cleanText(data.eventType || data.event_type || 'addon.event'),
    status: cleanSlug(data.status || 'pending') || 'pending',
    amount_cents: Math.max(0, Number(data.amountCents ?? data.amount_cents ?? 0) || 0),
    provider: cleanSlug(data.provider || '') || null,
    external_event_id: cleanExternalId(data.externalEventId || data.external_event_id || '') || null,
    external_transaction_id: cleanExternalId(data.externalTransactionId || data.external_transaction_id || '') || null,
    description: cleanText(data.description || ''),
    metadata: sanitizeAuditPayload(data.metadata || {}) || {}
  };
  const [row] = await dbRequest('POST', 'addon_billing_events', {}, payload, ['Prefer: return=representation']);
  return row || null;
}

async function findReusablePendingBillingCheckout(companyId, planId, billingCycle = 'monthly') {
  const resolvedCompanyId = cleanUuid(companyId);
  const resolvedPlanId = cleanUuid(planId);
  if (!resolvedCompanyId || !resolvedPlanId) return null;
  const cycle = normalizeBillingCycle(billingCycle);
  const [subscription] = await dbRequest('GET', 'company_subscriptions', {
    select: '*',
    company_id: `eq.${resolvedCompanyId}`,
    plan_id: `eq.${resolvedPlanId}`,
    status: 'eq.payment_pending',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  if (!subscription) return null;
  if (normalizeBillingCycle(subscription.metadata?.billing_cycle || 'monthly') !== cycle) return null;
  const dueAt = subscription.payment_due_at ? new Date(subscription.payment_due_at).getTime() : 0;
  const checkoutUrl = cleanText(subscription.metadata?.checkout_url || '');
  if (!checkoutUrl || (dueAt && dueAt < Date.now())) return null;
  const [transaction] = await dbRequest('GET', 'subscription_payment_transactions', {
    select: '*',
    subscription_id: `eq.${subscription.id}`,
    status: 'eq.pending',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  const expiresAt = transaction?.expires_at ? new Date(transaction.expires_at).getTime() : dueAt;
  if (expiresAt && expiresAt < Date.now()) return null;
  return { subscription, transaction: transaction || null, checkout_url: transaction?.checkout_url || checkoutUrl };
}

async function activateCompanyPlan(req, admin, company, plan, options = {}) {
  const companyId = cleanUuid(company.id || admin.company_id, 'empresa');
  const now = new Date();
  const billingCycle = normalizeBillingCycle(options.billingCycle || options.billing_cycle || 'monthly');
  const amountCents = Number(options.amountCents ?? options.amount_cents ?? planBillingAmountCents(plan, billingCycle)) || 0;
  const monthlyPrice = moneyCents(plan.monthly_price || 0);
  const isTrialPlan = plan.code === 'trial' || amountCents <= 0;
  const periodDays = isTrialPlan ? Number(plan.settings?.trial_days || 14) || 14 : billingCyclePeriodDays(billingCycle);
  const periodEnd = new Date(now.getTime() + periodDays * 86400000);
  const status = isTrialPlan ? 'trial' : 'active';
  const previousSubscriptions = await listCompanySubscriptions(companyId, 100);
  const current = previousSubscriptions.find((entry) => ['trial', 'active', 'grace_period'].includes(entry.status));
  const isSamePlan = current?.plan_id && current.plan_id === plan.id && ['trial', 'active'].includes(current.status);
  const changeType = options.changeType || billingPlanChangeType(options.currentPlan || null, plan);
  const downgradeWarnings = Array.isArray(options.downgradeWarnings) ? options.downgradeWarnings : [];

  if (isSamePlan) {
    return { subscription: current, plan, already_current: true };
  }
  if (isTrialPlan && previousSubscriptions.some((entry) => entry.status === 'trial' || entry.trial_ends_at)) {
    throw httpError(409, 'Esta empresa já utilizou o período de teste.');
  }

  await dbRequest('PATCH', 'company_subscriptions', {
    company_id: `eq.${companyId}`,
    status: 'in.(trial,active,payment_pending,grace_period,suspended)'
  }, { status: 'cancelled', cancelled_at: now.toISOString() }, ['Prefer: return=minimal']).catch(() => {});

  const [subscription] = await dbRequest('POST', 'company_subscriptions', {}, {
    company_id: companyId,
    plan_id: plan.id,
    status,
    trial_ends_at: isTrialPlan ? periodEnd.toISOString() : null,
    current_period_starts_at: now.toISOString(),
    current_period_ends_at: periodEnd.toISOString(),
    next_renewal_at: periodEnd.toISOString(),
    billing_provider: options.provider || 'manual',
    last_payment_at: isTrialPlan ? null : now.toISOString(),
    metadata: {
      source: options.source || 'manual_activation',
      activated_by: admin.id,
      amount_cents: amountCents,
      billing_cycle: billingCycle,
      change_type: changeType,
      downgrade_warnings: downgradeWarnings
    }
  }, ['Prefer: return=representation']);

  await dbRequest('PATCH', 'companies', { id: `eq.${companyId}` }, {
    status: isTrialPlan ? 'trial' : 'active'
  }, ['Prefer: return=minimal']).catch(() => {});

  await dbRequest('POST', 'subscription_events', {}, {
    company_id: companyId,
    subscription_id: subscription.id,
    event_type: current ? `plan_${changeType}` : 'plan_activated',
    description: `${current ? 'Plano alterado' : 'Plano ativado'} para ${plan.name}.`,
    metadata: {
      provider: options.provider || 'manual',
      plan_code: plan.code,
      plan_name: plan.name,
      billing_cycle: billingCycle,
      previous_subscription_id: current?.id || null,
      amount_cents: amountCents,
      change_type: changeType,
      downgrade_warnings: downgradeWarnings
    },
    created_by: admin.id
  }, ['Prefer: return=minimal']).catch(() => {});

  await audit('billing.plan.activate', {
    req,
    actor_admin_id: admin.id,
    company_id: companyId,
    store_id: admin.store_id,
    entity_type: 'company_subscription',
    entity_id: subscription.id,
    after_data: { plan_code: plan.code, billing_cycle: billingCycle, status, provider: options.provider || 'manual' }
  });

  return { subscription, plan, change_type: changeType, downgrade_warnings: downgradeWarnings };
}

async function createProviderSubscriptionCheckout({ company, plan, admin, amount, billingCycle = 'monthly', billingConfig = null }) {
  const config = billingConfig || await privatePlatformBillingSettings();
  const cycle = normalizeBillingCycle(billingCycle);
  if (config.provider === 'mock') {
    return {
      subscriptionId: `mock_sub_${company.id}_${Date.now()}`,
      checkoutUrl: absolutePanelUrl(`/?billing=mock&plan=${encodeURIComponent(plan.code)}&cycle=${encodeURIComponent(cycle)}`)
    };
  }
  if (config.provider !== 'abacatepay') throw httpError(422, 'Provedor de assinatura não suportado.');
  const origin = cleanText(config.public_url || panelBaseUrl() || process.env.APP_URL || 'http://127.0.0.1:3000').replace(/\/+$/, '');
  const productId = await ensureAbacateSubscriptionProduct({ plan, amount, billingCycle: cycle, token: config.api_key });
  const customerId = await createAbacateSubscriptionCustomer({ company, admin, token: config.api_key }).catch(() => '');
  const externalId = cleanExternalId(`tapronto-sub-${company.id}-${plan.code}-${cycle}-${Date.now()}`);
  const body = {
    items: [{ id: productId, quantity: 1 }],
    methods: ['PIX', 'CARD'],
    returnUrl: `${origin}/?billing=cancelled`,
    completionUrl: `${origin}/?billing=success`,
    externalId,
    metadata: { companyId: company.id, planCode: plan.code, billingCycle: cycle, kind: 'platform_subscription_charge' }
  };
  if (customerId) body.customerId = customerId;
  const data = await createAbacateCheckoutWithPixAutomaticFallback(body, config.api_key, 'mensalidade');
  const payload = data.data || data;
  const checkoutUrl = payload.url || payload.checkoutUrl || payload.paymentUrl || payload.subscription?.url || '';
  if (!checkoutUrl) {
    throw httpError(502, 'A Abacate Pay criou a cobrança mensal, mas não retornou a URL de checkout.');
  }
  return {
    subscriptionId: String(payload.id || payload.checkoutId || payload.billingId || ''),
    transactionId: externalId,
    checkoutUrl
  };
}

async function createAbacateCheckoutWithPixAutomaticFallback(body, token, contextLabel = 'cobrança') {
  try {
    return await providerFetch(`${ABACATEPAY_API_BASE}/checkouts/create`, {
      method: 'POST',
      token,
      body
    });
  } catch (error) {
    if (!abacatePayPixAutomaticUnavailable(error) || !Array.isArray(body?.methods) || !body.methods.includes('CARD')) {
      throw error;
    }
    const retryBody = {
      ...body,
      methods: ['CARD'],
      metadata: {
        ...(body.metadata || {}),
        payment_methods_fallback: 'card_only',
        fallback_reason: 'pix_automatic_unavailable'
      }
    };
    console.warn(`Abacate Pay recusou Pix Automático na ${contextLabel}; reabrindo checkout somente com cartão.`);
    return providerFetch(`${ABACATEPAY_API_BASE}/checkouts/create`, {
      method: 'POST',
      token,
      body: retryBody
    });
  }
}

function abacatePayPixAutomaticUnavailable(error) {
  const detail = error?.detail || error?.data || error;
  const message = [
    error?.message,
    detail?.message,
    detail?.error,
    detail?.code,
    detail?.status
  ].filter(Boolean).join(' ').toLowerCase();
  return message.includes('pix automatic') || message.includes('pix automático') || message.includes('pix automatico');
}

async function ensureAbacateSubscriptionProduct({ plan, amount, billingCycle = 'monthly', token }) {
  const cycle = normalizeBillingCycle(billingCycle);
  const externalId = cleanExternalId(`tapronto-plan-${plan.code}-${cycle}-${amount}`);
  const existing = await findAbacateProductByExternalId(externalId, token).catch(() => null);
  if (existing?.id) return String(existing.id);
  const data = await providerFetch(`${ABACATEPAY_API_BASE}/products/create`, {
    method: 'POST',
    token,
    body: {
      externalId,
      name: `Assinatura ${plan.name} ${cycle === 'annual' ? 'Anual' : 'Mensal'}`,
      description: plan.description || `Assinatura ${cycle === 'annual' ? 'anual' : 'mensal'} da plataforma TáPronto`,
      price: amount,
      currency: 'BRL',
      cycle: cycle === 'annual' ? 'YEARLY' : 'MONTHLY'
    }
  });
  const payload = data.data || data;
  const productId = payload.id || payload.product?.id || '';
  if (!productId) throw httpError(502, 'A Abacate Pay não retornou o identificador do produto de assinatura.');
  return String(productId);
}

async function findAbacateProductByExternalId(externalId, token) {
  const data = await providerFetch(`${ABACATEPAY_API_BASE}/products/list`, { method: 'GET', token });
  const payload = data.data || data;
  const items = Array.isArray(payload)
    ? payload
    : (Array.isArray(payload.items) ? payload.items : (Array.isArray(payload.products) ? payload.products : []));
  return items.find((item) => item?.externalId === externalId || item?.external_id === externalId) || null;
}

async function createAbacateSubscriptionCustomer({ company, admin, token }) {
  const email = cleanText(admin.email || company.billing_email || '');
  if (!email) return '';
  const data = await providerFetch(`${ABACATEPAY_API_BASE}/customers/create`, {
    method: 'POST',
    token,
    body: {
      name: cleanText(admin.name || company.name || 'Cliente TáPronto'),
      email,
      cellphone: onlyDigits(company.phone || admin.phone || ''),
      metadata: { companyId: company.id, kind: 'platform_subscription' }
    }
  });
  const payload = data.data || data;
  return String(payload.id || payload.customer?.id || '');
}

async function createSubscriptionPaymentTransaction(data = {}) {
  const payload = {
    company_id: cleanUuid(data.companyId || data.company_id, 'empresa'),
    subscription_id: data.subscriptionId || data.subscription_id ? cleanUuid(data.subscriptionId || data.subscription_id, 'assinatura') : null,
    plan_id: data.planId || data.plan_id ? cleanUuid(data.planId || data.plan_id, 'plano') : null,
    provider: cleanSlug(data.provider || PLATFORM_BILLING_PROVIDER || 'manual'),
    external_transaction_id: cleanExternalId(data.externalTransactionId || data.external_transaction_id || '') || null,
    external_event_id: cleanExternalId(data.externalEventId || data.external_event_id || '') || null,
    status: cleanSlug(data.status || 'pending') || 'pending',
    amount_cents: Math.max(0, Number(data.amountCents ?? data.amount_cents ?? 0) || 0),
    checkout_url: cleanText(data.checkoutUrl || data.checkout_url || '') || null,
    expires_at: data.expiresAt || data.expires_at || null,
    metadata: sanitizeAuditPayload(data.metadata || {}) || {}
  };
  const [row] = await dbRequest('POST', 'subscription_payment_transactions', {}, payload, ['Prefer: return=representation']);
  return row || null;
}

async function findSubscriptionPaymentTransactionByEvent(provider, eventId) {
  const normalizedProvider = cleanSlug(provider || '');
  const normalizedEventId = cleanExternalId(eventId || '');
  if (!normalizedProvider || !normalizedEventId) return null;
  const [row] = await dbRequest('GET', 'subscription_payment_transactions', {
    select: '*',
    provider: `eq.${normalizedProvider}`,
    external_event_id: `eq.${normalizedEventId}`,
    limit: '1'
  }).catch(() => []);
  return row || null;
}

async function findSubscriptionPaymentTransactionByExternalId(provider, externalId) {
  const normalizedProvider = cleanSlug(provider || '');
  const normalizedExternalId = cleanExternalId(externalId || '');
  if (!normalizedProvider || !normalizedExternalId) return null;
  const [row] = await dbRequest('GET', 'subscription_payment_transactions', {
    select: '*',
    provider: `eq.${normalizedProvider}`,
    external_transaction_id: `eq.${normalizedExternalId}`,
    limit: '1'
  }).catch(() => []);
  return row || null;
}

async function findSubscriptionPaymentTransactionByExternalIds(provider, externalIds = []) {
  for (const externalId of uniqueCleanExternalIds(externalIds)) {
    const row = await findSubscriptionPaymentTransactionByExternalId(provider, externalId);
    if (row) return row;
  }
  return null;
}

function uniqueCleanExternalIds(values = []) {
  return [...new Set((Array.isArray(values) ? values : [values])
    .map((value) => cleanExternalId(value || ''))
    .filter(Boolean))];
}

function billingWebhookExternalIds(payload = {}, data = {}) {
  return uniqueCleanExternalIds([
    payload.id,
    payload.billingId,
    payload.subscriptionId,
    payload.checkoutId,
    payload.transactionId,
    payload.externalId,
    payload.external_id,
    data.billingId,
    data.subscriptionId,
    data.checkoutId,
    data.transactionId,
    data.externalId,
    data.external_id
  ]);
}

function companyIdFromBillingExternalId(externalId = '') {
  const match = cleanExternalId(externalId).match(/^tapronto-sub-([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})-/i);
  return match?.[1] ? cleanUuid(match[1]) : '';
}

async function findPendingCompanySubscriptionByExternalIds(provider, externalIds = [], fallbackCompanyId = '') {
  const ids = uniqueCleanExternalIds(externalIds);
  const companyId = cleanOptionalUuid(fallbackCompanyId || ids.map(companyIdFromBillingExternalId).find(Boolean) || '', 'empresa');
  if (!companyId) return null;
  const rows = await dbRequest('GET', 'company_subscriptions', {
    select: '*',
    company_id: `eq.${companyId}`,
    billing_provider: `eq.${cleanSlug(provider || '')}`,
    status: 'in.(payment_pending,trial,active,grace_period,past_due)',
    order: 'created_at.desc',
    limit: '20'
  }).catch(() => []);
  return rows.find((subscription) => {
    const metadata = subscription.metadata || {};
    return ids.includes(cleanExternalId(subscription.external_subscription_id || ''))
      || ids.includes(cleanExternalId(metadata.external_id || ''))
      || ids.includes(cleanExternalId(metadata.checkout_external_id || ''));
  }) || null;
}

async function updateSubscriptionPaymentTransaction(id, patch = {}) {
  const transactionId = cleanUuid(id);
  if (!transactionId) return null;
  const payload = {
    ...patch,
    updated_at: new Date().toISOString()
  };
  const [row] = await dbRequest('PATCH', 'subscription_payment_transactions', { id: `eq.${transactionId}` }, payload, ['Prefer: return=representation']);
  return row || null;
}

function billingWebhookAmountCents(payload = {}, data = {}) {
  const raw = payload.amount ?? payload.value ?? payload.totalAmount ?? data.amount ?? data.value ?? null;
  if (raw === null || raw === undefined || raw === '') return 0;
  if (typeof raw === 'string' && /[,.]/.test(raw)) return moneyCents(parseMoneyInput(raw) ?? raw);
  const numeric = Number(raw);
  if (!Number.isFinite(numeric)) return 0;
  return numeric > 999 ? Math.round(numeric) : moneyCents(numeric);
}

function billingTransactionStatus(subscriptionStatus) {
  return ({
    active: 'paid',
    payment_pending: 'pending',
    grace_period: 'past_due',
    past_due: 'past_due',
    cancelled: 'cancelled',
    suspended: 'failed',
    expired: 'expired'
  })[subscriptionStatus] || 'pending';
}

function normalizeBillingCycle(value) {
  const cycle = cleanSlug(value || 'monthly');
  return ['annual', 'yearly', 'anual'].includes(cycle) ? 'annual' : 'monthly';
}

function billingCyclePeriodDays(value) {
  return normalizeBillingCycle(value) === 'annual' ? 365 : 30;
}

function planBillingAmountCents(plan = {}, billingCycle = 'monthly') {
  const cycle = normalizeBillingCycle(billingCycle);
  const amount = cycle === 'annual'
    ? moneyCents(plan.annual_price || 0)
    : moneyCents(plan.monthly_price || 0);
  if (cycle === 'annual' && amount <= 0) {
    return moneyCents(plan.monthly_price || 0) * 12;
  }
  return amount;
}

async function receiveBillingWebhook(data, options = {}) {
  const config = await privatePlatformBillingSettings();
  const provider = cleanSlug(options.provider || inferPaymentProvider(data) || config.provider || PLATFORM_BILLING_PROVIDER);
  if (config.webhook_secret && options.webhookSecret !== config.webhook_secret) {
    throw httpError(401, 'Webhook de assinatura inválido.');
  }
  const payload = data.data || data.billing || data.subscription || data;
  const rawEventId = data.id || data.eventId || data.event_id || (
    (data.event || payload.status) && (payload.id || payload.billingId || payload.subscriptionId)
      ? `${data.event || payload.status}_${payload.id || payload.billingId || payload.subscriptionId}`
      : payload.id
  ) || `billing_${Date.now()}`;
  const eventId = cleanExternalId(rawEventId);
  const externalId = cleanText(payload.id || payload.billingId || payload.subscriptionId || data.billingId || '');
  const externalIds = billingWebhookExternalIds(payload, data);
  const metadata = payload.metadata || data.metadata || {};
  const companyId = cleanOptionalUuid(metadata.companyId || metadata.company_id || data.companyId || externalIds.map(companyIdFromBillingExternalId).find(Boolean) || '', 'empresa');
  const planCode = cleanPlanCode(metadata.planCode || metadata.plan_code || payload.externalId || '');
  const billingCycle = normalizeBillingCycle(metadata.billingCycle || metadata.billing_cycle || '');
  const status = billingProviderStatus(payload.status || data.status || data.event);
  const amountCents = billingWebhookAmountCents(payload, data);

  const duplicateTransaction = await findSubscriptionPaymentTransactionByEvent(provider, eventId);
  if (duplicateTransaction) return { ok: true, duplicate: true, transaction: duplicateTransaction };

  const addonTransaction = await findSubscriptionPaymentTransactionByExternalIds(provider, externalIds);
  if (addonTransaction?.metadata?.kind === 'addon_bundle') {
    return processAddonBundleBillingWebhook(reqLikeFromWebhook(), {
      data, payload, provider, eventId, externalId, status, amountCents, transaction: addonTransaction
    });
  }
  if (addonTransaction?.metadata?.kind === 'addon') {
    return processAddonBillingWebhook(reqLikeFromWebhook(), {
      data,
      payload,
      provider,
      eventId,
      externalId,
      status,
      amountCents,
      transaction: addonTransaction
    });
  }

  let query = {
    select: '*',
    billing_provider: `eq.${provider}`,
    order: 'created_at.desc',
    limit: '1'
  };
  if (externalId) query.external_subscription_id = `eq.${externalId}`;
  else if (companyId) query.company_id = `eq.${companyId}`;
  else throw httpError(422, 'Webhook sem identificador de assinatura.');

  let [subscription] = await dbRequest('GET', 'company_subscriptions', query);
  if (!subscription) {
    subscription = await findPendingCompanySubscriptionByExternalIds(provider, externalIds, companyId);
  }
  if (!subscription) throw httpError(404, 'Assinatura não encontrada.');
  let transaction = addonTransaction || await findSubscriptionPaymentTransactionByExternalIds(provider, externalIds);
  if (!transaction && subscription.id) {
    const [latest] = await dbRequest('GET', 'subscription_payment_transactions', {
      select: '*',
      subscription_id: `eq.${subscription.id}`,
      provider: `eq.${provider}`,
      order: 'created_at.desc',
      limit: '1'
    }).catch(() => []);
    transaction = latest || null;
  }
  if (transaction?.amount_cents && amountCents && Number(transaction.amount_cents) !== Number(amountCents)) {
    await updateSubscriptionPaymentTransaction(transaction.id, {
      external_event_id: eventId,
      status: 'amount_mismatch',
      raw_payload: sanitizeAuditPayload(data),
      metadata: {
        ...(transaction.metadata || {}),
        expected_amount_cents: Number(transaction.amount_cents || 0),
        received_amount_cents: amountCents,
        mismatch_at: new Date().toISOString()
      },
      failed_at: new Date().toISOString()
    }).catch(() => {});
    throw httpError(422, 'Valor do pagamento não confere com a cobrança da assinatura.');
  }
  let planId = subscription.plan_id;
  if (planCode) {
    const [plan] = await dbRequest('GET', 'subscription_plans', { select: 'id', code: `eq.${planCode}`, limit: '1' });
    if (plan?.id) planId = plan.id;
  }
  const now = new Date();
  const transactionCycle = normalizeBillingCycle(transaction?.metadata?.billing_cycle || subscription.metadata?.billing_cycle || billingCycle || 'monthly');
  const periodEnd = new Date(now.getTime() + billingCyclePeriodDays(transactionCycle) * 86400000).toISOString();
  const graceEnd = new Date(now.getTime() + BILLING_GRACE_DAYS * 86400000).toISOString();
  const nextPaymentDue = status === 'grace_period' ? graceEnd : status === 'payment_pending' || status === 'past_due' ? subscription.payment_due_at || periodEnd : null;
  const [updated] = await dbRequest('PATCH', 'company_subscriptions', { id: `eq.${subscription.id}` }, {
    status,
    plan_id: planId,
    external_subscription_id: externalId || subscription.external_subscription_id || null,
    last_payment_at: status === 'active' ? now.toISOString() : subscription.last_payment_at,
    payment_due_at: nextPaymentDue,
    current_period_starts_at: status === 'active' ? now.toISOString() : subscription.current_period_starts_at,
    current_period_ends_at: status === 'active' ? periodEnd : subscription.current_period_ends_at,
    next_renewal_at: status === 'active' ? periodEnd : subscription.next_renewal_at,
    metadata: { ...(subscription.metadata || {}), billing_cycle: transactionCycle, last_webhook: { eventId, status, received_at: now.toISOString() } }
  }, ['Prefer: return=representation']);
  if (!transaction) {
    transaction = await createSubscriptionPaymentTransaction({
      companyId: subscription.company_id,
      subscriptionId: subscription.id,
      planId,
      provider,
      externalTransactionId: externalId || subscription.external_subscription_id || null,
      status: billingTransactionStatus(status),
      amountCents,
      metadata: {
        source: 'webhook_without_checkout_transaction',
        plan_code: planCode || null,
        billing_cycle: transactionCycle
      }
    }).catch(() => null);
  }
  if (transaction?.id) {
    await updateSubscriptionPaymentTransaction(transaction.id, {
      subscription_id: subscription.id,
      plan_id: planId || transaction.plan_id || null,
      external_transaction_id: externalId || transaction.external_transaction_id || subscription.external_subscription_id || null,
      external_event_id: eventId,
      status: billingTransactionStatus(status),
      amount_cents: amountCents || transaction.amount_cents || 0,
      raw_payload: sanitizeAuditPayload(data),
      metadata: {
        ...(transaction.metadata || {}),
        last_status: status,
        last_event_id: eventId,
        received_at: now.toISOString()
      },
      paid_at: status === 'active' ? now.toISOString() : transaction.paid_at || null,
      failed_at: ['past_due', 'cancelled', 'suspended'].includes(status) ? now.toISOString() : transaction.failed_at || null
    }).catch(() => {});
  }
  if (status === 'active') {
    await dbRequest('PATCH', 'company_subscriptions', {
      company_id: `eq.${subscription.company_id}`,
      id: `neq.${subscription.id}`,
      status: 'in.(trial,active,payment_pending,grace_period,past_due,suspended)'
    }, { status: 'cancelled' }, ['Prefer: return=minimal']).catch(() => {});
  }
  const companyStatus = status === 'active' ? 'active' : status === 'cancelled' ? 'cancelled' : status === 'suspended' ? 'suspended' : status === 'past_due' ? 'past_due' : status === 'grace_period' ? 'grace_period' : 'payment_pending';
  await dbRequest('PATCH', 'companies', { id: `eq.${subscription.company_id}` }, { status: companyStatus }, ['Prefer: return=minimal']);
  await dbRequest('POST', 'subscription_events', {}, {
    company_id: subscription.company_id,
    subscription_id: subscription.id,
    event_type: `billing.${status}`,
    description: `Evento de cobrança recebido: ${status}.`,
    metadata: {
      provider,
      provider_event_id: eventId,
      payment_transaction_id: transaction?.id || null,
      plan_code: planCode || null,
      billing_cycle: transactionCycle,
      amount_cents: amountCents || transaction?.amount_cents || 0,
      payload: sanitizeAuditPayload(data)
    }
  }, ['Prefer: return=minimal']);
  if (status === 'active') {
    const [marketingCompany] = await dbRequest('GET', 'companies', { select: 'marketing_attribution', id: `eq.${subscription.company_id}`, limit: '1' }).catch(() => []);
    await recordMarketingMilestone('subscription_activated', {
      companyId: subscription.company_id,
      attribution: marketingCompany?.marketing_attribution || {},
      properties: { plan_code: planCode || null, amount_cents: amountCents || transaction?.amount_cents || 0 },
      idempotencyKey: `subscription_activated:${transaction?.id || eventId}`
    }).catch(() => {});
    await processReferralPayment(reqLikeFromWebhook(), {
      companyId: subscription.company_id,
      transactionId: transaction?.id || null,
      amountCents: amountCents || transaction?.amount_cents || 0
    }).catch((error) => {
      console.warn('Não foi possível processar recompensa de indicação:', error.message || error);
    });
  }
  return { ok: true, subscription: updated, transaction };
}

function reqLikeFromWebhook() {
  return { headers: {}, socket: {} };
}

async function processAddonBillingWebhook(req, context = {}) {
  const { data, provider, eventId, externalId, status, amountCents, transaction } = context;
  const metadata = transaction.metadata || {};
  const addonId = cleanUuid(metadata.addon_id || '');
  const addonCode = cleanAddonCode(metadata.addon_code || '');
  const storeId = cleanUuid(metadata.store_id || '');
  const subscriptionAddonId = cleanUuid(metadata.store_subscription_addon_id || '');
  const [subscriptionAddon] = subscriptionAddonId
    ? await dbRequest('GET', 'store_subscription_addons', { select: '*', id: `eq.${subscriptionAddonId}`, limit: '1' }).catch(() => [])
    : [];
  const addon = addonId
    ? (await dbRequest('GET', 'plan_addons', { select: '*', id: `eq.${addonId}`, limit: '1' }).catch(() => []))[0]
    : await getPlanAddonByCode(addonCode);
  if (!addon) throw httpError(404, 'Adicional do webhook não encontrado.');
  const companyId = cleanUuid(transaction.company_id || subscriptionAddon?.company_id || '');
  const resolvedStoreId = storeId || cleanUuid(subscriptionAddon?.store_id || '');
  if (!companyId || !resolvedStoreId) throw httpError(422, 'Webhook de adicional sem empresa ou loja.');
  if (transaction.amount_cents && amountCents && Number(transaction.amount_cents) !== Number(amountCents)) {
    await updateSubscriptionPaymentTransaction(transaction.id, {
      external_event_id: eventId,
      status: 'amount_mismatch',
      raw_payload: sanitizeAuditPayload(data),
      failed_at: new Date().toISOString()
    }).catch(() => {});
    throw httpError(422, 'Valor do pagamento não confere com a cobrança do adicional.');
  }

  const transactionStatus = billingTransactionStatus(status);
  const now = new Date();
  const periodEnd = new Date(now.getTime() + 30 * 86400000);
  const oneTime = isOneTimeAddon(addon);
  let updatedAddon = subscriptionAddon || null;
  if (status === 'active') {
    if (updatedAddon?.id) {
      [updatedAddon] = await dbRequest('PATCH', 'store_subscription_addons', { id: `eq.${updatedAddon.id}` }, {
        status: 'active',
        provider,
        external_transaction_id: externalId || updatedAddon.external_transaction_id || null,
        current_period_starts_at: now.toISOString(),
        current_period_ends_at: oneTime ? null : periodEnd.toISOString(),
        next_renewal_at: oneTime ? null : periodEnd.toISOString(),
        activated_at: updatedAddon.activated_at || now.toISOString(),
        updated_at: now.toISOString(),
        metadata: {
          ...(updatedAddon.metadata || {}),
          billing_type: addonBillingType(addon),
          service_type: isAssistedServiceAddon(addon) ? 'assisted_setup' : updatedAddon.metadata?.service_type || null,
          service_status: isAssistedServiceAddon(addon) ? 'awaiting_support' : updatedAddon.metadata?.service_status || null,
          last_webhook: { eventId, status, received_at: now.toISOString() }
        }
      }, ['Prefer: return=representation']);
      if (isAssistedServiceAddon(addon)) {
        updatedAddon = await ensureAssistedAddonSupportTicket(req, {
          id: null,
          company_id: companyId,
          store_id: resolvedStoreId
        }, updatedAddon, addon).catch(() => updatedAddon);
      }
    } else {
      updatedAddon = await activateStoreAddon(req, {
        id: null,
        company_id: companyId,
        store_id: resolvedStoreId
      }, {
        companyId,
        storeId: resolvedStoreId,
        addon,
        provider,
        externalTransactionId: externalId,
        source: 'billing_webhook'
      });
    }
  } else if (updatedAddon?.id) {
    [updatedAddon] = await dbRequest('PATCH', 'store_subscription_addons', { id: `eq.${updatedAddon.id}` }, {
      status: status === 'cancelled' ? 'cancelled' : transactionStatus,
      updated_at: now.toISOString(),
      metadata: {
        ...(updatedAddon.metadata || {}),
        last_webhook: { eventId, status, received_at: now.toISOString() }
      }
    }, ['Prefer: return=representation']);
  }

  await updateSubscriptionPaymentTransaction(transaction.id, {
    external_event_id: eventId,
    external_transaction_id: externalId || transaction.external_transaction_id || null,
    status: transactionStatus,
    amount_cents: amountCents || transaction.amount_cents || 0,
    raw_payload: sanitizeAuditPayload(data),
    metadata: {
      ...(transaction.metadata || {}),
      last_status: status,
      last_event_id: eventId,
      received_at: now.toISOString()
    },
    paid_at: status === 'active' ? now.toISOString() : transaction.paid_at || null,
    failed_at: ['past_due', 'cancelled', 'suspended'].includes(status) ? now.toISOString() : transaction.failed_at || null
  }).catch(() => {});

  await recordAddonBillingEvent({
    companyId,
    storeId: resolvedStoreId,
    subscriptionAddonId: updatedAddon?.id || subscriptionAddonId || null,
    addonId: addon.id,
    eventType: `addon.billing.${status}`,
    status,
    amountCents: amountCents || transaction.amount_cents || 0,
    provider,
    externalEventId: eventId,
    externalTransactionId: externalId,
    description: `Evento de cobrança do adicional recebido: ${status}.`,
    metadata: { payment_transaction_id: transaction.id, payload: sanitizeAuditPayload(data) }
  }).catch(() => {});

  return { ok: true, addon_subscription: updatedAddon, transaction };
}

async function processAddonBundleBillingWebhook(req, context = {}) {
  const { data, provider, eventId, externalId, status, amountCents, transaction } = context;
  const items = Array.isArray(transaction.metadata?.addon_items) ? transaction.metadata.addon_items : [];
  if (!items.length) throw httpError(422, 'Cobrança agrupada sem configurações identificadas.');
  if (transaction.amount_cents && amountCents && Number(transaction.amount_cents) !== Number(amountCents)) {
    await updateSubscriptionPaymentTransaction(transaction.id, { external_event_id: eventId, status: 'amount_mismatch', raw_payload: sanitizeAuditPayload(data), failed_at: new Date().toISOString() }).catch(() => {});
    throw httpError(422, 'Valor do pagamento não confere com a cobrança das configurações.');
  }
  const now = new Date().toISOString();
  const updatedAddons = [];
  for (const item of items) {
    const addon = item.addon_id
      ? (await dbRequest('GET', 'plan_addons', { select: '*', id: `eq.${cleanUuid(item.addon_id)}`, limit: '1' }).catch(() => []))[0]
      : await getPlanAddonByCode(item.addon_code);
    const subscriptionAddonId = cleanUuid(item.store_subscription_addon_id || '');
    if (!addon || !subscriptionAddonId) continue;
    const [current] = await dbRequest('GET', 'store_subscription_addons', { select: '*', id: `eq.${subscriptionAddonId}`, limit: '1' }).catch(() => []);
    if (!current) continue;
    const nextStatus = status === 'active' ? 'active' : status === 'cancelled' ? 'cancelled' : billingTransactionStatus(status);
    let [updated] = await dbRequest('PATCH', 'store_subscription_addons', { id: `eq.${current.id}` }, {
      status: nextStatus,
      provider,
      external_transaction_id: externalId || current.external_transaction_id || null,
      activated_at: status === 'active' ? (current.activated_at || now) : current.activated_at,
      updated_at: now,
      metadata: {
        ...(current.metadata || {}),
        service_type: 'assisted_setup',
        service_status: status === 'active' ? 'awaiting_support' : nextStatus,
        last_webhook: { eventId, status, received_at: now }
      }
    }, ['Prefer: return=representation']);
    if (status === 'active') {
      updated = await ensureAssistedAddonSupportTicket(req, {
        id: null, company_id: current.company_id, store_id: current.store_id
      }, updated, addon).catch(() => updated);
    }
    updatedAddons.push(updated);
    await recordAddonBillingEvent({
      companyId: current.company_id, storeId: current.store_id, subscriptionAddonId: current.id, addonId: addon.id,
      eventType: `addon.bundle.billing.${status}`, status, amountCents: Number(item.amount_cents || 0), provider,
      externalEventId: eventId, externalTransactionId: externalId,
      description: `Evento de cobrança agrupada recebido para ${addon.name}.`, metadata: { payment_transaction_id: transaction.id }
    }).catch(() => {});
  }
  await updateSubscriptionPaymentTransaction(transaction.id, {
    external_event_id: eventId,
    external_transaction_id: externalId || transaction.external_transaction_id || null,
    status: billingTransactionStatus(status),
    amount_cents: amountCents || transaction.amount_cents || 0,
    raw_payload: sanitizeAuditPayload(data),
    metadata: { ...(transaction.metadata || {}), last_status: status, last_event_id: eventId, received_at: now },
    paid_at: status === 'active' ? now : transaction.paid_at || null,
    failed_at: ['past_due', 'cancelled', 'suspended'].includes(status) ? now : transaction.failed_at || null
  }).catch(() => {});
  return { ok: true, addon_subscriptions: updatedAddons, transaction };
}

async function recordBillingWebhookFailure(data, options = {}) {
  const payload = data?.data || data?.billing || data?.subscription || data || {};
  const metadata = payload.metadata || data?.metadata || {};
  const companyId = cleanUuid(metadata.companyId || metadata.company_id || data?.companyId || '');
  if (!companyId) return;
  const error = options.error || {};
  await dbRequest('POST', 'subscription_events', {}, {
    company_id: companyId,
    subscription_id: null,
    event_type: 'billing.webhook_failed',
    description: error.message || 'Falha ao processar webhook de cobrança.',
    metadata: {
      provider: cleanSlug(options.provider || PLATFORM_BILLING_PROVIDER),
      status: error.status || 500,
      code: error.detail?.code || error.code || null,
      payload: sanitizeAuditPayload(data)
    }
  }, ['Prefer: return=minimal']);
}

function billingProviderStatus(value) {
  const status = cleanSlug(value || '');
  if (['paid', 'active', 'completed', 'approved', 'billing-paid', 'payment-paid', 'payment-approved'].includes(status) || status.endsWith('-paid') || status.endsWith('-approved')) return 'active';
  if (['past-due', 'past_due', 'overdue', 'expired', 'billing-expired', 'payment-expired', 'refused', 'rejected', 'failed'].includes(status) || status.endsWith('-failed') || status.endsWith('-refused')) return 'past_due';
  if (['cancelled', 'canceled', 'billing-cancelled', 'billing-canceled'].includes(status) || status.endsWith('-cancelled') || status.endsWith('-canceled')) return 'cancelled';
  if (['suspended', 'blocked', 'billing-blocked'].includes(status)) return 'suspended';
  return 'payment_pending';
}

async function companyCommercialStatus(companyId) {
  const resolvedCompanyId = cleanUuid(companyId);
  if (!resolvedCompanyId) return { canOperate: true, status: 'unknown', message: '' };
  const [company, subscriptions] = await Promise.all([
    getCompanyById(resolvedCompanyId).catch(() => null),
    listCompanySubscriptions(resolvedCompanyId)
  ]);
  const subscription = pickCurrentCompanySubscription(subscriptions);
  const status = subscription?.status || company?.status || 'unknown';
  if (!company || ['suspended', 'blocked', 'cancelled', 'archived'].includes(company.status)) {
    return { canOperate: false, status: company?.status || 'missing', message: 'Empresa sem permissão comercial para operar.' };
  }
  if (['suspended', 'blocked', 'cancelled', 'expired'].includes(status)) {
    return { canOperate: false, status, message: 'Plano indisponível para operação. Regularize ou reative a empresa.' };
  }
  if (status === 'trial' && subscription?.trial_ends_at && new Date(subscription.trial_ends_at).getTime() < Date.now()) {
    return { canOperate: false, status: 'trial_expired', message: 'Período de teste encerrado. Ative um plano para continuar operando.' };
  }
  if (['payment_pending', 'past_due'].includes(status)) {
    return { canOperate: false, status, message: 'Pagamento pendente. A operação está temporariamente bloqueada.' };
  }
  if (status === 'grace_period') {
    const due = subscription?.payment_due_at || subscription?.current_period_ends_at;
    if (due && new Date(due).getTime() < Date.now()) {
      return { canOperate: false, status: 'grace_period_expired', message: 'Prazo de regularização encerrado.' };
    }
  }
  return { canOperate: true, status, message: '' };
}

async function companyCommercialStatusByStore(storeId) {
  const [store] = await dbRequest('GET', 'stores', {
    select: 'id,company_id',
    id: `eq.${cleanUuid(storeId)}`,
    limit: '1'
  }).catch(() => []);
  const status = await companyCommercialStatus(store?.company_id);
  return { ...status, company_id: store?.company_id || null };
}

async function listCompanyPlanFeatures(planId) {
  const entries = await dbRequest('GET', 'plan_features', {
    select: '*',
    plan_id: `eq.${cleanUuid(planId)}`,
    limit: '500'
  }).catch(() => []);
  const featureIds = cleanUuidArray(entries.map((entry) => entry.feature_id));
  if (!featureIds.length) return [];
  const features = await dbRequest('GET', 'platform_features', {
    select: '*',
    id: uuidInFilter(featureIds),
    order: 'sort_order.asc'
  }).catch(() => []);
  const featureById = new Map(features.map((feature) => [feature.id, feature]));
  return entries.map((entry) => ({
    ...entry,
    feature: featureById.get(entry.feature_id) || null
  })).filter((entry) => entry.feature);
}

async function companyUsageSnapshot(companyId, storeId) {
  const resolvedCompanyId = cleanUuid(companyId);
  const resolvedStoreId = cleanOptionalUuid(storeId);
  const stores = resolvedCompanyId ? await dbRequest('GET', 'stores', {
    select: 'id',
    company_id: `eq.${resolvedCompanyId}`,
    limit: '1000'
  }).catch(() => []) : [];
  const storeIds = cleanUuidArray(stores.map((store) => store.id));
  const scopedStoreIds = resolvedStoreId ? [resolvedStoreId] : storeIds;
  const scopedFilter = scopedStoreIds.length ? uuidInFilter(scopedStoreIds) : null;
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  const countRows = async (table, extra = {}) => {
    const storeScopedTables = ['orders', 'menu_categories', 'menu_items', 'customers', 'dining_tables', 'customer_tabs', 'order_print_logs', 'order_whatsapp_logs', 'order_payment_events'];
    if (!scopedFilter && storeScopedTables.includes(table)) return 0;
    const rows = await dbRequest('GET', table, {
      select: 'id',
      ...(scopedFilter && storeScopedTables.includes(table) ? { store_id: scopedFilter } : {}),
      ...extra,
      limit: '1000'
    }).catch(() => []);
    return rows.length;
  };
  const [users, categories, products, orders, ordersMonth, customers, tables, tabs, whatsappMessages] = await Promise.all([
    resolvedCompanyId ? dbRequest('GET', 'admin_user_store_access', {
      select: 'admin_user_id',
      company_id: `eq.${resolvedCompanyId}`,
      is_active: 'eq.true',
      limit: '1000'
    }).then((rows) => new Set(rows.map((row) => row.admin_user_id)).size).catch(() => 0) : 0,
    countRows('menu_categories'),
    countRows('menu_items'),
    countRows('orders'),
    countRows('orders', { created_at: `gte.${monthStart.toISOString()}` }),
    countRows('customers'),
    countRows('dining_tables'),
    countRows('customer_tabs', { status: 'eq.open' }),
    countRows('order_whatsapp_logs', { created_at: `gte.${monthStart.toISOString()}` })
  ]);
  return {
    stores: stores.length,
    users,
    categories,
    products,
    orders,
    orders_month: ordersMonth,
    customers,
    tables,
    open_tabs: tabs,
    whatsapp_messages: whatsappMessages
  };
}

async function listAuditLogs(params = new URLSearchParams()) {
  const companyId = cleanOptionalUuid(params.get?.('company_id') || '');
  const storeId = cleanOptionalUuid(params.get?.('store_id') || '');
  const action = cleanText(params.get?.('action') || '');
  const from = cleanOptionalDate(params.get?.('from') || '');
  const to = cleanOptionalDate(params.get?.('to') || '');
  const query = {
    select: '*',
    ...(companyId ? { company_id: `eq.${companyId}` } : {}),
    ...(storeId ? { store_id: `eq.${storeId}` } : {}),
    ...(action ? { action: `eq.${action}` } : {}),
    order: 'created_at.desc',
    limit: '100'
  };
  if (from && to) {
    query.created_at = `gte.${from}T00:00:00`;
  } else if (from) {
    query.created_at = `gte.${from}T00:00:00`;
  } else if (to) {
    query.created_at = `lte.${to}T23:59:59`;
  }
  const rows = await dbRequest('GET', 'audit_logs', {
    ...query
  });
  const filtered = from && to
    ? rows.filter((row) => {
      const time = new Date(row.created_at).getTime();
      return time >= new Date(`${from}T00:00:00`).getTime() && time <= new Date(`${to}T23:59:59`).getTime();
    })
    : rows;
  return { logs: filtered };
}

async function platformBackupStatus() {
  const statusPath = path.join(BACKUP_DIR, 'backup-status.json');
  const manifest = await readJsonFile(statusPath).catch(() => null);
  const entries = await readdir(BACKUP_DIR).catch(() => []);
  const dumps = await Promise.all(entries
    .filter((entry) => isRestorableBackupFile(entry))
    .map(async (entry) => {
      const info = await stat(path.join(BACKUP_DIR, entry)).catch(() => null);
      return info ? {
        file: entry,
        size_bytes: info.size,
        created_at: info.mtime.toISOString()
      } : null;
    }));
  const recent = dumps
    .filter(Boolean)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 10);
  const latest = recent[0] || null;
  const manifestStatus = sanitizeBackupStatus(manifest?.status);
  const status = manifestStatus !== 'unknown' ? manifestStatus : latest ? 'success' : 'unknown';
  return {
    status,
    updated_at: cleanText(manifest?.updated_at || latest?.created_at || ''),
    started_at: cleanText(manifest?.started_at || ''),
    finished_at: cleanText(manifest?.finished_at || latest?.created_at || ''),
    latest,
    last_output: cleanBackupFileName(manifest?.output || latest?.file || ''),
    retention_days: clampNumber(Number(manifest?.retention_days || process.env.BACKUP_RETENTION_DAYS || 7), 1, 365),
    mode: cleanText(manifest?.mode || ''),
    error: manifest?.status === 'failed' ? cleanText(manifest.error || '').slice(0, 240) : '',
    recent
  };
}

async function platformServicesStatus() {
  const [database, backup, git, storageUsage, smtp] = await Promise.all([
    checkDatabaseHealth(),
    platformBackupStatus(),
    getGitRuntimeInfo(),
    platformStorageUsage(),
    smtpServiceStatus()
  ]);
  const serviceName = cleanText(process.env.PLATFORM_SERVICE_NAME || 'cardapio.service');
  return {
    checked_at: new Date().toISOString(),
    permissions: {
      service_control_enabled: parseBoolean(process.env.PLATFORM_ALLOW_SERVICE_CONTROL, false),
      backup_enabled: true,
      jobs_enabled: true
    },
    application: {
      status: 'healthy',
      service_name: serviceName,
      uptime_seconds: Math.floor(process.uptime()),
      started_at: new Date(Date.now() - process.uptime() * 1000).toISOString(),
      memory: process.memoryUsage(),
      pid: process.pid,
      node: process.version
    },
    database: {
      status: database.status,
      message: database.message,
      latency_ms: database.latency_ms
    },
    smtp,
    backups: backup,
    webhooks: await platformWebhookServiceStatus(),
    jobs: {
      trial_cleanup: {
        status: 'ready',
        command: 'maintenance:trial-cleanup:apply',
        description: 'Remove empresas em teste sem acesso recente conforme regra operacional.'
      },
      log_cleanup: {
        status: 'ready',
        command: 'maintenance:logs:apply',
        description: 'Remove auditoria antiga, sessões expiradas, eventos técnicos, temporários e backups fora da retenção.'
      },
      backup: {
        status: backup.status || 'unknown',
        command: 'db:backup'
      }
    },
    deploy: git,
    storage_usage: storageUsage,
    retention: platformRetentionSettings(),
    risk_zone: {
      restart_requires_confirmation: true,
      database_stop_available: false,
      database_stop_reason: 'Parada de banco não foi habilitada nesta fase por segurança.'
    }
  };
}

function platformRetentionSettings() {
  return {
    audit_log_days: envInt('AUDIT_LOG_RETENTION_DAYS', envInt('LOG_RETENTION_DAYS', 180)),
    operational_log_days: envInt('OPERATIONAL_LOG_RETENTION_DAYS', 90),
    session_days: envInt('SESSION_RETENTION_DAYS', 7),
    subscription_event_days: envInt('SUBSCRIPTION_EVENT_RETENTION_DAYS', 365),
    billing_event_days: envInt('BILLING_EVENT_RETENTION_DAYS', 1825),
    support_message_days: envInt('SUPPORT_MESSAGE_RETENTION_DAYS', 730),
    backup_days: envInt('BACKUP_RETENTION_DAYS', 7),
    tmp_days: envInt('TMP_RETENTION_DAYS', 7)
  };
}

async function platformStorageUsage() {
  const [database, backups, uploads, tmp, cleanupRows] = await Promise.all([
    platformDatabaseStorageStats().catch((error) => ({ error: error.message || 'indisponível' })),
    directoryUsage(BACKUP_DIR).catch(() => ({ bytes: 0, files: 0 })),
    directoryUsage(UPLOAD_DIR).catch(() => ({ bytes: 0, files: 0 })),
    directoryUsage(path.resolve(__dirname, process.env.TMP_DIR || '.tmp')).catch(() => ({ bytes: 0, files: 0 })),
    dbRequest('GET', 'audit_logs', {
      select: 'id,after_data,created_at',
      action: 'eq.platform.logs.cleanup',
      order: 'created_at.desc',
      limit: '1'
    }).catch(() => [])
  ]);
  return {
    database,
    backups,
    uploads,
    tmp,
    latest_cleanup: cleanupRows[0] ? {
      created_at: cleanupRows[0].created_at,
      summary: cleanupRows[0].after_data || {}
    } : null
  };
}

async function platformDatabaseStorageStats() {
  if (!DATABASE_URL) return { bytes: 0, pretty: '0 B', tables: [] };
  const client = new pg.Client({
    connectionString: DATABASE_URL,
    ssl: process.env.DB_SSL === 'true' || /sslmode=require/i.test(DATABASE_URL) ? { rejectUnauthorized: false } : false
  });
  await client.connect();
  try {
    const db = await client.query('select pg_database_size(current_database())::bigint as bytes');
    const tables = await client.query(`
      select relname as table_name,
             n_live_tup::bigint as estimated_rows,
             pg_total_relation_size(relid)::bigint as bytes
      from pg_stat_user_tables
      where relname in (
        'audit_logs',
        'app_sessions',
        'subscription_events',
        'support_tickets',
        'support_ticket_messages',
        'orders',
        'order_items',
        'customers',
        'menu_items'
      )
      order by pg_total_relation_size(relid) desc
    `);
    return {
      bytes: Number(db.rows[0]?.bytes || 0),
      tables: tables.rows.map((row) => ({
        table_name: row.table_name,
        estimated_rows: Number(row.estimated_rows || 0),
        bytes: Number(row.bytes || 0)
      }))
    };
  } finally {
    await client.end().catch(() => {});
  }
}

async function directoryUsage(directory) {
  let bytes = 0;
  let files = 0;
  const entries = await readdir(directory, { withFileTypes: true }).catch(() => []);
  for (const entry of entries) {
    const fullPath = path.join(directory, entry.name);
    const info = await stat(fullPath).catch(() => null);
    if (!info) continue;
    if (entry.isDirectory()) {
      const nested = await directoryUsage(fullPath);
      bytes += nested.bytes;
      files += nested.files;
    } else {
      bytes += info.size;
      files += 1;
    }
  }
  return { bytes, files };
}

function envInt(key, fallback) {
  const value = Number.parseInt(process.env[key] || '', 10);
  return Number.isFinite(value) && value >= 0 ? value : fallback;
}

async function platformServicesLogs(params = new URLSearchParams()) {
  const limit = clampNumber(Number(params.get?.('limit') || 80), 1, 200);
  const since = new Date(Date.now() - 86400000).toISOString();
  const actions = [
    'platform.service.backup',
    'platform.service.backup.failed',
    'platform.service.backup.restore',
    'platform.service.backup.restore.failed',
    'platform.service.trial_cleanup',
    'platform.service.trial_cleanup.failed',
    'platform.logs.cleanup',
    'platform.logs.cleanup.failed',
    'platform.service.app.restart',
    'platform.service.app.restart.failed',
    'platform.service.confirmation.failed',
    'platform.service.password.failed',
    'platform.subscription.change',
    'platform.company.update',
    'platform.company.status'
  ];
  const rows = await dbRequest('GET', 'audit_logs', {
    select: 'id,action,severity,entity_type,entity_id,actor_admin_id,ip_address,after_data,created_at',
    action: `in.(${actions.join(',')})`,
    created_at: `gte.${since}`,
    order: 'created_at.desc',
    limit: String(limit)
  }).catch(() => []);
  return {
    logs: rows.map((row) => ({
      id: row.id,
      action: row.action,
      severity: row.severity,
      status: row.after_data?.status || (row.severity === 'critical' ? 'failed' : 'info'),
      message: cleanText(row.after_data?.message || row.after_data?.summary || '').slice(0, 500),
      actor_admin_id: row.actor_admin_id || null,
      ip_address: row.ip_address || null,
      created_at: row.created_at
    }))
  };
}

async function runPlatformBackup(req, admin, data = {}) {
  await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  const startedAt = Date.now();
  try {
    await writeBackupStatus({ status: 'running', started_at: new Date().toISOString(), output: 'manual-platform-backup' });
    const result = await runNodeScript('scripts/backup-postgres.mjs', [], { timeoutMs: 120000 });
    const status = await platformBackupStatus();
    await auditPlatformService(req, admin, 'platform.service.backup', 'info', {
      status: 'success',
      duration_ms: Date.now() - startedAt,
      message: safeCommandOutput(result.stdout || 'Backup manual concluído.'),
      backup: status.latest ? { file: status.latest.file, size_bytes: status.latest.size_bytes } : null
    });
    return { ok: true, status, output: safeCommandOutput(result.stdout) };
  } catch (error) {
    await writeBackupStatus({ status: 'failed', finished_at: new Date().toISOString(), output: 'manual-platform-backup', error: error.message || String(error) }).catch(() => {});
    await auditPlatformService(req, admin, 'platform.service.backup.failed', 'critical', {
      status: 'failed',
      duration_ms: Date.now() - startedAt,
      message: safeCommandOutput(error.message || String(error))
    });
    throw httpError(500, 'Não foi possível executar o backup manual.');
  }
}

async function restorePlatformBackup(req, admin, data = {}) {
  await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  const file = cleanBackupFileName(data.file || data.backup_file || '');
  if (!isRestorableBackupFile(file)) {
    await auditPlatformService(req, admin, 'platform.service.backup.restore.failed', 'critical', {
      status: 'failed',
      message: 'Arquivo de backup inválido para restauração.',
      file
    });
    throw httpError(422, 'Selecione um backup válido para restaurar.');
  }
  const backupPath = path.resolve(BACKUP_DIR, file);
  if (!backupPath.startsWith(`${path.resolve(BACKUP_DIR)}${path.sep}`)) {
    throw httpError(422, 'Arquivo de backup inválido.');
  }
  const backupInfo = await stat(backupPath).catch(() => null);
  if (!backupInfo || !backupInfo.isFile()) {
    throw httpError(404, 'Backup não encontrado.');
  }
  const startedAt = Date.now();
  let prepared = null;
  try {
    const preRestore = await runNodeScript('scripts/backup-postgres.mjs', [], { timeoutMs: 120000 })
      .then(() => platformBackupStatus())
      .catch((error) => ({ error: error.message || String(error), latest: null }));
    prepared = await prepareBackupForRestore(backupPath, file);
    const commandResult = prepared.format === 'sql'
      ? await runCommand('psql', ['--set', 'ON_ERROR_STOP=1', '--file', prepared.path, pgToolConnectionString(DATABASE_URL)], { timeoutMs: 180000 })
      : await runCommand('pg_restore', ['--clean', '--if-exists', '--no-owner', '--no-privileges', '--dbname', pgToolConnectionString(DATABASE_URL), prepared.path], { timeoutMs: 180000 });
    await writeBackupStatus({
      status: 'success',
      finished_at: new Date().toISOString(),
      output: file,
      restored_from: file,
      restore_finished_at: new Date().toISOString(),
      retention_days: envInt('BACKUP_RETENTION_DAYS', 7),
      mode: prepared.format === 'sql' ? 'psql-restore' : 'pg_restore'
    }).catch(() => {});
    await auditPlatformService(req, admin, 'platform.service.backup.restore', 'critical', {
      status: 'success',
      duration_ms: Date.now() - startedAt,
      file,
      pre_restore_backup: preRestore.latest ? {
        file: preRestore.latest.file,
        size_bytes: preRestore.latest.size_bytes
      } : null,
      pre_restore_warning: preRestore.error ? safeCommandOutput(preRestore.error) : '',
      message: safeCommandOutput(commandResult.stdout || 'Backup restaurado com sucesso.')
    });
    return {
      ok: true,
      restored_from: file,
      pre_restore_backup: preRestore.latest || null,
      output: safeCommandOutput(commandResult.stdout),
      status: await platformBackupStatus()
    };
  } catch (error) {
    await auditPlatformService(req, admin, 'platform.service.backup.restore.failed', 'critical', {
      status: 'failed',
      duration_ms: Date.now() - startedAt,
      file,
      message: safeCommandOutput(error.message || String(error))
    });
    throw httpError(500, 'Não foi possível restaurar o backup. Verifique o arquivo e os logs operacionais.');
  } finally {
    if (prepared?.temporary && prepared.path) await unlink(prepared.path).catch(() => {});
  }
}

async function prepareBackupForRestore(backupPath, fileName) {
  const lower = fileName.toLowerCase();
  const encrypted = lower.endsWith('.tapronto.enc');
  const compressed = encrypted ? lower.endsWith('.gz.tapronto.enc') : lower.endsWith('.gz');
  const format = /\.sql(?:\.gz)?(?:\.tapronto\.enc)?$/.test(lower) ? 'sql' : 'dump';
  if (!encrypted && !compressed) return { path: backupPath, format, temporary: false };

  const info = await stat(backupPath);
  if (info.size > 100 * 1024 * 1024) throw new Error('Backup excede o limite operacional de 100 MB.');
  let contents = await readFile(backupPath);
  if (encrypted) contents = decryptEmailBackup(contents);
  if (compressed) contents = await gunzipAsync(contents);

  const tempDir = path.resolve(__dirname, process.env.TMP_DIR || '.tmp');
  await mkdir(tempDir, { recursive: true });
  const tempPath = path.join(tempDir, `restore-${randomUUID()}.${format}`);
  await writeFile(tempPath, contents, { flag: 'wx', mode: 0o600 });
  return { path: tempPath, format, temporary: true };
}

function decryptEmailBackup(data) {
  const password = String(process.env.BACKUP_EMAIL_ENCRYPTION_KEY || '');
  if (password.length < 24) throw new Error('Chave de descriptografia dos backups não configurada.');
  const header = Buffer.from('TAPRONTO-BACKUP-V1\n', 'ascii');
  if (!data.subarray(0, header.length).equals(header)) throw new Error('Formato criptografado do backup é inválido.');
  let offset = header.length;
  const salt = data.subarray(offset, offset += 16);
  const iv = data.subarray(offset, offset += 12);
  const tag = data.subarray(offset, offset += 16);
  const decipher = createDecipheriv('aes-256-gcm', scryptSync(password, salt, 32), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data.subarray(offset)), decipher.final()]);
}

async function runPlatformTrialCleanup(req, admin, data = {}) {
  await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  const startedAt = Date.now();
  try {
    const result = await runNodeScript('scripts/cleanup-inactive-trials.mjs', ['--apply'], { timeoutMs: 120000 });
    await auditPlatformService(req, admin, 'platform.service.trial_cleanup', 'warning', {
      status: 'success',
      duration_ms: Date.now() - startedAt,
      message: safeCommandOutput(result.stdout || 'Limpeza de trials concluída.')
    });
    return { ok: true, output: safeCommandOutput(result.stdout) };
  } catch (error) {
    await auditPlatformService(req, admin, 'platform.service.trial_cleanup.failed', 'critical', {
      status: 'failed',
      duration_ms: Date.now() - startedAt,
      message: safeCommandOutput(error.message || String(error))
    });
    throw httpError(500, 'Não foi possível executar a limpeza de trials inativos.');
  }
}

async function runPlatformLogCleanup(req, admin, data = {}) {
  const applyCleanup = data.apply === true;
  if (applyCleanup) {
    await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  }
  const startedAt = Date.now();
  try {
    const args = ['--json'];
    if (applyCleanup) args.unshift('--apply');
    const result = await runNodeScript('scripts/cleanup-logs.mjs', args, {
      timeoutMs: 120000,
      env: {
        CLEANUP_ACTOR_ADMIN_ID: admin.id || '',
        CLEANUP_REQUEST_SOURCE: 'platform'
      }
    });
    const parsed = parseJsonOutput(result.stdout);
    return {
      ok: parsed.ok !== false,
      mode: parsed.mode || (applyCleanup ? 'apply' : 'dry_run'),
      duration_ms: parsed.duration_ms ?? Date.now() - startedAt,
      result: parsed
    };
  } catch (error) {
    await auditPlatformService(req, admin, 'platform.logs.cleanup.failed', 'critical', {
      status: 'failed',
      mode: applyCleanup ? 'apply' : 'dry_run',
      duration_ms: Date.now() - startedAt,
      message: safeCommandOutput(error.message || String(error))
    });
    throw httpError(500, 'Não foi possível executar a limpeza de logs.');
  }
}

function parseJsonOutput(output) {
  const lines = String(output || '').trim().split(/\r?\n/).filter(Boolean);
  const jsonLine = [...lines].reverse().find((line) => line.trim().startsWith('{'));
  if (!jsonLine) throw new Error('Comando não retornou JSON válido.');
  return JSON.parse(jsonLine);
}

async function restartPlatformApplication(req, admin, data = {}) {
  await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  const serviceName = cleanText(process.env.PLATFORM_SERVICE_NAME || 'cardapio.service');
  if (!parseBoolean(process.env.PLATFORM_ALLOW_SERVICE_CONTROL, false)) {
    await auditPlatformService(req, admin, 'platform.service.app.restart', 'warning', {
      status: 'blocked',
      message: 'Restart solicitado, mas PLATFORM_ALLOW_SERVICE_CONTROL não está habilitado.',
      service_name: serviceName
    });
    throw httpError(403, 'Controle de serviço não habilitado neste ambiente. Configure PLATFORM_ALLOW_SERVICE_CONTROL=true para liberar.');
  }
  await auditPlatformService(req, admin, 'platform.service.app.restart', 'warning', {
    status: 'scheduled',
    message: 'Restart da aplicação agendado.',
    service_name: serviceName
  });
  setTimeout(() => {
    // Encerra somente este processo. O systemd, configurado com Restart=always,
    // inicia uma nova instância sem conceder sudo ou controle de outros serviços.
    process.kill(process.pid, 'SIGTERM');
  }, 500).unref?.();
  return { ok: true, scheduled: true, service_name: serviceName };
}

async function platformWebhookServiceStatus() {
  const rows = await dbRequest('GET', 'audit_logs', {
    select: 'id,action,severity,created_at',
    order: 'created_at.desc',
    limit: '200'
  }).catch(() => []);
  const webhookRows = rows.filter((row) => /webhook/i.test(row.action || '')).slice(0, 50);
  const failures = webhookRows.filter((row) => row.severity === 'critical' || /fail|erro|failed/i.test(row.action || ''));
  return {
    status: failures.length ? 'attention' : 'healthy',
    recent_events: webhookRows.length,
    recent_failures: failures.length,
    last_event_at: webhookRows[0]?.created_at || null
  };
}

async function getGitRuntimeInfo() {
  const [commit, branch] = await Promise.all([
    runCommand('git', ['rev-parse', '--short', 'HEAD'], { timeoutMs: 5000 }).catch(() => ({ stdout: '' })),
    runCommand('git', ['branch', '--show-current'], { timeoutMs: 5000 }).catch(() => ({ stdout: '' }))
  ]);
  return {
    commit: cleanText(commit.stdout || '').slice(0, 40) || 'indisponível',
    branch: cleanText(branch.stdout || '').slice(0, 80) || 'indisponível',
    deployed_at: null
  };
}

async function assertPlatformDangerConfirmation(req, admin, data = {}, expected = 'CONFIRMAR') {
  if (cleanText(data.confirmation || data.confirm || '') !== expected) {
    await auditPlatformService(req, admin, 'platform.service.confirmation.failed', 'warning', {
      status: 'failed',
      message: 'Texto de confirmação inválido.'
    });
    throw httpError(422, `Digite ${expected} para confirmar esta ação.`);
  }
  await assertPlatformAdminPassword(req, admin, data.password || '');
  return true;
}

async function assertPlatformAdminPassword(req, admin, passwordValue) {
  const password = String(passwordValue || '');
  if (!password) {
    await auditPlatformService(req, admin, 'platform.service.password.failed', 'warning', {
      status: 'failed',
      message: 'Senha do superadmin ausente.'
    });
    throw httpError(401, 'Informe sua senha para confirmar esta ação.');
  }
  const [current] = await dbRequest('GET', 'admin_users', {
    select: 'id,password_hash,role,is_active,email',
    id: `eq.${cleanUuid(admin.id)}`,
    limit: '1'
  });
  if (!current || current.is_active === false || normalizeAdminRole(current.role) !== 'superadmin' || !verifyPassword(password, current.password_hash)) {
    await auditPlatformService(req, admin, 'platform.service.password.failed', 'critical', {
      status: 'failed',
      message: 'Senha do superadmin inválida.'
    });
    throw httpError(403, 'Senha inválida para executar esta ação.');
  }
  return true;
}

async function auditPlatformService(req, admin, action, severity, payload = {}) {
  await audit(action, {
    req,
    actor_admin_id: admin?.id || null,
    company_id: admin?.company_id || null,
    entity_type: 'platform_service',
    severity,
    after_data: {
      ...payload,
      actor_email: admin?.email || null
    }
  });
}

function runNodeScript(scriptPath, args = [], options = {}) {
  return runCommand(process.execPath, [path.join(__dirname, scriptPath), ...args], options);
}

function pgToolConnectionString(value) {
  if (!value) return '';
  try {
    const url = new URL(value);
    url.searchParams.delete('schema');
    return url.toString();
  } catch {
    return value.replace(/([?&])schema=[^&]*&?/, (match, prefix) => prefix === '?' ? '?' : '').replace(/[?&]$/, '');
  }
}

function runCommand(command, args = [], options = {}) {
  const timeoutMs = options.timeoutMs || 30000;
  return new Promise((resolve, reject) => {
    const child = spawn(resolveExecutable(command), args, {
      cwd: __dirname,
      env: { ...process.env, ...(options.env || {}) },
      shell: false
    });
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error('Tempo esgotado ao executar comando operacional.'));
    }, timeoutMs);
    child.stdout?.on('data', (chunk) => {
      stdout += chunk.toString();
      if (stdout.length > 12000) stdout = stdout.slice(-12000);
    });
    child.stderr?.on('data', (chunk) => {
      stderr += chunk.toString();
      if (stderr.length > 12000) stderr = stderr.slice(-12000);
    });
    child.on('error', (error) => {
      clearTimeout(timer);
      reject(error);
    });
    child.on('exit', (code) => {
      clearTimeout(timer);
      const result = { code: code || 0, stdout, stderr };
      if (code && code !== 0) {
        reject(new Error(safeCommandOutput(stderr || stdout || `Comando finalizou com código ${code}.`)));
      } else {
        resolve(result);
      }
    });
  });
}

function resolveExecutable(command) {
  if (process.platform !== 'win32' || path.isAbsolute(command) || command.includes(path.sep)) {
    return command;
  }
  const lookup = spawnSync('where.exe', [command], { encoding: 'utf8', shell: false });
  const first = String(lookup.stdout || '').split(/\r?\n/).map((line) => line.trim()).find(Boolean);
  return first || command;
}

function safeCommandOutput(value) {
  return maskSensitiveText(String(value || '').replace(/\r/g, '').trim()).slice(0, 2000);
}

function maskSensitiveText(value) {
  let output = String(value || '');
  const secrets = [
    DATABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    process.env.COOKIE_SECRET,
    PLATFORM_BILLING_API_KEY,
    PLATFORM_BILLING_WEBHOOK_SECRET
  ].filter(Boolean);
  for (const secret of secrets) {
    if (secret && output.includes(secret)) output = output.split(secret).join('[redacted]');
  }
  output = output.replace(/(postgres(?:ql)?:\/\/)[^\s]+/gi, '$1[redacted]');
  output = output.replace(/(password|secret|token|api[_-]?key)=([^\s&]+)/gi, '$1=[redacted]');
  return output;
}

async function writeBackupStatus(data) {
  await mkdir(BACKUP_DIR, { recursive: true });
  await writeFile(path.join(BACKUP_DIR, 'backup-status.json'), JSON.stringify({
    ...data,
    updated_at: new Date().toISOString()
  }, null, 2));
}

async function platformOperationalHealth(params = new URLSearchParams()) {
  const period = platformHealthPeriod(params.get?.('period') || '24h');
  const [database, backup, operationalLogs] = await Promise.all([
    checkDatabaseHealth(),
    platformBackupStatus(),
    listOperationalLogs(period.since, params)
  ]);
  const metrics = await platformTechnicalMetrics(period, database, backup);
  const config = await platformConfigChecklist();
  const statuses = [
    apiHealthStatus(metrics),
    database,
    platformStatus('auth', 'Autenticação', config.items.find((item) => item.key === 'cookie_secret')?.ok === false ? 'attention' : 'healthy', 'Sessões administrativas e cookies operando.', null),
    await billingHealthStatus(),
    webhookHealthStatus(operationalLogs),
    backupHealthStatus(backup),
    jobsHealthStatus(),
    await storageHealthStatus(UPLOAD_DIR, 'storage', 'Storage/uploads'),
    sslDomainHealthStatus(),
    await smtpHealthStatus()
  ];
  const alerts = await platformHealthAlerts({ statuses, metrics, config, backup, operationalLogs });
  return normalizePortuguesePayload({
    checked_at: new Date().toISOString(),
    period: period.label,
    statuses,
    metrics,
    backup,
    config,
    alerts,
    logs: operationalLogs
  });
}

async function platformOperationalMetrics(params = new URLSearchParams()) {
  const period = platformHealthPeriod(params.get?.('period') || '24h');
  const [database, backup] = await Promise.all([
    checkDatabaseHealth(),
    platformBackupStatus()
  ]);
  return normalizePortuguesePayload({
    generated_at: new Date().toISOString(),
    period: period.label,
    metrics: await platformTechnicalMetrics(period, database, backup)
  });
}

async function platformOperationalAlertsEndpoint(params = new URLSearchParams()) {
  const period = platformHealthPeriod(params.get?.('period') || '24h');
  const [database, backup, operationalLogs] = await Promise.all([
    checkDatabaseHealth(),
    platformBackupStatus(),
    listOperationalLogs(period.since, params)
  ]);
  const metrics = await platformTechnicalMetrics(period, database, backup);
  const config = await platformConfigChecklist();
  const statuses = [
    apiHealthStatus(metrics),
    database,
    platformStatus('auth', 'Autenticação', config.items.find((item) => item.key === 'cookie_secret')?.ok === false ? 'attention' : 'healthy', 'Sessões administrativas e cookies operando.', null),
    await billingHealthStatus(),
    webhookHealthStatus(operationalLogs),
    backupHealthStatus(backup),
    jobsHealthStatus(),
    await storageHealthStatus(UPLOAD_DIR, 'storage', 'Storage/uploads'),
    sslDomainHealthStatus(),
    await smtpHealthStatus()
  ];
  return normalizePortuguesePayload({
    generated_at: new Date().toISOString(),
    period: period.label,
    alerts: await platformHealthAlerts({ statuses, metrics, config, backup, operationalLogs })
  });
}

async function platformOperationalLogs(params = new URLSearchParams()) {
  const period = platformHealthPeriod(params.get?.('period') || '24h');
  return normalizePortuguesePayload({
    generated_at: new Date().toISOString(),
    period: period.label,
    logs: await listOperationalLogs(period.since, params)
  });
}

function platformHealthPeriod(value) {
  const key = ['7d', '30d'].includes(String(value)) ? String(value) : '24h';
  const days = key === '30d' ? 30 : key === '7d' ? 7 : 1;
  return {
    key,
    label: key === '24h' ? 'Últimas 24h' : key === '7d' ? 'Últimos 7 dias' : 'Últimos 30 dias',
    since: Date.now() - days * 86400000
  };
}

function recordRequestMetric(entry) {
  if (!entry?.pathname) return;
  requestMetrics.push({
    ...entry,
    route: normalizeMetricRoute(entry.pathname),
    created_at: Date.now()
  });
  if (requestMetrics.length > MAX_REQUEST_METRICS) requestMetrics.splice(0, requestMetrics.length - MAX_REQUEST_METRICS);
}

function platformMetricsSnapshot(period) {
  const rows = requestMetrics.filter((entry) => entry.created_at >= period.since);
  const allApiRows = rows.filter((entry) => entry.pathname.startsWith('/api/'));
  const operationalRows = allApiRows.filter((entry) => isOperationalMetricRoute(entry.pathname));
  const apiRows = allApiRows.filter((entry) => !isOperationalMetricRoute(entry.pathname));
  const checkoutRows = rows.filter((entry) => entry.pathname === '/api/orders');
  const orderMutationRows = rows.filter((entry) => /^\/api\/admin\/orders/.test(entry.pathname) && ['POST', 'PUT', 'PATCH'].includes(entry.method));
  const stats = (entries) => latencyStats(entries.map((entry) => entry.duration_ms));
  return {
    period: period.label,
    api: {
      ...stats(apiRows),
      requests: apiRows.length,
      errors_5xx: apiRows.filter((entry) => entry.status >= 500).length,
      requests_per_minute: requestsPerMinute(apiRows, period),
      slow_routes: slowMetricRoutes(apiRows)
    },
    api_all: { ...stats(allApiRows), requests: allApiRows.length, errors_5xx: allApiRows.filter((entry) => entry.status >= 500).length },
    operational_api: { ...stats(operationalRows), requests: operationalRows.length, errors_5xx: operationalRows.filter((entry) => entry.status >= 500).length, slow_routes: slowMetricRoutes(operationalRows) },
    database: { average_ms: null, p95_ms: null, p99_ms: null, source: 'verificação atual no card de banco' },
    checkout: { ...stats(checkoutRows), requests: checkoutRows.length },
    order_mutations: { ...stats(orderMutationRows), requests: orderMutationRows.length }
  };
}

function normalizeMetricRoute(pathname = '') {
  return String(pathname || '/')
    .replace(/[0-9a-f]{8}-[0-9a-f-]{27,}/gi, ':id')
    .replace(/\/\d+(?=\/|$)/g, '/:id')
    .replace(/\/[A-Z0-9_-]{16,}(?=\/|$)/gi, '/:token');
}

function isOperationalMetricRoute(pathname = '') {
  return /^\/api\/platform\/(health|metrics|alerts\/operational|logs|services(?:\/|$)|backups(?:\/|$))/.test(pathname);
}

function slowMetricRoutes(rows = []) {
  const grouped = new Map();
  for (const row of rows) {
    const key = `${row.method || 'GET'} ${row.route || normalizeMetricRoute(row.pathname)}`;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(row.duration_ms);
  }
  return [...grouped.entries()].map(([route, values]) => ({
    route,
    requests: values.length,
    ...latencyStats(values)
  })).sort((a, b) => (b.p95_ms || 0) - (a.p95_ms || 0)).slice(0, 10);
}

async function platformTechnicalMetrics(period, databaseStatus = null, backup = null) {
  const metrics = platformMetricsSnapshot(period);
  const [uploadsDisk, backupsDisk] = await Promise.all([
    diskUsageForPath(UPLOAD_DIR).catch(() => null),
    diskUsageForPath(BACKUP_DIR).catch(() => null)
  ]);
  metrics.database = {
    average_ms: databaseStatus?.latency_ms ?? null,
    p95_ms: databaseStatus?.latency_ms ?? null,
    p99_ms: databaseStatus?.latency_ms ?? null,
    status: databaseStatus?.status || 'unknown',
    source: 'verificação atual'
  };
  metrics.system = {
    memory: await memorySnapshot(),
    cpu: cpuSnapshot(),
    disk: {
      uploads: uploadsDisk,
      backups: backupsDisk,
      lowest_free_percent: lowestFreePercent([uploadsDisk, backupsDisk])
    },
    uptime_seconds: Math.floor(process.uptime()),
    node: process.version
  };
  metrics.storage = {
    uploads_dir: safeDirectoryLabel(UPLOAD_DIR),
    backups_dir: safeDirectoryLabel(BACKUP_DIR),
    backup_latest_size_bytes: backup?.latest?.size_bytes || 0,
    upload_free_bytes: uploadsDisk?.free_bytes ?? null,
    backup_free_bytes: backupsDisk?.free_bytes ?? null
  };
  return metrics;
}

function requestsPerMinute(rows, period) {
  const minutes = Math.max(1, Math.ceil((Date.now() - period.since) / 60000));
  return Number((rows.length / minutes).toFixed(2));
}

async function memorySnapshot() {
  const memory = process.memoryUsage();
  const heap = v8.getHeapStatistics();
  const meminfo = await linuxMeminfo();
  const swapTotal = meminfo.SwapTotal || 0;
  const swapFree = meminfo.SwapFree || 0;
  const swapUsed = Math.max(0, swapTotal - swapFree);
  const heapLimit = Number(heap.heap_size_limit || 0);
  return {
    rss_bytes: memory.rss,
    heap_used_bytes: memory.heapUsed,
    heap_total_bytes: memory.heapTotal,
    heap_limit_bytes: heapLimit,
    heap_used_percent: heapLimit ? Number(((memory.heapUsed / heapLimit) * 100).toFixed(1)) : null,
    external_bytes: memory.external,
    system_total_bytes: os.totalmem(),
    system_free_bytes: os.freemem(),
    system_used_percent: os.totalmem() ? Number((((os.totalmem() - os.freemem()) / os.totalmem()) * 100).toFixed(1)) : null,
    swap_total_bytes: swapTotal,
    swap_free_bytes: swapFree,
    swap_used_bytes: swapUsed,
    swap_used_percent: swapTotal ? Number(((swapUsed / swapTotal) * 100).toFixed(1)) : null
  };
}

async function linuxMeminfo() {
  if (process.platform !== 'linux') return {};
  const content = await readFile('/proc/meminfo', 'utf8').catch(() => '');
  const data = {};
  for (const line of content.split('\n')) {
    const match = line.match(/^([A-Za-z_()]+):\s+(\d+)\s+kB/i);
    if (match) data[match[1]] = Number(match[2]) * 1024;
  }
  return data;
}

function cpuSnapshot() {
  const cpus = os.cpus() || [];
  const load = os.loadavg?.() || [0, 0, 0];
  const cores = cpus.length || 1;
  return {
    cores,
    load_1m: Number(load[0] || 0),
    load_5m: Number(load[1] || 0),
    load_15m: Number(load[2] || 0),
    load_percent: load[0] ? Number(Math.min(100, (load[0] / cores) * 100).toFixed(1)) : null
  };
}

async function diskUsageForPath(directory) {
  await mkdir(directory, { recursive: true });
  const info = await statfs(directory);
  const total = Number(info.blocks || 0) * Number(info.bsize || 0);
  const free = Number(info.bavail || info.bfree || 0) * Number(info.bsize || 0);
  return {
    path: safeDirectoryLabel(directory),
    total_bytes: total || null,
    free_bytes: free || null,
    used_bytes: total && free !== null ? total - free : null,
    free_percent: total ? Number(((free / total) * 100).toFixed(1)) : null
  };
}

function lowestFreePercent(rows = []) {
  const values = rows.map((row) => row?.free_percent).filter((value) => Number.isFinite(value));
  return values.length ? Math.min(...values) : null;
}

function safeDirectoryLabel(directory) {
  return path.basename(directory) ? `.../${path.basename(directory)}` : 'configurado';
}

function latencyStats(values = []) {
  const clean = values.filter((value) => Number.isFinite(value)).sort((a, b) => a - b);
  if (!clean.length) return { average_ms: null, p95_ms: null, p99_ms: null };
  const average = Math.round(clean.reduce((sum, value) => sum + value, 0) / clean.length);
  return {
    average_ms: average,
    p95_ms: percentile(clean, 0.95),
    p99_ms: percentile(clean, 0.99)
  };
}

function percentile(values, ratio) {
  if (!values.length) return null;
  const index = Math.min(values.length - 1, Math.ceil(values.length * ratio) - 1);
  return Math.round(values[index]);
}

function apiHealthStatus(metrics) {
  const api = metrics?.api || {};
  if (Number(api.errors_5xx || 0) >= 5) return platformStatus('api', 'Aplicação/API', 'error', `${Number(api.errors_5xx || 0)} erro(s) 5xx no período.`, api.average_ms);
  if (Number(api.p95_ms || 0) > 1500) return platformStatus('api', 'Aplicação/API', 'attention', `P95 alto: ${api.p95_ms} ms.`, api.average_ms);
  return platformStatus('api', 'Aplicação/API', 'healthy', `Servidor ativo desde ${new Date(Date.now() - process.uptime() * 1000).toLocaleString('pt-BR')}.`, api.average_ms);
}

async function checkDatabaseHealth() {
  const startedAt = performance.now();
  try {
    await dbRequest('GET', 'companies', { select: 'id', limit: '1' });
    const duration = Math.round(performance.now() - startedAt);
    return platformStatus('database', 'Banco PostgreSQL', duration > 800 ? 'attention' : 'healthy', `Resposta em ${duration} ms.`, duration);
  } catch (error) {
    return platformStatus('database', 'Banco PostgreSQL', 'error', error.message || 'Banco indisponível.', null);
  }
}

function platformStatus(key, label, status, message, latencyMs = null) {
  return {
    key,
    label,
    status,
    message,
    latency_ms: latencyMs,
    checked_at: new Date().toISOString()
  };
}

async function billingHealthStatus() {
  const billing = await getPlatformBillingSettings().catch(() => null);
  const configured = Boolean(billing?.is_active && billing?.has_api_key);
  return platformStatus(
    'billing',
    'Billing/Abacate Pay',
    configured ? 'healthy' : 'attention',
    configured ? `Provider e API key configurados (${billing.source}).` : 'API key de billing não configurada; configure Billing > Configuração Abacate Pay.',
    null
  );
}

function jobsHealthStatus() {
  const backupScript = existsSync(path.join(__dirname, 'scripts', 'backup-postgres.mjs'));
  const cleanupScript = existsSync(path.join(__dirname, 'scripts', 'cleanup-inactive-trials.mjs'));
  if (!backupScript || !cleanupScript) return platformStatus('jobs', 'Jobs/rotinas', 'attention', 'Alguma rotina operacional não foi encontrada.', null);
  return platformStatus('jobs', 'Jobs/rotinas', 'healthy', 'Rotinas de backup e limpeza de trials disponíveis.', null);
}

function sslDomainHealthStatus() {
  const appUrl = process.env.PUBLIC_APP_URL || process.env.APP_URL || '';
  if (!appUrl) return platformStatus('ssl', 'SSL/domínio', 'unknown', 'APP_URL/PUBLIC_APP_URL não configurada.', null);
  try {
    const parsed = new URL(appUrl);
    if (parsed.protocol !== 'https:') return platformStatus('ssl', 'SSL/domínio', 'attention', 'URL pública não está em HTTPS.', null);
    return platformStatus('ssl', 'SSL/domínio', 'healthy', `HTTPS configurado para ${parsed.hostname}.`, null);
  } catch {
    return platformStatus('ssl', 'SSL/domínio', 'attention', 'URL pública inválida.', null);
  }
}

async function smtpHealthStatus() {
  const smtp = await getPlatformSmtpSettings().catch(() => null);
  const configured = Boolean(smtp?.is_active && smtp?.host && smtp?.from_email && smtp?.has_password);
  const source = smtp?.source === 'env' ? 'ambiente' : 'Platform';
  const lastTest = smtp?.last_test_status
    ? ` Último teste: ${smtp.last_test_status}${smtp.last_test_at ? ` em ${new Date(smtp.last_test_at).toLocaleString('pt-BR')}` : ''}.`
    : '';
  return platformStatus(
    'smtp',
    'SMTP/e-mail',
    configured ? 'healthy' : 'attention',
    configured ? `SMTP ativo via ${source}.${lastTest}` : 'SMTP não está ativo ou está incompleto.',
    null
  );
}

async function smtpServiceStatus() {
  const smtp = await getPlatformSmtpSettings().catch(() => null);
  const configured = Boolean(smtp?.is_active && smtp?.host && smtp?.from_email && smtp?.has_password);
  const missing = [];
  if (!smtp?.is_active) missing.push('ativo');
  if (!smtp?.host) missing.push('host');
  if (!smtp?.from_email) missing.push('remetente');
  if (!smtp?.has_password) missing.push('senha/token');
  return {
    status: configured ? 'healthy' : 'attention',
    source: smtp?.source || 'database',
    host: smtp?.host ? maskConfigValue(`smtp://${smtp.host}`, 'url') : '',
    port: smtp?.port || 587,
    from_email: smtp?.from_email || '',
    has_password: Boolean(smtp?.has_password),
    is_active: Boolean(smtp?.is_active),
    last_test_status: smtp?.last_test_status || null,
    last_test_at: smtp?.last_test_at || null,
    message: configured
      ? `SMTP ativo para ${smtp.from_email}.`
      : `Configuração incompleta: ${missing.join(', ') || 'dados ausentes'}.`
  };
}

async function getPlatformBillingSettings() {
  const rows = await dbRequest('GET', 'platform_billing_settings', {
    select: '*',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  const row = rows[0] || null;
  if (!row) {
    return publicPlatformBillingSettings({
      provider: PLATFORM_BILLING_PROVIDER || 'abacatepay',
      api_key: PLATFORM_BILLING_API_KEY,
      webhook_secret: PLATFORM_BILLING_WEBHOOK_SECRET,
      is_active: Boolean(PLATFORM_BILLING_API_KEY),
      source: PLATFORM_BILLING_API_KEY ? 'env' : 'empty',
      metadata: {}
    });
  }
  return publicPlatformBillingSettings(row);
}

async function privatePlatformBillingSettings() {
  const rows = await dbRequest('GET', 'platform_billing_settings', {
    select: '*',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  const row = rows[0] || null;
  if (!row) {
    return {
      provider: PLATFORM_BILLING_PROVIDER || 'abacatepay',
      api_key: PLATFORM_BILLING_API_KEY,
      webhook_secret: PLATFORM_BILLING_WEBHOOK_SECRET,
      is_active: Boolean(PLATFORM_BILLING_API_KEY),
      source: PLATFORM_BILLING_API_KEY ? 'env' : 'empty',
      public_url: cleanText(process.env.PUBLIC_APP_URL || process.env.APP_URL || '')
    };
  }
  const provider = cleanSlug(row.provider || PLATFORM_BILLING_PROVIDER || 'abacatepay');
  return {
    id: row.id || null,
    provider,
    api_key: row.is_active === false ? '' : (row.api_key || PLATFORM_BILLING_API_KEY || ''),
    webhook_secret: row.is_active === false ? '' : (row.webhook_secret || PLATFORM_BILLING_WEBHOOK_SECRET || ''),
    is_active: row.is_active === true,
    public_url: cleanText(row.public_url || process.env.PUBLIC_APP_URL || process.env.APP_URL || ''),
    source: 'database'
  };
}

async function updatePlatformBillingSettings(req, admin, data = {}) {
  await assertPlatformAdminPassword(req, admin, data.password || data.superadmin_password || '');
  const currentRows = await dbRequest('GET', 'platform_billing_settings', {
    select: '*',
    order: 'created_at.desc',
    limit: '1'
  }).catch((error) => {
    throw httpError(500, 'Tabela de billing não encontrada. Execute as migrations antes de configurar Abacate Pay.', { cause: error.message });
  });
  const current = currentRows[0] || null;
  const provider = cleanSlug(data.provider || 'abacatepay');
  if (!['abacatepay', 'mock'].includes(provider)) throw httpError(422, 'Provedor de billing não suportado.');
  const apiKey = String(data.api_key || data.apiKey || '').trim();
  const webhookSecret = String(data.webhook_secret || data.webhookSecret || '').trim();
  const publicUrl = cleanText(data.public_url || data.publicUrl || process.env.PUBLIC_APP_URL || process.env.APP_URL || '').slice(0, 500) || null;
  const payload = {
    provider,
    ...(apiKey ? { api_key: apiKey } : {}),
    ...(webhookSecret ? { webhook_secret: webhookSecret } : {}),
    public_url: publicUrl,
    is_active: data.is_active === true || data.is_active === 'true',
    metadata: { updated_by: admin.id },
    updated_at: new Date().toISOString()
  };
  if (payload.is_active && provider === 'abacatepay' && !apiKey && !current?.api_key && !PLATFORM_BILLING_API_KEY) {
    throw httpError(422, 'Informe a API key da Abacate Pay para ativar o checkout.');
  }
  const [saved] = current
    ? await dbRequest('PATCH', 'platform_billing_settings', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation'])
    : await dbRequest('POST', 'platform_billing_settings', {}, { ...payload, created_at: new Date().toISOString() }, ['Prefer: return=representation']);
  await audit('platform.billing.config.update', {
    req,
    actor_admin_id: admin.id,
    entity_type: 'platform_billing_settings',
    entity_id: saved.id,
    severity: 'warning',
    before_data: current ? publicPlatformBillingSettings(current) : null,
    after_data: publicPlatformBillingSettings(saved)
  });
  return publicPlatformBillingSettings(saved);
}

function publicPlatformBillingSettings(row = {}) {
  const origin = cleanText(row.public_url || process.env.PUBLIC_APP_URL || process.env.APP_URL || '').replace(/\/+$/, '');
  const provider = cleanSlug(row.provider || PLATFORM_BILLING_PROVIDER || 'abacatepay') || 'abacatepay';
  const apiKey = row.api_key || PLATFORM_BILLING_API_KEY || '';
  const webhookSecret = row.webhook_secret || PLATFORM_BILLING_WEBHOOK_SECRET || '';
  return {
    id: row.id || null,
    provider,
    is_active: row.is_active === true,
    has_api_key: Boolean(apiKey),
    api_key_masked: apiKey ? maskEmailOrToken(apiKey) : '',
    has_webhook_secret: Boolean(webhookSecret),
    webhook_secret_masked: webhookSecret ? maskEmailOrToken(webhookSecret) : '',
    webhook_url: origin ? `${origin}/api/billing/webhook?provider=${encodeURIComponent(provider)}` : '/api/billing/webhook?provider=abacatepay',
    public_url: origin || '',
    source: row.source || 'database',
    last_test_status: row.last_test_status || null,
    last_test_at: row.last_test_at || null,
    last_test_message: row.last_test_message || '',
    updated_at: row.updated_at || null
  };
}

async function testPlatformBillingSettings(req, admin) {
  const config = await privatePlatformBillingSettings();
  if (!config.is_active || !config.api_key) throw httpError(422, 'Abacate Pay não está ativo ou não possui API key configurada.');
  if (config.provider === 'mock') {
    await markPlatformBillingTest('success', 'Provider mock ativo.');
    return { ok: true, message: 'Provider mock ativo para testes internos.' };
  }
  if (config.provider !== 'abacatepay') throw httpError(422, 'Provedor de billing não suportado.');
  try {
    await providerFetch(`${ABACATEPAY_API_BASE}/store/get`, {
      method: 'GET',
      token: config.api_key
    });
    await markPlatformBillingTest('success', 'Conexão com Abacate Pay validada.');
    await audit('platform.billing.config.test', {
      req,
      actor_admin_id: admin.id,
      entity_type: 'platform_billing_settings',
      severity: 'info',
      after_data: { status: 'success', provider: config.provider }
    });
    return { ok: true, message: 'Conexão com Abacate Pay validada com sucesso.' };
  } catch (error) {
    const message = error.message || 'Falha ao testar Abacate Pay.';
    await markPlatformBillingTest('failed', message).catch(() => {});
    await audit('platform.billing.config.test', {
      req,
      actor_admin_id: admin.id,
      entity_type: 'platform_billing_settings',
      severity: 'warning',
      after_data: { status: 'failed', provider: config.provider, message: safeCommandOutput(message) }
    });
    throw httpError(502, 'Não foi possível conectar na Abacate Pay. Verifique a API key e o ambiente.');
  }
}

async function markPlatformBillingTest(status, message = '') {
  const rows = await dbRequest('GET', 'platform_billing_settings', { select: 'id', order: 'created_at.desc', limit: '1' }).catch(() => []);
  if (!rows[0]) return;
  await dbRequest('PATCH', 'platform_billing_settings', { id: `eq.${rows[0].id}` }, {
    last_test_status: status,
    last_test_at: new Date().toISOString(),
    last_test_message: cleanText(message).slice(0, 500),
    updated_at: new Date().toISOString()
  }).catch(() => {});
}

async function getPlatformSmtpSettings() {
  const rows = await dbRequest('GET', 'platform_smtp_settings', {
    select: '*',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  const row = rows[0] || null;
  if (!row) {
    return publicSmtpSettings({
      host: process.env.SMTP_HOST || '',
      port: Number(process.env.SMTP_PORT || 587),
      username: process.env.SMTP_USER || '',
      password_token: process.env.SMTP_PASS || process.env.SMTP_TOKEN || '',
      from_email: process.env.SMTP_FROM_EMAIL || '',
      from_name: process.env.SMTP_FROM_NAME || '',
      reply_to: process.env.SMTP_REPLY_TO || '',
      use_tls: parseBoolean(process.env.SMTP_TLS, true),
      is_active: Boolean(process.env.SMTP_HOST || process.env.SMTP_URL),
      source: process.env.SMTP_HOST || process.env.SMTP_URL ? 'env' : 'empty'
    });
  }
  return publicSmtpSettings(row);
}

async function updatePlatformSmtpSettings(req, admin, data = {}) {
  const currentRows = await dbRequest('GET', 'platform_smtp_settings', {
    select: '*',
    order: 'created_at.desc',
    limit: '1'
  }).catch((error) => {
    throw httpError(500, 'Tabela de SMTP não encontrada. Execute as migrations antes de configurar SMTP.', { cause: error.message });
  });
  const current = currentRows[0] || null;
  const password = String(data.password_token || data.password || '').trim();
  const rawUsername = cleanText(data.username || '').slice(0, 255);
  const username = rawUsername.includes('***') && current?.username ? current.username : rawUsername;
  const payload = {
    host: cleanText(data.host || '').slice(0, 255) || null,
    port: clampNumber(Number(data.port || 587), 1, 65535),
    username: username || null,
    ...(password ? { password_token: password } : {}),
    from_email: cleanEmail(data.from_email || '') || null,
    from_name: cleanText(data.from_name || '').slice(0, 180) || null,
    reply_to: cleanEmail(data.reply_to || '') || null,
    use_tls: data.use_tls !== false,
    is_active: data.is_active === true || data.is_active === 'true',
    metadata: { updated_by: admin.id },
    updated_at: new Date().toISOString()
  };
  if (!payload.host) throw httpError(422, 'Informe o host SMTP.');
  if (!payload.from_email) throw httpError(422, 'Informe o remetente padrão.');
  const [saved] = current
    ? await dbRequest('PATCH', 'platform_smtp_settings', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation'])
    : await dbRequest('POST', 'platform_smtp_settings', {}, { ...payload, created_at: new Date().toISOString() }, ['Prefer: return=representation']);
  await audit('platform.smtp.update', {
    req,
    actor_admin_id: admin.id,
    entity_type: 'platform_smtp_settings',
    entity_id: saved.id,
    severity: 'warning',
    before_data: current ? publicSmtpSettings(current) : null,
    after_data: publicSmtpSettings(saved)
  });
  return publicSmtpSettings(saved);
}

function publicSmtpSettings(row = {}) {
  return {
    id: row.id || null,
    host: row.host || '',
    port: Number(row.port || 587),
    username: row.username ? maskEmailOrToken(row.username) : '',
    has_password: Boolean(row.password_token || process.env.SMTP_PASS || process.env.SMTP_TOKEN),
    from_email: row.from_email || '',
    from_name: row.from_name || '',
    reply_to: row.reply_to || '',
    use_tls: row.use_tls !== false,
    is_active: row.is_active === true,
    last_test_status: row.last_test_status || null,
    last_test_at: row.last_test_at || null,
    source: row.source || 'database',
    updated_at: row.updated_at || null
  };
}

function privateSmtpSettings(row = {}) {
  const rawUsername = String(row.username || process.env.SMTP_USER || '');
  const safeUsername = rawUsername.includes('***') ? (row.from_email || process.env.SMTP_FROM_EMAIL || '') : rawUsername;
  return {
    host: row.host || process.env.SMTP_HOST || '',
    port: Number(row.port || process.env.SMTP_PORT || 587),
    username: safeUsername,
    password: row.password_token || process.env.SMTP_PASS || process.env.SMTP_TOKEN || '',
    from_email: row.from_email || process.env.SMTP_FROM_EMAIL || '',
    from_name: row.from_name || process.env.SMTP_FROM_NAME || '',
    reply_to: row.reply_to || process.env.SMTP_REPLY_TO || '',
    use_tls: row.use_tls !== false,
    is_active: row.is_active === true || Boolean(process.env.SMTP_HOST || process.env.SMTP_URL)
  };
}

function maskEmailOrToken(value = '') {
  const text = String(value || '');
  if (!text) return '';
  if (text.includes('@')) {
    const [name, domain] = text.split('@');
    return `${name.slice(0, 2)}***@${domain}`;
  }
  return text.length <= 4 ? '****' : `${text.slice(0, 2)}***${text.slice(-2)}`;
}

async function sendPlatformSmtpTest(req, admin, data = {}) {
  const target = cleanEmail(data.email || admin.email || '');
  if (!target) throw httpError(422, 'Informe um e-mail válido para teste.');
  try {
    await sendPlatformTemplateEmail({
      to: target,
      templateKey: 'smtp_test',
      variables: {
        customer_name: admin.name || 'Admin Master',
        company_name: 'TáPronto',
        store_name: '',
        due_date: '',
        dashboard_url: absolutePanelUrl('/'),
        support_url: absolutePlatformUrl('/?tab=communication'),
        payment_url: absolutePanelUrl('/?tab=plan'),
        platform_url: absolutePlatformUrl('/?tab=communication')
      },
      requireActive: true
    });
    await markSmtpTest('success');
    await audit('platform.smtp.test', {
      req,
      actor_admin_id: admin.id,
      entity_type: 'platform_smtp_settings',
      severity: 'info',
      after_data: { status: 'success', target_email: maskEmailOrToken(target) }
    });
    return { ok: true, message: 'E-mail de teste enviado com sucesso.' };
  } catch (error) {
    await markSmtpTest('failed').catch(() => {});
    await audit('platform.smtp.test', {
      req,
      actor_admin_id: admin.id,
      entity_type: 'platform_smtp_settings',
      severity: 'warning',
      after_data: { status: 'failed', target_email: maskEmailOrToken(target), message: error.message || 'Falha SMTP' }
    });
    throw httpError(502, 'Não foi possível enviar o e-mail de teste. Verifique host, porta, TLS, usuário e senha.');
  }
}

async function markSmtpTest(status) {
  const rows = await dbRequest('GET', 'platform_smtp_settings', { select: 'id', order: 'created_at.desc', limit: '1' }).catch(() => []);
  if (!rows[0]) return;
  await dbRequest('PATCH', 'platform_smtp_settings', { id: `eq.${rows[0].id}` }, {
    last_test_status: status,
    last_test_at: new Date().toISOString()
  }, ['Prefer: return=minimal']).catch(() => {});
}

async function getPlatformWhatsappSettings() {
  const rows = await dbRequest('GET', 'platform_whatsapp_settings', {
    select: '*',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  const row = rows[0] || null;
  if (!row) {
    const fallback = publicPlatformWhatsappSettings({
      provider: 'evolution_go',
      base_url: process.env.EVOLUTION_GO_API_URL || '',
      api_key_encrypted: process.env.EVOLUTION_GO_GLOBAL_API_KEY || '',
      is_active: Boolean(process.env.EVOLUTION_GO_API_URL && process.env.EVOLUTION_GO_GLOBAL_API_KEY),
      source: process.env.EVOLUTION_GO_API_URL ? 'env' : 'empty'
    });
    fallback.provider_account = await publicPlatformWhatsappProviderAccount();
    return fallback;
  }
  const settings = publicPlatformWhatsappSettings(row);
  settings.provider_account = await publicPlatformWhatsappProviderAccount();
  return settings;
}

async function privatePlatformWhatsappSettings() {
  const rows = await dbRequest('GET', 'platform_whatsapp_settings', {
    select: '*',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  const row = rows[0] || {};
  return {
    id: row.id || null,
    provider: cleanText(row.provider || 'evolution_go').toLowerCase(),
    base_url: cleanText(row.base_url || process.env.EVOLUTION_GO_API_URL || '').replace(/\/+$/, ''),
    api_key: row.api_key_encrypted || process.env.EVOLUTION_GO_GLOBAL_API_KEY || '',
    is_active: row.is_active === true || Boolean(process.env.EVOLUTION_GO_API_URL && process.env.EVOLUTION_GO_GLOBAL_API_KEY),
    webhook_secret: process.env.EVOLUTION_WEBHOOK_SECRET || ''
  };
}

function publicPlatformWhatsappSettings(row = {}) {
  const baseUrl = cleanText(row.base_url || process.env.EVOLUTION_GO_API_URL || '').replace(/\/+$/, '');
  const apiKey = row.api_key_encrypted || process.env.EVOLUTION_GO_GLOBAL_API_KEY || '';
  const origin = cleanText(process.env.PUBLIC_APP_URL || process.env.APP_URL || '').replace(/\/+$/, '');
  return {
    id: row.id || null,
    provider: cleanText(row.provider || 'evolution_go') || 'evolution_go',
    base_url: baseUrl,
    has_api_key: Boolean(apiKey),
    api_key_masked: apiKey ? maskEmailOrToken(apiKey) : '',
    is_active: row.is_active === true,
    webhook_url: origin ? `${origin}/api/integrations/evolution/webhook` : '/api/integrations/evolution/webhook',
    source: row.source || 'database',
    last_test_status: row.last_test_status || null,
    last_test_at: row.last_test_at || null,
    last_test_message: row.last_test_message || '',
    updated_at: row.updated_at || null
  };
}

async function updatePlatformWhatsappSettings(req, admin, data = {}) {
  await assertPlatformAdminPassword(req, admin, data.password || data.superadmin_password || '');
  const currentRows = await dbRequest('GET', 'platform_whatsapp_settings', {
    select: '*',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  const current = currentRows[0] || null;
  const nextApiKey = cleanText(data.api_key || data.apiKey || '').slice(0, 1000);
  const payload = {
    provider: 'evolution_go',
    base_url: cleanText(data.base_url || data.baseUrl || '').replace(/\/+$/, '').slice(0, 500) || null,
    ...(nextApiKey && !isMaskedSecretValue(nextApiKey) ? { api_key_encrypted: nextApiKey } : {}),
    is_active: data.is_active === true || data.is_active === 'true',
    metadata: { updated_by: admin.id },
    updated_at: new Date().toISOString()
  };
  if (!payload.base_url) throw httpError(422, 'Informe a URL base da Evolution Go.');
  assertEvolutionGoOnlyBaseUrl(payload.base_url);
  const [saved] = current
    ? await dbRequest('PATCH', 'platform_whatsapp_settings', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation'])
    : await dbRequest('POST', 'platform_whatsapp_settings', {}, { ...payload, created_at: new Date().toISOString() }, ['Prefer: return=representation']);
  const providerAccount = await upsertPlatformWhatsappProviderAccount(data, admin);
  await audit('platform.whatsapp.settings.update', {
    req,
    actor_admin_id: admin.id,
    entity_type: 'platform_whatsapp_settings',
    entity_id: saved.id,
    severity: 'warning',
    before_data: current ? publicPlatformWhatsappSettings(current) : null,
    after_data: publicPlatformWhatsappSettings(saved)
  });
  const publicSettings = publicPlatformWhatsappSettings(saved);
  publicSettings.provider_account = providerAccount;
  return publicSettings;
}

async function getPlatformWhatsappProviderAccount() {
  const currentRows = await dbRequest('GET', 'platform_whatsapp_provider_accounts', {
    select: '*',
    provider: 'eq.evolution_go',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  if (currentRows[0]) return currentRows[0];
  const legacyRows = await dbRequest('GET', 'platform_whatsapp_provider_accounts', {
    select: '*',
    provider: 'eq.evolution',
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  return legacyRows[0] || null;
}

async function publicPlatformWhatsappProviderAccount(row = null) {
  const account = row || await getPlatformWhatsappProviderAccount();
  const [currentInstances, legacyInstances, currentEvents, legacyEvents] = await Promise.all([
    dbRequest('GET', 'store_whatsapp_integrations', {
      select: 'id,status,monthly_cost_cents,next_billing_at,billing_status',
      provider: 'eq.evolution_go',
      limit: '5000'
    }).catch(() => []),
    dbRequest('GET', 'store_whatsapp_integrations', {
      select: 'id,status,monthly_cost_cents,next_billing_at,billing_status',
      provider: 'eq.evolution',
      limit: '5000'
    }).catch(() => []),
    dbRequest('GET', 'whatsapp_instance_events', {
      select: 'id,event_type,status,cost_cents,message,created_at',
      provider: 'eq.evolution_go',
      order: 'created_at.desc',
      limit: '5'
    }).catch(() => []),
    dbRequest('GET', 'whatsapp_instance_events', {
      select: 'id,event_type,status,cost_cents,message,created_at',
      provider: 'eq.evolution',
      order: 'created_at.desc',
      limit: '5'
    }).catch(() => [])
  ]);
  const instances = [...currentInstances, ...legacyInstances];
  const events = [...currentEvents, ...legacyEvents]
    .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0))
    .slice(0, 5);
  const billable = instances.filter((entry) => !['cancelled', 'removed', 'deleted'].includes(String(entry.billing_status || '').toLowerCase()));
  const connected = instances.filter((entry) => ['connected', 'connecting'].includes(normalizeWhatsappIntegrationStatus(entry.status)));
  const balanceCents = Number(account?.balance_cents || 0);
  const instanceCostCents = Number(account?.instance_cost_cents || 2990);
  const monthlyCostCents = billable.reduce((sum, entry) => sum + Number(entry.monthly_cost_cents || instanceCostCents), 0);
  return {
    id: account?.id || null,
    provider: account?.provider || 'evolution_go',
    status: account?.status || 'not_configured',
    balance_cents: balanceCents,
    instance_cost_cents: instanceCostCents,
    low_balance_cents: Number(account?.low_balance_cents || instanceCostCents),
    billing_cycle_days: Number(account?.billing_cycle_days || 30),
    active_instances: connected.length,
    billable_instances: billable.length,
    monthly_cost_cents: monthlyCostCents,
    balance_after_next_instance_cents: balanceCents - instanceCostCents,
    has_credit_for_new_instance: balanceCents >= instanceCostCents && ['active', 'ok'].includes(String(account?.status || '').toLowerCase()),
    low_balance: balanceCents <= Number(account?.low_balance_cents || instanceCostCents),
    recent_events: events,
    updated_at: account?.updated_at || null
  };
}

async function upsertPlatformWhatsappProviderAccount(data = {}, admin = {}) {
  const current = await getPlatformWhatsappProviderAccount();
  const payload = {
    provider: 'evolution_go',
    status: data.provider_status || data.account_status || (data.provider_is_active === false ? 'inactive' : 'active'),
    billing_cycle_days: clampNumber(Number(data.billing_cycle_days || data.provider_billing_cycle_days || current?.billing_cycle_days || 30), 1, 365),
    notes: cleanText(data.provider_notes || data.notes || '').slice(0, 1000) || current?.notes || null,
    metadata: { updated_by: admin.id || null },
    updated_at: new Date().toISOString()
  };
  const [saved] = current
    ? await dbRequest('PATCH', 'platform_whatsapp_provider_accounts', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation'])
    : await dbRequest('POST', 'platform_whatsapp_provider_accounts', {}, { ...payload, created_at: new Date().toISOString() }, ['Prefer: return=representation']);
  return publicPlatformWhatsappProviderAccount(saved);
}

function platformMoneyInputToCents(value) {
  const parsed = parseMoneyInput(value);
  if (parsed !== null) return Math.round(parsed * 100);
  const numeric = Number(value);
  return Number.isFinite(numeric) ? Math.round(numeric * 100) : 0;
}

function assertEvolutionGoOnlyBaseUrl(baseUrl = '') {
  const url = cleanText(baseUrl).replace(/\/+$/, '');
  if (!url) throw httpError(422, 'Informe a URL base da Evolution Go.');
  if (!/^https?:\/\//i.test(url)) throw httpError(422, 'A URL base da Evolution Go deve começar com http:// ou https://.');
  if (/\/manager\/?$/i.test(url) || /evolution-api/i.test(url)) {
    throw httpError(422, 'Configure a URL base da Evolution Go, não o painel/URL da Evolution API antiga.');
  }
}

function isLegacyEvolutionApiPayload(payload = {}) {
  const text = typeof payload === 'string' ? payload : JSON.stringify(payload || {});
  return /Welcome to the Evolution API/i.test(text)
    || /Evolution API/i.test(text) && /version["']?\s*:\s*["']?2\./i.test(text)
    || /Cannot (GET|POST) \/instance\/all/i.test(text);
}

async function assertEvolutionGoProvider(config = {}) {
  assertEvolutionGoOnlyBaseUrl(config.base_url);
  const response = await fetchWithTimeout(config.base_url, {
    headers: {
      apikey: config.api_key,
      Accept: 'application/json'
    }
  }, 7000).catch((error) => {
    if (error.status) throw error;
    return null;
  });
  if (!response) return;
  const payload = await safeResponse(response);
  if (isLegacyEvolutionApiPayload(payload)) {
    throw httpError(422, 'A URL configurada é Evolution API antiga. Use uma instalação/URL da Evolution Go.');
  }
}

async function testPlatformWhatsappSettings(req, admin) {
  const config = await privatePlatformWhatsappSettings();
  if (!config.is_active || !config.base_url || !config.api_key) {
    throw httpError(422, 'Evolution Go não está configurada ou ativa.');
  }
  try {
    await assertEvolutionGoProvider(config);
    await evolutionRequest('/instance/all', { method: 'GET' }, config);
    await markPlatformWhatsappTest('success', 'Conexão com Evolution Go validada.');
    await audit('platform.whatsapp.settings.test', {
      req,
      actor_admin_id: admin.id,
      entity_type: 'platform_whatsapp_settings',
      severity: 'info',
      after_data: { status: 'success', provider: config.provider }
    });
    return { ok: true, message: 'Conexão com Evolution Go validada.' };
  } catch (error) {
    const message = error.message || 'Falha ao testar Evolution Go.';
    await markPlatformWhatsappTest('failed', message).catch(() => {});
    await audit('platform.whatsapp.settings.test', {
      req,
      actor_admin_id: admin.id,
      entity_type: 'platform_whatsapp_settings',
      severity: 'warning',
      after_data: { status: 'failed', message: safeCommandOutput(message) }
    });
    throw httpError(502, 'Não foi possível conectar na Evolution Go. Verifique URL base e API key global.');
  }
}

async function markPlatformWhatsappTest(status, message = '') {
  const rows = await dbRequest('GET', 'platform_whatsapp_settings', { select: 'id', order: 'created_at.desc', limit: '1' }).catch(() => []);
  if (!rows[0]) return;
  await dbRequest('PATCH', 'platform_whatsapp_settings', { id: `eq.${rows[0].id}` }, {
    last_test_status: status,
    last_test_at: new Date().toISOString(),
    last_test_message: cleanText(message).slice(0, 500),
    updated_at: new Date().toISOString()
  }, ['Prefer: return=minimal']).catch(() => {});
}

async function listPlatformWhatsappInstances(params = new URLSearchParams()) {
  const status = cleanText(params.get('status') || '');
  const query = {
    select: '*',
    order: 'updated_at.desc',
    limit: String(clampNumber(Number(params.get('limit') || 100), 1, 500))
  };
  if (status) query.status = `eq.${status}`;
  const rows = await dbRequest('GET', 'store_whatsapp_integrations', query).catch(() => []);
  return { instances: rows.map(publicStoreWhatsappIntegration) };
}

async function listPlatformWhatsappLogs(params = new URLSearchParams()) {
  const query = {
    select: '*',
    order: 'created_at.desc',
    limit: String(clampNumber(Number(params.get('limit') || 100), 1, 500))
  };
  const storeId = cleanUuid(params.get('store_id') || '');
  if (storeId) query.store_id = `eq.${storeId}`;
  const rows = await dbRequest('GET', 'whatsapp_message_logs', query).catch(() => []);
  return { logs: rows.map(publicWhatsappMessageLog) };
}

async function getAdminWhatsappIntegration(admin) {
  const store = await getStoreSettings(admin.store_id);
  const integration = await getStoreWhatsappIntegration(admin.store_id);
  const settings = await getPlatformWhatsappSettings();
  const planAccess = await getCompanyFeatureAccess(admin.company_id, 'automatic_whatsapp').catch(() => ({ enabled: false }));
  const addonAccess = await getStoreAddonAccess(admin, 'whatsapp_automatic').catch(() => null);
  const automaticEnabled = planAccess.enabled === true || addonAccess?.active === true;
  return {
    configured: settings.is_active && settings.has_api_key && Boolean(settings.base_url),
    feature_enabled: automaticEnabled,
    feature_message: automaticEnabled ? '' : (addonAccess?.message || featureBlockedMessage('automatic_whatsapp')),
    addon: addonAccess ? {
      code: addonAccess.addon?.code || 'whatsapp_automatic',
      name: addonAccess.addon?.name || 'WhatsApp Automático',
      active: addonAccess.active,
      available: addonAccess.available,
      included: addonAccess.included,
      price_cents: Number(addonAccess.addon?.monthly_price_cents || 0),
      provider_cost_cents: Number(addonAccess.addon?.provider_cost_cents || 0),
      message: addonAccess.message
    } : null,
    store_phone: store.whatsapp_number || '',
    ...publicStoreWhatsappIntegration(integration),
    webhook_url: settings.webhook_url
  };
}

async function getAdminPaymentSetupAssistance(admin) {
  const store = await getStoreSettings(admin.store_id);
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  const pix = integrations.pix || {};
  const addonAccess = await getStoreAddonAccess(admin, 'payment_setup_assisted').catch(() => null);
  const configured = Boolean(pix.enabled && pix.apiKey && !isMaskedSecretValue(pix.apiKey));
  const addon = addonAccess?.addon || null;
  return {
    configured,
    pix_enabled: Boolean(pix.enabled),
    has_api_key: Boolean(pix.apiKey),
    has_webhook_secret: Boolean(pix.webhookSecret),
    addon: addonAccess ? {
      code: addon?.code || 'payment_setup_assisted',
      name: addon?.name || 'Configuração Assistida do Pix Online',
      active: addonAccess.active,
      available: addonAccess.available,
      included: addonAccess.included,
      billing_type: addonBillingType(addon || {}),
      price_cents: Number(addon?.monthly_price_cents || 0),
      price_label: addonPriceLabel(addon || {}),
      message: addonAccess.message
    } : null
  };
}

async function connectAdminWhatsappIntegration(req, admin) {
  await assertAutomaticWhatsappAccess(admin);
  const config = await privatePlatformWhatsappSettings();
  if (!config.is_active || !config.base_url || !config.api_key) throw httpError(503, 'WhatsApp automático ainda não foi configurado pela Central.');
  const store = await getStoreSettings(admin.store_id);
  const existing = await getStoreWhatsappIntegration(admin.store_id);
  const providerReserve = existing ? null : await prepareWhatsappProviderInstanceRecord(req, admin, store);
  const instanceName = existing?.instance_name || buildEvolutionInstanceName(store);
  let providerData = null;
  try {
    providerData = existing?.instance_name && existing?.instance_id
      ? await evolutionRestartOrConnectInstance(instanceName, config, { store, instanceId: existing.instance_id || null, instanceToken: existing.instance_token || null })
      : await evolutionCreateInstance(instanceName, store, config);
    await setEvolutionWebhook(instanceName, config, {
      store,
      instanceId: providerData.instance_id || existing?.instance_id || null,
      instanceToken: providerData.instance_token || existing?.instance_token || null
    }).catch(() => null);
  } catch (error) {
    await upsertStoreWhatsappIntegration({
      current: existing,
      store,
      instance_name: instanceName,
      status: 'error',
      last_error: error.message || 'Falha ao criar instância.'
    });
    const providerStatus = Number(error.status || error.detail?.status || 0);
    if ([401, 403].includes(providerStatus)) {
      throw httpError(502, 'A Evolution recusou a criação da instância. Atualize a API key na Central com permissão para criar instâncias e tente novamente.');
    }
    throw httpError(502, 'Não foi possível gerar o QR Code do WhatsApp. Tente novamente em instantes.');
  }
  const resolvedStatus = normalizeWhatsappIntegrationStatus(providerData.status || 'connecting');
  const resolvedQrCode = resolvedStatus === 'connecting' ? (providerData.qr_code_base64 || existing?.qr_code_base64 || null) : null;
  const saved = await upsertStoreWhatsappIntegration({
    current: existing,
    store,
    instance_name: instanceName,
    instance_id: providerData.instance_id || existing?.instance_id || null,
    instance_token: providerData.instance_token || existing?.instance_token || null,
    status: resolvedStatus,
    qr_code_base64: resolvedQrCode,
    last_qr_at: resolvedQrCode ? new Date().toISOString() : null,
    last_error: null,
    monthly_cost_cents: providerReserve?.instance_cost_cents || existing?.monthly_cost_cents || 2990,
    next_billing_at: providerReserve?.next_billing_at || existing?.next_billing_at || null,
    billing_status: existing?.billing_status || 'active'
  });
  if (!existing && providerReserve) {
    await registerWhatsappInstanceCreated(req, admin, saved, providerReserve).catch(() => {});
  }
  await audit('whatsapp.integration.connect', {
    req,
    company_id: admin.company_id,
    store_id: admin.store_id,
    actor_admin_id: admin.id,
    entity_type: 'store_whatsapp_integrations',
    entity_id: saved.id,
    severity: 'info',
    after_data: publicStoreWhatsappIntegration(saved)
  });
  return publicStoreWhatsappIntegration(saved);
}

async function refreshAdminWhatsappQrCode(admin) {
  await assertAutomaticWhatsappAccess(admin);
  const config = await privatePlatformWhatsappSettings();
  const integration = await requireStoreWhatsappIntegration(admin.store_id);
  const store = await getStoreSettings(admin.store_id);
  const data = await evolutionRestartOrConnectInstance(integration.instance_name, config, {
    store,
    instanceId: integration.instance_id || null,
    instanceToken: integration.instance_token || null
  });
  const resolvedStatus = normalizeWhatsappIntegrationStatus(data.status || integration.status || 'connecting');
  const resolvedQrCode = resolvedStatus === 'connecting' ? (data.qr_code_base64 || integration.qr_code_base64 || null) : null;
  const saved = await patchStoreWhatsappIntegration(integration.id, {
    qr_code_base64: resolvedQrCode,
    status: resolvedStatus,
    last_qr_at: resolvedQrCode ? new Date().toISOString() : null,
    last_error: null,
    updated_at: new Date().toISOString()
  });
  return publicStoreWhatsappIntegration(saved);
}

async function refreshAdminWhatsappStatus(admin) {
  const integration = await getStoreWhatsappIntegration(admin.store_id);
  if (!integration) return await getAdminWhatsappIntegration(admin);
  const config = await privatePlatformWhatsappSettings();
  if (!config.is_active || !config.base_url || !config.api_key) return publicStoreWhatsappIntegration(integration);
  const providerStatus = await evolutionConnectionStatus(integration.instance_name, config, {
    instanceId: integration.instance_id || null,
    instanceToken: integration.instance_token || null
  }).catch((error) => ({
    status: 'error',
    last_error: error.message || 'Falha ao consultar status.'
  }));
  const saved = await patchStoreWhatsappIntegration(integration.id, {
    status: providerStatus.status,
    phone_number: providerStatus.phone_number || integration.phone_number || null,
    connected_at: providerStatus.status === 'connected' ? (integration.connected_at || new Date().toISOString()) : integration.connected_at,
    disconnected_at: providerStatus.status === 'disconnected' ? new Date().toISOString() : integration.disconnected_at,
    last_error: providerStatus.last_error || null,
    updated_at: new Date().toISOString()
  });
  return publicStoreWhatsappIntegration(saved);
}

async function sendAdminWhatsappTest(admin, data = {}) {
  await assertAutomaticWhatsappAccess(admin);
  const store = await getStoreSettings(admin.store_id);
  const phone = whatsappRecipientPhone(data.phone || store.whatsapp_number || '');
  if (!phone) throw httpError(422, 'Configure o WhatsApp dos pedidos antes de enviar um teste.');
  const integration = await requireStoreWhatsappIntegration(admin.store_id);
  if (integration.status !== 'connected') throw httpError(409, 'Conecte o WhatsApp escaneando o QR Code antes do teste.');
  const text = `Teste do TáPronto: o WhatsApp automático da loja ${store.name || 'sua loja'} está conectado.`;
  const result = await sendEvolutionStoreMessage(store, integration, phone, text, { messageType: 'test' });
  return { ok: true, message: 'Mensagem de teste enviada.', log: publicWhatsappMessageLog(result.log) };
}

async function disconnectAdminWhatsappIntegration(req, admin) {
  const integration = await requireStoreWhatsappIntegration(admin.store_id);
  const config = await privatePlatformWhatsappSettings();
  await evolutionLogoutInstance(integration.instance_name, config, {
    instanceId: integration.instance_id || null,
    instanceToken: integration.instance_token || null
  }).catch(() => null);
  const saved = await patchStoreWhatsappIntegration(integration.id, {
    status: 'disconnected',
    disconnected_at: new Date().toISOString(),
    qr_code_base64: null,
    updated_at: new Date().toISOString()
  });
  await audit('whatsapp.integration.disconnect', {
    req,
    company_id: admin.company_id,
    store_id: admin.store_id,
    actor_admin_id: admin.id,
    entity_type: 'store_whatsapp_integrations',
    entity_id: saved.id,
    severity: 'warning'
  });
  return publicStoreWhatsappIntegration(saved);
}

async function reconnectPlatformWhatsappStore(req, admin, storeId) {
  const store = await getStoreSettings(storeId);
  const integration = await getStoreWhatsappIntegration(storeId);
  if (!integration) throw httpError(404, 'Integração de WhatsApp não encontrada para esta loja.');
  const config = await privatePlatformWhatsappSettings();
  const data = await evolutionConnectInstance(integration.instance_name, config, {
    store,
    instanceId: integration.instance_id || null,
    instanceToken: integration.instance_token || null
  });
  const saved = await patchStoreWhatsappIntegration(integration.id, {
    status: data.status || 'connecting',
    qr_code_base64: data.qr_code_base64 || null,
    last_qr_at: data.qr_code_base64 ? new Date().toISOString() : null,
    last_error: null,
    updated_at: new Date().toISOString()
  });
  await audit('platform.whatsapp.reconnect', {
    req,
    actor_admin_id: admin.id,
    company_id: store.company_id,
    store_id: storeId,
    entity_type: 'store_whatsapp_integrations',
    entity_id: saved.id,
    severity: 'warning'
  });
  return publicStoreWhatsappIntegration(saved);
}

async function disconnectPlatformWhatsappStore(req, admin, storeId) {
  const integration = await getStoreWhatsappIntegration(storeId);
  if (!integration) throw httpError(404, 'Integração de WhatsApp não encontrada para esta loja.');
  const config = await privatePlatformWhatsappSettings();
  await evolutionLogoutInstance(integration.instance_name, config, {
    instanceId: integration.instance_id || null,
    instanceToken: integration.instance_token || null
  }).catch(() => null);
  const saved = await patchStoreWhatsappIntegration(integration.id, {
    status: 'disconnected',
    disconnected_at: new Date().toISOString(),
    qr_code_base64: null,
    updated_at: new Date().toISOString()
  });
  await audit('platform.whatsapp.disconnect', {
    req,
    actor_admin_id: admin.id,
    store_id: storeId,
    entity_type: 'store_whatsapp_integrations',
    entity_id: saved.id,
    severity: 'warning'
  });
  return publicStoreWhatsappIntegration(saved);
}

async function getStoreWhatsappIntegration(storeId) {
  const resolvedStoreId = cleanUuid(storeId);
  if (!resolvedStoreId) return null;
  const currentRows = await dbRequest('GET', 'store_whatsapp_integrations', {
    select: '*',
    store_id: `eq.${resolvedStoreId}`,
    provider: 'eq.evolution_go',
    limit: '1'
  }).catch(() => []);
  if (currentRows[0]) return currentRows[0];
  const legacyRows = await dbRequest('GET', 'store_whatsapp_integrations', {
    select: '*',
    store_id: `eq.${resolvedStoreId}`,
    provider: 'eq.evolution',
    limit: '1'
  }).catch(() => []);
  return legacyRows[0] || null;
}

async function requireStoreWhatsappIntegration(storeId) {
  const integration = await getStoreWhatsappIntegration(storeId);
  if (!integration) throw httpError(404, 'Clique em Conectar WhatsApp para gerar o QR Code antes de continuar.');
  return integration;
}

async function prepareWhatsappProviderInstanceRecord(req, admin, store) {
  const account = await getPlatformWhatsappProviderAccount();
  const publicAccount = await publicPlatformWhatsappProviderAccount(account);
  const instanceCostCents = Number(publicAccount.instance_cost_cents || 2990);
  const nextBillingAt = new Date(Date.now() + Number(publicAccount.billing_cycle_days || 30) * 24 * 60 * 60 * 1000).toISOString();
  return {
    instance_cost_cents: instanceCostCents,
    next_billing_at: nextBillingAt
  };
}

async function registerWhatsappInstanceCreated(req, admin, integration, reserve = {}) {
  await recordWhatsappInstanceEvent({
    req,
    admin,
    integration,
    event_type: 'instance_created',
    status: 'success',
    cost_cents: reserve.instance_cost_cents || integration.monthly_cost_cents || 0,
    message: 'Instância Evolution criada.',
    metadata: {
      next_billing_at: reserve.next_billing_at
    }
  });
}

async function recordWhatsappInstanceEvent({ req, admin, store, integration, event_type, status = 'info', cost_cents = 0, message = '', metadata = {} }) {
  const storeId = integration?.store_id || store?.store_id || store?.id || admin?.store_id || null;
  const companyId = integration?.company_id || store?.company_id || admin?.company_id || null;
  const [event] = await dbRequest('POST', 'whatsapp_instance_events', {}, {
    company_id: companyId,
    store_id: storeId,
    integration_id: integration?.id || null,
    provider: 'evolution_go',
    event_type: cleanSlug(event_type || 'event'),
    status: cleanSlug(status || 'info'),
    cost_cents: Number(cost_cents || 0),
    message: cleanText(message).slice(0, 500) || null,
    metadata: metadata || {}
  }, ['Prefer: return=representation']);
  await audit(`whatsapp.instance.${cleanSlug(event_type || 'event')}`, {
    req,
    actor_admin_id: admin?.id || null,
    company_id: companyId,
    store_id: storeId,
    entity_type: 'whatsapp_instance_events',
    entity_id: event?.id || null,
    severity: status === 'blocked' || status === 'failed' ? 'warning' : 'info',
    after_data: {
      event_type,
      status,
      cost_cents,
      message: safeCommandOutput(message)
    }
  }).catch(() => {});
  return event;
}

async function upsertStoreWhatsappIntegration(data = {}) {
  const current = data.current || await getStoreWhatsappIntegration(data.store?.store_id || data.store?.id || data.store_id);
  const payload = {
    company_id: data.store?.company_id || data.company_id || current?.company_id || null,
    store_id: data.store?.store_id || data.store?.id || data.store_id || current?.store_id,
    provider: current?.provider || 'evolution_go',
    instance_name: data.instance_name || current?.instance_name,
    instance_id: data.instance_id || current?.instance_id || null,
    instance_token: data.instance_token || current?.instance_token || null,
    status: normalizeWhatsappIntegrationStatus(data.status || current?.status || 'disconnected'),
    phone_number: onlyDigits(data.phone_number || current?.phone_number || ''),
    qr_code_base64: data.qr_code_base64 || null,
    last_qr_at: data.last_qr_at || null,
    connected_at: data.connected_at || current?.connected_at || null,
    disconnected_at: data.disconnected_at || current?.disconnected_at || null,
    last_error: data.last_error ? cleanText(data.last_error).slice(0, 500) : null,
    monthly_cost_cents: Number(data.monthly_cost_cents ?? current?.monthly_cost_cents ?? 2990),
    next_billing_at: data.next_billing_at || current?.next_billing_at || null,
    billing_status: cleanSlug(data.billing_status || current?.billing_status || 'pending'),
    updated_at: new Date().toISOString()
  };
  if (!payload.store_id || !payload.instance_name) throw httpError(422, 'Loja ou instância inválida para WhatsApp automático.');
  let rows;
  if (current) {
    rows = await dbRequest('PATCH', 'store_whatsapp_integrations', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation']);
  } else {
    try {
      rows = await dbRequest('POST', 'store_whatsapp_integrations', {}, { ...payload, created_at: new Date().toISOString() }, ['Prefer: return=representation']);
    } catch (error) {
      if (error.code !== '23505') throw error;
      const existing = await getStoreWhatsappIntegration(payload.store_id);
      if (!existing) throw error;
      rows = await dbRequest('PATCH', 'store_whatsapp_integrations', { id: `eq.${existing.id}` }, payload, ['Prefer: return=representation']);
    }
  }
  return rows[0];
}

async function patchStoreWhatsappIntegration(id, payload = {}) {
  const cleanPayload = removeUndefinedFields({
    ...payload,
    status: payload.status ? normalizeWhatsappIntegrationStatus(payload.status) : undefined,
    updated_at: payload.updated_at || new Date().toISOString()
  });
  const [saved] = await dbRequest('PATCH', 'store_whatsapp_integrations', { id: `eq.${id}` }, cleanPayload, ['Prefer: return=representation']);
  return saved;
}

function removeUndefinedFields(value = {}) {
  return Object.fromEntries(Object.entries(value).filter(([, entry]) => entry !== undefined));
}

function publicStoreWhatsappIntegration(row = null) {
  if (!row) {
    return {
      id: null,
      provider: 'evolution_go',
      status: 'not_connected',
      status_label: 'Não conectado',
      instance_name: '',
      phone_number: '',
      has_qr_code: false,
      qr_code_base64: '',
      last_qr_at: null,
      connected_at: null,
      disconnected_at: null,
      last_error: '',
      monthly_message_count: 0,
      monthly_cost_cents: 2990,
      next_billing_at: null,
      billing_status: 'pending'
    };
  }
  return {
    id: row.id,
    provider: row.provider || 'evolution_go',
    status: normalizeWhatsappIntegrationStatus(row.status || 'disconnected'),
    status_label: whatsappIntegrationStatusLabel(row.status),
    instance_name: row.instance_name || '',
    instance_id: row.instance_id || '',
    phone_number: row.phone_number || '',
    has_qr_code: normalizeWhatsappIntegrationStatus(row.status || 'disconnected') === 'connecting' && Boolean(row.qr_code_base64),
    qr_code_base64: normalizeWhatsappIntegrationStatus(row.status || 'disconnected') === 'connecting' ? (row.qr_code_base64 || '') : '',
    last_qr_at: row.last_qr_at || null,
    connected_at: row.connected_at || null,
    disconnected_at: row.disconnected_at || null,
    last_error: row.last_error || '',
    monthly_message_count: Number(row.monthly_message_count || 0),
    monthly_cost_cents: Number(row.monthly_cost_cents || 2990),
    next_billing_at: row.next_billing_at || null,
    billing_status: row.billing_status || 'pending',
    updated_at: row.updated_at || null
  };
}

function normalizeWhatsappIntegrationStatus(status = '') {
  const value = String(status || '').toLowerCase();
  if (['open', 'connected', 'online'].includes(value)) return 'connected';
  if (['connecting', 'qrcode', 'qr', 'pairing'].includes(value)) return 'connecting';
  if (['close', 'closed', 'disconnected', 'offline', 'logout'].includes(value)) return 'disconnected';
  if (['error', 'failed'].includes(value)) return 'error';
  if (value === 'not_connected') return 'not_connected';
  return 'unknown';
}

function whatsappIntegrationStatusLabel(status = '') {
  return ({
    connected: 'Conectado',
    connecting: 'Aguardando QR Code',
    disconnected: 'Desconectado',
    error: 'Erro',
    not_connected: 'Não conectado',
    unknown: 'Desconhecido'
  })[normalizeWhatsappIntegrationStatus(status)] || 'Desconhecido';
}

function buildEvolutionInstanceName(store = {}) {
  const slug = cleanSlug(store.slug || store.name || 'loja') || 'loja';
  const shortId = cleanText(store.store_id || store.id || '').replace(/-/g, '').slice(0, 6) || randomBytes(3).toString('hex');
  return `tapronto_${slug.replace(/-/g, '_')}_${shortId}`.slice(0, 80);
}

async function evolutionCreateInstance(instanceName, store, config) {
  const instanceToken = randomUUID();
  let data = null;
  try {
    data = await evolutionRequest('/instance/create', {
      method: 'POST',
      body: {
        name: instanceName,
        token: instanceToken
      }
    }, config);
  } catch (error) {
    if (!isEvolutionDuplicateInstanceError(error)) throw error;
    const existing = await evolutionFindInstanceByName(instanceName, config);
    if (!existing?.id || !existing?.token) throw error;
    const connected = await evolutionConnectInstance(instanceName, config, {
      store,
      instanceId: existing.id,
      instanceToken: existing.token
    });
    return {
      ...connected,
      instance_token: existing.token,
      instance_id: existing.id
    };
  }
  const instanceId = data?.data?.id || data?.data?.instanceId || data?.instance?.id || data?.instance?.instanceId || data?.id || null;
  const resolvedInstanceToken = data?.data?.token || data?.instance?.token || data?.token || instanceToken;
  const connected = await evolutionConnectInstance(instanceName, config, { store, instanceToken: resolvedInstanceToken, instanceId });
  return {
    ...normalizeEvolutionQrResponse(data),
    ...connected,
    instance_token: resolvedInstanceToken,
    instance_id: instanceId
  };
}

function isEvolutionDuplicateInstanceError(error = {}) {
  const text = [
    error.message,
    error.detail?.message,
    error.detail?.detail,
    error.detail?.error,
    error.detail?.data?.message,
    error.detail?.response?.message
  ].filter(Boolean).join(' ').toLowerCase();
  return Number(error.status || error.detail?.status || 0) === 409
    || /instance.+already.+exist/.test(text)
    || /already.+exist/.test(text)
    || /duplicate key/.test(text)
    || /duplicad/.test(text)
    || /j[aá].+existe/.test(text);
}

async function evolutionFindInstanceByName(instanceName, config) {
  const data = await evolutionRequest('/instance/all', { method: 'GET' }, config);
  const instances = Array.isArray(data) ? data : Array.isArray(data?.data) ? data.data : [];
  return instances.find((entry) => cleanText(entry?.name || '') === instanceName) || null;
}

async function evolutionConnectInstance(instanceName, config, options = {}) {
  const instanceId = options.instanceId || options.instance_id || config.instance_id || null;
  const instanceToken = options.instanceToken || options.instance_token || config.instance_token || null;
  await evolutionRequest('/instance/connect', {
    method: 'POST',
    instanceId,
    instanceToken,
    body: {
      immediate: true,
      subscribe: ['MESSAGE', 'SEND_MESSAGE', 'CONNECTION', 'QRCODE'],
      webhookUrl: absolutePublicUrl('/api/integrations/evolution/webhook')
    }
  }, config);
  const qr = await evolutionGetQrCode(instanceId, config, { instanceToken }).catch(() => ({}));
  return normalizeEvolutionQrResponse({
    ...qr,
    state: qr?.data?.Qrcode || qr?.data?.Code || qr?.qrCode ? 'qrcode' : 'connecting'
  });
}

async function evolutionRestartOrConnectInstance(instanceName, config, options = {}) {
  return evolutionConnectInstance(instanceName, config, options);
}

async function evolutionConnectionStatus(instanceName, config, options = {}) {
  const instanceId = options.instanceId || options.instance_id || config.instance_id || null;
  const instanceToken = options.instanceToken || options.instance_token || config.instance_token || null;
  const data = await evolutionRequest('/instance/status', {
    method: 'GET',
    instanceId,
    instanceToken
  }, config);
  const instance = data?.data || data?.instance || data;
  const rawState = instance?.Connected === true || instance?.connected === true
    ? 'connected'
    : instance?.LoggedIn === true || instance?.loggedIn === true
      ? 'connected'
      : instance?.state || data?.state || data?.connectionState || '';
  return {
    status: normalizeWhatsappIntegrationStatus(rawState),
    phone_number: onlyDigits(instance?.owner || instance?.Name || instance?.profileName || instance?.number || data?.number || '')
  };
}

async function setEvolutionWebhook(instanceName, config, options = {}) {
  if (!options.instanceId && !options.instance_id) return null;
  return evolutionRequest('/instance/connect', {
    method: 'POST',
    instanceId: options.instanceId || options.instance_id,
    instanceToken: options.instanceToken || options.instance_token || config.instance_token || null,
    body: {
      immediate: false,
      subscribe: ['MESSAGE', 'SEND_MESSAGE', 'CONNECTION', 'QRCODE'],
      webhookUrl: absolutePublicUrl('/api/integrations/evolution/webhook')
    }
  }, config).catch((error) => {
    if ([400, 404, 405].includes(Number(error.status))) return null;
    throw error;
  });
}

async function evolutionLogoutInstance(instanceName, config, options = {}) {
  if (!config.is_active || !config.base_url || !config.api_key) return null;
  return evolutionRequest('/instance/disconnect', {
    method: 'POST',
    instanceId: options.instanceId || options.instance_id || config.instance_id || null,
    instanceToken: options.instanceToken || options.instance_token || config.instance_token || null
  }, config).catch(() => null);
}

async function evolutionSendText(instanceName, phone, message, config) {
  const data = await evolutionRequest('/send/text', {
    method: 'POST',
    instanceId: config.instance_id || null,
    instanceToken: config.instance_token || null,
    body: {
      number: phone,
      text: message,
      delay: 1200
    }
  }, config);
  return { id: data?.data?.Info?.ID || data?.messageId || data?.id || `evolution_${Date.now()}` };
}

async function evolutionRequest(endpoint, options = {}, config = null) {
  const settings = config || await privatePlatformWhatsappSettings();
  if (!settings.base_url || !settings.api_key) throw httpError(503, 'Evolution Go não configurada.');
  assertEvolutionGoOnlyBaseUrl(settings.base_url);
  const apiKey = options.instanceToken || options.instance_token || settings.api_key;
  const response = await fetchWithTimeout(`${settings.base_url}${endpoint}`, {
    method: options.method || 'GET',
    headers: {
      apikey: apiKey,
      ...(options.instanceId ? { instanceId: options.instanceId } : {}),
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    ...(options.body !== undefined ? { body: JSON.stringify(options.body) } : {})
  }, 12000);
  const data = await safeResponse(response);
  if (!response.ok && response.status === 404 && isLegacyEvolutionApiPayload(data)) {
    throw httpError(422, 'A URL configurada parece ser Evolution API antiga. Configure uma URL base da Evolution Go.');
  }
  if (!response.ok) throw httpError(response.status, whatsappProviderError('Erro na Evolution Go.', data), data);
  return data;
}

function normalizeEvolutionQrResponse(data = {}) {
  const qrcode = data?.data?.Qrcode || data?.data?.qrcode || data?.qrcode || data?.qrCode || data?.base64 || data?.code || {};
  const base64 = typeof qrcode === 'string'
    ? qrcode
    : qrcode?.base64 || qrcode?.image || data?.data?.qrCode || data?.base64 || data?.qr || '';
  const instance = data?.data || data?.instance || data;
  return {
    instance_id: instance?.instanceId || instance?.instance_id || instance?.id || data?.hash || null,
    status: normalizeWhatsappIntegrationStatus(instance?.state || data?.state || (base64 ? 'qrcode' : 'unknown')),
    qr_code_base64: normalizeQrBase64(base64)
  };
}

async function evolutionGetQrCode(instanceId, config, options = {}) {
  return evolutionRequest('/instance/qr', {
    method: 'GET',
    instanceId,
    instanceToken: options.instanceToken || options.instance_token || config.instance_token || null
  }, config);
}

function normalizeQrBase64(value = '') {
  const text = String(value || '').trim();
  if (!text) return '';
  if (text.startsWith('data:image')) return text;
  return `data:image/png;base64,${text.replace(/^base64,/, '')}`;
}

async function sendEvolutionStoreMessage(store, integration, phone, message, options = {}) {
  const config = await privatePlatformWhatsappSettings();
  const statusBefore = normalizeWhatsappIntegrationStatus(integration.status);
  if (statusBefore !== 'connected') throw httpError(409, 'WhatsApp da loja não está conectado.');
  const logPayload = {
    company_id: store.company_id || integration.company_id || null,
    store_id: store.store_id || store.id || integration.store_id || null,
    order_id: options.orderId || null,
    provider: 'evolution_go',
    instance_name: integration.instance_name,
    destination_phone: phone,
    message_type: options.messageType || 'order',
    status: 'pending'
  };
  let log = await createWhatsappMessageLog(logPayload);
  try {
    const result = await evolutionSendText(integration.instance_name, phone, message, {
      ...config,
      instance_id: integration.instance_id || null,
      instance_token: integration.instance_token || null
    });
    log = await patchWhatsappMessageLog(log.id, {
      status: 'sent',
      provider_message_id: result.id
    });
    await dbRequest('PATCH', 'store_whatsapp_integrations', { id: `eq.${integration.id}` }, {
      monthly_message_count: Number(integration.monthly_message_count || 0) + 1,
      last_error: null,
      updated_at: new Date().toISOString()
    }, ['Prefer: return=minimal']).catch(() => {});
    return { id: result.id, log };
  } catch (error) {
    log = await patchWhatsappMessageLog(log.id, {
      status: 'failed',
      error_message: cleanText(error.message || 'Falha ao enviar mensagem.').slice(0, 500)
    });
    await patchStoreWhatsappIntegration(integration.id, {
      last_error: error.message || 'Falha ao enviar mensagem.',
      updated_at: new Date().toISOString()
    }).catch(() => {});
    throw Object.assign(error, { whatsappLog: log });
  }
}

async function createWhatsappMessageLog(data = {}) {
  const [log] = await dbRequest('POST', 'whatsapp_message_logs', {}, {
    company_id: data.company_id || null,
    store_id: data.store_id || null,
    order_id: data.order_id || null,
    provider: data.provider || 'evolution_go',
    instance_name: data.instance_name || null,
    destination_phone: data.destination_phone || null,
    message_type: data.message_type || 'order',
    status: data.status || 'pending',
    error_message: data.error_message || null,
    provider_message_id: data.provider_message_id || null
  }, ['Prefer: return=representation']);
  return log;
}

async function patchWhatsappMessageLog(id, payload = {}) {
  const [log] = await dbRequest('PATCH', 'whatsapp_message_logs', { id: `eq.${id}` }, payload, ['Prefer: return=representation']);
  return log;
}

function publicWhatsappMessageLog(row = {}) {
  return {
    id: row.id || null,
    company_id: row.company_id || null,
    store_id: row.store_id || null,
    order_id: row.order_id || null,
    provider: row.provider || 'evolution_go',
    instance_name: row.instance_name || '',
    destination_phone: row.destination_phone ? maskPhone(row.destination_phone) : '',
    message_type: row.message_type || '',
    status: row.status || '',
    error_message: row.error_message || '',
    provider_message_id: row.provider_message_id || '',
    created_at: row.created_at || null
  };
}

function maskPhone(value = '') {
  const digits = onlyDigits(value);
  if (digits.length <= 4) return digits ? '****' : '';
  return `${digits.slice(0, 4)}***${digits.slice(-4)}`;
}

async function receiveEvolutionWebhook(req, payload = {}) {
  const config = await privatePlatformWhatsappSettings();
  const expectedSecret = config.webhook_secret;
  const receivedSecret = req.headers['x-evolution-webhook-secret'] || req.headers['x-webhook-secret'] || '';
  if (expectedSecret && receivedSecret !== expectedSecret) throw httpError(401, 'Webhook Evolution não autorizado.');
  const instanceName = cleanText(payload?.instance || payload?.instanceName || payload?.instance_name || payload?.data?.instance || payload?.data?.instanceName || payload?.name || '');
  const instanceId = cleanText(payload?.instanceId || payload?.instance_id || payload?.data?.instanceId || payload?.data?.id || '');
  const instanceToken = cleanText(payload?.instanceToken || payload?.instance_token || payload?.data?.instanceToken || payload?.data?.instance_token || '');
  if (!instanceName && !instanceId && !instanceToken) return { ok: true, ignored: true };
  const integration = await findWhatsappIntegrationByEvolutionIdentity({ instanceName, instanceId, instanceToken });
  if (!integration) return { ok: true, ignored: true };
  const event = String(payload?.event || payload?.type || '').toUpperCase();
  const state = payload?.data?.state || payload?.data?.status || payload?.state || payload?.status || payload?.connection || '';
  const qrData = normalizeEvolutionQrResponse(payload);
  const status = event.includes('QRCODE') || qrData.qr_code_base64
    ? 'connecting'
    : event.includes('CONNECTION') || state
      ? normalizeWhatsappIntegrationStatus(state)
      : integration.status;
  const resolvedStatus = normalizeWhatsappIntegrationStatus(status);
  const resolvedQrCode = resolvedStatus === 'connecting' ? (qrData.qr_code_base64 || integration.qr_code_base64 || null) : null;
  await patchStoreWhatsappIntegration(integration.id, {
    status: resolvedStatus,
    instance_id: instanceId || integration.instance_id || null,
    instance_token: instanceToken || integration.instance_token || null,
    qr_code_base64: resolvedQrCode,
    last_qr_at: resolvedQrCode ? new Date().toISOString() : null,
    connected_at: resolvedStatus === 'connected' ? (integration.connected_at || new Date().toISOString()) : integration.connected_at,
    disconnected_at: resolvedStatus === 'disconnected' ? new Date().toISOString() : integration.disconnected_at,
    last_error: resolvedStatus === 'error' ? cleanText(payload?.data?.message || payload?.message || 'Erro recebido no webhook.').slice(0, 500) : null,
    updated_at: new Date().toISOString()
  });
  return { ok: true };
}

async function findWhatsappIntegrationByEvolutionIdentity({ instanceName = '', instanceId = '', instanceToken = '' } = {}) {
  const attempts = [];
  if (instanceName) attempts.push({ instance_name: `eq.${instanceName}` });
  if (instanceId) attempts.push({ instance_id: `eq.${instanceId}` });
  if (instanceToken) attempts.push({ instance_token: `eq.${instanceToken}` });
  for (const filter of attempts) {
    const currentRows = await dbRequest('GET', 'store_whatsapp_integrations', {
      select: '*',
      provider: 'eq.evolution_go',
      ...filter,
      limit: '1'
    }).catch(() => []);
    if (currentRows[0]) return currentRows[0];
    const legacyRows = await dbRequest('GET', 'store_whatsapp_integrations', {
      select: '*',
      provider: 'eq.evolution',
      ...filter,
      limit: '1'
    }).catch(() => []);
    if (legacyRows[0]) return legacyRows[0];
  }
  return null;
}

const PLATFORM_SYSTEM_EMAIL_RECIPIENT = 'lucasbulow@hotmail.com';
const PLATFORM_SYSTEM_EMAIL_TEMPLATE_KEYS = new Set([
  'backup_failed',
  'webhook_failed',
  'smtp_failed',
  'internal_support_ticket_opened',
  'internal_support_ticket_replied',
  'critical_support_ticket',
  'delinquent_support_ticket',
  'cancellation_received',
  'account_created_not_published',
  'store_published_no_orders',
  'internal_payment_refused',
  'internal_account_suspended',
  'internal_trial_expiring',
  'internal_trial_expired',
  'internal_plan_changed'
]);

function platformEmailRecipient(templateKey, fallbackTo) {
  if (PLATFORM_SYSTEM_EMAIL_TEMPLATE_KEYS.has(String(templateKey || ''))) {
    return PLATFORM_SYSTEM_EMAIL_RECIPIENT;
  }
  return cleanEmail(fallbackTo || '');
}

async function sendPlatformTemplateEmail({ to, templateKey, variables = {}, requireActive = false }) {
  const key = cleanTemplateKey(templateKey || '');
  const template = (await listPlatformEmailTemplates()).templates.find((entry) => entry.template_key === key);
  if (!template?.is_active) {
    if (requireActive) throw new Error(`Template ${key || 'desconhecido'} desativado.`);
    return false;
  }
  await sendPlatformEmail({
    to,
    templateKey: key,
    subject: renderEmailTemplate(template.subject, variables),
    body: renderEmailTemplate(template.body, variables)
  });
  return true;
}

async function sendPlatformEmail({ to, subject, body, templateKey }) {
  const rows = await dbRequest('GET', 'platform_smtp_settings', { select: '*', order: 'created_at.desc', limit: '1' }).catch(() => []);
  const settings = privateSmtpSettings(rows[0] || {});
  if (!settings.is_active || !settings.host || !settings.from_email) throw new Error('SMTP não configurado.');
  const recipient = platformEmailRecipient(templateKey, to);
  if (!recipient) throw new Error('Destinatário de e-mail não informado.');
  const message = buildSmtpMessage({ to: recipient, subject, body, settings });
  await smtpSend(settings, message, recipient);
}

function buildSmtpMessage({ to, subject, body, settings }) {
  const fromName = settings.from_name || 'Suporte TáPronto';
  const ehloDomain = process.env.SMTP_EHLO_DOMAIN || 'cardapio.local';
  const rawBody = String(body || '').replace(/\r\n/g, '\n').trimEnd();
  const bodyWithLegalId = rawBody.includes(COMPANY_LEGAL_ID)
    ? rawBody
    : `${rawBody}\n\n--\n${COMPANY_LEGAL_ID}`;
  const plainBody = bodyWithLegalId.replace(/\n/g, '\r\n');
  const htmlBody = renderTransactionalEmailHtml({
    subject,
    body: rawBody,
    legalId: COMPANY_LEGAL_ID
  });
  const boundary = `tapronto_${randomUUID().replaceAll('-', '')}`;
  const headers = [
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${randomUUID()}@${ehloDomain}>`,
    `From: ${encodeMailAddress(fromName, settings.from_email)}`,
    `To: ${to}`,
    `Subject: ${encodeMimeHeader(subject)}`,
    `Reply-To: ${settings.reply_to || settings.from_email}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    'X-Mailer: TáPronto Platform'
  ];
  const plainPart = [
    `--${boundary}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    Buffer.from(plainBody, 'utf8').toString('base64')
  ].join('\r\n');
  const htmlPart = [
    `--${boundary}`,
    'Content-Type: text/html; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    Buffer.from(htmlBody, 'utf8').toString('base64')
  ].join('\r\n');
  return `${headers.join('\r\n')}\r\n\r\n${plainPart}\r\n${htmlPart}\r\n--${boundary}--\r\n`;
}

function renderTransactionalEmailHtml({ subject, body, legalId }) {
  const title = emailEscapeHtml(subject || 'TáPronto');
  const content = emailTextToHtml(body || '');
  const firstUrl = String(body || '').match(/https?:\/\/[^\s)]+/i)?.[0] || '';
  const cta = firstUrl ? `
    <tr>
      <td style="padding:8px 30px 24px;">
        <a href="${emailEscapeAttribute(firstUrl)}" style="display:inline-block;background:#e11d2a;color:#ffffff;text-decoration:none;font-weight:700;border-radius:12px;padding:13px 18px;">Abrir no TáPronto</a>
      </td>
    </tr>` : '';
  return `<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>${title}</title>
  </head>
  <body style="margin:0;background:#f4f6f8;color:#071326;font-family:Arial,Helvetica,sans-serif;">
    <div style="display:none;max-height:0;overflow:hidden;color:transparent;">${emailEscapeHtml(String(body || '').split('\n').find(Boolean) || subject || 'TáPronto')}</div>
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f4f6f8;padding:28px 12px;">
      <tr>
        <td align="center">
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:640px;background:#ffffff;border:1px solid #dde5ee;border-radius:20px;overflow:hidden;">
            <tr>
              <td style="padding:26px 30px 18px;border-left:5px solid #e11d2a;">
                <div style="font-size:13px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#e11d2a;">TáPronto</div>
                <h1 style="margin:8px 0 0;font-size:26px;line-height:1.18;color:#071326;">${title}</h1>
              </td>
            </tr>
            <tr>
              <td style="padding:0 30px 8px;font-size:16px;line-height:1.65;color:#24344d;">
                ${content}
              </td>
            </tr>
            ${cta}
            <tr>
              <td style="padding:20px 30px;background:#f8fafc;border-top:1px solid #e6edf5;color:#66758f;font-size:12px;line-height:1.5;">
                <strong style="color:#071326;">TáPronto</strong><br>
                Cardápio e pedidos para restaurantes.<br>
                ${emailEscapeHtml(legalId || '')}
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`;
}

function emailTextToHtml(text = '') {
  return String(text || '')
    .split(/\n{2,}/)
    .map((paragraph) => `<p style="margin:0 0 16px;">${linkifyEmailText(paragraph)}</p>`)
    .join('');
}

function linkifyEmailText(text = '') {
  return emailEscapeHtml(text)
    .replace(/\n/g, '<br>')
    .replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" style="color:#e11d2a;font-weight:700;">$1</a>');
}

function emailEscapeHtml(value = '') {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function emailEscapeAttribute(value = '') {
  return emailEscapeHtml(value).replace(/`/g, '&#96;');
}

function encodeMailAddress(name, email) {
  return `${encodeMimeHeader(name)} <${email}>`;
}

function encodeMimeHeader(value) {
  const text = String(value || '');
  return /[^\x20-\x7E]/.test(text) ? `=?UTF-8?B?${Buffer.from(text).toString('base64')}?=` : text;
}

function smtpSend(settings, message, to) {
  const directTls = Number(settings.port) === 465;
  const useStartTls = settings.use_tls === true && !directTls;
  return new Promise((resolve, reject) => {
    let socket = directTls
      ? tls.connect({ host: settings.host, port: settings.port, servername: settings.host, rejectUnauthorized: false })
      : net.connect({ host: settings.host, port: settings.port });
    let buffer = '';
    let settled = false;
    const timeout = setTimeout(() => {
      socket.destroy();
      reject(new Error('Tempo esgotado no SMTP.'));
    }, 15000);
    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      socket.destroy();
      if (error) reject(error);
      else resolve(true);
    };
    const upgradeToTls = () => new Promise((res, rej) => {
      const secureSocket = tls.connect({
        socket,
        servername: settings.host,
        rejectUnauthorized: false
      });
      secureSocket.once('secureConnect', () => {
        socket = secureSocket;
        socket.once('error', finish);
        buffer = '';
        res();
      });
      secureSocket.once('error', rej);
    });
    const read = (expected) => new Promise((res, rej) => {
      const cleanup = () => {
        socket.off('data', onData);
        socket.off('error', onError);
      };
      const onError = (error) => {
        cleanup();
        rej(error);
      };
      const onData = (chunk) => {
        buffer += chunk.toString('utf8');
        const lines = buffer.split(/\r?\n/).filter(Boolean);
        const last = lines[lines.length - 1] || '';
        if (/^\d{3} /.test(last)) {
          cleanup();
          const code = Number(last.slice(0, 3));
          if (!expected.includes(code)) rej(new Error(`SMTP respondeu ${code}.`));
          else {
            buffer = '';
            res(last);
          }
        }
      };
      socket.on('data', onData);
      socket.once('error', onError);
    });
    const write = (line) => socket.write(`${line}\r\n`);
    socket.once('error', (error) => {
      finish(error);
    });
    socket.once(directTls ? 'secureConnect' : 'connect', async () => {
      try {
        await read([220]);
        write(`EHLO ${process.env.SMTP_EHLO_DOMAIN || 'localhost'}`);
        await read([250]);
        if (useStartTls) {
          write('STARTTLS');
          await read([220]);
          await upgradeToTls();
          write(`EHLO ${process.env.SMTP_EHLO_DOMAIN || 'localhost'}`);
          await read([250]);
        }
        if (settings.username && settings.password) {
          write('AUTH LOGIN');
          await read([334]);
          write(Buffer.from(settings.username).toString('base64'));
          await read([334]);
          write(Buffer.from(settings.password).toString('base64'));
          await read([235]);
        }
        write(`MAIL FROM:<${settings.from_email}>`);
        await read([250]);
        write(`RCPT TO:<${to}>`);
        await read([250, 251]);
        write('DATA');
        await read([354]);
        socket.write(`${message.replace(/\r?\n\./g, '\r\n..')}\r\n.\r\n`);
        await read([250]);
        write('QUIT');
        await read([221, 250]).catch(() => {});
        finish();
      } catch (error) {
        finish(error);
      }
    });
  });
}

async function runMarketingLifecycleAutomations() {
  try {
    const [companies, stores, settings, admins, subscriptions, plans, products, orders] = await Promise.all([
      dbRequest('GET', 'companies', { select: 'id,name,billing_email,created_at,marketing_opt_in,marketing_unsubscribed_at', marketing_opt_in: 'eq.true', marketing_unsubscribed_at: 'is.null', limit: '1000' }),
      dbRequest('GET', 'stores', { select: 'id,company_id,name,slug,is_active,created_at', limit: '2000' }),
      dbRequest('GET', 'store_settings', { select: 'store_id,onboarding_completed', limit: '2000' }),
      dbRequest('GET', 'admin_users', { select: 'id,company_id,email,name,role,is_active', is_active: 'eq.true', limit: '2000' }),
      dbRequest('GET', 'company_subscriptions', { select: 'id,company_id,plan_id,status,trial_ends_at,created_at', status: 'eq.trial', limit: '1000' }),
      dbRequest('GET', 'subscription_plans', { select: 'id,name', limit: '100' }),
      dbRequest('GET', 'menu_items', { select: 'id,store_id,created_at', limit: '10000' }),
      dbRequest('GET', 'orders', { select: 'id,store_id,status,created_at', order: 'created_at.desc', limit: '10000' })
    ]);
    const storeByCompany = new Map(stores.map((store) => [store.company_id, store]));
    const settingsByStore = new Map(settings.map((setting) => [setting.store_id, setting]));
    const adminByCompany = new Map(admins.map((admin) => [admin.company_id, admin]));
    const planById = new Map(plans.map((plan) => [plan.id, plan]));
    const productStores = new Set(products.map((item) => item.store_id));
    const ordersByStore = new Map();
    for (const order of orders) {
      if (!ordersByStore.has(order.store_id)) ordersByStore.set(order.store_id, []);
      ordersByStore.get(order.store_id).push(order);
    }
    const now = Date.now();
    const candidates = [];
    for (const company of companies) {
      const store = storeByCompany.get(company.id);
      const storeSettings = store ? settingsByStore.get(store.id) : null;
      const recipient = cleanEmail(company.billing_email || adminByCompany.get(company.id)?.email || '');
      if (!recipient) continue;
      const ageHours = (now - new Date(company.created_at).getTime()) / 36e5;
      if (ageHours >= 24 && (!store || storeSettings?.onboarding_completed !== true)) candidates.push({ key: 'onboarding_incomplete_d1', template: 'onboarding_incomplete', company, store, recipient });
      if (store && ageHours >= 24 && !productStores.has(store.id)) candidates.push({ key: 'first_product_d1', template: 'first_product_reminder', company, store, recipient });
      if (store && productStores.has(store.id) && storeSettings?.onboarding_completed !== true && ageHours >= 48) candidates.push({ key: 'publish_menu_d2', template: 'publish_menu_reminder', company, store, recipient });
      const storeOrders = store ? (ordersByStore.get(store.id) || []) : [];
      if (storeSettings?.onboarding_completed === true && !storeOrders.length && ageHours >= 72) candidates.push({ key: 'first_order_d3', template: 'first_order_reminder', company, store, recipient });
      const lastOrderAt = storeOrders[0]?.created_at ? new Date(storeOrders[0].created_at).getTime() : 0;
      if (storeOrders.length && lastOrderAt < now - (7 * 864e5)) candidates.push({ key: `inactive_store:${new Date().toISOString().slice(0, 7)}`, template: 'inactive_store_checkin', company, store, recipient });
    }
    for (const subscription of subscriptions) {
      if (!subscription.trial_ends_at) continue;
      const days = Math.ceil((new Date(subscription.trial_ends_at).getTime() - now) / 864e5);
      if (![5, 2].includes(days)) continue;
      const company = companies.find((item) => item.id === subscription.company_id);
      if (!company) continue;
      const recipient = cleanEmail(company.billing_email || adminByCompany.get(company.id)?.email || '');
      if (recipient) candidates.push({ key: `trial_ending_d${days}`, template: 'trial_ending', company, store: storeByCompany.get(company.id), recipient, due: String(days), subscription });
    }
    for (const candidate of candidates) {
      const idempotencyKey = `${candidate.key}:${candidate.company.id}`;
      const exists = await dbRequest('GET', 'marketing_automation_runs', { select: 'id', idempotency_key: `eq.${idempotencyKey}`, limit: '1' });
      if (exists[0]) continue;
      const recentContact = await dbRequest('GET', 'marketing_automation_runs', { select: 'id', company_id: `eq.${candidate.company.id}`, status: 'eq.sent', executed_at: `gte.${new Date(now - (48 * 36e5)).toISOString()}`, limit: '1' });
      if (recentContact[0]) continue;
      const [run] = await dbRequest('POST', 'marketing_automation_runs', {}, { automation_key: candidate.key, company_id: candidate.company.id, idempotency_key: idempotencyKey, recipient: candidate.recipient, status: 'pending', details: { template: candidate.template } }, ['Prefer: return=representation']);
      try {
        await sendPlatformTemplateEmail({
          to: candidate.recipient,
          templateKey: candidate.template,
          requireActive: true,
          variables: {
            company_name: candidate.company.name,
            customer_name: adminByCompany.get(candidate.company.id)?.name || candidate.company.name,
            store_name: candidate.store?.name || candidate.company.name,
            plan_name: planById.get(candidate.subscription?.plan_id)?.name || 'Teste grátis',
            due_date: candidate.subscription?.trial_ends_at ? new Intl.DateTimeFormat('pt-BR').format(new Date(candidate.subscription.trial_ends_at)) : '',
            dashboard_url: absolutePanelUrl('/'),
            payment_url: absolutePanelUrl('/?tab=plans'),
            support_url: absolutePanelUrl('/?tab=support'),
            cardapio_url: candidate.store?.slug ? absolutePublicUrl(`/${candidate.store.slug}`) : absolutePublicUrl('/')
          }
        });
        await dbRequest('PATCH', 'marketing_automation_runs', { id: `eq.${run.id}` }, { status: 'sent', executed_at: new Date().toISOString() });
      } catch (error) {
        await dbRequest('PATCH', 'marketing_automation_runs', { id: `eq.${run.id}` }, { status: 'failed', executed_at: new Date().toISOString(), details: { template: candidate.template, error: String(error.message || error).slice(0, 500) } });
      }
    }
  } catch (error) {
    console.error(JSON.stringify({ scope: 'marketing-lifecycle', message: error.message }));
  }
}

const MARKETING_ITEM_CONFIG = {
  campaigns: {
    table: 'marketing_campaigns',
    statuses: ['draft', 'active', 'paused', 'completed'],
    fields: ['name', 'objective', 'niche', 'status', 'source', 'medium', 'campaign_code', 'landing_url', 'starts_at', 'ends_at', 'budget_cents']
  },
  leads: {
    table: 'marketing_leads',
    statuses: ['new', 'contacted', 'qualified', 'trial', 'customer', 'lost'],
    fields: ['business_name', 'contact_name', 'phone', 'email', 'niche', 'city', 'state', 'origin', 'stage', 'campaign_id', 'consent', 'next_contact_at', 'last_contact_at', 'contact_attempts', 'loss_reason', 'notes', 'next_action', 'cadence_step', 'cadence_started_at', 'closed_at', 'do_not_contact', 'contact_history']
  },
  content: {
    table: 'marketing_content_items',
    statuses: SOCIAL_CONTENT_STATUSES,
    fields: ['title', 'channel', 'format', 'pillar', 'funnel_stage', 'niche', 'objective', 'hook', 'script', 'caption', 'cta', 'overlay_text', 'voiceover', 'aspect_ratio', 'alt_text', 'location_name', 'timezone', 'social_account_id', 'assigned_to', 'status', 'scheduled_at', 'published_at', 'published_url', 'campaign_id', 'performance', 'scenes', 'hashtags', 'assets', 'utm_url', 'is_pinned', 'reach', 'views', 'retention_rate', 'saves', 'shares', 'clicks', 'signups', 'attributed_orders', 'attributed_revenue_cents']
  },
  experiments: {
    table: 'marketing_experiments',
    statuses: ['draft', 'running', 'paused', 'completed', 'cancelled'],
    fields: ['name', 'hypothesis', 'surface', 'audience', 'variant_a', 'variant_b', 'primary_kpi', 'baseline_value', 'target_value', 'guardrails', 'status', 'starts_at', 'ends_at', 'result_summary', 'decision', 'traffic_percentage', 'minimum_sample', 'winner']
  }
};

async function platformMarketingWorkspace() {
  const [campaigns, leads, content, automationRuns, events, experiments, assignments, pilots, weeklyReports, attributedCompanies] = await Promise.all([
    dbRequest('GET', 'marketing_campaigns', { select: '*', order: 'created_at.desc', limit: '100' }),
    dbRequest('GET', 'marketing_leads', { select: '*', order: 'updated_at.desc', limit: '250' }),
    dbRequest('GET', 'marketing_content_items', { select: '*', order: 'scheduled_at.asc.nullslast,created_at.desc', limit: '250' }),
    dbRequest('GET', 'marketing_automation_runs', { select: '*', order: 'created_at.desc', limit: '50' }),
    dbRequest('GET', 'marketing_events', { select: 'event_name,attribution,created_at', created_at: `gte.${new Date(Date.now() - (90 * 864e5)).toISOString()}`, order: 'created_at.desc', limit: '10000' }),
    dbRequest('GET', 'marketing_experiments', { select: '*', order: 'created_at.desc', limit: '100' }),
    dbRequest('GET', 'marketing_experiment_assignments', { select: 'experiment_id,variant,exposed_at,converted_at', limit: '10000' }),
    dbRequest('GET', 'marketing_pilot_stores', { select: '*', order: 'updated_at.desc', limit: '100' }),
    dbRequest('GET', 'marketing_weekly_reports', { select: '*', order: 'week_start.desc', limit: '12' }),
    dbRequest('GET', 'companies', { select: 'id,name,marketing_first_touch,marketing_last_touch,created_at', order: 'created_at.desc', limit: '250' })
  ]);
  const leadStages = Object.fromEntries(MARKETING_ITEM_CONFIG.leads.statuses.map((stage) => [stage, leads.filter((lead) => lead.stage === stage).length]));
  const contentStatuses = Object.fromEntries(MARKETING_ITEM_CONFIG.content.statuses.map((status) => [status, content.filter((item) => item.status === status).length]));
  const eventNames = ['landing_view', 'demo_started', 'signup_started', 'signup_completed', 'first_product_created', 'menu_published', 'first_order_received', 'subscription_activated'];
  const funnel = Object.fromEntries(eventNames.map((name) => [name, events.filter((event) => event.event_name === name).length]));
  const campaignMetrics = Object.fromEntries(campaigns.map((campaign) => {
    const attributed = events.filter((event) => cleanText(event.attribution?.utm_campaign || '') === campaign.campaign_code);
    return [campaign.id, Object.fromEntries(eventNames.map((name) => [name, attributed.filter((event) => event.event_name === name).length]))];
  }));
  const experimentMetrics = Object.fromEntries(experiments.map((experiment) => {
    const rows = assignments.filter((item) => item.experiment_id === experiment.id);
    const summarize = (variant) => {
      const variantRows = rows.filter((item) => item.variant === variant);
      const conversions = variantRows.filter((item) => item.converted_at).length;
      return { assigned: variantRows.length, exposed: variantRows.filter((item) => item.exposed_at).length, conversions, conversion_rate: variantRows.length ? Number(((conversions / variantRows.length) * 100).toFixed(2)) : 0 };
    };
    return [experiment.id, { a: summarize('a'), b: summarize('b') }];
  }));
  return {
    summary: {
      active_campaigns: campaigns.filter((item) => item.status === 'active').length,
      open_leads: leads.filter((item) => !['customer', 'lost'].includes(item.stage)).length,
      scheduled_content: content.filter((item) => item.status === 'scheduled').length,
      overdue_contacts: leads.filter((item) => item.next_contact_at && new Date(item.next_contact_at) < new Date() && !['customer', 'lost'].includes(item.stage)).length,
      running_experiments: experiments.filter((item) => item.status === 'running').length,
      lead_stages: leadStages,
      content_statuses: contentStatuses
    },
    funnel,
    campaign_metrics: campaignMetrics,
    campaigns,
    leads,
    content,
    experiments,
    experiment_metrics: experimentMetrics,
    pilots,
    weekly_reports: weeklyReports,
    attribution_journeys: attributedCompanies,
    automation_runs: automationRuns,
    content_intelligence: { audits: Object.fromEntries(content.map((item) => [item.id, auditMarketingContent(item, content.slice(0, 30))])), fatigue: contentFatigue(content) },
    safeguards: {
      consent_required: true,
      editorial_approval_required: true,
      duplicate_prevention: 'idempotency_key',
      automatic_social_publishing: false
    }
  };
}

function marketingPayload(kind, data = {}, partial = false) {
  const config = MARKETING_ITEM_CONFIG[kind];
  if (!config) throw httpError(404, 'Recurso de marketing inválido.');
  const payload = {};
  for (const field of config.fields) {
    if (!(field in data)) continue;
    if (['consent', 'do_not_contact', 'is_pinned'].includes(field)) payload[field] = data[field] === true;
    else if (['budget_cents', 'contact_attempts', 'cadence_step', 'reach', 'views', 'saves', 'shares', 'clicks', 'signups', 'attributed_orders', 'attributed_revenue_cents', 'traffic_percentage', 'minimum_sample'].includes(field)) payload[field] = Math.max(0, Number.parseInt(data[field], 10) || 0);
    else if (['baseline_value', 'target_value'].includes(field)) payload[field] = data[field] === '' || data[field] == null ? null : Number(data[field]);
    else if (field === 'retention_rate') payload[field] = Math.min(100, Math.max(0, Number(data[field]) || 0));
    else if (['performance', 'scenes', 'assets', 'contact_history'].includes(field)) payload[field] = data[field] && (typeof data[field] === 'object') ? data[field] : (field === 'performance' ? {} : []);
    else if (field === 'hashtags') payload[field] = Array.isArray(data[field]) ? data[field].map((item) => cleanText(item).slice(0, 80)).filter(Boolean).slice(0, 20) : cleanText(data[field]).split(/[ ,]+/).filter(Boolean).slice(0, 20);
    else if (['starts_at', 'ends_at', 'next_contact_at', 'last_contact_at', 'cadence_started_at', 'closed_at', 'scheduled_at', 'published_at', 'campaign_id', 'social_account_id', 'assigned_to'].includes(field)) payload[field] = data[field] || null;
    else payload[field] = cleanText(data[field] || '').slice(0, ['script', 'caption', 'notes'].includes(field) ? 8000 : 500);
  }
  const statusField = kind === 'leads' ? 'stage' : 'status';
  if (payload[statusField] && !config.statuses.includes(payload[statusField])) throw httpError(422, 'Status de marketing inválido.');
  if (kind === 'experiments' && payload.decision && !['keep', 'iterate', 'stop'].includes(payload.decision)) throw httpError(422, 'Decisão de experimento inválida.');
  const required = kind === 'campaigns' ? ['name'] : kind === 'leads' ? ['business_name'] : kind === 'experiments' ? ['name', 'hypothesis', 'primary_kpi'] : ['title'];
  if (!partial && required.some((field) => !payload[field])) throw httpError(422, 'Preencha os campos obrigatórios.');
  if (!partial && kind === 'leads' && !payload.phone && !payload.email) throw httpError(422, 'Informe telefone ou e-mail do lead.');
  if (kind === 'campaigns' && !payload.campaign_code && payload.name) payload.campaign_code = payload.name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 80);
  payload.updated_at = new Date().toISOString();
  return payload;
}

async function createPlatformMarketingCampaign(req, admin, data) {
  const payload = { ...marketingPayload('campaigns', data), created_by: admin.id };
  const [row] = await dbRequest('POST', 'marketing_campaigns', {}, payload, ['Prefer: return=representation']);
  await audit('platform.marketing.campaign.create', { req, actor_admin_id: admin.id, entity_type: 'marketing_campaign', entity_id: row.id, after_data: row });
  return row;
}

async function createPlatformMarketingLead(req, admin, data) {
  const payload = { ...marketingPayload('leads', data), created_by: admin.id };
  if (payload.consent && !payload.next_contact_at) {
    payload.cadence_started_at = new Date().toISOString();
    payload.next_contact_at = new Date().toISOString();
    payload.next_action = payload.next_action || 'Primeiro contato personalizado (D0)';
  }
  const [row] = await dbRequest('POST', 'marketing_leads', {}, payload, ['Prefer: return=representation']);
  await audit('platform.marketing.lead.create', { req, actor_admin_id: admin.id, entity_type: 'marketing_lead', entity_id: row.id, after_data: { ...row, phone: row.phone ? '***' : null, email: row.email ? '***' : null } });
  return row;
}

async function createPlatformMarketingContent(req, admin, data) {
  const payload = { ...marketingPayload('content', data), created_by: admin.id };
  const [row] = await dbRequest('POST', 'marketing_content_items', {}, payload, ['Prefer: return=representation']);
  await audit('platform.marketing.content.create', { req, actor_admin_id: admin.id, entity_type: 'marketing_content', entity_id: row.id, after_data: { title: row.title, status: row.status } });
  return row;
}

async function createPlatformMarketingExperiment(req, admin, data) {
  const payload = { ...marketingPayload('experiments', data), created_by: admin.id, updated_by: admin.id };
  const [row] = await dbRequest('POST', 'marketing_experiments', {}, payload, ['Prefer: return=representation']);
  await audit('platform.marketing.experiment.create', { req, actor_admin_id: admin.id, entity_type: 'marketing_experiment', entity_id: row.id, after_data: { name: row.name, hypothesis: row.hypothesis, primary_kpi: row.primary_kpi } });
  return row;
}

async function updatePlatformMarketingItem(req, admin, kind, id, data) {
  const config = MARKETING_ITEM_CONFIG[kind];
  const payload = marketingPayload(kind, data, true);
  const currentContent = kind === 'content' ? (await dbRequest('GET', config.table, { select: '*', id: `eq.${id}`, limit: '1' }))[0] : null;
  if (kind === 'content' && !currentContent) throw httpError(404, 'Item de marketing não encontrado.');
  if (kind === 'content' && currentContent.channel === 'instagram' && 'status' in payload) {
    delete payload.status;
    throw httpError(409, 'Use o fluxo editorial de Canais sociais para alterar o status e preservar a aprovação.');
  }
  if (kind === 'leads' && payload.stage === 'contacted') {
    const [current] = await dbRequest('GET', 'marketing_leads', { select: '*', id: `eq.${id}`, limit: '1' });
    if (current && current.consent && !current.do_not_contact) {
      const cadenceDays = [0, 2, 5, 9, 14];
      const nextStep = Math.min(Number(current.cadence_step || 0) + 1, cadenceDays.length);
      payload.last_contact_at = new Date().toISOString();
      payload.contact_attempts = Number(current.contact_attempts || 0) + 1;
      payload.cadence_step = Math.min(nextStep, cadenceDays.length - 1);
      payload.contact_history = [...(Array.isArray(current.contact_history) ? current.contact_history : []), { at: payload.last_contact_at, action: current.next_action || 'Contato', outcome: 'contacted' }].slice(-100);
      if (nextStep >= cadenceDays.length) {
        payload.stage = 'lost';
        payload.closed_at = payload.last_contact_at;
        payload.loss_reason = 'Cadência concluída sem retorno';
        payload.next_contact_at = null;
        payload.next_action = 'Encerrado respeitosamente após D14';
      } else {
        const base = new Date(current.cadence_started_at || current.created_at || Date.now());
        base.setUTCDate(base.getUTCDate() + cadenceDays[nextStep]);
        payload.next_contact_at = base.toISOString();
        payload.next_action = `Contato personalizado D${cadenceDays[nextStep]}`;
      }
    }
  }
  if (kind === 'experiments') payload.updated_by = admin.id;
  if (kind === 'content' && currentContent.channel === 'instagram') {
    const protectedFields = ['caption', 'cta', 'scheduled_at', 'social_account_id', 'format', 'alt_text', 'location_name'];
    if (protectedFields.some((field) => field in payload && JSON.stringify(payload[field]) !== JSON.stringify(currentContent[field]))) {
      Object.assign(payload, invalidateSocialApprovalPatch(currentContent, admin.id));
    }
  }
  if (kind === 'content' && currentContent.channel !== 'instagram' && ['approved', 'scheduled', 'published'].includes(payload.status)) payload.approved_by = admin.id;
  const [row] = await dbRequest('PATCH', config.table, { id: `eq.${id}` }, payload, ['Prefer: return=representation']);
  if (!row) throw httpError(404, 'Item de marketing não encontrado.');
  await audit(`platform.marketing.${kind}.update`, { req, actor_admin_id: admin.id, entity_type: `marketing_${kind}`, entity_id: id, after_data: { status: row.status || row.stage } });
  return row;
}

async function importPlatformMarketingLeads(req, admin, data = {}) {
  const rows = Array.isArray(data.rows) ? data.rows.slice(0, 1000) : [];
  if (!rows.length) throw httpError(422, 'Envie ao menos uma linha válida do CSV.');
  let imported = 0;
  let skipped = 0;
  for (const source of rows) {
    try {
      const candidate = marketingPayload('leads', { ...source, origin: source.origin || 'csv' });
      const duplicateFilters = candidate.email ? { email: `eq.${candidate.email}` } : { phone: `eq.${candidate.phone}` };
      const existing = await dbRequest('GET', 'marketing_leads', { select: 'id', ...duplicateFilters, limit: '1' });
      if (existing[0]) { skipped += 1; continue; }
      await dbRequest('POST', 'marketing_leads', {}, { ...candidate, created_by: admin.id }, ['Prefer: return=minimal']);
      imported += 1;
    } catch { skipped += 1; }
  }
  await audit('platform.marketing.leads.import', { req, actor_admin_id: admin.id, entity_type: 'marketing_lead', after_data: { imported, skipped } });
  return { imported, skipped };
}

function sanitizePilotPayload(data = {}, partial = false) {
  const payload = {};
  const textFields = ['business_name', 'niche', 'contact_name', 'status', 'authorization_notes', 'interview_notes', 'case_study'];
  for (const field of textFields) if (field in data) payload[field] = cleanText(data[field]).slice(0, ['interview_notes', 'case_study'].includes(field) ? 12000 : 1000);
  for (const field of ['company_id', 'store_id']) if (field in data) payload[field] = cleanUuid(data[field]) || null;
  for (const field of ['image_authorized', 'testimonial_authorized']) if (field in data) payload[field] = data[field] === true;
  for (const field of ['baseline', 'milestones']) if (field in data) payload[field] = data[field] && typeof data[field] === 'object' ? data[field] : (field === 'baseline' ? {} : []);
  const statuses = ['candidate', 'invited', 'active', 'interview', 'case_draft', 'approved', 'published', 'declined'];
  if (payload.status && !statuses.includes(payload.status)) throw httpError(422, 'Status de piloto inválido.');
  if (!partial && !payload.business_name) throw httpError(422, 'Informe o estabelecimento piloto.');
  payload.updated_at = new Date().toISOString();
  return payload;
}

async function createPlatformMarketingPilot(req, admin, data = {}) {
  const [row] = await dbRequest('POST', 'marketing_pilot_stores', {}, { ...sanitizePilotPayload(data), created_by: admin.id }, ['Prefer: return=representation']);
  await audit('platform.marketing.pilot.create', { req, actor_admin_id: admin.id, entity_type: 'marketing_pilot', entity_id: row.id, after_data: { business_name: row.business_name, status: row.status } });
  return row;
}

async function updatePlatformMarketingPilot(req, admin, id, data = {}) {
  const [row] = await dbRequest('PATCH', 'marketing_pilot_stores', { id: `eq.${id}` }, sanitizePilotPayload(data, true), ['Prefer: return=representation']);
  if (!row) throw httpError(404, 'Loja piloto não encontrada.');
  await audit('platform.marketing.pilot.update', { req, actor_admin_id: admin.id, entity_type: 'marketing_pilot', entity_id: id, after_data: { status: row.status } });
  return row;
}

function startOfMarketingWeek(value = new Date()) {
  const date = new Date(value);
  const day = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() - day + 1);
  return date.toISOString().slice(0, 10);
}

async function buildMarketingWeeklyReport() {
  const workspace = await platformMarketingWorkspace();
  const weekStart = startOfMarketingWeek();
  const events = await dbRequest('GET', 'marketing_events', { select: 'event_name,attribution,created_at', created_at: `gte.${new Date(Date.now() - 14 * 864e5).toISOString()}`, limit: '10000' });
  const midpoint = Date.now() - 7 * 864e5;
  const current = events.filter((item) => new Date(item.created_at).getTime() >= midpoint);
  const previous = events.filter((item) => new Date(item.created_at).getTime() < midpoint);
  const eventDelta = (name) => {
    const now = current.filter((item) => item.event_name === name).length;
    const before = previous.filter((item) => item.event_name === name).length;
    return { current: now, previous: before, variation_percent: before ? Math.round(((now - before) / before) * 100) : (now ? 100 : 0) };
  };
  const content = workspace.content.filter((item) => item.status === 'published' && item.published_at && new Date(item.published_at).getTime() >= midpoint);
  const failed = workspace.automation_runs.filter((item) => item.status === 'failed');
  const overdue = workspace.leads.filter((item) => item.next_contact_at && new Date(item.next_contact_at) < new Date() && !item.do_not_contact && !['customer', 'lost'].includes(item.stage));
  const recommendations = [];
  const signup = eventDelta('signup_completed');
  if (signup.variation_percent >= 10) recommendations.push({ decision: 'keep', reason: `Cadastros cresceram ${signup.variation_percent}% na comparação semanal.` });
  else if (signup.variation_percent <= -10) recommendations.push({ decision: 'iterate', reason: `Cadastros caíram ${Math.abs(signup.variation_percent)}%; revisar origem, mensagem e página.` });
  else recommendations.push({ decision: 'keep', reason: 'Funil estável; manter coleta até formar amostra maior.' });
  if (failed.length) recommendations.push({ decision: 'iterate', reason: `${failed.length} automação(ões) com falha precisam de revisão.` });
  const summary = { funnel: { landing_view: eventDelta('landing_view'), signup_completed: signup, subscription_activated: eventDelta('subscription_activated') }, overdue_leads: overdue.length, published_content: content.length, failed_automations: failed.length, active_campaigns: workspace.summary.active_campaigns, running_experiments: workspace.summary.running_experiments };
  return { weekStart, summary, recommendations };
}

async function generatePlatformMarketingWeeklyReport(req = null, admin = null) {
  const built = await buildMarketingWeeklyReport();
  const existing = await dbRequest('GET', 'marketing_weekly_reports', { select: 'id', week_start: `eq.${built.weekStart}`, limit: '1' });
  const rows = existing[0]
    ? await dbRequest('PATCH', 'marketing_weekly_reports', { id: `eq.${existing[0].id}` }, { summary: built.summary, recommendations: built.recommendations, generated_at: new Date().toISOString() }, ['Prefer: return=representation'])
    : await dbRequest('POST', 'marketing_weekly_reports', {}, { week_start: built.weekStart, summary: built.summary, recommendations: built.recommendations }, ['Prefer: return=representation']);
  if (admin) await audit('platform.marketing.weekly_report.generate', { req, actor_admin_id: admin.id, entity_type: 'marketing_weekly_report', entity_id: rows[0]?.id });
  return rows[0];
}

async function runMarketingWeeklyReportAutomation() {
  try {
    const now = new Date();
    if (now.getDay() !== 1) return;
    const report = await generatePlatformMarketingWeeklyReport();
    if (report.sent_at) return;
    const summary = report.summary || {};
    const body = [
      `Relatório semanal de marketing — semana de ${report.week_start}`,
      `Visitas: ${summary.funnel?.landing_view?.current || 0} (${summary.funnel?.landing_view?.variation_percent || 0}%)`,
      `Cadastros: ${summary.funnel?.signup_completed?.current || 0} (${summary.funnel?.signup_completed?.variation_percent || 0}%)`,
      `Assinaturas: ${summary.funnel?.subscription_activated?.current || 0}`,
      `Leads atrasados: ${summary.overdue_leads || 0}`,
      `Conteúdos publicados: ${summary.published_content || 0}`,
      `Automações com falha: ${summary.failed_automations || 0}`,
      '',
      ...(report.recommendations || []).map((item) => `${String(item.decision || '').toUpperCase()}: ${item.reason}`),
      '',
      `${platformBaseUrl()}/`
    ].join('\n');
    await sendPlatformEmail({ to: process.env.MARKETING_REPORT_EMAIL || 'sup.tapronto@gmail.com', subject: `TáPronto — relatório semanal ${report.week_start}`, body, templateKey: 'marketing_weekly_report' });
    await dbRequest('PATCH', 'marketing_weekly_reports', { id: `eq.${report.id}` }, { sent_at: new Date().toISOString() }, ['Prefer: return=minimal']);
  } catch (error) {
    console.error(JSON.stringify({ scope: 'marketing-weekly-report', message: error.message }));
  }
}

async function platformSocialWorkspace() {
  const config = socialConfig();
  const [accounts, content, assets, links, publications, attempts, metricSnapshots, alerts, workers] = await Promise.all([
    dbRequest('GET', 'social_accounts', { select: 'id,provider,mode,provider_account_id,username,display_name,profile_picture_url,account_type,scopes,token_expires_at,status,publishing_paused,last_tested_at,last_sync_at,last_error,created_at,updated_at', order: 'created_at.desc', limit: '20' }),
    dbRequest('GET', 'marketing_content_items', { select: '*', channel: 'eq.instagram', order: 'scheduled_at.asc.nullslast,created_at.desc', limit: '250' }),
    dbRequest('GET', 'social_media_assets', { select: '*', processing_status: 'neq.deleted', order: 'created_at.desc', limit: '500' }),
    dbRequest('GET', 'social_content_assets', { select: '*', order: 'sort_order.asc', limit: '2000' }),
    dbRequest('GET', 'social_publications', { select: '*', order: 'created_at.desc', limit: '250' }),
    dbRequest('GET', 'social_publication_attempts', { select: '*', order: 'created_at.desc', limit: '250' }),
    dbRequest('GET', 'social_metric_snapshots', { select: '*', order: 'captured_at.desc', limit: '500' }),
    dbRequest('GET', 'social_alerts', { select: '*', status: 'eq.open', order: 'created_at.desc', limit: '100' }),
    dbRequest('GET', 'social_worker_state', { select: '*', limit: '10' })
  ]);
  const assetsById = new Map(assets.map((item) => [item.id, item]));
  const contentAssets = Object.fromEntries(content.map((item) => [item.id, links.filter((link) => link.content_id === item.id).map((link) => ({ ...assetsById.get(link.asset_id), sort_order: link.sort_order, role: link.role })).filter((asset) => asset.id)]));
  const publicationMetrics = Object.fromEntries(publications.map((item) => [item.id, metricSnapshots.filter((metric) => metric.publication_id === item.id)]));
  return {
    config: { ...socialConfigStatus(config), graph_version: config.graphVersion, worker_interval_seconds: config.workerIntervalSeconds, metrics_interval_hours: config.metricsIntervalHours, token_alert_days: config.tokenAlertDays, max_retries: config.maxRetries },
    accounts, content, assets, content_assets: contentAssets, publications,
    attempts, metrics: publicationMetrics, alerts, worker: workers.find((item) => item.worker_key === 'instagram-publisher') || null,
    summary: {
      awaiting_approval: content.filter((item) => item.status === 'review').length,
      scheduled: content.filter((item) => item.status === 'scheduled').length,
      processing: publications.filter((item) => ['claimed', 'container_created', 'processing', 'retry'].includes(item.status)).length,
      failed: publications.filter((item) => item.status === 'failed').length,
      published_24h: publications.filter((item) => ['published', 'simulated'].includes(item.status) && item.published_at && new Date(item.published_at) > new Date(Date.now() - 864e5)).length
    }
  };
}

async function beginPlatformSocialConnection(req, admin) {
  const config = socialConfig();
  if (config.simulation) {
    const existing = await dbRequest('GET', 'social_accounts', { select: '*', provider_account_id: 'eq.simulation-tapronto', limit: '1' });
    const payload = { provider: 'instagram', mode: 'simulation', provider_account_id: 'simulation-tapronto', username: 'tapronto_simulacao', display_name: 'TáPronto · Simulação', account_type: 'BUSINESS', scopes: ['simulation'], status: 'connected', publishing_paused: false, connected_by: admin.id, updated_at: new Date().toISOString() };
    const rows = existing[0] ? await dbRequest('PATCH', 'social_accounts', { id: `eq.${existing[0].id}` }, payload, ['Prefer: return=representation']) : await dbRequest('POST', 'social_accounts', {}, payload, ['Prefer: return=representation']);
    await audit('platform.social.account.connect_simulation', { req, actor_admin_id: admin.id, entity_type: 'social_account', entity_id: rows[0].id });
    return { mode: 'simulation', connected: true, account: sanitizeSocialAccount(rows[0]) };
  }
  const status = socialConfigStatus(config);
  if (!status.oauthReady) throw httpError(503, 'Configure META_APP_ID, META_APP_SECRET, META_REDIRECT_URI e SOCIAL_TOKEN_ENCRYPTION_KEY.');
  const state = createOAuthState();
  await dbRequest('POST', 'social_oauth_states', {}, { state_hash: state.hash, provider: 'instagram', admin_id: admin.id, redirect_uri: config.redirectUri, expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString() }, ['Prefer: return=minimal']);
  await audit('platform.social.oauth.begin', { req, actor_admin_id: admin.id, entity_type: 'social_oauth_state' });
  return { mode: 'live', authorization_url: instagramAuthorizationUrl(state.state, config) };
}

async function completePlatformSocialConnection(req, admin, params) {
  const state = cleanText(params.get('state') || '');
  const code = cleanText(params.get('code') || '');
  if (!state || !code) throw httpError(422, 'Callback OAuth incompleto.');
  const stateHash = hashText(state);
  const rows = await dbRequest('GET', 'social_oauth_states', { select: '*', state_hash: `eq.${stateHash}`, admin_id: `eq.${admin.id}`, used_at: 'is.null', limit: '1' });
  const saved = rows[0];
  if (!saved || new Date(saved.expires_at) <= new Date()) throw httpError(401, 'Estado OAuth inválido ou expirado.');
  await dbRequest('PATCH', 'social_oauth_states', { id: `eq.${saved.id}`, used_at: 'is.null' }, { used_at: new Date().toISOString() }, ['Prefer: return=minimal']);
  const config = socialConfig();
  const connected = await exchangeInstagramCode(code, config);
  const expiresAt = connected.expiresIn ? new Date(Date.now() + connected.expiresIn * 1000).toISOString() : null;
  const payload = { provider: 'instagram', mode: 'live', provider_account_id: String(connected.profile.id), username: cleanText(connected.profile.username || ''), display_name: cleanText(connected.profile.name || ''), profile_picture_url: cleanText(connected.profile.profile_picture_url || ''), account_type: cleanText(connected.profile.account_type || 'BUSINESS'), access_token_encrypted: encryptSocialSecret(connected.token, config), refresh_token_encrypted: encryptSocialSecret(connected.refreshToken || '', config), scopes: connected.scopes, token_expires_at: expiresAt, status: 'connected', publishing_paused: true, connected_by: admin.id, updated_at: new Date().toISOString() };
  const existing = await dbRequest('GET', 'social_accounts', { select: 'id', provider_account_id: `eq.${payload.provider_account_id}`, provider: 'eq.instagram', limit: '1' });
  const account = existing[0] ? (await dbRequest('PATCH', 'social_accounts', { id: `eq.${existing[0].id}` }, payload, ['Prefer: return=representation']))[0] : (await dbRequest('POST', 'social_accounts', {}, payload, ['Prefer: return=representation']))[0];
  await audit('platform.social.oauth.complete', { req, actor_admin_id: admin.id, entity_type: 'social_account', entity_id: account.id, after_data: { username: account.username, mode: account.mode, scopes: account.scopes } });
  return sanitizeSocialAccount(account);
}

async function platformSocialAccountAction(req, admin, id, action, data = {}) {
  const rows = await dbRequest('GET', 'social_accounts', { select: '*', id: `eq.${id}`, limit: '1' });
  const account = rows[0];
  if (!account) throw httpError(404, 'Conta social não encontrada.');
  let payload = {};
  if (action === 'disconnect') {
    payload = { status: 'disconnected', publishing_paused: true, access_token_encrypted: '', refresh_token_encrypted: '', updated_at: new Date().toISOString() };
  } else if (action === 'pause') payload = { publishing_paused: true, updated_at: new Date().toISOString() };
  else if (action === 'resume') {
    await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
    if (account.mode === 'live' && !socialConfigStatus().liveReady) throw httpError(503, 'Ambiente ainda não está liberado para publicação real.');
    payload = { publishing_paused: false, updated_at: new Date().toISOString() };
  } else if (action === 'test') {
    if (account.mode === 'live') {
      const result = await metaRequest(`/${account.provider_account_id}?fields=id,username,account_type`, decryptSocialSecret(account.access_token_encrypted), {}, socialConfig());
      payload = { status: 'connected', username: cleanText(result.username || account.username), account_type: cleanText(result.account_type || account.account_type), last_tested_at: new Date().toISOString(), last_error: '', updated_at: new Date().toISOString() };
    } else payload = { status: 'connected', last_tested_at: new Date().toISOString(), last_error: '', updated_at: new Date().toISOString() };
  }
  const updated = (await dbRequest('PATCH', 'social_accounts', { id: `eq.${id}` }, payload, ['Prefer: return=representation']))[0];
  await audit(`platform.social.account.${action}`, { req, actor_admin_id: admin.id, entity_type: 'social_account', entity_id: id, after_data: { status: updated.status, publishing_paused: updated.publishing_paused } });
  return { account: sanitizeSocialAccount(updated) };
}

function sanitizeSocialAccount(account = {}) {
  const { access_token_encrypted, refresh_token_encrypted, ...safe } = account;
  return { ...safe, has_token: Boolean(access_token_encrypted), has_refresh_token: Boolean(refresh_token_encrypted) };
}

async function uploadPlatformSocialAsset(req, admin, data = {}) {
  const fileName = cleanFileName(data.file_name || data.fileName || 'social-media');
  const contentType = cleanText(data.content_type || data.contentType || '').split(';')[0].toLowerCase();
  const base64 = String(data.data_base64 || data.dataBase64 || '').replace(/^data:[^;]+;base64,/, '');
  if (!allowedSocialUploadTypes.has(contentType) || !base64) throw httpError(422, 'Envie JPG, PNG, WebP ou MP4.');
  const buffer = Buffer.from(base64, 'base64');
  const isVideo = contentType === 'video/mp4';
  const maxBytes = isVideo ? 7 * 1024 * 1024 : 5 * 1024 * 1024;
  if (!buffer.length || buffer.length > maxBytes) throw httpError(422, `Arquivo excede o limite de ${Math.floor(maxBytes / 1024 / 1024)} MB desta interface.`);
  if (isVideo ? !isMp4Buffer(buffer) : detectImageContentType(buffer) !== contentType) throw httpError(422, 'O conteúdo real não corresponde ao tipo informado.');
  const checksum = createHash('sha256').update(buffer).digest('hex');
  const duplicate = await dbRequest('GET', 'social_media_assets', { select: '*', checksum_sha256: `eq.${checksum}`, processing_status: 'neq.deleted', limit: '1' });
  if (duplicate[0]) return duplicate[0];
  const extension = isVideo ? '.mp4' : path.extname(fileName).toLowerCase() || ({ 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' })[contentType];
  const objectPath = `social/${new Date().toISOString().slice(0, 10)}/${Date.now()}-${randomBytes(8).toString('hex')}${extension}`;
  const fullPath = path.resolve(UPLOAD_DIR, objectPath);
  if (!fullPath.startsWith(`${UPLOAD_DIR}${path.sep}`)) throw httpError(400, 'Caminho de mídia inválido.');
  await mkdir(path.dirname(fullPath), { recursive: true }); await writeFile(fullPath, buffer, { flag: 'wx' });
  const dimensions = isVideo ? { width: Number(data.width) || null, height: Number(data.height) || null } : imageDimensions(buffer, contentType);
  const relativeUrl = `/uploads/${objectPath.replaceAll(path.sep, '/')}`;
  const publicUrl = absolutePublicUrl(relativeUrl);
  assertSafeMediaUrl(publicUrl, socialConfig());
  const [asset] = await dbRequest('POST', 'social_media_assets', {}, { provider: 'instagram', kind: isVideo ? 'video' : 'image', file_name: fileName, storage_path: objectPath, public_url: publicUrl, content_type: contentType, size_bytes: buffer.length, width: dimensions.width, height: dimensions.height, duration_seconds: isVideo ? Number(data.duration_seconds || 0) || null : null, aspect_ratio: dimensions.width && dimensions.height ? `${dimensions.width}:${dimensions.height}` : '', checksum_sha256: checksum, processing_status: 'ready', validation_details: { signature_valid: true, uploaded_via: 'platform' }, created_by: admin.id }, ['Prefer: return=representation']);
  await audit('platform.social.asset.upload', { req, actor_admin_id: admin.id, entity_type: 'social_media_asset', entity_id: asset.id, after_data: { kind: asset.kind, size_bytes: asset.size_bytes, checksum: checksum.slice(0, 12) } });
  return asset;
}

async function attachPlatformSocialAsset(req, admin, contentId, data = {}) {
  const assetId = cleanUuid(data.asset_id);
  const [contentRows, assetRows] = await Promise.all([dbRequest('GET', 'marketing_content_items', { select: '*', id: `eq.${contentId}`, channel: 'eq.instagram', limit: '1' }), dbRequest('GET', 'social_media_assets', { select: '*', id: `eq.${assetId}`, processing_status: 'eq.ready', limit: '1' })]);
  if (!contentRows[0] || !assetRows[0]) throw httpError(404, 'Conteúdo ou asset não encontrado.');
  await dbRequest('POST', 'social_content_assets', { on_conflict: 'content_id,asset_id' }, { content_id: contentId, asset_id: assetId, sort_order: clampInteger(data.sort_order, 0, 20), role: ['media', 'cover', 'thumbnail'].includes(data.role) ? data.role : 'media' }, ['Prefer: resolution=merge-duplicates,return=minimal']);
  if (['approved', 'scheduled'].includes(contentRows[0].status)) await invalidateSocialContentApproval(contentRows[0], admin.id, 'Asset alterado depois da aprovação.');
  await audit('platform.social.asset.attach', { req, actor_admin_id: admin.id, entity_type: 'marketing_content', entity_id: contentId, after_data: { asset_id: assetId } });
  return { ok: true };
}

async function socialContentContext(contentId) {
  const rows = await dbRequest('GET', 'marketing_content_items', { select: '*', id: `eq.${contentId}`, channel: 'eq.instagram', limit: '1' });
  const content = rows[0]; if (!content) throw httpError(404, 'Conteúdo social não encontrado.');
  const links = await dbRequest('GET', 'social_content_assets', { select: '*', content_id: `eq.${contentId}`, order: 'sort_order.asc' });
  const assetIds = links.map((item) => item.asset_id).filter(Boolean);
  const assets = assetIds.length ? await dbRequest('GET', 'social_media_assets', { select: '*', id: `in.(${assetIds.join(',')})` }) : [];
  const byId = new Map(assets.map((item) => [item.id, item]));
  const ordered = links.map((link) => ({ ...byId.get(link.asset_id), sort_order: link.sort_order, role: link.role })).filter((item) => item.id);
  const account = content.social_account_id ? (await dbRequest('GET', 'social_accounts', { select: '*', id: `eq.${content.social_account_id}`, limit: '1' }))[0] : null;
  return { content, assets: ordered, account };
}

async function transitionPlatformSocialContent(req, admin, contentId, data = {}) {
  const target = cleanText(data.status || '').toLowerCase();
  if (!SOCIAL_CONTENT_STATUSES.includes(target)) throw httpError(422, 'Status editorial inválido.');
  const context = await socialContentContext(contentId);
  assertTransition(context.content.status, target);
  const patch = { status: target, updated_at: new Date().toISOString(), revision_history: [...(Array.isArray(context.content.revision_history) ? context.content.revision_history : []), { at: new Date().toISOString(), from: context.content.status, to: target, admin_id: admin.id, note: cleanText(data.note || '').slice(0, 500) }].slice(-100) };
  if (data.scheduled_at) patch.scheduled_at = new Date(data.scheduled_at).toISOString();
  if (data.social_account_id) patch.social_account_id = cleanUuid(data.social_account_id);
  if (target === 'approved') {
    const refreshed = await socialContentContext(contentId);
    const account = patch.social_account_id ? (await dbRequest('GET', 'social_accounts', { select: '*', id: `eq.${patch.social_account_id}`, limit: '1' }))[0] : refreshed.account;
    const candidate = { ...refreshed.content, ...patch };
    const errors = validateContentForApproval(candidate, refreshed.assets, account);
    if (errors.length) throw httpError(422, 'Conteúdo ainda não pode ser aprovado.', { code: 'SOCIAL_APPROVAL_FAILED', errors });
    patch.approved_at = new Date().toISOString(); patch.approved_by = admin.id; patch.approved_caption = candidate.caption;
    patch.approved_assets_hash = assetsApprovalHash(refreshed.assets); patch.approved_version_hash = contentApprovalHash(candidate, refreshed.assets); patch.publication_error = '';
  }
  if (target === 'scheduled') {
    const candidate = { ...context.content, ...patch };
    if (!candidate.scheduled_at || new Date(candidate.scheduled_at) <= new Date()) throw httpError(422, 'Escolha uma data futura para agendar.');
    if (!candidate.social_account_id || !candidate.approved_version_hash) throw httpError(422, 'Aprove o conteúdo com conta e horário definidos antes de agendar.');
  }
  const [updated] = await dbRequest('PATCH', 'marketing_content_items', { id: `eq.${contentId}` }, patch, ['Prefer: return=representation']);
  let publication = null;
  if (target === 'scheduled') publication = await queueSocialPublication(updated, admin.id);
  await audit('platform.social.content.transition', { req, actor_admin_id: admin.id, entity_type: 'marketing_content', entity_id: contentId, before_data: { status: context.content.status }, after_data: { status: target, publication_id: publication?.id || null } });
  return { content: updated, publication };
}

async function queueSocialPublication(content, adminId) {
  const account = (await dbRequest('GET', 'social_accounts', { select: '*', id: `eq.${content.social_account_id}`, limit: '1' }))[0];
  if (!account) throw httpError(422, 'Conta social não encontrada.');
  const key = publicationIdempotencyKey(content, account);
  const existing = await dbRequest('GET', 'social_publications', { select: '*', idempotency_key: `eq.${key}`, limit: '1' });
  if (existing[0]) return existing[0];
  const [row] = await dbRequest('POST', 'social_publications', {}, { content_id: content.id, account_id: account.id, content_version: content.content_version, idempotency_key: key, approved_hash: content.approved_version_hash, mode: account.mode, status: 'queued', scheduled_at: content.scheduled_at, created_by: adminId }, ['Prefer: return=representation']);
  return row;
}

async function publishPlatformSocialContentNow(req, admin, contentId, data = {}) {
  await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  const context = await socialContentContext(contentId);
  if (!['approved', 'failed', 'simulated'].includes(context.content.status)) throw httpError(422, 'Somente conteúdo aprovado pode ser publicado agora.');
  const scheduledAt = new Date(Date.now() + 5000).toISOString();
  const next = { ...context.content, status: 'scheduled', scheduled_at: scheduledAt, content_version: Number(context.content.content_version || 1) + (context.content.status === 'simulated' ? 1 : 0), publication_error: '', updated_at: new Date().toISOString() };
  if (context.content.status === 'simulated') next.approved_version_hash = contentApprovalHash(next, context.assets);
  const [updated] = await dbRequest('PATCH', 'marketing_content_items', { id: `eq.${contentId}` }, next, ['Prefer: return=representation']);
  const publication = await queueSocialPublication(updated, admin.id);
  await audit('platform.social.content.publish_now', { req, actor_admin_id: admin.id, entity_type: 'marketing_content', entity_id: contentId, after_data: { publication_id: publication.id, mode: publication.mode } });
  return { content: updated, publication };
}

async function platformSocialPublicationAction(req, admin, id, action) {
  const publication = (await dbRequest('GET', 'social_publications', { select: '*', id: `eq.${id}`, limit: '1' }))[0];
  if (!publication) throw httpError(404, 'Publicação não encontrada.');
  if (action === 'cancel' && !['queued', 'retry', 'claimed'].includes(publication.status)) throw httpError(422, 'Esta publicação não pode mais ser cancelada com segurança.');
  if (action === 'retry' && publication.status !== 'failed') throw httpError(422, 'Somente falhas podem voltar para a fila.');
  const status = action === 'retry' ? 'retry' : 'cancelled';
  const [updated] = await dbRequest('PATCH', 'social_publications', { id: `eq.${id}` }, { status, next_attempt_at: action === 'retry' ? new Date().toISOString() : null, last_error: action === 'retry' ? '' : publication.last_error, updated_at: new Date().toISOString() }, ['Prefer: return=representation']);
  await dbRequest('PATCH', 'marketing_content_items', { id: `eq.${publication.content_id}` }, { status: action === 'retry' ? 'scheduled' : 'cancelled', updated_at: new Date().toISOString() }, ['Prefer: return=minimal']);
  await audit(`platform.social.publication.${action}`, { req, actor_admin_id: admin.id, entity_type: 'social_publication', entity_id: id });
  return { publication: updated };
}

async function invalidateSocialContentApproval(content, adminId, reason) {
  return dbRequest('PATCH', 'marketing_content_items', { id: `eq.${content.id}` }, invalidateSocialApprovalPatch(content, adminId, reason), ['Prefer: return=minimal']);
}

function invalidateSocialApprovalPatch(content, adminId = null, reason = 'Conteúdo alterado depois da aprovação.') {
  if (!['approved', 'scheduled'].includes(content.status)) return { content_version: Number(content.content_version || 1) + 1 };
  return { status: 'review', approved_at: null, approved_by: null, approved_version_hash: '', approved_caption: '', approved_assets_hash: '', content_version: Number(content.content_version || 1) + 1, revision_history: [...(Array.isArray(content.revision_history) ? content.revision_history : []), { at: new Date().toISOString(), from: content.status, to: 'review', admin_id: adminId, note: reason }].slice(-100), updated_at: new Date().toISOString() };
}

function isMp4Buffer(buffer) { return buffer.length > 12 && buffer.subarray(4, 12).toString('ascii').includes('ftyp'); }
function imageDimensions(buffer, contentType) {
  try {
    if (contentType === 'image/png' && buffer.length >= 24) return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
    if (contentType === 'image/jpeg') {
      let offset = 2;
      while (offset + 9 < buffer.length) { if (buffer[offset] !== 0xff) break; const marker = buffer[offset + 1]; const length = buffer.readUInt16BE(offset + 2); if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) return { height: buffer.readUInt16BE(offset + 5), width: buffer.readUInt16BE(offset + 7) }; offset += 2 + length; }
    }
  } catch {}
  return { width: null, height: null };
}

async function assignPublicMarketingExperiment(req, rawSurface = '') {
  const surface = cleanText(rawSurface).toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 50);
  if (!surface) return { assignment: null };
  const experiments = await dbRequest('GET', 'marketing_experiments', { select: '*', surface: `eq.${surface}`, status: 'eq.running', order: 'starts_at.asc.nullslast,created_at.asc', limit: '1' });
  const experiment = experiments[0];
  if (!experiment) return { assignment: null };
  const attribution = marketingAttributionFromRequest(req);
  const visitorKey = attribution.visitor_key || accessVisitorKey(req);
  const bucket = Number.parseInt(createHash('sha256').update(`${experiment.id}:${visitorKey}`).digest('hex').slice(0, 8), 16) % 100;
  if (bucket >= Number(experiment.traffic_percentage || 100)) return { assignment: null };
  let rows = await dbRequest('GET', 'marketing_experiment_assignments', { select: '*', experiment_id: `eq.${experiment.id}`, visitor_key: `eq.${visitorKey}`, limit: '1' });
  if (!rows[0]) {
    const variant = bucket % 2 === 0 ? 'a' : 'b';
    rows = await dbRequest('POST', 'marketing_experiment_assignments', {}, { experiment_id: experiment.id, visitor_key: visitorKey, variant }, ['Prefer: return=representation']).catch(async (error) => {
      if (!isUniqueViolation(error)) throw error;
      return dbRequest('GET', 'marketing_experiment_assignments', { select: '*', experiment_id: `eq.${experiment.id}`, visitor_key: `eq.${visitorKey}`, limit: '1' });
    });
  }
  const assignment = rows[0];
  return { assignment: { id: assignment.id, experiment_id: experiment.id, surface, variant: assignment.variant, value: assignment.variant === 'a' ? experiment.variant_a : experiment.variant_b, target: experiment.audience || '', primary_kpi: experiment.primary_kpi } };
}

async function recordPublicExperimentEvent(req, data = {}) {
  const assignmentId = cleanUuid(data.assignment_id || data.assignmentId);
  const event = cleanText(data.event || '').toLowerCase();
  if (!assignmentId || !['exposure', 'conversion'].includes(event)) throw httpError(422, 'Evento de experimento inválido.');
  const rows = await dbRequest('GET', 'marketing_experiment_assignments', { select: '*', id: `eq.${assignmentId}`, limit: '1' });
  if (!rows[0]) throw httpError(404, 'Atribuição de experimento não encontrada.');
  const patch = event === 'exposure'
    ? { exposed_at: rows[0].exposed_at || new Date().toISOString() }
    : { converted_at: rows[0].converted_at || new Date().toISOString(), conversion_event: cleanMarketingEventName(data.conversion_event || 'click') };
  await dbRequest('PATCH', 'marketing_experiment_assignments', { id: `eq.${assignmentId}` }, patch, ['Prefer: return=minimal']);
}

const EMAIL_TEMPLATE_DEFINITIONS = [
  { key: 'account_activation', name: 'Ativação de conta', subject: 'Ative sua conta no TáPronto', body: 'Olá {{customer_name}},\n\nSua loja {{store_name}} foi criada no TáPronto.\n\nPara liberar o acesso ao painel, ative sua conta pelo link abaixo:\n{{activation_url}}\n\nEste link expira em {{due_date}}.\n\nSe você não criou essa conta, ignore este e-mail.' },
  { key: 'welcome', name: 'Boas-vindas', subject: 'Bem-vindo ao {{store_name}}', body: 'Olá {{customer_name}},\n\nSua loja {{store_name}} foi criada com sucesso.\n\nAcesse o painel para concluir a configuração, cadastrar produtos e publicar seu cardápio:\n{{dashboard_url}}\n\nConte com o suporte TáPronto sempre que precisar.' },
  { key: 'password_recovery', name: 'Recuperação de senha', subject: 'Recupere sua senha de acesso', body: 'Olá {{customer_name}},\n\nRecebemos uma solicitação para recuperar o acesso ao painel da sua loja.\n\nClique no link abaixo para criar uma nova senha:\n{{reset_url}}\n\nEste link expira em {{due_date}}.\n\nSe você não solicitou isso, ignore este e-mail.' },
  { key: 'onboarding_incomplete', name: 'Onboarding incompleto', subject: 'Finalize a configuração da sua loja', body: 'Olá {{company_name}},\n\nSua loja {{store_name}} ainda não está totalmente configurada.\n\nFinalize o onboarding para ajustar horários, pagamentos, entrega e cardápio inicial:\n{{dashboard_url}}\n\nIsso ajuda sua loja a ficar pronta para receber pedidos sem retrabalho.' },
  { key: 'first_product_reminder', name: 'Primeiro produto pendente', subject: 'Cadastre os primeiros produtos da {{store_name}}', body: 'Olá {{company_name}},\n\nComece pelos três produtos mais vendidos da sua loja. Depois você pode completar o restante com calma.\n\nContinue pelo painel:\n{{dashboard_url}}\n\nSe alguma etapa travar, fale com nosso suporte.' },
  { key: 'publish_menu_reminder', name: 'Cardápio pronto para publicar', subject: 'Seu cardápio está quase pronto', body: 'Olá {{company_name}},\n\nVocê já começou o cardápio da {{store_name}}. Revise horários, entrega e pagamento para publicar o link.\n\nContinuar configuração:\n{{dashboard_url}}' },
  { key: 'first_order_reminder', name: 'Primeiro pedido teste', subject: 'Teste o pedido da {{store_name}} pelo celular', body: 'Olá {{company_name}},\n\nSeu cardápio está publicado. Abra o link pelo celular e faça um pedido teste para conferir produtos, adicionais, entrega e pagamento.\n\nCardápio:\n{{cardapio_url}}\n\nAcompanhe pelo painel:\n{{dashboard_url}}' },
  { key: 'inactive_store_checkin', name: 'Loja sem pedidos recentes', subject: 'Podemos ajudar com a {{store_name}}?', body: 'Olá {{company_name}},\n\nPercebemos que a {{store_name}} está há alguns dias sem novos pedidos no painel. Alguma configuração está dificultando o uso?\n\nRevise a loja pelo painel:\n{{dashboard_url}}\n\nSe precisar, abra um chamado e conte o que aconteceu:\n{{support_url}}' },
  { key: 'store_published', name: 'Loja publicada', subject: 'Seu cardápio já está publicado', body: 'Olá {{company_name}},\n\nBoa notícia: o cardápio da {{store_name}} foi publicado com sucesso.\n\nVocê já pode compartilhar o link com seus clientes:\n{{cardapio_url}}\n\nAcompanhe os pedidos pelo painel:\n{{dashboard_url}}' },
  { key: 'first_order_received', name: 'Primeiro pedido recebido', subject: 'Seu primeiro pedido chegou', body: 'Olá {{company_name}},\n\nA loja {{store_name}} recebeu o primeiro pedido pelo cardápio digital.\n\nPedido: {{order_id}}\nValor: {{order_total}}\n\nAcesse o painel para acompanhar o preparo, entrega e conclusão:\n{{dashboard_url}}' },
  { key: 'trial_ending', name: 'Trial acabando', subject: 'Seu teste grátis termina em breve', body: 'Olá {{company_name}},\n\nSeu período de teste do plano {{plan_name}} termina em {{due_date}}.\n\nPara manter o cardápio ativo e continuar recebendo pedidos, escolha um plano no painel:\n{{payment_url}}' },
  { key: 'trial_expired', name: 'Trial encerrado', subject: 'Seu teste grátis terminou', body: 'Olá {{company_name}},\n\nO período de teste da loja {{store_name}} terminou.\n\nPara continuar usando o cardápio, pedidos e recursos do painel, contrate um plano mensal:\n{{payment_url}}\n\nSe precisar de ajuda para escolher o melhor plano, fale com o suporte.' },
  { key: 'payment_pending', name: 'Pagamento pendente', subject: 'Pagamento pendente do plano {{plan_name}}', body: 'Olá {{company_name}},\n\nIdentificamos uma pendência no pagamento do plano {{plan_name}}.\n\nRegularize pelo painel para evitar bloqueios no cardápio e nos recursos da loja:\n{{payment_url}}' },
  { key: 'payment_approved', name: 'Pagamento aprovado', subject: 'Pagamento aprovado', body: 'Olá {{company_name}},\n\nO pagamento do plano {{plan_name}} foi aprovado.\n\nSua assinatura está ativa e os recursos do plano já podem ser usados no painel:\n{{dashboard_url}}' },
  { key: 'payment_refused', name: 'Pagamento recusado', subject: 'Não foi possível aprovar seu pagamento', body: 'Olá {{company_name}},\n\nO pagamento do plano {{plan_name}} não foi aprovado.\n\nConfira os dados de pagamento ou tente novamente pelo painel:\n{{payment_url}}\n\nSua assinatura pode entrar em período de tolerância até a regularização.' },
  { key: 'account_suspended', name: 'Conta suspensa', subject: 'Sua conta foi suspensa', body: 'Olá {{company_name}},\n\nSua conta foi suspensa temporariamente.\n\nAcesse o painel para regularizar a assinatura ou fale com o suporte:\n{{payment_url}}' },
  { key: 'account_reactivated', name: 'Conta reativada', subject: 'Sua conta foi reativada', body: 'Olá {{company_name}},\n\nSua conta foi reativada e a loja {{store_name}} já pode voltar a operar.\n\nAcesse o painel para conferir o status da assinatura e continuar recebendo pedidos:\n{{dashboard_url}}' },
  { key: 'support_replied', name: 'Suporte respondeu', subject: 'O suporte respondeu seu chamado', body: 'Olá {{customer_name}},\n\nA equipe de suporte respondeu seu chamado.\n\nAcompanhe a conversa e envie uma nova mensagem pelo painel:\n{{support_url}}\n\nSe o problema já foi resolvido, você pode encerrar o atendimento por lá.' },
  { key: 'support_ticket_closed', name: 'Chamado encerrado', subject: 'Seu chamado foi encerrado', body: 'Olá {{customer_name}},\n\nO chamado "{{ticket_subject}}" foi encerrado pela equipe de suporte.\n\nSe precisar continuar o atendimento, acesse o histórico e envie uma nova mensagem:\n{{support_url}}\n\nObrigado pelo retorno.' },
  { key: 'account_created_not_published', name: 'Conta sem publicação', subject: 'Sua loja ainda não foi publicada', body: 'Olá {{company_name}},\n\nPercebemos que sua conta foi criada, mas o cardápio da {{store_name}} ainda não está publicado.\n\nPublique sua loja para começar a divulgar o link e receber pedidos:\n{{dashboard_url}}\n\nSe quiser, podemos ajudar nos primeiros ajustes.' },
  { key: 'store_published_no_orders', name: 'Loja publicada sem pedidos', subject: 'Vamos ajudar sua loja a receber pedidos', body: 'Olá {{company_name}},\n\nSeu cardápio já está publicado, mas ainda não encontramos pedidos recentes na {{store_name}}.\n\nConfira produtos, formas de pagamento, WhatsApp e compartilhe o link com seus clientes:\n{{cardapio_url}}\n\nAcesse o painel para revisar tudo:\n{{dashboard_url}}' },
  { key: 'plan_limit_warning', name: 'Limite do plano próximo', subject: 'Sua loja está perto do limite do plano', body: 'Olá {{company_name}},\n\nA loja {{store_name}} está perto do limite de {{limit_name}} do plano {{plan_name}}.\n\nUso atual: {{usage_count}}\nLimite: {{limit_value}}\n\nPara continuar crescendo sem bloqueios, avalie um upgrade:\n{{payment_url}}' },
  { key: 'plan_upgrade_suggestion', name: 'Sugestão de upgrade', subject: 'Existe um plano melhor para sua operação', body: 'Olá {{company_name}},\n\nPelo uso recente da loja {{store_name}}, o plano {{plan_name}} pode estar limitando sua operação.\n\nUm plano superior pode liberar mais produtos, pedidos, mesas, relatórios e recursos avançados.\n\nConfira as opções no painel:\n{{payment_url}}' },
  { key: 'plan_changed', name: 'Plano alterado', subject: 'Seu plano foi alterado para {{plan_name}}', body: 'Olá {{company_name}},\n\nO plano da loja {{store_name}} foi alterado para {{plan_name}}.\n\nOs recursos e limites já foram atualizados no painel:\n{{dashboard_url}}\n\nConsulte o histórico de cobrança para acompanhar os detalhes.' },
  { key: 'cancellation_received', name: 'Cancelamento recebido', subject: 'Recebemos sua solicitação de cancelamento', body: 'Olá {{company_name}},\n\nRecebemos a solicitação de cancelamento da loja {{store_name}}.\n\nNossa equipe vai revisar a assinatura e confirmar os próximos passos.\n\nSe o cancelamento foi um engano ou se podemos ajudar com algum ajuste, responda este e-mail ou abra um chamado:\n{{support_url}}' },
  { key: 'satisfaction_survey', name: 'Pesquisa de satisfação', subject: 'Como foi sua experiência com o suporte?', body: 'Olá {{customer_name}},\n\nQueremos saber como foi sua experiência com o atendimento.\n\nSe puder, avalie rapidamente o suporte recebido:\n{{rating_url}}\n\nSua opinião ajuda a melhorar o sistema e o atendimento.' },
  { key: 'referral_invite', name: 'Convite de indicação', subject: '{{customer_name}} indicou o TáPronto para você', body: 'Olá,\n\n{{customer_name}} usa o TáPronto para organizar cardápio digital e pedidos da loja.\n\nVocê também pode criar sua loja online em poucos minutos pelo link abaixo:\n{{referral_url}}\n\nAo contratar um plano, a indicação pode liberar {{referral_reward}} de crédito para quem indicou.\n\nTáPronto\nCardápio digital, pedidos organizados.' },
  { key: 'referral_received', name: 'Indicação cadastrada', subject: 'Sua indicação criou uma conta no TáPronto', body: 'Olá {{customer_name}},\n\nUma indicação sua criou uma conta no TáPronto.\n\nIndicação: {{company_name}}\nCódigo usado: {{referral_code}}\n\nA recompensa será liberada quando essa loja pagar o primeiro plano.' },
  { key: 'referral_reward_unlocked', name: 'Recompensa de indicação liberada', subject: 'Você ganhou {{referral_reward}} em indicação', body: 'Olá {{customer_name}},\n\nBoa notícia: a indicação {{company_name}} pagou o primeiro plano.\n\nLiberamos {{referral_reward}} de crédito para sua conta.\n\nVocê pode acompanhar suas indicações no painel:\n{{dashboard_url}}' },
  { key: 'smtp_test', name: 'Teste SMTP', subject: 'Teste de envio SMTP do TáPronto', body: 'Olá {{customer_name}},\n\nEste é um teste de entrega do TáPronto.\n\nSe este e-mail chegou corretamente, a configuração SMTP está autenticando e preservando acentos.\n\nAcesse a Central para revisar a comunicação:\n{{platform_url}}' },
  { key: 'backup_failed', name: 'Backup falhou', subject: 'Alerta: falha no backup da plataforma', body: 'Alerta operacional do TáPronto.\n\nA rotina de backup falhou ou está atrasada.\n\nResumo: {{error_summary}}\nPeríodo: {{period}}\n\nAcesse o Platform para verificar Saúde e Serviços:\n{{platform_url}}' },
  { key: 'webhook_failed', name: 'Webhook falhou', subject: 'Alerta: webhook com falha', body: 'Alerta operacional do TáPronto.\n\nUm webhook apresentou falha de processamento.\n\nProvedor: {{provider}}\nEvento: {{event_id}}\nResumo: {{error_summary}}\n\nVerifique logs, assinatura do webhook e eventos financeiros no Platform:\n{{platform_url}}' },
  { key: 'smtp_failed', name: 'SMTP com erro', subject: 'Alerta: envio de e-mail com falha', body: 'Alerta operacional do TáPronto.\n\nO SMTP apresentou falha no envio ou teste de entrega.\n\nResumo: {{error_summary}}\n\nAcesse Comunicação no Platform para revisar host, porta, TLS, usuário e senha de app:\n{{platform_url}}' },
  { key: 'internal_support_ticket_opened', name: 'Interno: novo chamado', subject: 'Novo chamado recebido: {{ticket_subject}}', body: 'Novo chamado recebido na Central TáPronto.\n\nCliente: {{company_name}}\nLoja: {{store_name}}\nCategoria: {{ticket_category}}\nPrioridade: {{ticket_priority}}\nAssunto: {{ticket_subject}}\nResumo: {{message_preview}}\n\nAcesse a fila de atendimentos para responder rapidamente:\n{{support_url}}' },
  { key: 'internal_support_ticket_replied', name: 'Interno: cliente respondeu chamado', subject: 'Cliente respondeu chamado: {{ticket_subject}}', body: 'Um cliente respondeu um chamado na Central TáPronto.\n\nCliente: {{company_name}}\nLoja: {{store_name}}\nCategoria: {{ticket_category}}\nPrioridade: {{ticket_priority}}\nAssunto: {{ticket_subject}}\nResumo: {{message_preview}}\n\nAcesse a fila de atendimentos:\n{{support_url}}' },
  { key: 'critical_support_ticket', name: 'Chamado crítico aberto', subject: 'Chamado crítico aberto no suporte', body: 'Um chamado crítico foi aberto no Platform.\n\nCliente: {{company_name}}\nLoja: {{store_name}}\nAssunto: {{ticket_subject}}\n\nAcesse a central de atendimentos para responder com prioridade:\n{{support_url}}' },
  { key: 'delinquent_support_ticket', name: 'Inadimplente abriu chamado', subject: 'Cliente inadimplente abriu chamado', body: 'Um cliente com pendência financeira abriu chamado.\n\nCliente: {{company_name}}\nLoja: {{store_name}}\nPlano: {{plan_name}}\nAssunto: {{ticket_subject}}\n\nVerifique cobrança, assinatura e atendimento:\n{{support_url}}' },
  { key: 'internal_payment_refused', name: 'Interno: pagamento recusado', subject: 'Alerta interno: pagamento recusado', body: 'Alerta comercial do TáPronto.\n\nUm pagamento foi recusado.\n\nCliente: {{company_name}}\nLoja: {{store_name}}\nPlano: {{plan_name}}\nResumo: {{error_summary}}\n\nVerifique a assinatura, cobrança e eventos do provedor no Platform:\n{{platform_url}}' },
  { key: 'internal_account_suspended', name: 'Interno: conta suspensa', subject: 'Alerta interno: conta suspensa', body: 'Alerta comercial do TáPronto.\n\nUma conta foi suspensa.\n\nCliente: {{company_name}}\nLoja: {{store_name}}\nPlano: {{plan_name}}\nResumo: {{error_summary}}\n\nConfira o motivo, cobrança e histórico do cliente no Platform:\n{{platform_url}}' },
  { key: 'internal_trial_expiring', name: 'Interno: trial vencendo', subject: 'Alerta interno: trial perto do fim', body: 'Alerta comercial do TáPronto.\n\nUm trial está perto do fim.\n\nCliente: {{company_name}}\nLoja: {{store_name}}\nPlano: {{plan_name}}\nVencimento: {{due_date}}\n\nEntre em contato para orientar a contratação:\n{{platform_url}}' },
  { key: 'internal_trial_expired', name: 'Interno: trial encerrado', subject: 'Alerta interno: trial encerrado', body: 'Alerta comercial do TáPronto.\n\nUm trial terminou.\n\nCliente: {{company_name}}\nLoja: {{store_name}}\nPlano: {{plan_name}}\nVencimento: {{due_date}}\n\nVerifique se o cliente deve ser acionado, bloqueado ou convertido:\n{{platform_url}}' },
  { key: 'internal_plan_changed', name: 'Interno: plano alterado', subject: 'Alerta interno: plano alterado', body: 'Alerta comercial do TáPronto.\n\nUm plano foi alterado.\n\nCliente: {{company_name}}\nLoja: {{store_name}}\nNovo plano: {{plan_name}}\nResumo: {{error_summary}}\n\nConfira assinatura, MRR e auditoria no Platform:\n{{platform_url}}' }
];

const EMAIL_TEMPLATE_VARIABLES = [
  'store_name',
  'company_name',
  'customer_name',
  'plan_name',
  'due_date',
  'dashboard_url',
  'reset_url',
  'payment_url',
  'support_url',
  'cardapio_url',
  'platform_url',
  'activation_url',
  'order_id',
  'order_total',
  'ticket_subject',
  'ticket_category',
  'ticket_priority',
  'message_preview',
  'rating_url',
  'limit_name',
  'usage_count',
  'limit_value',
  'referral_url',
  'referral_code',
  'referral_reward',
  'referral_credit',
  'period',
  'provider',
  'event_id',
  'error_summary'
];

async function listPlatformEmailTemplates() {
  const rows = await dbRequest('GET', 'email_templates', {
    select: '*',
    order: 'template_key.asc',
    limit: '100'
  }).catch(() => []);
  const byKey = new Map(rows.map((row) => [row.template_key, row]));
  return {
    variables: EMAIL_TEMPLATE_VARIABLES,
    templates: EMAIL_TEMPLATE_DEFINITIONS.map((definition) => publicEmailTemplate(byKey.get(definition.key) || {
      template_key: definition.key,
      name: definition.name,
      subject: definition.subject,
      body: definition.body,
      variables: EMAIL_TEMPLATE_VARIABLES,
      is_active: true
    }))
  };
}

async function updatePlatformEmailTemplates(req, admin, data = {}) {
  const templates = Array.isArray(data.templates) ? data.templates : [data];
  const saved = [];
  for (const template of templates) {
    const key = cleanTemplateKey(template.template_key || template.key || '');
    if (!EMAIL_TEMPLATE_DEFINITIONS.some((entry) => entry.key === key)) throw httpError(422, 'Template de e-mail inválido.');
    const definition = EMAIL_TEMPLATE_DEFINITIONS.find((entry) => entry.key === key);
    const payload = {
      template_key: key,
      name: definition.name,
      subject: cleanText(template.subject || '').slice(0, 240) || definition.subject,
      body: cleanText(template.body || '').slice(0, 6000) || definition.body,
      variables: EMAIL_TEMPLATE_VARIABLES,
      is_active: template.is_active !== false,
      updated_by: admin.id,
      updated_at: new Date().toISOString()
    };
    const existing = await dbRequest('GET', 'email_templates', { select: 'id', template_key: `eq.${key}`, limit: '1' }).catch(() => {
      throw httpError(500, 'Tabela de templates não encontrada. Execute as migrations antes de salvar templates.');
    });
    const [row] = existing[0]
      ? await dbRequest('PATCH', 'email_templates', { id: `eq.${existing[0].id}` }, payload, ['Prefer: return=representation'])
      : await dbRequest('POST', 'email_templates', {}, payload, ['Prefer: return=representation']);
    saved.push(publicEmailTemplate(row));
  }
  await audit('platform.email_templates.update', {
    req,
    actor_admin_id: admin.id,
    entity_type: 'email_template',
    severity: 'warning',
    after_data: { templates: saved.map((template) => template.template_key) }
  });
  return { templates: saved };
}

function cleanTemplateKey(value) {
  return String(value || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '').replaceAll('-', '_');
}

function publicEmailTemplate(row = {}) {
  return {
    id: row.id || null,
    template_key: row.template_key || row.key || '',
    name: row.name || '',
    subject: row.subject || '',
    body: row.body || '',
    variables: Array.isArray(row.variables) ? row.variables : EMAIL_TEMPLATE_VARIABLES,
    is_active: row.is_active !== false,
    updated_at: row.updated_at || null
  };
}

async function listPlatformSupportTickets(params = new URLSearchParams()) {
  const query = {
    select: '*',
    order: 'updated_at.desc',
    limit: String(clampNumber(Number(params.get?.('limit') || 100), 1, 300))
  };
  const status = cleanSlug(params.get?.('status') || '');
  const priority = cleanSlug(params.get?.('priority') || '');
  const companyId = cleanOptionalUuid(params.get?.('company_id') || '');
  if (status) query.status = `eq.${supportStatus(status)}`;
  if (priority) query.priority = `eq.${supportPriority(priority)}`;
  if (companyId) query.company_id = `eq.${companyId}`;
  const tickets = await dbRequest('GET', 'support_tickets', query).catch(() => []);
  return enrichSupportTickets(tickets, true);
}

async function listAdminSupportTickets(admin) {
  const companyId = cleanUuid(admin.company_id);
  const storeId = cleanUuid(admin.store_id);
  const tickets = companyId ? await dbRequest('GET', 'support_tickets', {
    select: '*',
    company_id: `eq.${companyId}`,
    ...(storeId ? { store_id: `eq.${storeId}` } : {}),
    order: 'updated_at.desc',
    limit: '100'
  }).catch(() => []) : [];
  return enrichSupportTickets(tickets, false);
}

async function enrichSupportTickets(tickets, includeInternal = false) {
  const ids = cleanUuidArray(tickets.map((ticket) => ticket.id));
  const companyIds = cleanUuidArray(tickets.map((ticket) => ticket.company_id));
  const storeIds = cleanUuidArray(tickets.map((ticket) => ticket.store_id));
  const [messages, companies, stores, admins] = await Promise.all([
    ids.length ? dbRequest('GET', 'support_ticket_messages', {
      select: '*',
      ticket_id: uuidInFilter(ids),
      order: 'created_at.asc',
      limit: '1000'
    }).catch(() => []) : [],
    companyIds.length ? dbRequest('GET', 'companies', { select: 'id,name,billing_email,phone', id: uuidInFilter(companyIds), limit: '300' }).catch(() => []) : [],
    storeIds.length ? dbRequest('GET', 'stores', { select: 'id,name,slug', id: uuidInFilter(storeIds), limit: '300' }).catch(() => []) : [],
    dbRequest('GET', 'admin_users', { select: 'id,name,email', limit: '1000' }).catch(() => [])
  ]);
  const messagesByTicket = new Map();
  for (const message of messages) {
    if (!includeInternal && message.is_internal) continue;
    if (!messagesByTicket.has(message.ticket_id)) messagesByTicket.set(message.ticket_id, []);
    messagesByTicket.get(message.ticket_id).push(publicSupportMessage(message, admins));
  }
  const companyById = new Map(companies.map((company) => [company.id, company]));
  const storeById = new Map(stores.map((store) => [store.id, store]));
  const adminById = new Map(admins.map((admin) => [admin.id, admin]));
  return {
    tickets: tickets.map((ticket) => publicSupportTicket(ticket, {
      company: companyById.get(ticket.company_id),
      store: storeById.get(ticket.store_id),
      assignedAdmin: adminById.get(ticket.assigned_to_admin_id),
      messages: messagesByTicket.get(ticket.id) || []
    }))
  };
}

function publicSupportTicket(ticket = {}, extra = {}) {
  return {
    id: ticket.id,
    company_id: ticket.company_id || null,
    company_name: extra.company?.name || null,
    store_id: ticket.store_id || null,
    store_name: extra.store?.name || null,
    admin_user_id: ticket.admin_user_id || null,
    assigned_to_admin_id: ticket.assigned_to_admin_id || null,
    assigned_to_admin_name: extra.assignedAdmin?.name || null,
    assigned_to_admin_email: extra.assignedAdmin?.email || null,
    subject: ticket.subject || '',
    category: ticket.category || '',
    status: ticket.status || 'open',
    priority: ticket.priority || 'medium',
    source: ticket.source || 'admin',
    last_message_at: ticket.last_message_at || null,
    created_at: ticket.created_at,
    updated_at: ticket.updated_at,
    messages: extra.messages || []
  };
}

function publicSupportMessage(message = {}, admins = []) {
  const admin = admins.find((entry) => entry.id === message.author_admin_id);
  const authorType = message.author_type || 'admin';
  const authorName = (() => {
    if (authorType === 'support') return 'Equipe de suporte';
    if (authorType === 'internal') return admin?.name || 'Nota interna';
    return admin?.name || 'Cliente';
  })();
  return {
    id: message.id,
    ticket_id: message.ticket_id,
    author_type: authorType,
    author_name: authorName,
    message: message.message || '',
    is_internal: message.is_internal === true,
    created_at: message.created_at
  };
}

async function createAdminSupportTicket(req, admin, data = {}) {
  const subject = cleanText(data.subject || '').slice(0, 180);
  const message = cleanText(data.message || '').slice(0, 5000);
  const contactName = cleanText(data.contact_name || admin.name || '').slice(0, 120);
  if (!subject) throw httpError(422, 'Informe o assunto do chamado.');
  if (!contactName) throw httpError(422, 'Informe o nome para contato.');
  if (!message) throw httpError(422, 'Informe a mensagem do chamado.');
  const messageWithContact = `Contato: ${contactName}\n\n${message}`;
  const [ticket] = await dbRequest('POST', 'support_tickets', {}, {
    company_id: cleanOptionalUuid(admin.company_id || '') || null,
    store_id: cleanOptionalUuid(admin.store_id || '') || null,
    admin_user_id: admin.id,
    created_by_admin_id: admin.id,
    subject,
    category: cleanText(data.category || '').slice(0, 80) || null,
    priority: supportPriority(data.priority || 'medium'),
    status: 'open',
    source: 'admin',
    last_message_at: new Date().toISOString()
  }, ['Prefer: return=representation']);
  await dbRequest('POST', 'support_ticket_messages', {}, {
    ticket_id: ticket.id,
    author_admin_id: admin.id,
    author_type: 'admin',
    message: messageWithContact,
    is_internal: false
  }, ['Prefer: return=minimal']);
  await audit('admin.support.ticket.create', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id,
    store_id: admin.store_id,
    entity_type: 'support_ticket',
    entity_id: ticket.id,
    after_data: { subject, priority: ticket.priority, contact_name: contactName }
  });
  await notifyPlatformSupportActivity(ticket, 'internal_support_ticket_opened', {
    messagePreview: message,
    req
  }).catch(async (error) => {
    await audit('admin.support.ticket.notify_failed', {
      req,
      actor_admin_id: admin.id,
      company_id: admin.company_id,
      store_id: admin.store_id,
      entity_type: 'support_ticket',
      entity_id: ticket.id,
      severity: 'warning',
      after_data: { error: error.message || 'Falha ao enviar notificação interna.' }
    }).catch(() => {});
  });
  return publicSupportTicket(ticket, { messages: [{ message: messageWithContact, author_type: 'admin', created_at: new Date().toISOString() }] });
}

async function requestPaymentSetupSupport(req, admin) {
  const companyId = cleanOptionalUuid(admin.company_id || '') || null;
  const storeId = cleanOptionalUuid(admin.store_id || '') || null;
  if (!companyId || !storeId) throw httpError(403, 'Sua conta precisa estar vinculada a uma loja para solicitar a configuração.');
  const addonAccess = await getStoreAddonAccess(admin, 'payment_setup_assisted').catch(() => null);
  if (!addonAccess?.active) {
    const addon = addonAccess?.addon || await getPlanAddonByCode('payment_setup_assisted').catch(() => null);
    const message = addonAccess?.available
      ? `Contrate ${addon?.name || 'Configuração Assistida do Pix Online'} por ${addonPriceLabel(addon || {})} para a equipe TáPronto configurar com você.`
      : 'A configuração assistida do pagamento online está inclusa no Premium ou disponível como adicional nos planos pagos.';
    throw httpError(402, message, planErrorPayload('ADDON_REQUIRED', message, { addon: 'payment_setup_assisted' }));
  }

  const existingTickets = await dbRequest('GET', 'support_tickets', {
    select: '*',
    company_id: `eq.${companyId}`,
    store_id: `eq.${storeId}`,
    category: 'eq.Pagamento online',
    order: 'updated_at.desc',
    limit: '20'
  }).catch(() => []);
  const openTicket = existingTickets.find((ticket) => !['closed', 'resolved'].includes(ticket.status));
  if (openTicket) {
    const enriched = await enrichSupportTickets([openTicket], false).catch(() => ({ tickets: [publicSupportTicket(openTicket)] }));
    return {
      ticket: enriched.tickets[0] || publicSupportTicket(openTicket),
      message: 'Já existe uma solicitação aberta para pagamento online. Abrimos o chamado para você acompanhar.'
    };
  }

  const [company, store, subscription] = await Promise.all([
    dbRequest('GET', 'companies', { select: 'id,name,billing_email,phone', id: `eq.${companyId}`, limit: '1' }).then((rows) => rows[0] || null).catch(() => null),
    dbRequest('GET', 'stores', { select: 'id,name,slug', id: `eq.${storeId}`, limit: '1' }).then((rows) => rows[0] || null).catch(() => null),
    dbRequest('GET', 'company_subscriptions', { select: '*', company_id: `eq.${companyId}`, order: 'created_at.desc', limit: '20' })
      .then((rows) => pickCurrentCompanySubscription(rows) || rows[0] || null)
      .catch(() => null)
  ]);
  const plan = subscription?.plan_id
    ? await dbRequest('GET', 'subscription_plans', { select: 'id,name,code,slug,monthly_price', id: `eq.${subscription.plan_id}`, limit: '1' })
      .then((rows) => rows[0] || null)
      .catch(() => null)
    : null;

  const storeUrl = store?.slug ? `${publicAppBaseUrl(req)}/${store.slug}` : '';
  const message = [
    `Contato: ${admin.name || company?.name || 'Administrador'}`,
    '',
    'Quero ajuda da equipe TáPronto para configurar pagamento online com Abacate Pay.',
    '',
    `Empresa: ${company?.name || 'Não identificada'}`,
    `Loja: ${store?.name || admin.active_store?.name || 'Loja atual'}`,
    `Slug: ${store?.slug || '-'}`,
    `Plano atual: ${plan?.name || 'Sem plano identificado'}`,
    `Status da assinatura: ${subscription?.status || 'Sem assinatura'}`,
    `E-mail do administrador: ${admin.email || '-'}`,
    `Contato financeiro: ${company?.billing_email || company?.phone || '-'}`,
    storeUrl ? `Cardápio: ${storeUrl}` : '',
    '',
    'Observação interna para a Central: configuração assistida já está liberada para esta loja por plano incluso ou adicional contratado. Ajudar com API key, webhook e teste de pagamento.'
  ].filter((line) => line !== '').join('\n');

  const now = new Date().toISOString();
  const [ticket] = await dbRequest('POST', 'support_tickets', {}, {
    company_id: companyId,
    store_id: storeId,
    admin_user_id: admin.id,
    created_by_admin_id: admin.id,
    subject: 'Configurar pagamento online com Abacate Pay',
    category: 'Pagamento online',
    priority: planCodeIsPremium(plan) ? 'high' : 'medium',
    status: 'open',
    source: 'admin',
    last_message_at: now
  }, ['Prefer: return=representation']);
  await dbRequest('POST', 'support_ticket_messages', {}, {
    ticket_id: ticket.id,
    author_admin_id: admin.id,
    author_type: 'admin',
    message,
    is_internal: false
  }, ['Prefer: return=minimal']);
  await audit('admin.support.payment_setup_request', {
    req,
    actor_admin_id: admin.id,
    company_id: companyId,
    store_id: storeId,
    entity_type: 'support_ticket',
    entity_id: ticket.id,
    after_data: {
      subject: ticket.subject,
      category: ticket.category,
      plan_code: plan?.code || plan?.slug || null
    }
  });
  await notifyPlatformSupportActivity(ticket, 'internal_support_ticket_opened', {
    messagePreview: 'Solicitação de configuração assistida do pagamento online com Abacate Pay.',
    company,
    store,
    req
  }).catch(async (error) => {
    await audit('admin.support.payment_setup_notify_failed', {
      req,
      actor_admin_id: admin.id,
      company_id: companyId,
      store_id: storeId,
      entity_type: 'support_ticket',
      entity_id: ticket.id,
      severity: 'warning',
      after_data: { error: error.message || 'Falha ao enviar notificação interna.' }
    }).catch(() => {});
  });
  const enriched = await enrichSupportTickets([ticket], false).catch(() => ({ tickets: [publicSupportTicket(ticket)] }));
  return {
    ticket: enriched.tickets[0] || publicSupportTicket(ticket),
    message: 'Solicitação enviada. A equipe TáPronto vai orientar a configuração do pagamento online.'
  };
}

function planCodeIsPremium(plan = {}) {
  const value = cleanSlug(plan?.code || plan?.slug || plan?.name || '');
  return value.includes('premium');
}

function publicAppBaseUrl(req) {
  return String(process.env.PUBLIC_APP_URL || publicBaseUrl() || process.env.APP_URL || requestOrigin(req) || '').replace(/\/+$/, '');
}

function publicBaseUrl() {
  return subdomainBaseUrl('PUBLIC_BASE_URL', 'PUBLIC_HOSTS', 'taprontomenu.com.br');
}

function requestOrigin(req) {
  const proto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() || 'http';
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
  return host ? `${proto}://${host}` : '';
}

async function createAdminSupportMessage(req, admin, ticketId, data = {}) {
  const ticket = await getSupportTicket(ticketId);
  const adminCompanyId = cleanOptionalUuid(admin.company_id || '');
  const adminStoreId = cleanOptionalUuid(admin.store_id || '');
  if ((ticket.company_id && ticket.company_id !== adminCompanyId) || (ticket.store_id && ticket.store_id !== adminStoreId)) {
    throw httpError(403, 'Este chamado não pertence à sua loja.');
  }
  if (['closed'].includes(ticket.status)) throw httpError(422, 'Chamado fechado não aceita novas respostas.');
  const messageText = cleanText(data.message || '').slice(0, 5000);
  if (!messageText) throw httpError(422, 'Informe a mensagem.');
  const duplicateWindow = new Date(Date.now() - 15000).toISOString();
  const [recentDuplicate] = await dbRequest('GET', 'support_ticket_messages', {
    select: '*',
    ticket_id: `eq.${ticket.id}`,
    author_admin_id: `eq.${admin.id}`,
    author_type: 'eq.admin',
    is_internal: 'eq.false',
    message: `eq.${messageText}`,
    created_at: `gte.${duplicateWindow}`,
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  if (recentDuplicate) return publicSupportMessage(recentDuplicate, [admin]);

  const [message] = await dbRequest('POST', 'support_ticket_messages', {}, {
    ticket_id: ticket.id,
    author_admin_id: admin.id,
    author_type: 'admin',
    message: messageText,
    is_internal: false
  }, ['Prefer: return=representation']);
  await dbRequest('PATCH', 'support_tickets', { id: `eq.${ticket.id}` }, {
    status: 'open',
    last_message_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }, ['Prefer: return=minimal']).catch(() => {});
  await audit('admin.support.ticket.message', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id,
    store_id: admin.store_id,
    entity_type: 'support_ticket',
    entity_id: ticket.id
  });
  await notifyPlatformSupportActivity(ticket, 'internal_support_ticket_replied', {
    messagePreview: messageText,
    req
  }).catch(async (error) => {
    await audit('admin.support.ticket.reply_notify_failed', {
      req,
      actor_admin_id: admin.id,
      company_id: admin.company_id,
      store_id: admin.store_id,
      entity_type: 'support_ticket',
      entity_id: ticket.id,
      severity: 'warning',
      after_data: { error: error.message || 'Falha ao enviar notificação interna.' }
    }).catch(() => {});
  });
  return publicSupportMessage(message, [admin]);
}

async function closeAdminSupportTicket(req, admin, ticketId) {
  const ticket = await getSupportTicket(ticketId);
  const adminCompanyId = cleanOptionalUuid(admin.company_id || '');
  const adminStoreId = cleanOptionalUuid(admin.store_id || '');
  if ((ticket.company_id && ticket.company_id !== adminCompanyId) || (ticket.store_id && ticket.store_id !== adminStoreId)) {
    throw httpError(403, 'Este chamado não pertence à sua loja.');
  }
  if (['closed', 'resolved'].includes(ticket.status)) return publicSupportTicket(ticket);
  const now = new Date().toISOString();
  const [updated] = await dbRequest('PATCH', 'support_tickets', { id: `eq.${ticket.id}` }, {
    status: 'closed',
    updated_at: now
  }, ['Prefer: return=representation']);
  await audit('admin.support.ticket.close', {
    req,
    actor_admin_id: admin.id,
    company_id: admin.company_id,
    store_id: admin.store_id,
    entity_type: 'support_ticket',
    entity_id: ticket.id,
    before_data: { status: ticket.status },
    after_data: { status: 'closed' }
  });
  return publicSupportTicket(updated || { ...ticket, status: 'closed', updated_at: now });
}

async function createPlatformSupportTicket(req, admin, data = {}) {
  const subject = cleanText(data.subject || '').slice(0, 180);
  const message = cleanText(data.message || '').slice(0, 5000);
  if (!subject) throw httpError(422, 'Informe o assunto do chamado.');
  const companyId = cleanOptionalUuid(data.company_id || '');
  const storeId = cleanOptionalUuid(data.store_id || '');
  const [ticket] = await dbRequest('POST', 'support_tickets', {}, {
    company_id: companyId || null,
    store_id: storeId || null,
    admin_user_id: cleanOptionalUuid(data.admin_user_id || '') || null,
    created_by_admin_id: admin.id,
    assigned_to_admin_id: admin.id,
    subject,
    category: cleanText(data.category || '').slice(0, 80) || null,
    status: supportStatus(data.status || 'open'),
    priority: supportPriority(data.priority || 'medium'),
    source: 'platform',
    last_message_at: message ? new Date().toISOString() : null
  }, ['Prefer: return=representation']);
  if (message) {
    await dbRequest('POST', 'support_ticket_messages', {}, {
      ticket_id: ticket.id,
      author_admin_id: admin.id,
      author_type: 'support',
      message,
      is_internal: data.is_internal === true
    }, ['Prefer: return=minimal']);
  }
  await audit('platform.support.ticket.create', {
    req,
    actor_admin_id: admin.id,
    company_id: companyId || null,
    store_id: storeId || null,
    entity_type: 'support_ticket',
    entity_id: ticket.id,
    after_data: { subject, priority: ticket.priority, status: ticket.status }
  });
  return publicSupportTicket(ticket);
}

async function createPlatformSupportMessage(req, admin, ticketId, data = {}) {
  const ticket = await getSupportTicket(ticketId);
  const messageText = cleanText(data.message || '').slice(0, 5000);
  if (!messageText) throw httpError(422, 'Informe a mensagem.');
  const isInternal = data.is_internal === true;
  const authorType = isInternal ? 'internal' : 'support';
  const duplicateWindow = new Date(Date.now() - 15000).toISOString();
  const [recentDuplicate] = await dbRequest('GET', 'support_ticket_messages', {
    select: '*',
    ticket_id: `eq.${ticket.id}`,
    author_admin_id: `eq.${admin.id}`,
    author_type: `eq.${authorType}`,
    is_internal: `eq.${isInternal}`,
    message: `eq.${messageText}`,
    created_at: `gte.${duplicateWindow}`,
    order: 'created_at.desc',
    limit: '1'
  }).catch(() => []);
  if (recentDuplicate) return publicSupportMessage(recentDuplicate, [admin]);

  const [message] = await dbRequest('POST', 'support_ticket_messages', {}, {
    ticket_id: ticket.id,
    author_admin_id: admin.id,
    author_type: authorType,
    message: messageText,
    is_internal: isInternal
  }, ['Prefer: return=representation']);
  await dbRequest('PATCH', 'support_tickets', { id: `eq.${ticket.id}` }, {
    status: isInternal ? ticket.status : 'waiting_customer',
    last_message_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }, ['Prefer: return=minimal']).catch(() => {});
  await audit('platform.support.ticket.message', {
    req,
    actor_admin_id: admin.id,
    company_id: ticket.company_id,
    store_id: ticket.store_id,
    entity_type: 'support_ticket',
    entity_id: ticket.id,
    after_data: { is_internal: isInternal }
  });
  if (!isInternal) await notifySupportTicket(ticket, 'support_replied').catch(() => {});
  return publicSupportMessage(message, [admin]);
}

async function updatePlatformSupportTicket(req, admin, ticketId, data = {}) {
  const ticket = await getSupportTicket(ticketId);
  const payload = {};
  if ('status' in data) payload.status = supportStatus(data.status);
  if ('priority' in data) payload.priority = supportPriority(data.priority);
  if ('assigned_to_admin_id' in data) payload.assigned_to_admin_id = cleanOptionalUuid(data.assigned_to_admin_id || '') || null;
  if ('company_id' in data) payload.company_id = cleanOptionalUuid(data.company_id || '') || null;
  if ('store_id' in data) payload.store_id = cleanOptionalUuid(data.store_id || '') || null;
  if (!Object.keys(payload).length) throw httpError(422, 'Informe algum dado para atualizar.');
  payload.updated_at = new Date().toISOString();
  const [updated] = await dbRequest('PATCH', 'support_tickets', { id: `eq.${ticket.id}` }, payload, ['Prefer: return=representation']);
  await audit('platform.support.ticket.update', {
    req,
    actor_admin_id: admin.id,
    company_id: updated.company_id,
    store_id: updated.store_id,
    entity_type: 'support_ticket',
    entity_id: updated.id,
    before_data: { status: ticket.status, priority: ticket.priority },
    after_data: payload
  });
  if (payload.status && payload.status !== ticket.status) await notifySupportTicket(updated, 'support_replied').catch(() => {});
  return publicSupportTicket(updated);
}

async function getSupportTicket(ticketId) {
  const id = cleanUuid(ticketId, 'chamado');
  const [ticket] = await dbRequest('GET', 'support_tickets', { select: '*', id: `eq.${id}`, limit: '1' });
  if (!ticket) throw httpError(404, 'Chamado não encontrado.');
  return ticket;
}

function supportStatus(value) {
  const status = cleanSlug(value || '');
  const map = {
    open: 'open',
    aberto: 'open',
    waiting_customer: 'waiting_customer',
    'waiting-customer': 'waiting_customer',
    aguardando_cliente: 'waiting_customer',
    'aguardando-cliente': 'waiting_customer',
    in_review: 'in_review',
    'in-review': 'in_review',
    em_analise: 'in_review',
    'em-analise': 'in_review',
    resolved: 'resolved',
    resolvido: 'resolved',
    closed: 'closed',
    fechado: 'closed'
  };
  if (map[status]) return map[status];
  throw httpError(422, 'Status de chamado inválido.');
}

function supportPriority(value) {
  const priority = cleanSlug(value || 'medium');
  const map = {
    low: 'low',
    baixa: 'low',
    medium: 'medium',
    media: 'medium',
    high: 'high',
    alta: 'high',
    critical: 'critical',
    critica: 'critical'
  };
  if (map[priority]) return map[priority];
  throw httpError(422, 'Prioridade de chamado inválida.');
}

async function notifySupportTicket(ticket, templateKey) {
  const [company] = ticket.company_id ? await dbRequest('GET', 'companies', { select: 'name,billing_email', id: `eq.${ticket.company_id}`, limit: '1' }).catch(() => []) : [];
  const [admin] = ticket.admin_user_id ? await dbRequest('GET', 'admin_users', { select: 'name,email', id: `eq.${ticket.admin_user_id}`, limit: '1' }).catch(() => []) : [];
  const to = cleanEmail(admin?.email || company?.billing_email || '');
  if (!to) return;
  const variables = {
    store_name: '',
    company_name: company?.name || '',
    customer_name: admin?.name || company?.name || 'cliente',
    plan_name: '',
    due_date: '',
    dashboard_url: absolutePanelUrl('/'),
    payment_url: absolutePanelUrl('/?tab=plan'),
    support_url: absolutePanelUrl('/?tab=support')
  };
  await sendPlatformTemplateEmail({
    to,
    templateKey,
    variables
  });
}

async function notifyPlatformSupportActivity(ticket = {}, templateKey, options = {}) {
  const [company] = options.company
    ? [options.company]
    : ticket.company_id
      ? await dbRequest('GET', 'companies', { select: 'name,billing_email,phone', id: `eq.${ticket.company_id}`, limit: '1' }).catch(() => [])
      : [];
  const [store] = options.store
    ? [options.store]
    : ticket.store_id
      ? await dbRequest('GET', 'stores', { select: 'name,slug', id: `eq.${ticket.store_id}`, limit: '1' }).catch(() => [])
      : [];
  const baseUrl = publicAppBaseUrl(options.req || { headers: {} });
  const variables = {
    company_name: company?.name || 'Cliente sem empresa',
    store_name: store?.name || 'Loja não identificada',
    ticket_subject: ticket.subject || 'Chamado sem assunto',
    ticket_category: ticket.category || 'Sem categoria',
    ticket_priority: priorityLabelForEmail(ticket.priority || 'medium'),
    message_preview: supportEmailPreview(options.messagePreview || ''),
    support_url: platformBaseUrl(),
    platform_url: platformBaseUrl()
  };
  await sendPlatformTemplateEmail({
    to: PLATFORM_SYSTEM_EMAIL_RECIPIENT,
    templateKey,
    variables
  });
}

function priorityLabelForEmail(priority = '') {
  return ({
    low: 'Baixa',
    medium: 'Média',
    high: 'Alta',
    critical: 'Crítica'
  })[cleanSlug(priority || 'medium')] || 'Média';
}

function supportEmailPreview(message = '') {
  const text = String(message || '')
    .replace(/^Contato:\s*[^\n]+\n*/i, '')
    .replace(/\s+/g, ' ')
    .trim();
  return text.slice(0, 320) || 'Sem descrição informada.';
}

function renderEmailTemplate(text, variables = {}) {
  return String(text || '').replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_, key) => cleanText(variables[key] ?? ''));
}

function webhookHealthStatus(logs = []) {
  const failed = logs.filter((entry) => entry.type === 'webhook' && entry.status === 'failed').length;
  return platformStatus(
    'webhooks',
    'Webhooks',
    failed ? 'attention' : 'healthy',
    failed ? `${failed} falha(s) recente(s) em webhooks.` : 'Sem falhas recentes registradas.',
    null
  );
}

function backupHealthStatus(backup = {}) {
  if (backup.status === 'running') return platformStatus('backup', 'Backup', 'attention', 'Backup em andamento.', null);
  if (backup.status === 'failed') return platformStatus('backup', 'Backup', 'error', backup.error || 'Último backup falhou.', null);
  if (!backup.latest?.created_at) return platformStatus('backup', 'Backup', 'unknown', 'Nenhum backup local registrado.', null);
  const ageHours = (Date.now() - new Date(backup.latest.created_at).getTime()) / 3600000;
  return platformStatus(
    'backup',
    'Backup',
    backup.status === 'success' && ageHours <= 24 ? 'healthy' : 'attention',
    ageHours <= 24 ? 'Backup gerado nas últimas 24h.' : 'Backup bem-sucedido atrasado há mais de 24h.',
    null
  );
}

async function storageHealthStatus(directory, key, label) {
  try {
    await mkdir(directory, { recursive: true });
    const file = path.join(directory, `.health-${Date.now()}.tmp`);
    await writeFile(file, 'ok');
    await unlink(file).catch(() => {});
    return platformStatus(key, label, 'healthy', 'Diretório configurado e gravável.', null);
  } catch (error) {
    return platformStatus(key, label, 'error', 'Diretório sem permissão de escrita.', null);
  }
}

async function platformConfigChecklist() {
  const uploads = await directoryWritable(UPLOAD_DIR);
  const backups = await directoryWritable(BACKUP_DIR);
  const smtp = await smtpServiceStatus();
  const billing = await getPlatformBillingSettings().catch(() => null);
  const production = process.env.NODE_ENV === 'production';
  const appUrl = process.env.APP_URL || process.env.PUBLIC_APP_URL || '';
  const apiUrl = process.env.API_URL || appUrl || '';
  const social = socialConfigStatus();
  const items = [
    configItem('database_url', 'DATABASE_URL configurada', Boolean(DATABASE_URL), maskConfigValue(DATABASE_URL, 'url')),
    configItem('app_url', 'APP_URL/PUBLIC_APP_URL configurada', Boolean(appUrl), maskConfigValue(appUrl, 'url')),
    configItem('api_url', 'API_URL configurada', Boolean(apiUrl), maskConfigValue(apiUrl, 'url')),
    configItem('https', 'HTTPS ativo em produção', !production || /^https:\/\//i.test(appUrl), production ? 'Obrigatório em produção' : 'Ambiente não produção'),
    configItem('jwt_secret', 'Secrets de sessão não padrão', hasStrongSessionSecret(), hasStrongSessionSecret() ? 'Configurado' : 'Configure SESSION_SECRET/COOKIE_SECRET'),
    configItem('cookie_secret', 'COOKIE_SECRET/SESSION_SECRET configurado', Boolean(process.env.COOKIE_SECRET || process.env.SESSION_SECRET), 'Não exibe segredo'),
    configItem('payment_secrets_key', 'Criptografia das credenciais de pagamento', Boolean(process.env.PAYMENT_SECRETS_KEY), 'Configure PAYMENT_SECRETS_KEY e não altere depois de salvar credenciais'),
    configItem('social_encryption', 'Criptografia dos tokens sociais', social.encryptionReady, 'Configure SOCIAL_TOKEN_ENCRYPTION_KEY e guarde-a fora do servidor'),
    configItem('instagram_mode', 'Instagram em modo seguro', social.simulation || social.liveReady, social.simulation ? 'Simulação ativa; nenhum post real será enviado' : social.liveReady ? 'Publicação real habilitada' : 'Credenciais ou liberação ausentes'),
    configItem('instagram_oauth', 'OAuth oficial do Instagram', social.oauthReady, social.oauthReady ? 'Credenciais Meta presentes' : 'Opcional enquanto o modo simulado estiver ativo', social.simulation),
    configItem('cookie_secure', 'COOKIE_SECURE correto para produção', !production || COOKIE_SECURE === true, String(COOKIE_SECURE)),
    configItem('abacate_api', 'Abacate Pay configurado', Boolean(billing?.is_active && billing?.has_api_key), billing?.has_api_key ? `Configurado (${billing.source})` : 'Ausente'),
    configItem('abacate_webhook', 'Webhook Abacate Pay configurado', Boolean(billing?.has_webhook_secret), billing?.has_webhook_secret ? `Configurado (${billing.source})` : 'Ausente'),
    configItem('uploads', 'Upload/storage gravável', uploads, maskConfigValue(UPLOAD_DIR, 'path')),
    configItem('smtp', 'SMTP/e-mail configurado', smtp.status === 'healthy', smtp.status === 'healthy' ? `Configurado (${smtp.source})` : smtp.message, true),
    configItem('proxy', 'Proxy/Nginx compatível', Boolean(process.env.TRUST_PROXY || process.env.PUBLIC_APP_URL || process.env.APP_URL), 'Verifique headers X-Forwarded-* no Nginx'),
    configItem('rate_limit', 'Rate limit ativo', true, 'Ativo em memória por rota sensível'),
    configItem('backup_dir', 'Diretório de backup configurado', Boolean(BACKUP_DIR), maskConfigValue(BACKUP_DIR, 'path')),
    configItem('backup_write', 'Permissão de escrita em backups', backups, maskConfigValue(BACKUP_DIR, 'path'))
  ];
  return {
    ok: items.every((item) => item.ok || item.optional),
    items
  };
}

function configItem(key, label, ok, hint = '', optional = false) {
  return { key, label, ok: Boolean(ok), hint, optional };
}

async function directoryWritable(directory) {
  try {
    await mkdir(directory, { recursive: true });
    const file = path.join(directory, `.health-${Date.now()}-${randomBytes(3).toString('hex')}.tmp`);
    await writeFile(file, 'ok');
    await unlink(file).catch(() => {});
    return true;
  } catch {
    return false;
  }
}

function hasStrongSessionSecret() {
  const value = process.env.COOKIE_SECRET || process.env.SESSION_SECRET || '';
  return value.length >= 24 && !/^(secret|changeme|default|password|dev)$/i.test(value);
}

function maskConfigValue(value, type = 'text') {
  const text = String(value || '');
  if (!text) return 'Não configurado';
  if (type === 'path') return path.basename(text) ? `.../${path.basename(text)}` : 'Configurado';
  if (type === 'url') {
    try {
      const url = new URL(text);
      return `${url.protocol}//${url.hostname}${url.port ? ':' + url.port : ''}`;
    } catch {
      return 'Configurado';
    }
  }
  return 'Configurado';
}

function bytesLabel(value) {
  const bytes = Number(value || 0);
  if (!bytes) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

async function platformHealthAlerts({ statuses, metrics, config, backup, operationalLogs }) {
  const alerts = [];
  const add = (type, severity, title, message, action) => alerts.push({ key: type, type, severity, title, message, action });
  for (const status of statuses) {
    if (status.status === 'error') add(status.key, 'critical', `${status.label} com erro`, status.message, 'Verifique logs do servidor e configuração.');
    if (status.status === 'attention') add(status.key, 'warning', `${status.label} exige atenção`, status.message, 'Revise a configuração operacional.');
  }
  const missingConfig = (config.items || []).filter((item) => !item.ok && !item.optional);
  if (missingConfig.length) {
    add('config', 'warning', 'Configurações críticas ausentes', `${missingConfig.length} item(ns) precisam de revisão.`, 'Abra o checklist operacional e complete os itens pendentes.');
  }
  if (backup.latest?.created_at && (Date.now() - new Date(backup.latest.created_at).getTime()) > 86400000) {
    add('backup_delayed', 'warning', 'Backup atrasado', 'Não há backup bem-sucedido nas últimas 24h.', 'Execute npm run db:backup e confira o agendamento.');
  }
  if (metrics.api.errors_5xx >= 5) {
    add('api_5xx', 'critical', 'Erros 5xx frequentes', `${metrics.api.errors_5xx} erro(s) 5xx no período em memória.`, 'Verifique logs e rotas com falha.');
  }
  if (Number(metrics.database?.average_ms || 0) > 800) {
    add('database_slow', 'warning', 'Banco lento', `Banco respondeu em ${metrics.database.average_ms} ms.`, 'Verifique carga, índices e conexão PostgreSQL.');
  }
  if (Number(metrics.system?.disk?.lowest_free_percent ?? 100) < 15) {
    add('disk_low', 'critical', 'Espaço em disco baixo', `Menos de ${metrics.system.disk.lowest_free_percent}% livre em uploads/backups.`, 'Limpe arquivos antigos ou aumente o volume.');
  }
  const memory = metrics.system?.memory || {};
  const ramUsed = Number(memory.system_used_percent || 0);
  if (ramUsed >= 90) {
    add('ram_critical', 'critical', 'RAM em uso crítico', `Memória do sistema em ${ramUsed}%.`, 'Reduza carga, verifique processos e planeje upgrade de RAM.');
  } else if (ramUsed >= 75) {
    add('ram_attention', 'warning', 'RAM exige atenção', `Memória do sistema em ${ramUsed}%.`, 'Monitore crescimento, paginação e consumo do Node/PostgreSQL.');
  }
  const swapUsed = Number(memory.swap_used_bytes || 0);
  if (swapUsed >= 1024 * 1024 * 1024) {
    add('swap_critical', 'critical', 'Swap em uso crítico', `Swap usado: ${bytesLabel(swapUsed)}.`, 'Swap não substitui RAM. Considere upgrade e revise processos.');
  } else if (swapUsed >= 512 * 1024 * 1024) {
    add('swap_attention', 'warning', 'Swap em uso elevado', `Swap usado: ${bytesLabel(swapUsed)}.`, 'Monitore lentidão e reduza pressão de memória.');
  }
  const heapUsed = Number(memory.heap_used_percent || 0);
  if (heapUsed >= 90) {
    add('node_heap_critical', 'critical', 'Heap do Node em uso crítico', `Heap usado: ${heapUsed}%.`, 'Reinicie de forma planejada e investigue vazamento de memória.');
  } else if (heapUsed >= 80) {
    add('node_heap_attention', 'warning', 'Heap do Node exige atenção', `Heap usado: ${heapUsed}%.`, 'Monitore crescimento e avalie NODE_OPTIONS/upgrade de RAM.');
  }
  const billing = await getPlatformBillingSettings().catch(() => null);
  if (!billing?.is_active || !billing?.has_api_key) {
    add('abacatepay_missing', 'warning', 'Abacate Pay desconfigurado', 'API key de billing não encontrada.', 'Configure Billing > Configuração Abacate Pay na Central.');
  }
  if (statuses.some((status) => status.key === 'smtp' && status.status !== 'healthy')) {
    add('smtp_missing', 'attention', 'SMTP exige atenção', 'Envio de e-mails operacionais não está totalmente disponível.', 'Revise Comunicação > SMTP no Platform ou as variáveis SMTP do servidor.');
  }
  if (metrics.api.p95_ms && metrics.api.p95_ms > 1500) {
    add('latency', 'warning', 'Latência alta', `P95 da API em ${metrics.api.p95_ms} ms.`, 'Verifique banco, integrações e servidor.');
  }
  const failedWebhooks = operationalLogs.filter((entry) => entry.type === 'webhook' && entry.status === 'failed').length;
  if (failedWebhooks) {
    add('webhook', 'warning', 'Falhas recentes em webhooks', `${failedWebhooks} falha(s) registradas.`, 'Confira segredo do webhook e payloads recebidos.');
  }
  return alerts;
}

async function listOperationalLogs(sinceMs, params = new URLSearchParams()) {
  const last24h = Date.now() - 86400000;
  const since = new Date(Math.max(Number(sinceMs || 0), last24h)).toISOString();
  const companyId = cleanOptionalUuid(params.get?.('company_id') || params.get?.('tenant') || '');
  const storeId = cleanOptionalUuid(params.get?.('store_id') || '');
  const [auditRows, events, companies, stores] = await Promise.all([
    dbRequest('GET', 'audit_logs', {
      select: 'id,company_id,store_id,action,severity,entity_type,actor_admin_id,ip_address,after_data,created_at',
      created_at: `gte.${since}`,
      ...(companyId ? { company_id: `eq.${companyId}` } : {}),
      ...(storeId ? { store_id: `eq.${storeId}` } : {}),
      order: 'created_at.desc',
      limit: '200'
    }).catch(() => []),
    dbRequest('GET', 'subscription_events', {
      select: 'id,company_id,event_type,description,metadata,created_at',
      created_at: `gte.${since}`,
      ...(companyId ? { company_id: `eq.${companyId}` } : {}),
      order: 'created_at.desc',
      limit: '200'
    }).catch(() => []),
    dbRequest('GET', 'companies', { select: 'id,name', limit: '1500' }).catch(() => []),
    dbRequest('GET', 'stores', { select: 'id,name,slug', limit: '3000' }).catch(() => [])
  ]);
  const companyById = new Map(companies.map((company) => [company.id, company]));
  const storeById = new Map(stores.map((store) => [store.id, store]));
  const auditLogs = auditRows
    .filter((row) => ['critical', 'warning'].includes(row.severity) || /(webhook|backup|billing|subscription|migration|deploy|integration|auth|login|platform\.service|superadmin|password)/i.test(row.action || ''))
    .map((row) => ({
      id: row.id,
      type: operationalLogType(row.action),
      status: row.severity === 'critical' ? 'failed' : row.severity === 'warning' ? 'attention' : 'info',
      severity: row.severity || 'info',
      service: operationalLogService(row.action),
      action: row.action,
      company_id: row.company_id || null,
      company_name: companyById.get(row.company_id)?.name || null,
      store_id: row.store_id || null,
      store_name: storeById.get(row.store_id)?.name || null,
      message: maskSensitiveText(cleanText(row.after_data?.message || row.after_data?.summary || row.entity_type || row.action).slice(0, 500)),
      created_at: row.created_at
    }));
  const eventLogs = events.map((event) => ({
    id: event.id,
    type: operationalLogType(event.event_type),
    status: /failed|past_due|suspended|cancelled/i.test(event.event_type || '') ? 'failed' : 'info',
    severity: /failed|past_due|suspended|cancelled/i.test(event.event_type || '') ? 'warning' : 'info',
    service: 'billing',
    action: event.event_type,
    company_id: event.company_id || null,
    company_name: companyById.get(event.company_id)?.name || null,
    store_id: null,
    store_name: null,
    message: maskSensitiveText(cleanText(event.description || event.event_type).slice(0, 500)),
    created_at: event.created_at
  }));
  const type = cleanSlug(params.get?.('type') || '');
  const status = cleanSlug(params.get?.('status') || '');
  const severity = cleanSlug(params.get?.('severity') || '');
  const service = cleanSlug(params.get?.('service') || '');
  const limit = clampNumber(Number(params.get?.('limit') || 100), 1, 300);
  return [...auditLogs, ...eventLogs]
    .filter((entry) => !type || entry.type === type)
    .filter((entry) => !status || entry.status === status)
    .filter((entry) => !severity || entry.severity === severity)
    .filter((entry) => !service || entry.service === service)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, limit);
}

function operationalLogType(action = '') {
  if (/webhook/i.test(action)) return 'webhook';
  if (/backup/i.test(action)) return 'backup';
  if (/trial_cleanup|job|maintenance/i.test(action)) return 'job';
  if (/billing|subscription|payment/i.test(action)) return 'billing';
  if (/auth|login|password|session/i.test(action)) return 'auth';
  if (/critical|fatal|error|failed/i.test(action)) return 'critical_error';
  if (/platform\.service|restart|systemctl/i.test(action)) return 'service';
  if (/superadmin|platform\.company|platform\.billing/i.test(action)) return 'superadmin_action';
  if (/deploy|migration/i.test(action)) return 'deploy';
  if (/integration/i.test(action)) return 'integration';
  return 'system';
}

function operationalLogService(action = '') {
  if (/abacate|billing|subscription|payment|webhook/i.test(action)) return 'billing';
  if (/backup/i.test(action)) return 'backup';
  if (/trial|job|maintenance/i.test(action)) return 'jobs';
  if (/auth|login|password|session/i.test(action)) return 'auth';
  if (/service|restart|systemctl/i.test(action)) return 'application';
  if (/deploy|migration/i.test(action)) return 'deploy';
  return 'system';
}

function normalizePortuguesePayload(value) {
  if (typeof value === 'string') return normalizePortugueseText(value);
  if (Array.isArray(value)) return value.map(normalizePortuguesePayload);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, normalizePortuguesePayload(entry)]));
  }
  return value;
}

function normalizePortugueseText(value) {
  return String(value)
    .replaceAll('\u00c3\u0080', 'À')
    .replaceAll('\u00c3\u0081', 'Á')
    .replaceAll('\u00c3\u0082', 'Â')
    .replaceAll('\u00c3\u0083', 'Ã')
    .replaceAll('\u00c3\u0087', 'Ç')
    .replaceAll('\u00c3\u0089', 'É')
    .replaceAll('\u00c3\u008a', 'Ê')
    .replaceAll('\u00c3\u008d', 'Í')
    .replaceAll('\u00c3\u0093', 'Ó')
    .replaceAll('\u00c3\u0094', 'Ô')
    .replaceAll('\u00c3\u0095', 'Õ')
    .replaceAll('\u00c3\u009a', 'Ú')
    .replaceAll('\u00c3\u00a0', 'à')
    .replaceAll('\u00c3\u00a1', 'á')
    .replaceAll('\u00c3\u00a2', 'â')
    .replaceAll('\u00c3\u00a3', 'ã')
    .replaceAll('\u00c3\u00a7', 'ç')
    .replaceAll('\u00c3\u00a9', 'é')
    .replaceAll('\u00c3\u00aa', 'ê')
    .replaceAll('\u00c3\u00ad', 'í')
    .replaceAll('\u00c3\u00b3', 'ó')
    .replaceAll('\u00c3\u00b4', 'ô')
    .replaceAll('\u00c3\u00b5', 'õ')
    .replaceAll('\u00c3\u00ba', 'ú');
}

async function readJsonFile(filePath) {
  return JSON.parse(await readFile(filePath, 'utf8'));
}

function sanitizeBackupStatus(value) {
  return ['success', 'failed', 'running'].includes(String(value || '')) ? String(value) : 'unknown';
}

function cleanBackupFileName(value) {
  const file = path.basename(cleanText(value || ''));
  return isRestorableBackupFile(file) ? file : '';
}

function isRestorableBackupFile(value) {
  return /^postgres-[a-zA-Z0-9._-]+\.(dump|sql)(\.gz)?(\.tapronto\.enc)?$/.test(String(value || ''));
}

async function listStoreDomains(storeId) {
  const resolvedStoreId = cleanUuid(storeId);
  if (!resolvedStoreId) return [];
  const domains = await dbRequest('GET', 'store_domains', {
    select: '*',
    store_id: `eq.${resolvedStoreId}`,
    order: 'created_at.desc'
  });
  return domains.map(publicStoreDomain);
}

async function createStoreDomain(data, admin) {
  await assertCompanyUsageLimit(admin, 'custom_domain', 'custom_domains');
  const domain = normalizeDomain(data.domain || '');
  if (!isValidDomain(domain)) throw httpError(422, 'Informe um domínio válido.');
  const [created] = await dbRequest('POST', 'store_domains', {}, {
    store_id: admin.store_id,
    domain,
    status: 'pending',
    verification_token: randomBytes(16).toString('hex')
  }, ['Prefer: return=representation']);
  await recordCompanyUsage({ ...admin, entity_type: 'store_domain', entity_id: created.id }, 'custom_domain', 'custom_domains');
  await audit('store_domain.create', {
    company_id: admin.company_id,
    store_id: admin.store_id,
    actor_admin_id: admin.id,
    entity_type: 'store_domain',
    entity_id: created.id,
    after_data: { domain, status: created.status }
  });
  return publicStoreDomain(created);
}

async function verifyStoreDomain(id, admin) {
  const domainId = cleanUuid(id, 'domínio');
  const [domain] = await dbRequest('GET', 'store_domains', {
    select: '*',
    id: `eq.${domainId}`,
    store_id: `eq.${admin.store_id}`,
    limit: '1'
  });
  if (!domain) throw httpError(404, 'Domínio não encontrado nesta loja.');
  const dnsStatus = await checkStoreDomainDns(domain.domain);
  if (!dnsStatus.ok) {
    const [updatedPending] = await dbRequest('PATCH', 'store_domains', { id: `eq.${domain.id}` }, {
      status: 'pending',
      verified_at: null
    }, ['Prefer: return=representation']);
    throw httpError(422, dnsStatus.message, {
      domain: publicStoreDomain(updatedPending),
      dns: dnsStatus
    });
  }
  const [updated] = await dbRequest('PATCH', 'store_domains', { id: `eq.${domain.id}` }, {
    status: 'verified',
    verified_at: new Date().toISOString()
  }, ['Prefer: return=representation']);
  await audit('store_domain.verify', {
    company_id: admin.company_id,
    store_id: admin.store_id,
    actor_admin_id: admin.id,
    entity_type: 'store_domain',
    entity_id: domain.id,
    after_data: { domain: domain.domain, status: 'verified' }
  });
  return publicStoreDomain(updated);
}

async function deleteStoreDomain(id, admin) {
  const domainId = cleanUuid(id, 'domínio');
  const [domain] = await dbRequest('GET', 'store_domains', {
    select: '*',
    id: `eq.${domainId}`,
    store_id: `eq.${admin.store_id}`,
    limit: '1'
  });
  if (!domain) throw httpError(404, 'Domínio não encontrado nesta loja.');
  await dbRequest('DELETE', 'store_domains', { id: `eq.${domain.id}` }, undefined, ['Prefer: return=minimal']);
  await audit('store_domain.delete', {
    company_id: admin.company_id,
    store_id: admin.store_id,
    actor_admin_id: admin.id,
    entity_type: 'store_domain',
    entity_id: domain.id,
    severity: 'warning',
    before_data: { domain: domain.domain, status: domain.status }
  });
}

function customDomainTargetHost() {
  const explicit = normalizeDomain(process.env.CUSTOM_DOMAIN_TARGET_HOST || process.env.PUBLIC_DOMAIN_TARGET || '');
  if (explicit) return explicit;
  try {
    const base = process.env.PUBLIC_APP_URL || process.env.APP_URL || '';
    const parsed = base ? new URL(base) : null;
    const host = normalizeDomain(parsed?.hostname || '');
    return host || 'taprontomenu.com.br';
  } catch {
    return 'taprontomenu.com.br';
  }
}

function customDomainTargetIp() {
  const configured = String(process.env.CUSTOM_DOMAIN_TARGET_IP || process.env.PUBLIC_SERVER_IP || '').trim();
  if (net.isIP(configured)) return configured;
  return '';
}

function publicStoreDomain(domain = {}) {
  const normalized = normalizeDomain(domain.domain || '');
  const status = cleanSlug(domain.status || 'pending') || 'pending';
  const targetHost = customDomainTargetHost();
  const targetIp = customDomainTargetIp();
  const dnsName = dnsHostLabel(normalized);
  const isRootDomain = dnsName === '@';
  return {
    ...domain,
    domain: normalized,
    status,
    status_label: domainStatusLabel(status),
    setup: {
      recommended_type: 'CNAME',
      name: dnsName,
      value: targetHost,
      fallback_type: targetIp ? 'A' : '',
      fallback_value: targetIp,
      txt_name: `_tapronto.${normalized}`,
      txt_value: domain.verification_token || '',
      is_root_domain: isRootDomain,
      target_host: targetHost,
      target_ip: targetIp,
      example_label: isRootDomain ? 'domínio raiz' : 'subdomínio',
      provider_hint: isRootDomain
        ? 'Para domínio raiz, alguns provedores não aceitam CNAME em @. Se isso acontecer, use o registro A alternativo.'
        : 'Para subdomínio, use preferencialmente CNAME. Exemplo: cardapio apontando para taprontomenu.com.br.'
    }
  };
}

function domainStatusLabel(status) {
  const labels = {
    active: 'Ativo',
    verified: 'Verificado',
    pending: 'Aguardando DNS',
    failed: 'DNS não encontrado',
    error: 'Erro ao verificar'
  };
  return labels[status] || 'Aguardando DNS';
}

function dnsHostLabel(domain) {
  const targetHost = customDomainTargetHost();
  if (domain && targetHost && domain.endsWith(`.${targetHost}`)) {
    return domain.slice(0, -(targetHost.length + 1)) || '@';
  }
  const parts = String(domain || '').split('.').filter(Boolean);
  if (parts.length > 2) return parts.slice(0, -2).join('.');
  return '@';
}

async function checkStoreDomainDns(domain) {
  const normalized = normalizeDomain(domain);
  if (!isValidDomain(normalized)) return { ok: false, status: 'failed', message: 'Domínio inválido.' };
  const targetHost = customDomainTargetHost();
  const targetIp = customDomainTargetIp();
  const details = { cname: [], a: [], target_host: targetHost, target_ip: targetIp };

  try {
    details.cname = (await dns.resolveCname(normalized)).map(normalizeDomain);
  } catch {}

  try {
    details.a = await dns.resolve4(normalized);
  } catch {}

  const cnameMatches = details.cname.some((value) => value === targetHost || value.endsWith(`.${targetHost}`));
  const aMatches = Boolean(targetIp && details.a.includes(targetIp));
  if (cnameMatches || aMatches) {
    return { ok: true, status: 'verified', message: 'DNS encontrado corretamente.', details };
  }

  const expected = targetIp
    ? `Crie um CNAME para ${targetHost} ou um registro A para ${targetIp}.`
    : `Crie um CNAME apontando para ${targetHost}.`;
  return {
    ok: false,
    status: 'pending',
    message: `Ainda não encontramos o apontamento deste domínio. ${expected} Depois aguarde a propagação e tente novamente.`,
    details
  };
}

async function getCompanyById(id) {
  const companyId = cleanUuid(id, 'empresa');
  const [company] = await dbRequest('GET', 'companies', {
    select: '*',
    id: `eq.${companyId}`,
    limit: '1'
  });
  if (!company) throw httpError(404, 'Empresa não encontrada.');
  return company;
}

async function getStoreById(id) {
  const storeId = cleanUuid(id, 'loja');
  const [store] = await dbRequest('GET', 'stores', {
    select: '*',
    id: `eq.${storeId}`,
    limit: '1'
  });
  if (!store) {
    throw httpError(404, 'Loja não encontrada ou indisponível.', { code: 'STORE_NOT_FOUND' });
  }
  return store;
}

function sanitizeCompanyStatus(status) {
  const value = cleanSlug(status || '');
  if (['onboarding', 'active', 'trial', 'payment_pending', 'grace_period', 'past_due', 'blocked', 'suspended', 'cancelled', 'archived'].includes(value)) return value;
  throw httpError(422, 'Status da empresa inválido.');
}

function sanitizeSubscriptionStatus(status) {
  const value = cleanSlug(status || '');
  if (['trial', 'active', 'payment_pending', 'grace_period', 'past_due', 'blocked', 'cancelled', 'expired', 'suspended'].includes(value)) return value;
  return 'active';
}

async function createDefaultSubscription(companyId, planCode) {
  const plan = (await dbRequest('GET', 'subscription_plans', {
    select: 'id',
    code: `eq.${cleanSlug(planCode || 'trial')}`,
    limit: '1'
  }))[0] || (await dbRequest('GET', 'subscription_plans', {
    select: 'id',
    code: 'eq.trial',
    limit: '1'
  }))[0];
  if (!plan) return null;
  const [subscription] = await dbRequest('POST', 'company_subscriptions', {}, {
    company_id: companyId,
    plan_id: plan.id,
    status: 'trial',
    trial_ends_at: new Date(Date.now() + 14 * 86400000).toISOString(),
    current_period_starts_at: new Date().toISOString(),
    current_period_ends_at: new Date(Date.now() + 14 * 86400000).toISOString(),
    next_renewal_at: new Date(Date.now() + 14 * 86400000).toISOString(),
    metadata: { source: 'platform_api' }
  }, ['Prefer: return=representation']);
  return subscription;
}

async function audit(action, data = {}) {
  const reqMeta = data.req ? requestAuditMeta(data.req) : {};
  await dbRequest('POST', 'audit_logs', {}, {
    company_id: data.company_id || null,
    store_id: data.store_id || null,
    actor_admin_id: data.actor_admin_id || null,
    action,
    entity_type: data.entity_type || null,
    entity_id: data.entity_id || null,
    severity: sanitizeAuditSeverity(data.severity),
    request_id: data.request_id || reqMeta.request_id || null,
    ip_address: data.ip_address || reqMeta.ip_address || null,
    user_agent: data.user_agent || reqMeta.user_agent || null,
    before_data: sanitizeAuditPayload(data.before_data),
    after_data: sanitizeAuditPayload(data.after_data)
  }, ['Prefer: return=minimal']).catch((error) => {
    console.warn('Falha ao registrar auditoria:', error.message || error);
  });
}

function requestAuditMeta(req) {
  const forwarded = String(req?.headers?.['x-forwarded-for'] || '').split(',')[0].trim();
  const remote = req?.socket?.remoteAddress || '';
  return {
    request_id: String(req?.headers?.['x-request-id'] || randomBytes(8).toString('hex')).slice(0, 80),
    ip_address: String(forwarded || remote || '').slice(0, 80),
    user_agent: String(req?.headers?.['user-agent'] || '').slice(0, 300)
  };
}

function sanitizeAuditSeverity(value) {
  const severity = cleanSlug(value || 'info');
  return ['debug', 'info', 'warning', 'critical'].includes(severity) ? severity : 'info';
}

function sanitizeAuditPayload(value, depth = 0) {
  if (value === undefined || value === null) return null;
  if (depth > 5) return '[truncated]';
  if (Array.isArray(value)) return value.slice(0, 50).map((entry) => sanitizeAuditPayload(entry, depth + 1));
  if (typeof value !== 'object') return value;
  const blocked = new Set([
    'password',
    'password_hash',
    'current_password',
    'new_password',
    'token',
    'access_token',
    'refresh_token',
    'api_key',
    'apikey',
    'secret',
    'webhook_secret',
    'service_role',
    'authorization'
  ]);
  const output = {};
  for (const [key, entry] of Object.entries(value)) {
    const normalizedKey = key.toLowerCase();
    if ([...blocked].some((blockedKey) => normalizedKey.includes(blockedKey))) {
      output[key] = '[redacted]';
      continue;
    }
    output[key] = sanitizeAuditPayload(entry, depth + 1);
  }
  return output;
}

async function requireAdmin(req, res) {
  const cookies = parseCookies(req);
  const token = cookies[ADMIN_COOKIE];
  const session = await readPersistentSession(token, 'admin');
  if (!session) {
    json(res, 401, { error: 'Faça login para acessar o admin.' });
    return null;
  }
  if (isSupportModeExpired(session.data)) {
    await audit('platform.support.impersonate.expired', {
      req,
      actor_admin_id: session.data?.support_mode?.original_admin_id || session.data?.id || null,
      company_id: session.data?.company_id || null,
      store_id: session.data?.store_id || null,
      entity_type: 'support_session',
      severity: 'warning',
      after_data: {
        target_store_id: session.data?.store_id || null,
        original_admin_email: session.data?.support_mode?.original_admin_email || null
      }
    }).catch(() => {});
    await deleteSession(token);
    json(res, 401, { error: 'Sessão de suporte expirada. Entre novamente.' }, { 'Set-Cookie': clearCookie(ADMIN_COOKIE) });
    return null;
  }
  if (session.data?.session_version !== 2 || !session.data?.store_id) {
    session.data = await enrichAdminSessionData(session.data);
    if (token) {
      await dbRequest('PATCH', 'app_sessions', { token: `eq.${sessionTokenHash(token)}`, type: 'eq.admin' }, {
        company_id: session.data.company_id ? cleanUuid(session.data.company_id) : null,
        store_id: session.data.store_id ? cleanUuid(session.data.store_id) : null,
        data: session.data
      }, ['Prefer: return=minimal']).catch(() => {});
      clearSessionCacheToken(token);
    }
  }
  return session.data;
}

async function enrichAdminSessionData(admin) {
  const access = await getAdminStoreAccess(admin);
  const selectedAccess = access.find((entry) => entry.store_id === admin.store_id) || access[0] || null;
  const activeStore = selectedAccess?.store || null;
  const companyId = activeStore?.company_id || admin.company_id || selectedAccess?.company_id || null;
  return {
    ...admin,
    session_version: 2,
    company_id: companyId,
    store_id: activeStore?.id || null,
    active_store: activeStore ? publicStoreRef(activeStore) : null,
    stores: access.map((entry) => publicStoreRef(entry.store)).filter(Boolean),
    plan_access: companyId ? await getCompanyPlanAccess(companyId) : {}
  };
}

async function requireAdminPermission(req, res, permission) {
  const admin = await requireAdmin(req, res);
  if (!admin) return null;
  if (!adminCan(admin, permission)) {
    json(res, 403, { error: 'Sua conta não tem permissão para acessar esta área.' });
    return null;
  }
  if (isSupportModeAdmin(admin) && supportModeRestrictedPermission(permission)) {
    json(res, 403, { error: 'Modo suporte não permite executar esta ação sensível.' });
    return null;
  }
  if (isSupportModeAdmin(admin) && !['account', 'plan', 'platform'].includes(permission)) {
    if (!admin.store_id || cleanUuid(admin.store_id) !== cleanUuid(admin.support_mode?.target_store_id)) {
      json(res, 403, { error: 'Sessão de suporte sem loja alvo válida.' });
      return null;
    }
    return admin;
  }
  if (!['account', 'plan', 'platform'].includes(permission)) {
    if (!admin.store_id) {
      json(res, 403, { error: 'Sua conta não possui uma loja ativa vinculada.' });
      return null;
    }
    const access = await getAdminStoreAccess(admin);
    const activeAccess = access.find((entry) => entry.store_id === admin.store_id);
    if (!activeAccess) {
      json(res, 403, { error: 'Sua sessão não possui acesso ativo a esta loja. Entre novamente.' });
      return null;
    }
    admin.company_id = activeAccess.company_id;
    admin.active_store = publicStoreRef(activeAccess.store);
    admin.stores = access.map((entry) => publicStoreRef(entry.store)).filter(Boolean);
  }
  if (!['account', 'plan'].includes(permission)) {
    const commercial = await companyCommercialStatus(admin.company_id);
    if (!commercial.canOperate) {
      json(res, 402, { error: commercial.message, commercial_status: commercial.status });
      return null;
    }
  }
  const featureCode = featureForPermission(permission);
  if (featureCode && !(await canUseFeature(admin.company_id, featureCode))) {
    json(res, 403, planErrorPayload('FEATURE_NOT_AVAILABLE', featureBlockedMessage(featureCode), { feature: featureCode }));
    return null;
  }
  return admin;
}

async function requireAdminAnyPermission(req, res, permissions = []) {
  const admin = await requireAdmin(req, res);
  if (!admin) return null;
  const allowed = permissions.some((permission) => adminCan(admin, permission));
  if (!allowed) {
    json(res, 403, { error: 'Sua conta não tem permissão para acessar esta área.' });
    return null;
  }
  const permission = permissions.includes('plan') ? 'plan' : permissions[0];
  if (isSupportModeAdmin(admin) && permissions.some((entry) => supportModeRestrictedPermission(entry))) {
    json(res, 403, { error: 'Modo suporte não permite executar esta ação sensível.' });
    return null;
  }
  if (!admin.store_id) {
    json(res, 403, { error: 'Sua conta não possui uma loja ativa vinculada.' });
    return null;
  }
  const access = await getAdminStoreAccess(admin);
  const activeAccess = access.find((entry) => entry.store_id === admin.store_id);
  if (!activeAccess) {
    json(res, 403, { error: 'Sua sessão não possui acesso ativo a esta loja. Entre novamente.' });
    return null;
  }
  admin.company_id = activeAccess.company_id;
  admin.active_store = publicStoreRef(activeAccess.store);
  admin.stores = access.map((entry) => publicStoreRef(entry.store)).filter(Boolean);
  if (!permissions.includes('account') && !permissions.includes('plan') && !permissions.includes('platform')) {
    const commercial = await companyCommercialStatus(admin.company_id);
    if (!commercial.canOperate) {
      json(res, 402, { error: commercial.message, commercial_status: commercial.status });
      return null;
    }
  }
  const featureCode = featureForPermission(permission);
  if (featureCode && !(await canUseFeature(admin.company_id, featureCode))) {
    json(res, 403, planErrorPayload('FEATURE_NOT_AVAILABLE', featureBlockedMessage(featureCode), { feature: featureCode }));
    return null;
  }
  return admin;
}

async function requirePlatformAdmin(req, res, permission = 'platform.view') {
  const admin = await requireAdmin(req, res);
  if (!admin) return null;
  if (!isPlatformAdmin(admin) || !platformAdminCan(admin, permission)) {
    json(res, 403, { error: 'Sua conta não tem acesso ao painel da plataforma.' });
    return null;
  }
  return admin;
}

const PLATFORM_PERMISSION_GROUPS = Object.freeze({
  view: ['platform.view', 'platform.audit.view', 'platform.services.view'],
  billing: ['platform.billing.manage'],
  customer: ['platform.customer.suspend'],
  services: ['platform.services.manage']
});

function platformPermissions(admin) {
  if (normalizeAdminRole(admin?.role) !== 'superadmin') return [];
  return [
    'platform.view',
    'platform.audit.view',
    'platform.billing.manage',
    'platform.customer.suspend',
    'platform.services.view',
    'platform.services.manage'
  ];
}

function platformAdminCan(admin, permission) {
  if (!permission) return isPlatformAdmin(admin);
  return platformPermissions(admin).includes(permission);
}

function adminPermissions(admin) {
  if (isSupportModeAdmin(admin)) {
    return ['operation', 'orders', 'menu', 'reports', 'tables', 'promotions', 'customers', 'store', 'integrations'];
  }
  const role = normalizeAdminRole(admin?.role);
  if (role === 'superadmin') {
    return ['platform', ...platformPermissions(admin), 'operation', 'orders', 'menu', 'reports', 'tables', 'promotions', 'customers', 'store', 'integrations', 'plan', 'account', 'admin_users'];
  }
  if (role === 'admin') {
    return ['operation', 'orders', 'menu', 'reports', 'tables', 'promotions', 'customers', 'store', 'integrations', 'plan', 'account', 'admin_users'];
  }
  if (role === 'waiter' || role === 'attendant') return ['orders', 'tables', 'customers', 'account'];
  if (role === 'delivery') return ['orders', 'account'];
  if (role === 'kitchen') return ['orders', 'account'];
  return ['account'];
}

function adminCan(admin, permission) {
  return adminPermissions(admin).includes(permission);
}

function featureForPermission(permission) {
  return ({
    operation: 'orders',
    orders: 'orders',
    menu: 'digital_menu',
    reports: 'basic_reports',
    tables: 'tables',
    promotions: 'promotions',
    customers: 'customers',
    store: 'store_settings',
    integrations: 'store_settings'
  })[permission] || null;
}

function adminPlanFeatureCodes() {
  return [
    'orders',
    'digital_menu',
    'menu_categories',
    'basic_reports',
    'advanced_reports',
    'business_insights',
    'tables',
    'promotions',
    'customers',
    'store_settings',
    'admin_users',
    'manual_whatsapp',
    'automatic_whatsapp',
    'print_kitchen',
    'loyalty',
    'reorder',
    'cart_suggestions',
    'custom_domain',
    'priority_support'
  ];
}

function featureBlockedMessage(featureCode) {
  return ({
    tables: 'Mesas e comandas completas estão disponíveis a partir do Profissional. O Essencial permite até 2 mesas para começar.',
    promotions: 'Cupons e campanhas estão disponíveis a partir do Profissional.',
    customers: 'Clientes não estão disponíveis no plano atual.',
    basic_reports: 'Relatórios simples não estão disponíveis no plano atual.',
    advanced_reports: 'Relatórios completos estão disponíveis a partir do Profissional.',
    business_insights: 'Insights avançados estão disponíveis no Premium.',
    digital_menu: 'Cardápio não está disponível no plano atual.',
    menu_categories: 'Novas categorias não estão disponíveis no plano atual.',
    orders: 'Pedidos não estão disponíveis no plano atual.',
    store_settings: 'Configurações da loja não estão disponíveis no plano atual.',
    admin_users: 'Usuários da equipe não estão disponíveis no plano atual.',
    manual_whatsapp: 'WhatsApp manual não está disponível no plano atual.',
    automatic_whatsapp: 'WhatsApp automático está disponível no Profissional como adicional ou incluso no Premium.',
    print_kitchen: 'KDS, impressão e reimpressão estão disponíveis a partir do Profissional.',
    loyalty: 'Fidelidade e recompensas estão disponíveis no Premium.',
    reorder: 'Peça novamente está disponível a partir do Profissional.',
    cart_suggestions: 'Sugestões no carrinho estão disponíveis no Premium.',
    custom_domain: 'Domínio personalizado está disponível no Premium.',
    priority_support: 'Suporte prioritário está disponível no Premium.'
  })[featureCode] || 'Recurso não disponível no plano atual.';
}

async function getCurrentPlan(companyId) {
  const subscription = await getCurrentSubscription(companyId);
  if (!subscription?.plan_id) return { subscription, plan: null };
  const [plan] = await dbRequest('GET', 'subscription_plans', {
    select: '*',
    id: `eq.${subscription.plan_id}`,
    limit: '1'
  }).catch(() => []);
  return { subscription, plan: plan || null };
}

async function canUseFeature(companyId, featureCode) {
  const access = await getCompanyFeatureAccess(companyId, featureCode);
  return access.enabled;
}

async function companyCanUseFeature(companyId, featureCode) {
  return canUseFeature(companyId, featureCode);
}

async function assertFeatureEnabled(companyId, featureCode) {
  const access = await getCompanyFeatureAccess(companyId, featureCode);
  if (!access.enabled) {
    throw httpError(403, featureBlockedMessage(featureCode), planErrorPayload('FEATURE_NOT_AVAILABLE', featureBlockedMessage(featureCode), { feature: featureCode, source: access.source }));
  }
  return access;
}

async function assertPlanLimit(admin, featureCode, usageKey, nextAmount = 1) {
  return assertCompanyUsageLimit(admin, featureCode, usageKey, nextAmount);
}

function planErrorPayload(code, message, extra = {}) {
  return { code, error_code: code, message, ...extra };
}

async function getCompanyFeatureAccess(companyId, featureCode) {
  const resolvedCompanyId = cleanUuid(companyId);
  if (!resolvedCompanyId || !featureCode) return { enabled: true, limit_value: null, source: 'none' };
  const [feature] = await dbRequest('GET', 'platform_features', {
    select: 'id,code',
    code: `eq.${featureCode}`,
    is_active: 'eq.true',
    limit: '1'
  });
  if (!feature) return { enabled: true, limit_value: null, source: 'missing_feature' };
  const [company] = await dbRequest('GET', 'companies', {
    select: 'id,status',
    id: `eq.${resolvedCompanyId}`,
    limit: '1'
  });
  if (!company || ['suspended', 'cancelled', 'archived'].includes(company.status)) {
    return { enabled: false, limit_value: null, source: 'company_status' };
  }
  const overrides = await dbRequest('GET', 'company_feature_overrides', {
    select: 'override_type,limit_value,ends_at,feature_id',
    company_id: `eq.${resolvedCompanyId}`,
    feature_id: `eq.${feature.id}`,
    order: 'created_at.desc',
    limit: '5'
  }).catch(() => []);
  const activeOverride = overrides.find((entry) => !entry.ends_at || new Date(entry.ends_at).getTime() >= Date.now());
  if (activeOverride?.override_type === 'block') return { enabled: false, limit_value: null, source: 'override' };
  if (activeOverride?.override_type === 'allow') return { enabled: true, limit_value: null, source: 'override' };
  if (activeOverride?.override_type === 'limit') {
    return { enabled: true, limit_value: activeOverride.limit_value, source: 'override' };
  }
  const subscription = await getCurrentSubscription(resolvedCompanyId);
  if (!subscription || ['cancelled', 'expired', 'suspended'].includes(subscription.status)) {
    return { enabled: false, limit_value: null, source: 'subscription' };
  }
  if (subscription.status === 'trial' && subscription.trial_ends_at && new Date(subscription.trial_ends_at).getTime() < Date.now()) {
    return { enabled: false, limit_value: null, source: 'trial_expired' };
  }
  if (['payment_pending', 'past_due', 'blocked'].includes(subscription.status)) {
    return { enabled: false, limit_value: null, source: 'subscription_status' };
  }
  if (subscription.status === 'grace_period') {
    const due = subscription.payment_due_at || subscription.current_period_ends_at;
    if (due && new Date(due).getTime() < Date.now()) {
      return { enabled: false, limit_value: null, source: 'grace_period_expired' };
    }
  }
  const [planFeature] = await dbRequest('GET', 'plan_features', {
    select: 'id,is_enabled,limit_value',
    plan_id: `eq.${subscription.plan_id}`,
    feature_id: `eq.${feature.id}`,
    limit: '1'
  });
  return {
    enabled: planFeature?.is_enabled !== false && Boolean(planFeature),
    limit_value: planFeature?.limit_value ?? null,
    source: 'plan'
  };
}

async function getCompanyPlanAccess(companyId) {
  const entries = await Promise.all(adminPlanFeatureCodes().map(async (featureCode) => {
    const access = await getCompanyFeatureAccess(companyId, featureCode).catch(() => ({ enabled: true, limit_value: null, source: 'error' }));
    return [featureCode, access];
  }));
  return Object.fromEntries(entries);
}

async function getCurrentSubscription(companyId) {
  const resolvedCompanyId = cleanUuid(companyId);
  if (!resolvedCompanyId) return null;
  const subscriptions = await listCompanySubscriptions(resolvedCompanyId, 100);
  return pickCurrentCompanySubscription(subscriptions);
}

async function assertCompanyUsageLimit(admin, featureCode, usageKey, nextAmount = 1) {
  if (!admin?.company_id) return;
  const access = await getCompanyFeatureAccess(admin.company_id, featureCode);
  if (!access.enabled) {
    const message = featureBlockedMessage(featureCode);
    throw httpError(403, message, planErrorPayload('FEATURE_NOT_AVAILABLE', message, { feature: featureCode, usage_key: usageKey, source: access.source }));
  }
  const limit = Number(access.limit_value);
  if (!Number.isFinite(limit) || limit <= 0) return;
  const used = await currentUsageForKey(admin, usageKey);
  if (used + nextAmount > limit) {
    const message = `Limite do plano atingido para ${usageLabel(usageKey)}. Uso atual: ${used}/${limit}.`;
    throw httpError(403, message, planErrorPayload('PLAN_LIMIT_REACHED', message, { feature: featureCode, usage_key: usageKey, used, limit, next_amount: nextAmount }));
  }
}

async function currentUsageForKey(admin, usageKey) {
  const storeId = cleanUuid(admin?.store_id);
  const companyId = cleanUuid(admin?.company_id);
  if (!companyId && !storeId) return 0;
  const scopedStoreIds = storeId ? [storeId] : await listCompanyStoreIds(companyId);
  const scopedFilter = scopedStoreIds.length ? uuidInFilter(scopedStoreIds) : null;
  if (usageKey === 'stores') {
    return (await dbRequest('GET', 'stores', { select: 'id', company_id: `eq.${companyId}`, limit: '1000' }).catch(() => [])).length;
  }
  if (usageKey === 'admin_users') {
    const rows = await dbRequest('GET', 'admin_user_store_access', {
      select: 'admin_user_id',
      company_id: `eq.${companyId}`,
      is_active: 'eq.true',
      limit: '1000'
    }).catch(() => []);
    return new Set(rows.map((row) => row.admin_user_id)).size;
  }
  if (usageKey === 'custom_domains') {
    if (!scopedFilter) return 0;
    return (await dbRequest('GET', 'store_domains', {
      select: 'id',
      store_id: scopedFilter,
      status: 'neq.disabled',
      limit: '1000'
    }).catch(() => [])).length;
  }
  const tableByUsage = {
    menu_categories: 'menu_categories',
    menu_items: 'menu_items',
    dining_tables: 'dining_tables',
    promotions: 'promotions',
    customers: 'customers',
    orders: 'orders',
    print_jobs: 'order_print_logs',
    whatsapp_messages: 'order_whatsapp_logs',
    payment_transactions: 'order_payment_events'
  };
  const table = tableByUsage[usageKey];
  if (!table || !scopedFilter) return 0;
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  return (await dbRequest('GET', table, {
    select: 'id',
    store_id: scopedFilter,
    ...(usageKey === 'orders' ? { created_at: `gte.${monthStart.toISOString()}` } : {}),
    limit: '1000'
  }).catch(() => [])).length;
}

async function listCompanyStoreIds(companyId) {
  const resolvedCompanyId = cleanUuid(companyId);
  if (!resolvedCompanyId) return [];
  const rows = await dbRequest('GET', 'stores', {
    select: 'id',
    company_id: `eq.${resolvedCompanyId}`,
    limit: '1000'
  }).catch(() => []);
  return cleanUuidArray(rows.map((row) => row.id));
}

async function recordCompanyUsage(admin, featureCode, usageKey) {
  const companyId = cleanUuid(admin?.company_id);
  if (!companyId) return;
  const [feature] = await dbRequest('GET', 'platform_features', {
    select: 'id',
    code: `eq.${featureCode}`,
    limit: '1'
  }).catch(() => []);
  const now = new Date();
  const periodStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const periodEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const payload = {
    company_id: companyId,
    feature_id: feature?.id || null,
    usage_key: usageKey,
    period_start: periodStart.toISOString().slice(0, 10),
    period_end: periodEnd.toISOString().slice(0, 10),
    used_value: await currentUsageForKey(admin, usageKey),
    metadata: { store_id: admin.store_id || null, updated_by: admin.id || null }
  };
  const existing = await dbRequest('GET', 'company_usage_counters', {
    select: 'id',
    company_id: `eq.${payload.company_id}`,
    usage_key: `eq.${payload.usage_key}`,
    period_start: `eq.${payload.period_start}`,
    period_end: `eq.${payload.period_end}`,
    limit: '1'
  }).catch(() => []);
  if (existing[0]) {
    await dbRequest('PATCH', 'company_usage_counters', { id: `eq.${existing[0].id}` }, payload, ['Prefer: return=minimal']).catch(() => {});
  } else {
    await dbRequest('POST', 'company_usage_counters', {}, payload, ['Prefer: return=minimal']).catch(() => {});
  }
  await recordUsageEvent({
    company_id: companyId,
    store_id: admin.store_id || null,
    feature_id: feature?.id || null,
    usage_key: usageKey,
    entity_type: admin.entity_type || null,
    entity_id: admin.entity_id || null,
    metadata: { updated_by: admin.id || null }
  });
}

async function assertPublicUsageLimitByStore(storeId, featureCode, usageKey, nextAmount = 1) {
  const companyId = await companyIdForStore(storeId);
  if (!companyId) return;
  await assertCompanyUsageLimit({ company_id: companyId, store_id: storeId }, featureCode, usageKey, nextAmount);
}

async function storeHasFeature(storeId, featureCode) {
  const companyId = await companyIdForStore(storeId);
  if (!companyId) return false;
  if (featureCode === 'automatic_whatsapp') {
    const planAccess = await getCompanyFeatureAccess(companyId, featureCode).catch(() => ({ enabled: false }));
    if (planAccess.enabled) return true;
    return Boolean(await getActiveStoreAddon(storeId, 'whatsapp_automatic').catch(() => null));
  }
  return canUseFeature(companyId, featureCode).catch(() => false);
}

async function recordUsageByStore(storeId, featureCode, usageKey, options = {}) {
  const companyId = await companyIdForStore(storeId);
  if (!companyId) return;
  await recordCompanyUsage({
    company_id: companyId,
    store_id: storeId,
    entity_type: options.entity_type || null,
    entity_id: options.entity_id || null
  }, featureCode, usageKey);
}

async function companyIdForStore(storeId) {
  const resolvedStoreId = cleanUuid(storeId);
  if (!resolvedStoreId) return null;
  const [store] = await dbRequest('GET', 'stores', {
    select: 'company_id',
    id: `eq.${resolvedStoreId}`,
    limit: '1'
  }).catch(() => []);
  return cleanUuid(store?.company_id) || null;
}

async function recordUsageEvent(data) {
  const companyId = data.company_id ? cleanUuid(data.company_id) : null;
  if (!companyId) return;
  await dbRequest('POST', 'usage_events', {}, {
    company_id: companyId,
    store_id: data.store_id ? cleanUuid(data.store_id) : null,
    feature_id: data.feature_id ? cleanUuid(data.feature_id) : null,
    usage_key: cleanText(data.usage_key || ''),
    quantity: Math.max(1, Number(data.quantity || 1)),
    entity_type: cleanText(data.entity_type || '') || null,
    entity_id: data.entity_id ? String(data.entity_id).slice(0, 80) : null,
    metadata: isPlainObject(data.metadata) ? data.metadata : {}
  }, ['Prefer: return=minimal']).catch(() => {});
}

function usageLabel(usageKey) {
  return ({
    stores: 'lojas',
    admin_users: 'usuários',
    menu_categories: 'categorias',
    menu_items: 'produtos',
    dining_tables: 'mesas',
    promotions: 'promoções',
    customers: 'clientes',
    orders: 'pedidos no mês'
  })[usageKey] || usageKey;
}

function normalizeAdminRole(role) {
  if (role === 'superadmin') return 'superadmin';
  if (role === 'owner' || role === 'manager') return 'admin';
  if (role === 'waiter' || role === 'attendant' || role === 'delivery' || role === 'kitchen' || role === 'admin') return role;
  return 'admin';
}

function isFullAdminRole(role) {
  return ['admin', 'superadmin'].includes(normalizeAdminRole(role));
}

function isPlatformAdmin(admin) {
  return normalizeAdminRole(admin?.role) === 'superadmin';
}

async function registerCustomer(data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId) || (await getDefaultStore())?.id || null;
  if (data.accept_terms !== true && data.acceptTerms !== true) {
    throw httpError(422, 'Aceite o EULA, os Termos de Uso e a Política de Privacidade para continuar.');
  }
  const customer = sanitizeCustomer(data.customer || data);
  const password = validatePassword(data.password);
  const address = data.address && data.address.street ? sanitizeAddress(data.address) : null;

  const existing = await db('GET', 'customers', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    phone: `eq.${customer.phone}`,
    limit: '1'
  });

  let row;
  if (existing[0]) {
    if (existing[0].password_hash) {
      throw httpError(409, 'Este telefone já possui cadastro. Entre com sua senha.');
    }
    [row] = await db('PATCH', 'customers', { id: `eq.${existing[0].id}` }, {
      ...customer,
      password_hash: hashPassword(password)
    }, ['Prefer: return=representation']);
  } else {
    [row] = await db('POST', 'customers', {}, {
      ...customer,
      store_id: resolvedStoreId,
      password_hash: hashPassword(password)
    }, ['Prefer: return=representation']);
  }

  if (address) await upsertAddress(row.id, address, resolvedStoreId, options);
  clearAdminCustomersCache();

  return createCustomerSession(row);
}

async function loginCustomer(data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId) || (await getDefaultStore())?.id || null;
  const phone = onlyDigits(data.phone);
  const password = String(data.password || '');
  if (!phone || !password) throw httpError(422, 'Informe telefone e senha.');

  const rows = await db('GET', 'customers', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    phone: `eq.${phone}`,
    limit: '1'
  });

  const customer = rows[0];
  if (!customer || !customer.password_hash || !verifyPassword(password, customer.password_hash)) {
    throw httpError(401, 'Telefone ou senha inválidos.');
  }

  await db('PATCH', 'customers', { id: `eq.${customer.id}` }, {
    last_login_at: new Date().toISOString()
  }, ['Prefer: return=representation']);
  clearAdminCustomersCache();

  return createCustomerSession(customer);
}

async function resetCustomerPassword(data, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const phone = onlyDigits(data.phone);
  const orderCode = cleanPublicCode(String(data.order_code || '').replace(/^#/, ''));
  const orderTotal = parseMoneyInput(data.order_total);
  const newPassword = validatePassword(data.new_password);
  if (!phone || !orderCode || orderTotal === null) {
    throw httpError(422, 'Informe telefone, código e total de um pedido.');
  }

  const customers = await db('GET', 'customers', {
    select: 'id,phone',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    phone: `eq.${phone}`,
    limit: '1'
  });
  const customer = customers[0];
  if (!customer) throw httpError(401, 'Não foi possível validar os dados informados.');

  const orders = await db('GET', 'orders', {
    select: 'id,customer_id,public_code,total',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    customer_id: `eq.${customer.id}`,
    public_code: `eq.${orderCode}`,
    limit: '1'
  });
  if (!orders[0] || Math.abs(moneyNumber(orders[0].total) - orderTotal) > 0.01) {
    throw httpError(401, 'Não foi possível validar os dados informados.');
  }

  await db('PATCH', 'customers', { id: `eq.${customer.id}` }, {
    password_hash: hashPassword(newPassword)
  }, ['Prefer: return=minimal']);
}

async function createCustomerSession(customer) {
  const sessionId = await createPersistentSession('customer', customer.id, {
    id: customer.id,
    name: customer.name,
    phone: customer.phone,
    store_id: customer.store_id || null
  });
  return { sessionId, body: { customer: publicCustomer(customer) } };
}

async function requireCustomer(req, res) {
  const session = await readPersistentSession(parseCookies(req)[CUSTOMER_COOKIE], 'customer');
  if (!session) {
    json(res, 401, { error: 'Faça login para acessar sua conta.' });
    return null;
  }
  return session.data;
}

async function getCustomerProfile(customerId, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const [rows, addresses, loyalty] = await Promise.all([
    db('GET', 'customers', {
    select: 'id,store_id,name,phone,email,document,birth_date,notes,created_at,updated_at',
    id: `eq.${customerId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    limit: '1'
    }),
    listCustomerAddresses(customerId, resolvedStoreId, options),
    customerLoyaltyProgress(customerId, options)
  ]);
  if (!rows[0]) throw httpError(404, 'Cliente não encontrado.');
  return { ...rows[0], address: addresses[0] || null, addresses, loyalty };
}

async function customerLoyaltyProgress(customerId, options = {}) {
  const db = options.db || dbRequest;
  const storeId = await getCustomerStoreId(customerId, options);
  const store = await getStoreSettings(storeId, options);
  const program = sanitizeLoyaltyProgram(store.loyalty_program || {});
  const orders = await db('GET', 'orders', {
    select: 'id,total,status,created_at',
    ...(storeId ? { store_id: `eq.${storeId}` } : {}),
    customer_id: `eq.${customerId}`,
    status: 'eq.completed'
  });
  const completedOrders = orders.length;
  const completedRevenue = roundMoney(orders.reduce((sum, order) => sum + moneyNumber(order.total), 0));

  if (!program.is_active) {
    return {
      is_active: false,
      mode: program.mode,
      reward: program.reward,
      completed_orders: completedOrders,
      points: 0,
      target: program.mode === 'points' ? program.points_target : program.orders_required,
      progress: 0,
      remaining: program.mode === 'points' ? program.points_target : program.orders_required
    };
  }

  if (program.mode === 'points') {
    const points = Math.floor(completedRevenue * program.points_per_currency);
    const target = Math.max(1, program.points_target);
    return {
      is_active: true,
      mode: 'points',
      reward: program.reward,
      completed_orders: completedOrders,
      points,
      target,
      progress: Math.min(100, Math.round((points / target) * 100)),
      remaining: Math.max(0, target - points)
    };
  }

  const target = Math.max(1, program.orders_required);
  const currentCycle = completedOrders % target;
  const cycleProgress = currentCycle === 0 && completedOrders > 0 ? target : currentCycle;
  return {
    is_active: true,
    mode: 'orders_reward',
    reward: program.reward,
    completed_orders: completedOrders,
    points: 0,
    target,
    progress: Math.min(100, Math.round((cycleProgress / target) * 100)),
    remaining: cycleProgress >= target ? 0 : target - cycleProgress
  };
}

async function updateCustomerProfile(customerId, data, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const customer = sanitizeCustomer(data.customer || data);
  const payload = { ...customer };
  if (data.password) payload.password_hash = hashPassword(validatePassword(data.password));

  const [updated] = await db('PATCH', 'customers', {
    id: `eq.${customerId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {})
  }, payload, ['Prefer: return=representation']);
  if (!updated) throw httpError(404, 'Cliente não encontrado nesta loja.');
  clearSessionCacheByOwner('customer', customerId);
  if (data.address?.street) {
    await upsertAddress(customerId, sanitizeAddress(data.address), updated.store_id, options);
  }
  return getCustomerProfile(updated.id, updated.store_id, options);
}

async function updateCustomerAddressByOwner(customerId, addressId, data, storeId = null, options = {}) {
  return updateCustomerAddressByAdmin(customerId, addressId, data, storeId, options);
}

async function createCustomerAddressByOwner(customerId, data, storeId = null, options = {}) {
  return createCustomerAddressByAdmin(customerId, data, storeId, options);
}

async function deleteCustomerAddressByOwner(customerId, addressId, storeId = null, options = {}) {
  return deleteCustomerAddressByAdmin(customerId, addressId, storeId, options);
}

async function updateCustomerByAdmin(customerId, data, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const customer = sanitizeCustomer(data.customer || data);
  const payload = { ...customer };
  if (data.password) payload.password_hash = hashPassword(validatePassword(data.password));
  const [updated] = await db('PATCH', 'customers', {
    id: `eq.${customerId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {})
  }, payload, ['Prefer: return=representation']);
  if (!updated) throw httpError(404, 'Cliente não encontrado nesta loja.');
  clearSessionCacheByOwner('customer', customerId);
  return getCustomerProfile(customerId, resolvedStoreId, options);
}

async function deleteCustomerByAdmin(customerId, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  await assertCustomerBelongsToStore(customerId, resolvedStoreId, options);
  await dbRequest('DELETE', 'app_sessions', {
    type: 'eq.customer',
    owner_id: `eq.${customerId}`
  }, undefined, ['Prefer: return=minimal']);
  await db('DELETE', 'customers', {
    id: `eq.${customerId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {})
  }, undefined, ['Prefer: return=minimal']);
}

async function createCustomerAddressByAdmin(customerId, data, storeId = null, options = {}) {
  const resolvedStoreId = cleanUuid(storeId);
  await assertCustomerBelongsToStore(customerId, resolvedStoreId, options);
  const payload = sanitizeAddressWithDefault(data, true);
  await saveCustomerAddress(customerId, payload, resolvedStoreId, options);
  return getCustomerProfile(customerId, resolvedStoreId, options);
}

async function updateCustomerAddressByAdmin(customerId, addressId, data, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  await assertCustomerBelongsToStore(customerId, resolvedStoreId, options);
  const payload = sanitizeAddressWithDefault(data, true);
  if (payload.is_default) {
    await db('PATCH', 'customer_addresses', {
      customer_id: `eq.${customerId}`,
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {})
    }, {
      is_default: false
    }, ['Prefer: return=minimal']);
  }

  const [updated] = await db('PATCH', 'customer_addresses', {
    id: `eq.${addressId}`,
    customer_id: `eq.${customerId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {})
  }, payload, ['Prefer: return=representation']);
  if (!updated) throw httpError(404, 'Endereço não encontrado nesta loja.');
  return getCustomerProfile(customerId, resolvedStoreId, options);
}

async function deleteCustomerAddressByAdmin(customerId, addressId, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  await assertCustomerBelongsToStore(customerId, resolvedStoreId, options);
  await db('DELETE', 'customer_addresses', {
    id: `eq.${addressId}`,
    customer_id: `eq.${customerId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {})
  }, undefined, ['Prefer: return=minimal']);
  const addresses = await listCustomerAddresses(customerId, resolvedStoreId, options);
  if (addresses.length && !addresses.some((address) => address.is_default)) {
    await db('PATCH', 'customer_addresses', { id: `eq.${addresses[0].id}` }, {
      is_default: true
    }, ['Prefer: return=minimal']);
  }
  return getCustomerProfile(customerId, resolvedStoreId, options);
}

async function getDefaultAddress(customerId, options = {}) {
  const rows = await listCustomerAddresses(customerId, null, options);
  return rows[0] || null;
}

async function listCustomerAddresses(customerId, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  return db('GET', 'customer_addresses', {
    select: '*',
    customer_id: `eq.${customerId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    order: 'is_default.desc,created_at.desc'
  });
}

async function assertCustomerBelongsToStore(customerId, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const [customer] = await db('GET', 'customers', {
    select: 'id,store_id',
    id: `eq.${customerId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    limit: '1'
  });
  if (!customer) throw httpError(404, 'Cliente não encontrado nesta loja.');
  return customer;
}

async function resolvePublicStore(req, url) {
  const hostStore = await getStoreByHost(req);
  const slug = cleanSlug(
    url.searchParams.get('store') ||
    url.searchParams.get('loja') ||
    req.headers['x-store-slug'] ||
    storeSlugFromReferer(req) ||
    ''
  );
  const store = hostStore || (slug ? await getStoreBySlug(slug) : await getDefaultStore());
  if (!store) {
    throw httpError(404, 'Loja não encontrada ou indisponível.', { code: 'STORE_NOT_FOUND' });
  }
  return { store };
}

async function resolveTenant(req, url) {
  const context = await resolvePublicStore(req, url);
  return {
    ...context,
    tenant: null,
    db: dbRequest
  };
}

async function adminOperationalOptions(admin) {
  return {
    db: dbRequest,
    tenant: null
  };
}

async function getStoreByHost(req) {
  const forwardedHost = String(req.headers['x-forwarded-host'] || req.headers['x-original-host'] || '').split(',')[0];
  const rawHost = forwardedHost || req.headers.host || '';
  const host = normalizeDomain(String(rawHost).split(':')[0] || '');
  if (!host || ['localhost', '127.0.0.1', '0.0.0.0'].includes(host)) return null;
  const [domain] = await dbRequest('GET', 'store_domains', {
    select: '*',
    domain: `eq.${host}`,
    status: 'in.(verified,active)',
    limit: '1'
  }).catch(() => []);
  if (!domain) return null;
  const [store] = await dbRequest('GET', 'stores', {
    select: '*',
    id: `eq.${domain.store_id}`,
    is_active: 'eq.true',
    limit: '1'
  });
  return store || null;
}

function storeSlugFromReferer(req) {
  try {
    const referer = String(req.headers.referer || '');
    if (!referer) return '';
    const parsed = new URL(referer);
    return firstPublicPathSegment(parsed.pathname);
  } catch {
    return '';
  }
}

function firstPublicPathSegment(pathname) {
  const segment = String(pathname || '').split('/').filter(Boolean)[0] || '';
  if (!segment || ['admin', 'api', 'payment', 'pedidos', 'conta', 'kitchen'].includes(segment)) return '';
  return segment;
}

async function getStoreBySlug(slug) {
  const clean = cleanSlug(slug);
  if (!clean) return null;
  const rows = await dbRequest('GET', 'stores', {
    select: '*',
    slug: `eq.${clean}`,
    is_active: 'eq.true',
    limit: '1'
  });
  return rows[0] || null;
}

async function getDefaultStore() {
  const bySlug = await getStoreBySlug(DEFAULT_STORE_SLUG);
  if (bySlug) return ensureDefaultStoreContent(bySlug);
  return ensureDefaultStoreStructure();
}

async function ensureDefaultStoreStructure() {
  const [existingCompany] = await dbRequest('GET', 'companies', {
    select: '*',
    name: 'eq.Luske Alimentacao',
    limit: '1'
  }).catch(() => []);
  const company = existingCompany || (await dbRequest('POST', 'companies', {}, {
    name: 'Luske Alimentacao',
    status: 'trial'
  }, ['Prefer: return=representation']).catch(() => []))[0];
  if (!company?.id) return null;
  const [store] = await dbRequest('POST', 'stores', {}, {
    company_id: company.id,
    name: 'LSK Burguer',
    slug: DEFAULT_STORE_SLUG,
    description: 'Loja online da LSK Burguer no TáPronto.',
    public_url: `/${DEFAULT_STORE_SLUG}`,
    is_active: true
  }, ['Prefer: return=representation']).catch(async () => {
    return dbRequest('GET', 'stores', {
      select: '*',
      slug: `eq.${DEFAULT_STORE_SLUG}`,
      limit: '1'
    }).catch(() => []);
  });
  if (!store?.id) return null;
  await dbRequest('POST', 'store_settings', {}, {
    store_id: store.id,
    name: store.name,
    slug: store.slug,
    description: store.description,
    payment_methods: ['Pix', 'Cartao na entrega', 'Dinheiro'],
    business_hours: {},
    theme_settings: {},
    print_settings: {},
    integration_settings: {},
    onboarding_completed: false,
    is_open: false
  }, ['Prefer: return=minimal']).catch(() => {});
  return ensureDefaultStoreContent(store);
}

async function ensureDefaultStoreContent(store) {
  if (!store?.id) return store || null;
  const settings = await dbRequest('GET', 'store_settings', {
    select: 'id',
    store_id: `eq.${store.id}`,
    limit: '1'
  }).catch(() => []);
  if (!settings.length) {
    await dbRequest('POST', 'store_settings', {}, {
      store_id: store.id,
      name: store.name || 'LSK Burguer',
      slug: store.slug || DEFAULT_STORE_SLUG,
      description: store.description || 'Loja de demonstração do TáPronto.',
      is_open: true,
      accepts_delivery: true,
      accepts_pickup: true,
      delivery_fee: 5,
      minimum_order: 20,
      payment_methods: ['Pix', 'Cartao na entrega', 'Dinheiro'],
      business_hours: defaultBusinessHours(),
      theme_settings: defaultThemeSettings(),
      print_settings: defaultPrintSettings(),
      integration_settings: defaultIntegrationSettings(),
      onboarding_completed: true
    }, ['Prefer: return=minimal']).catch(() => {});
  }

  const existingItems = await dbRequest('GET', 'menu_items', {
    select: 'id',
    store_id: `eq.${store.id}`,
    limit: '1'
  }).catch(() => []);
  if (existingItems.length) return store;

  const demoCategories = [
    { name: 'Hamburgueres', description: 'Burgers artesanais com pao macio, queijo e molhos da casa.', sort_order: 10 },
    { name: 'Porcoes', description: 'Entradas e acompanhamentos para compartilhar.', sort_order: 20 },
    { name: 'Bebidas', description: 'Opcoes geladas para acompanhar o pedido.', sort_order: 30 }
  ];
  const categoriesByName = new Map();
  for (const category of demoCategories) {
    const [existingCategory] = await dbRequest('GET', 'menu_categories', {
      select: '*',
      store_id: `eq.${store.id}`,
      name: `eq.${category.name}`,
      limit: '1'
    }).catch(() => []);
    const [created] = existingCategory ? [existingCategory] : await dbRequest('POST', 'menu_categories', {}, {
      store_id: store.id,
      name: category.name,
      description: category.description,
      sort_order: category.sort_order,
      is_active: true
    }, ['Prefer: return=representation']).catch(async () => dbRequest('GET', 'menu_categories', {
      select: '*',
      store_id: `eq.${store.id}`,
      name: `eq.${category.name}`,
      limit: '1'
    }).catch(() => []));
    if (created?.id) categoriesByName.set(category.name, created);
  }

  const demoItems = [
    {
      category: 'Hamburgueres',
      name: 'Luske Smash',
      description: 'Dois smash burgers, cheddar cremoso, cebola caramelizada e molho da casa.',
      price: 34.9,
      image_url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80',
      tags: ['smash', 'cheddar'],
      is_featured: true,
      sort_order: 10
    },
    {
      category: 'Hamburgueres',
      name: 'Bacon Supreme',
      description: 'Burger artesanal, bacon crocante, queijo prato, alface, tomate e maionese temperada.',
      price: 39.9,
      image_url: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=900&q=80',
      tags: ['bacon', 'artesanal'],
      is_featured: true,
      sort_order: 20
    },
    {
      category: 'Porcoes',
      name: 'Batata da Casa',
      description: 'Batata crocante com cheddar, bacon e molho especial.',
      price: 24.9,
      image_url: 'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&w=900&q=80',
      tags: ['porcao'],
      is_featured: false,
      sort_order: 10
    },
    {
      category: 'Bebidas',
      name: 'Refrigerante Lata',
      description: 'Escolha o sabor nas observacoes do pedido.',
      price: 7.9,
      image_url: '',
      tags: ['bebida'],
      is_featured: false,
      sort_order: 10
    }
  ];
  for (const item of demoItems) {
    const category = categoriesByName.get(item.category);
    if (!category?.id) continue;
    await dbRequest('POST', 'menu_items', {}, {
      store_id: store.id,
      category_id: category.id,
      name: item.name,
      description: item.description,
      price: item.price,
      image_url: item.image_url || null,
      tags: item.tags,
      is_featured: item.is_featured,
      is_available: true,
      sort_order: item.sort_order
    }, ['Prefer: return=minimal']).catch(() => {});
  }
  clearMenuCache();
  clearStoreSettingsCache();
  return store;
}

async function getStoreSettings(storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = (storeId ? cleanUuid(storeId) : '') || (await getDefaultStore())?.id || '';
  const cacheKey = `${resolvedStoreId || 'default'}:${options.tenant?.id || 'central'}`;
  const now = Date.now();
  const cached = storeSettingsCache.get(cacheKey);
  if (cached && cached.expiresAt > now) {
    return cached.data;
  }
  const query = {
    select: '*',
    order: 'created_at.asc',
    limit: '1'
  };
  if (resolvedStoreId) query.store_id = `eq.${resolvedStoreId}`;
  const [rows, storeRows] = await Promise.all([
    db('GET', 'store_settings', query),
    resolvedStoreId
      ? db('GET', 'stores', { select: '*', id: `eq.${resolvedStoreId}`, limit: '1' }).catch(() => [])
      : Promise.resolve([])
  ]);
  const canonicalStore = storeRows[0] || null;

  const store = rows[0] || {
    store_id: resolvedStoreId || null,
    name: 'Menu da Casa',
    page_title: 'TáPronto',
    description: 'Pedido rápido pelo TáPronto.',
    whatsapp_number: STORE_WHATSAPP_NUMBER,
    is_open: true,
    accepts_delivery: true,
    accepts_pickup: true,
    delivery_fee: 0,
    delivery_neighborhood_fees: defaultNeighborhoodFees(),
    minimum_order: 0,
    payment_methods: ['Pix', 'Cartão', 'Dinheiro'],
    business_hours: defaultBusinessHours(),
    loyalty_program: defaultLoyaltyProgram(),
    theme_settings: defaultThemeSettings(),
    print_settings: defaultPrintSettings(),
    onboarding_completed: false
  };
  const normalized = {
    ...store,
    name: store.name || canonicalStore?.name || 'Menu da Casa',
    slug: canonicalStore?.slug || store.slug || '',
    public_url: canonicalStore?.public_url || (canonicalStore?.slug ? `/${canonicalStore.slug}` : store.public_url || ''),
    store_is_active: canonicalStore?.is_active !== false,
    seo_index_enabled: canonicalStore?.seo_index_enabled === true,
    company_id: canonicalStore?.company_id || store.company_id || null,
    delivery_neighborhood_fees: isPlainObject(store.delivery_neighborhood_fees) ? store.delivery_neighborhood_fees : defaultNeighborhoodFees(),
    business_hours: isPlainObject(store.business_hours) ? store.business_hours : defaultBusinessHours(),
    loyalty_program: sanitizeLoyaltyProgram(store.loyalty_program || {}),
    theme_settings: sanitizeThemeSettings(store.theme_settings || {}),
    print_settings: sanitizePrintSettings(store.print_settings || {}),
    integration_settings: sanitizeIntegrationSettings(store.integration_settings || {})
  };
  storeSettingsCache.set(cacheKey, {
    data: normalized,
    expiresAt: now + STORE_SETTINGS_CACHE_MS
  });
  return normalized;
}

async function getPublicBootstrap(storeId, options = {}) {
  const cacheKey = cleanUuid(storeId) || 'default';
  const now = Date.now();
  const cacheKeyWithTenant = options.tenant?.id ? `${cacheKey}:tenant:${options.tenant.id}` : cacheKey;
  const cached = publicBootstrapCache.get(cacheKeyWithTenant);
  if (cached && cached.expiresAt > now) {
    return cached.data;
  }

  const [store, categories] = await Promise.all([
    getStoreSettings(storeId, options),
    getMenu(false, storeId, options)
  ]);
  const data = { store: publicStore(store), categories };
  publicBootstrapCache.set(cacheKeyWithTenant, {
    data,
    expiresAt: now + PUBLIC_BOOTSTRAP_CACHE_MS
  });
  return data;
}

function clearPublicBootstrapCache() {
  publicBootstrapCache.clear();
}

function clearStoreSettingsCache() {
  storeSettingsCache.clear();
  clearPublicBootstrapCache();
}

function clearMenuCache() {
  menuCache.clear();
  clearPublicBootstrapCache();
}

function clearAdminCustomersCache() {
  adminCustomersCache = null;
}

function clearAdminPromotionsCache() {
  adminPromotionsCache = null;
}

function clearAdminTablesCache() {
  adminTablesCache = null;
}

function clearAdminUsersCache() {
  adminUsersCache = null;
}

async function updateStoreSettings(data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const current = await getStoreSettings(storeId, options);
  const resolvedStoreId = cleanUuid(storeId) || current.store_id || null;
  const payload = sanitizeStore(data);
  const seoIndexEnabled = 'seo_index_enabled' in payload ? payload.seo_index_enabled === true : current.seo_index_enabled === true;
  delete payload.seo_index_enabled;
  const nextSlug = cleanSlug(payload.slug || current.slug || payload.name || '');
  if (!nextSlug) throw httpError(422, 'Informe o caminho público da loja.');
  if (reservedPublicSlugs().has(nextSlug)) {
    throw httpError(422, 'Este caminho público é reservado. Escolha outro.');
  }
  const existingStore = await getStoreBySlug(nextSlug);
  if (existingStore && existingStore.id !== resolvedStoreId) {
    throw httpError(409, 'Este caminho público já está sendo usado por outra loja.');
  }
  payload.slug = nextSlug;

  if (resolvedStoreId) {
    const storePayload = {
      ...(payload.name ? { name: payload.name } : {}),
      slug: nextSlug,
      public_url: `/${nextSlug}`,
      seo_index_enabled: seoIndexEnabled,
      ...(payload.description !== undefined ? { description: payload.description || null } : {})
    };
    await dbRequest('PATCH', 'stores', { id: `eq.${resolvedStoreId}` }, storePayload, ['Prefer: return=minimal']);
    if (options.tenant) {
      await db('PATCH', 'stores', { id: `eq.${resolvedStoreId}` }, storePayload, ['Prefer: return=minimal']).catch(() => {});
    }
  }

  let result;
  if (current.id) {
    result = await db('PATCH', 'store_settings', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation']);
  } else {
    result = await db('POST', 'store_settings', {}, { ...payload, store_id: resolvedStoreId }, ['Prefer: return=representation']);
  }
  storeSettingsCache.delete(resolvedStoreId || 'default');
  publicBootstrapCache.clear();
  return result;
}

async function updateLoyaltyProgram(data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const current = await getStoreSettings(storeId, options);
  const resolvedStoreId = cleanUuid(storeId) || current.store_id || null;
  const payload = {
    loyalty_program: sanitizeLoyaltyProgram(data.loyalty_program || data)
  };

  if (current.id) {
    const [updated] = await db('PATCH', 'store_settings', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation']);
    return {
      ...updated,
      loyalty_program: sanitizeLoyaltyProgram(updated.loyalty_program || {})
    };
  }

  const [created] = await db('POST', 'store_settings', {}, {
    store_id: resolvedStoreId,
    name: current.name || 'Menu da Casa',
    slug: current.slug || 'menu-da-casa',
    description: current.description || 'Pedido rápido pelo TáPronto.',
    whatsapp_number: current.whatsapp_number || STORE_WHATSAPP_NUMBER,
    loyalty_program: payload.loyalty_program
  }, ['Prefer: return=representation']);
  return {
    ...created,
    loyalty_program: sanitizeLoyaltyProgram(created.loyalty_program || {})
  };
}

async function updatePrintSettings(data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const current = await getStoreSettings(storeId, options);
  const resolvedStoreId = cleanUuid(storeId) || current.store_id || null;
  const payload = {
    print_settings: sanitizePrintSettings(data.print_settings || data)
  };

  if (current.id) {
    const [updated] = await db('PATCH', 'store_settings', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation']);
    return {
      ...updated,
      print_settings: sanitizePrintSettings(updated.print_settings || {})
    };
  }

  const [created] = await db('POST', 'store_settings', {}, {
    store_id: resolvedStoreId,
    name: current.name || 'Menu da Casa',
    slug: current.slug || 'menu-da-casa',
    description: current.description || 'Pedido rápido pelo TáPronto.',
    whatsapp_number: current.whatsapp_number || STORE_WHATSAPP_NUMBER,
    print_settings: payload.print_settings
  }, ['Prefer: return=representation']);
  return {
    ...created,
    print_settings: sanitizePrintSettings(created.print_settings || {})
  };
}

async function updateIntegrationSettings(data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const current = await getStoreSettings(storeId, options);
  const resolvedStoreId = cleanUuid(storeId) || current.store_id || null;
  const nextSettings = mergeIntegrationSettings(current.integration_settings || {}, data.integration_settings || data);
  const payload = {
    integration_settings: protectIntegrationSettings(nextSettings)
  };

  if (current.id) {
    const [updated] = await db('PATCH', 'store_settings', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation']);
    return {
      ...updated,
      integration_settings: sanitizeIntegrationSettings(updated.integration_settings || {})
    };
  }

  const [created] = await db('POST', 'store_settings', {}, {
    store_id: resolvedStoreId,
    name: current.name || 'Menu da Casa',
    slug: current.slug || 'menu-da-casa',
    description: current.description || 'Pedido rápido pelo TáPronto.',
    whatsapp_number: current.whatsapp_number || STORE_WHATSAPP_NUMBER,
    integration_settings: payload.integration_settings
  }, ['Prefer: return=representation']);
  return {
    ...created,
    integration_settings: sanitizeIntegrationSettings(created.integration_settings || {})
  };
}

async function testIntegrations(data = {}, storeId, options = {}) {
  const store = await getStoreSettings(storeId, options);
  const settings = data.integration_settings
    ? mergeIntegrationSettings(store.integration_settings || {}, data.integration_settings)
    : sanitizeIntegrationSettings(store.integration_settings || {});
  const whatsappCheck = await testWhatsappIntegration(settings.whatsapp).catch((error) => ({
    ok: false,
    message: error.message || 'Não foi possível testar o WhatsApp.'
  }));
  return {
    whatsapp: {
      enabled: settings.whatsapp.enabled,
      provider: settings.whatsapp.provider,
      ok: whatsappCheck.ok,
      message: whatsappCheck.message
    },
    pix: {
      enabled: settings.pix.enabled,
      provider: settings.pix.provider,
      ok: settings.pix.enabled ? Boolean(settings.pix.apiKey) : true,
      message: settings.pix.enabled
        ? (settings.pix.apiKey ? 'Abacate Pay pronta para gerar Pix online.' : 'Informe a API key da Abacate Pay.')
        : 'Pix online desativado.'
    }
  };
}

async function testWhatsappIntegration(settings) {
  if (!settings.enabled) return { ok: true, message: 'WhatsApp automático desativado.' };
  if (settings.provider === 'whatsevolution' || isWhatsEvolutionUrl(settings.apiUrl)) {
    return {
      ok: false,
      message: 'Configuração antiga de WhatsApp detectada. Use Evolution Go pela Central e conecte a loja por QR Code.'
    };
  }
  const hasConfig = Boolean(settings.phoneNumberId || settings.apiUrl || settings.accessToken);
  return {
    ok: hasConfig,
    message: hasConfig ? 'Configuração de WhatsApp pronta para envio via provedor.' : 'Preencha a configuração do WhatsApp.'
  };
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 7000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (error) {
    if (error.name === 'AbortError') {
      throw httpError(504, 'Tempo esgotado ao testar o provedor. Verifique URL, instância e conexão da API.');
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function setStoreOpen(isOpen, storeId, options = {}) {
  const db = options.db || dbRequest;
  const current = await getStoreSettings(storeId, options);
  const resolvedStoreId = cleanUuid(storeId) || current.store_id || null;
  const payload = { is_open: Boolean(isOpen) };

  if (current.id) {
    const [updated] = await db('PATCH', 'store_settings', { id: `eq.${current.id}` }, payload, ['Prefer: return=representation']);
    return updated;
  }

  const [created] = await db('POST', 'store_settings', {}, {
    store_id: resolvedStoreId,
    name: current.name || 'Menu da Casa',
    slug: current.slug || 'menu-da-casa',
    description: current.description || 'Pedido rápido pelo TáPronto.',
    whatsapp_number: current.whatsapp_number || STORE_WHATSAPP_NUMBER,
    accepts_delivery: current.accepts_delivery !== false,
    accepts_pickup: current.accepts_pickup !== false,
    delivery_fee: current.delivery_fee || 0,
    delivery_neighborhood_fees: current.delivery_neighborhood_fees || defaultNeighborhoodFees(),
    minimum_order: current.minimum_order || 0,
    payment_methods: current.payment_methods || ['Pix', 'Cartão', 'Dinheiro'],
    business_hours: current.business_hours || defaultBusinessHours(),
    ...payload
  }, ['Prefer: return=representation']);
  return created;
}

async function getMenu(admin, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId) || (await getDefaultStore())?.id || '';
  const cacheKey = `${admin ? 'admin' : 'public'}:${resolvedStoreId || 'default'}:${options.tenant?.id || 'central'}`;
  const now = Date.now();
  const cached = menuCache.get(cacheKey);
  if (cached && cached.expiresAt > now) {
    return cached.data;
  }
  const [categories, items, groups, modifiers] = await Promise.all([
    db('GET', 'menu_categories', {
      select: admin ? '*' : 'id,name,description,sort_order',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      ...(admin ? {} : { is_active: 'eq.true' }),
      order: 'sort_order.asc,name.asc'
    }),
    db('GET', 'menu_items', {
      select: admin ? '*' : 'id,category_id,name,description,price,image_url,tags,is_featured,is_available,sort_order',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      ...(admin ? {} : { is_available: 'eq.true' }),
      order: 'sort_order.asc,name.asc'
    }),
    db('GET', 'menu_modifier_groups', {
      select: '*',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      order: 'sort_order.asc,name.asc'
    }),
    db('GET', 'menu_modifiers', {
      select: '*',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      ...(admin ? {} : { is_available: 'eq.true' }),
      order: 'sort_order.asc,name.asc'
    })
  ]);

  const modifiersByGroup = new Map(groups.map((group) => [group.id, []]));
  for (const modifier of modifiers) {
    modifiersByGroup.get(modifier.group_id)?.push(modifier);
  }

  const groupsByItem = new Map();
  for (const group of groups) {
    if (!groupsByItem.has(group.menu_item_id)) groupsByItem.set(group.menu_item_id, []);
    groupsByItem.get(group.menu_item_id).push({
      ...group,
      modifiers: modifiersByGroup.get(group.id) || []
    });
  }

  const byCategory = new Map(categories.map((category) => [category.id, { ...category, items: [] }]));
  for (const item of items) {
    byCategory.get(item.category_id)?.items.push({
      ...item,
      modifier_groups: groupsByItem.get(item.id) || []
    });
  }

  const menu = [...byCategory.values()];
  menuCache.set(cacheKey, {
    data: menu,
    expiresAt: now + MENU_CACHE_MS
  });
  return menu;
}

async function createOrder(req, data, options = {}) {
  if (!options.inTransaction && (!options.db || options.db === dbRequest)) {
    return withLocalTransaction((db) => createOrder(req, data, { ...options, db, inTransaction: true }));
  }
  const db = options.db || dbRequest;
  const storeId = cleanUuid(options.storeId) || (await getDefaultStore())?.id || null;
  const commercial = await companyCommercialStatusByStore(storeId);
  if (!commercial.canOperate) throw httpError(402, commercial.message);
  await assertPublicUsageLimitByStore(storeId, 'orders', 'orders');
  const session = await readPersistentSession(parseCookies(req)[CUSTOMER_COOKIE], 'customer');
  let fulfillmentMethod = ['delivery', 'pickup', 'counter', 'table', 'tab'].includes(data.fulfillment_method)
    ? data.fulfillment_method
    : 'delivery';
  const customer = sanitizeOrderCustomer(data.customer || {}, fulfillmentMethod);
  const address = fulfillmentMethod === 'delivery' ? sanitizeAddress(data.address || {}) : null;
  const paymentMethod = cleanText(data.payment_method || '');
  const paymentDetails = sanitizePaymentDetails(data.payment_details || {}, paymentMethod);
  const notes = cleanText(data.notes || '');
  const couponCode = cleanText(data.coupon_code || '').toUpperCase().replace(/[^A-Z0-9_-]/g, '');
  const requestedItems = Array.isArray(data.items) ? data.items : [];

  if (!paymentMethod) throw httpError(422, 'Informe a forma de pagamento.');
  if (requestedItems.length === 0) throw httpError(422, 'Inclua ao menos um item no pedido.');

  const itemIds = cleanUuidArray(requestedItems.map((item) => item.id));
  if (itemIds.length === 0) throw httpError(422, 'Itens do pedido inválidos.');

  const menuItems = await db('GET', 'menu_items', {
    select: '*',
    ...(storeId ? { store_id: `eq.${storeId}` } : {}),
    id: uuidInFilter(itemIds),
    is_available: 'eq.true'
  });

  const menuById = new Map(menuItems.map((item) => [item.id, item]));
  const modifierCatalog = await loadModifierCatalog(itemIds, storeId, options);
  const orderItems = requestedItems.map((requested) => {
    const menuItem = menuById.get(cleanUuid(requested.id));
    if (!menuItem) throw httpError(422, 'Um item escolhido não está mais disponível.');

    const quantity = clampInteger(requested.quantity, 1, 99);
    const selectedModifiers = options.skipModifierValidation
      ? validateExistingSelectedModifiers(menuItem.id, requested.modifier_ids, modifierCatalog)
      : validateSelectedModifiers(menuItem.id, requested.modifier_ids, modifierCatalog);
    const basePrice = moneyNumber(menuItem.price);
    const modifiersTotal = selectedModifiers.reduce((sum, modifier) => sum + moneyNumber(modifier.price_delta), 0);
    const unitPrice = roundMoney(basePrice + modifiersTotal);
    return {
      menu_item_id: menuItem.id,
      item_snapshot: {
        id: menuItem.id,
        name: menuItem.name,
        description: menuItem.description,
        price: basePrice,
        category_id: menuItem.category_id,
        modifiers: selectedModifiers.map((modifier) => ({
          id: modifier.id,
          group_id: modifier.group_id,
          group_name: modifier.group_name,
          name: modifier.name,
          price_delta: moneyNumber(modifier.price_delta)
        })),
        image_url: menuItem.image_url,
        tags: menuItem.tags || []
      },
      quantity,
      unit_price: unitPrice,
      total: roundMoney(unitPrice * quantity),
      notes: cleanText(requested.notes || '')
    };
  });

  const store = await getStoreSettings(storeId, options);
  if (store.is_open === false && !options.allowClosedStore) {
    throw httpError(423, 'A loja está fechada no momento e não está aceitando pedidos.');
  }
  const integrationSettings = sanitizeIntegrationSettings(store.integration_settings || {});
  if (isOnlinePixPayment(paymentMethod) && !integrationSettings.pix.enabled) {
    throw httpError(422, 'Pix online não está ativo nesta loja.');
  }
  if (isOnlineCardPayment(paymentMethod) && !integrationSettings.card.enabled) {
    throw httpError(422, 'Cartão online não está ativo nesta loja.');
  }
  const subtotal = roundMoney(orderItems.reduce((sum, item) => sum + item.total, 0));
  const deliveryFee = fulfillmentMethod === 'delivery' ? deliveryFeeForAddress(store, address) : 0;
  const table = ['table', 'tab'].includes(fulfillmentMethod) ? await requireActiveDiningTable(data.dining_table_id || data.table_code, storeId, options) : null;
  let tab = null;
  if (fulfillmentMethod === 'tab') {
    tab = await requireOpenTab(data.customer_tab_id, table?.id, storeId, options);
  } else if (fulfillmentMethod === 'table' && table?.id) {
    tab = await findOpenTabForTable(table.id, storeId, options);
    if (tab) fulfillmentMethod = 'tab';
  }
  let customerRow = null;
  if (session?.data?.id) {
    customerRow = await getCustomerProfile(session.data.id, storeId, options).catch((error) => {
      if (options.tenant && error.status === 404) return null;
      throw error;
    });
  }
  if (!customerRow && customer.phone) {
    customerRow = await upsertCustomer(customer, storeId, options);
  }
  let coupon = couponCode ? await findActivePromotion(couponCode, {
    db,
    storeId,
    subtotal,
    deliveryFee,
    customer: customerRow,
    items: orderItems
  }) : null;
  if (coupon && typeof db.lockPromotion === 'function') {
    await db.lockPromotion(coupon.id);
    coupon = await findActivePromotion(couponCode, {
      db, storeId, subtotal, deliveryFee, customer: customerRow, items: orderItems
    });
  }
  const discount = coupon ? couponDiscountAmount(coupon, subtotal, deliveryFee) : 0;
  const total = roundMoney(Math.max(0, subtotal + deliveryFee - discount));
  validatePaymentDetails(paymentDetails, paymentMethod, total);
  validateOnlinePaymentAmount(paymentMethod, integrationSettings, total);

  if (fulfillmentMethod === 'delivery') {
    await upsertAddress(customerRow.id, address, storeId, options);
  }

  const paymentAccessToken = isOnlinePaymentMethod(paymentMethod) ? randomBytes(32).toString('base64url') : '';
  const orderPayload = {
    store_id: storeId,
    public_code: createPublicCode(),
    customer_id: customerRow?.id || null,
    status: 'new',
    fulfillment_method: fulfillmentMethod,
    payment_method: paymentMethod,
    customer_snapshot: customer,
    address_snapshot: address,
    dining_table_id: table?.id || null,
    customer_tab_id: tab?.id || null,
    table_snapshot: table ? { id: table.id, name: table.name, code: table.code } : null,
    tab_snapshot: tab ? { id: tab.id, name: tab.name, customer_name: tab.customer_name } : null,
    subtotal,
    delivery_fee: deliveryFee,
    discount,
    total,
    notes,
    payment_details: paymentDetails,
    financial_status: isOnlinePixPayment(paymentMethod) ? 'pending' : 'pending',
    payment_provider: onlinePaymentProviderFor(paymentMethod, integrationSettings),
    promotion_code: coupon?.code || null
    ,payment_access_token_hash: paymentAccessToken ? createHash('sha256').update(paymentAccessToken).digest('hex') : null
    ,payment_access_expires_at: paymentAccessToken ? new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() : null
  };

  const [order] = await db('POST', 'orders', {}, orderPayload, ['Prefer: return=representation']);
  clearAdminOrdersCache(storeId);
  await recordUsageByStore(storeId, 'orders', 'orders', { entity_type: 'order', entity_id: order.id });
  const itemsWithOrder = orderItems.map((item) => ({ ...item, order_id: order.id, store_id: storeId }));
  await db('POST', 'order_items', {}, itemsWithOrder, ['Prefer: return=representation']);
  const whatsappMessage = buildWhatsappMessage(store, order, itemsWithOrder, customer, address);
  const [updatedOrder] = await db('PATCH', 'orders', { id: `eq.${order.id}` }, {
    whatsapp_message: whatsappMessage
  }, ['Prefer: return=representation']);

  let payment = null;
  let finalOrder = updatedOrder;
  if (isOnlinePixPayment(paymentMethod)) {
    payment = await createPixPayment(updatedOrder, { ...options, paymentAccessToken });
    finalOrder = payment.order;
  } else if (isOnlineCardPayment(paymentMethod)) {
    payment = await createCardPayment(updatedOrder, { ...options, paymentAccessToken });
    finalOrder = payment.order;
  }
  const hasOnlinePayment = isOnlinePaymentMethod(paymentMethod);
  // O cupom só é consumido depois que uma tentativa online foi criada com sucesso.
  // Pedidos offline continuam consumindo-o imediatamente.
  if (coupon) {
    await db('PATCH', 'promotions', { id: `eq.${coupon.id}` }, {
      used_count: Number(coupon.used_count || 0) + 1
    }, ['Prefer: return=minimal']);
    await db('POST', 'promotion_redemptions', {}, {
      promotion_id: coupon.id,
      order_id: order.id,
      customer_id: customerRow?.id || null,
      store_id: storeId,
      status: hasOnlinePayment ? 'reserved' : 'consumed'
    }, ['Prefer: return=minimal']);
    clearAdminPromotionsCache();
  }
  if (!hasOnlinePayment) {
    await sendOrderStatusWhatsapp(order.id, 'new', { manual: false, db, tenant: options.tenant }).catch(() => null);
  }
  if (['table', 'tab'].includes(fulfillmentMethod)) clearAdminTablesCache();
  if (customerRow?.id) clearAdminCustomersCache();

  const existingOrders = await db('GET', 'orders', {
    select: 'id', store_id: `eq.${storeId}`, order: 'created_at.asc', limit: '2'
  });
  if (existingOrders.length === 1 && existingOrders[0]?.id === order.id) {
    await recordMarketingMilestone('first_order_received', {
      db,
      companyId: commercial.company_id,
      storeId,
      idempotencyKey: `first_order_received:${storeId}`,
      properties: { fulfillment_method: fulfillmentMethod, payment_method: paymentMethod }
    });
  }

  return {
    order: { ...stripPaymentAccessSecrets(finalOrder), items: itemsWithOrder, ...(paymentAccessToken ? { payment_access_token: paymentAccessToken } : {}) },
    payment,
    whatsapp_url: null,
    whatsapp_message: whatsappMessage
  };
}

async function loadModifierCatalog(itemIds, storeId, options = {}) {
  const db = options.db || dbRequest;
  const cleanItemIds = cleanUuidArray(itemIds);
  const resolvedStoreId = cleanUuid(storeId);
  if (cleanItemIds.length === 0) return { groupsByItem: new Map(), modifiersById: new Map() };
  const groups = await db('GET', 'menu_modifier_groups', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    menu_item_id: uuidInFilter(cleanItemIds),
    order: 'sort_order.asc,name.asc'
  });

  if (groups.length === 0) {
    return { groupsByItem: new Map(), modifiersById: new Map() };
  }

  const groupIds = cleanUuidArray(groups.map((group) => group.id));
  const modifiers = await db('GET', 'menu_modifiers', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    group_id: uuidInFilter(groupIds),
    is_available: 'eq.true',
    order: 'sort_order.asc,name.asc'
  });

  const groupsByItem = new Map();
  const groupsById = new Map();
  for (const group of groups) {
    groupsById.set(group.id, group);
    if (!groupsByItem.has(group.menu_item_id)) groupsByItem.set(group.menu_item_id, []);
    groupsByItem.get(group.menu_item_id).push(group);
  }

  const modifiersById = new Map();
  for (const modifier of modifiers) {
    const group = groupsById.get(modifier.group_id);
    if (!group) continue;
    modifiersById.set(modifier.id, {
      ...modifier,
      menu_item_id: group.menu_item_id,
      group_name: group.name,
      min_choices: group.min_choices,
      max_choices: group.max_choices,
      is_required: group.is_required
    });
  }

  return { groupsByItem, modifiersById };
}

function validateSelectedModifiers(menuItemId, selectedIds, catalog) {
  const ids = cleanUuidArray(selectedIds || []);
  const selected = ids.map((id) => {
    const modifier = catalog.modifiersById.get(id);
    if (!modifier || modifier.menu_item_id !== menuItemId) {
      throw httpError(422, 'Adicional inválido para um item escolhido.');
    }
    return modifier;
  });

  const selectedByGroup = new Map();
  for (const modifier of selected) {
    if (!selectedByGroup.has(modifier.group_id)) selectedByGroup.set(modifier.group_id, []);
    selectedByGroup.get(modifier.group_id).push(modifier);
  }

  const groups = catalog.groupsByItem.get(menuItemId) || [];
  for (const group of groups) {
    const count = selectedByGroup.get(group.id)?.length || 0;
    if (group.is_required && count < Number(group.min_choices || 1)) {
      throw httpError(422, `Escolha ${group.name}.`);
    }
    if (count < Number(group.min_choices || 0)) {
      throw httpError(422, `Escolha ao menos ${group.min_choices} opção(ões) em ${group.name}.`);
    }
    if (Number(group.max_choices || 0) > 0 && count > Number(group.max_choices)) {
      throw httpError(422, `Escolha no máximo ${group.max_choices} opção(ões) em ${group.name}.`);
    }
  }

  return selected;
}

function validateExistingSelectedModifiers(menuItemId, selectedIds, catalog) {
  const ids = cleanUuidArray(selectedIds || []);
  return ids.map((id) => {
    const modifier = catalog.modifiersById.get(id);
    if (!modifier || modifier.menu_item_id !== menuItemId) {
      throw httpError(422, 'Adicional inválido para um item escolhido.');
    }
    return modifier;
  });
}

async function ensureUniqueModifierGroupName(menuItemId, name, options = {}) {
  const db = options.db || dbRequest;
  const existing = await db('GET', 'menu_modifier_groups', {
    select: 'id,name',
    menu_item_id: `eq.${menuItemId}`
  });
  const normalized = normalizeName(name);
  if (existing.some((group) => normalizeName(group.name) === normalized)) {
    throw httpError(409, 'Já existe um grupo com esse nome neste produto.');
  }
}

async function ensureUniqueModifierName(groupId, name, options = {}) {
  const db = options.db || dbRequest;
  const existing = await db('GET', 'menu_modifiers', {
    select: 'id,name',
    group_id: `eq.${groupId}`
  });
  const normalized = normalizeName(name);
  if (existing.some((modifier) => normalizeName(modifier.name) === normalized)) {
    throw httpError(409, 'Já existe uma opção com esse nome neste grupo.');
  }
}

async function upsertCustomer(customer, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId) || null;
  const customerProfile = { ...(customer || {}) };
  const existing = await db('GET', 'customers', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    phone: `eq.${customerProfile.phone}`,
    limit: '1'
  });

  if (existing[0]) {
    if (!customerProfile.document) delete customerProfile.document;
    const [updated] = await db('PATCH', 'customers', { id: `eq.${existing[0].id}` }, customerProfile, ['Prefer: return=representation']);
    return updated;
  }

  const [created] = await db('POST', 'customers', {}, {
    ...customerProfile,
    store_id: resolvedStoreId
  }, ['Prefer: return=representation']);
  return created;
}

async function upsertAddress(customerId, address, storeId, options = {}) {
  if (!address) return null;
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId) || null;

  const existing = await db('GET', 'customer_addresses', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    customer_id: `eq.${customerId}`
  });

  const payload = { ...address, store_id: resolvedStoreId, customer_id: customerId, is_default: true };
  const sameAddress = existing.find((row) => addressKey(row) === addressKey(address));

  if (existing.length > 0) {
    await db('PATCH', 'customer_addresses', { customer_id: `eq.${customerId}` }, {
      is_default: false
    }, ['Prefer: return=minimal']);
  }

  if (sameAddress) {
    const [updated] = await db('PATCH', 'customer_addresses', { id: `eq.${sameAddress.id}` }, {
      ...payload,
      label: sameAddress.label || payload.label || 'Principal'
    }, ['Prefer: return=representation']);
    return updated;
  }

  const [created] = await db('POST', 'customer_addresses', {}, payload, ['Prefer: return=representation']);
  return created;
}

async function saveCustomerAddress(customerId, address, storeId = null, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId) || cleanUuid(address.store_id) || await getCustomerStoreId(customerId, options);
  if (address.is_default) {
    await db('PATCH', 'customer_addresses', {
      customer_id: `eq.${customerId}`,
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {})
    }, {
      is_default: false
    }, ['Prefer: return=minimal']);
  }
  const [created] = await db('POST', 'customer_addresses', {}, {
    ...address,
    store_id: resolvedStoreId,
    customer_id: customerId
  }, ['Prefer: return=representation']);
  return created;
}

async function getCustomerStoreId(customerId, options = {}) {
  const db = options.db || dbRequest;
  const rows = await db('GET', 'customers', {
    select: 'store_id',
    id: `eq.${customerId}`,
    limit: '1'
  });
  return cleanUuid(rows[0]?.store_id) || null;
}

async function createPersistentSession(type, ownerId, data) {
  const token = randomBytes(32).toString('hex');
  const tokenHash = sessionTokenHash(token);
  const expiresAt = new Date(Date.now() + SESSION_MAX_AGE * 1000).toISOString();
  await dbRequest('POST', 'app_sessions', {}, {
    token: tokenHash,
    type,
    owner_id: ownerId,
    company_id: data.company_id ? cleanUuid(data.company_id) : null,
    store_id: data.store_id ? cleanUuid(data.store_id) : null,
    data,
    expires_at: expiresAt
  }, ['Prefer: return=minimal']);
  sessionCache.set(`${type}:${token}`, {
    session: { token: tokenHash, type, owner_id: ownerId, data, expires_at: expiresAt },
    expiresAt: Date.now() + SESSION_CACHE_MS
  });
  return token;
}

async function readPersistentSession(token, expectedType) {
  if (!token) return null;
  const tokenHash = sessionTokenHash(token);
  const cacheKey = `${expectedType}:${token}`;
  const cached = sessionCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.session;
  }
  const rows = await dbRequest('GET', 'app_sessions', {
    select: '*',
    token: `eq.${tokenHash}`,
    type: `eq.${expectedType}`,
    limit: '1'
  });
  const session = rows[0];
  if (!session) return null;

  if (new Date(session.expires_at).getTime() <= Date.now()) {
    await deleteSession(token);
    return null;
  }

  if (new Date(session.expires_at).getTime() - Date.now() < SESSION_RENEW_MS) {
    await dbRequest('PATCH', 'app_sessions', { token: `eq.${tokenHash}` }, {
      expires_at: new Date(Date.now() + SESSION_MAX_AGE * 1000).toISOString()
    }, ['Prefer: return=minimal']);
  }

  sessionCache.set(cacheKey, {
    session,
    expiresAt: Date.now() + SESSION_CACHE_MS
  });
  return session;
}

async function deleteSession(token) {
  if (!token) return;
  clearSessionCacheToken(token);
  await dbRequest('DELETE', 'app_sessions', { token: `eq.${sessionTokenHash(token)}` }, undefined, ['Prefer: return=minimal']);
}

function sessionTokenHash(token) {
  return createHash('sha256').update(String(token || '')).digest('hex');
}

async function startPlatformSupportImpersonation(req, admin, data = {}) {
  await assertPlatformDangerConfirmation(req, admin, data, 'CONFIRMAR');
  const storeId = cleanUuid(data.store_id || data.storeId, 'loja');
  const [store] = await dbRequest('GET', 'stores', {
    select: '*',
    id: `eq.${storeId}`,
    limit: '1'
  });
  if (!store) throw httpError(404, 'Loja alvo não encontrada.');
  const company = await getCompanyById(store.company_id);
  const ttlSeconds = clampNumber(Number(data.ttl_seconds || data.ttlSeconds || 30 * 60), 1, 60 * 60);
  const expiresAt = new Date(Date.now() + ttlSeconds * 1000).toISOString();
  const originalToken = parseCookies(req)[ADMIN_COOKIE] || '';
  const accessStore = publicStoreRef(store);
  const supportSession = {
    id: admin.id,
    name: admin.name,
    email: admin.email,
    role: 'admin',
    company_id: company.id,
    store_id: store.id,
    session_version: 2,
    active_store: accessStore,
    stores: [accessStore],
    plan_access: await getCompanyPlanAccess(company.id).catch(() => ({})),
    support_mode: {
      active: true,
      started_at: new Date().toISOString(),
      expires_at: expiresAt,
      original_admin_id: admin.id,
      original_admin_email: admin.email,
      original_session_token: originalToken,
      target_company_id: company.id,
      target_company_name: company.name,
      target_store_id: store.id,
      target_store_name: store.name,
      target_store_slug: store.slug
    }
  };
  const token = await createPersistentSession('admin', admin.id, supportSession);
  await audit('platform.support.impersonate.start', {
    req,
    actor_admin_id: admin.id,
    company_id: company.id,
    store_id: store.id,
    entity_type: 'support_session',
    severity: 'warning',
    after_data: {
      target_company_id: company.id,
      target_company_name: company.name,
      target_store_id: store.id,
      target_store_slug: store.slug,
      expires_at: expiresAt
    }
  });
  return { token, admin: supportSession, expires_at: expiresAt };
}

async function endPlatformSupportImpersonation(req, admin) {
  if (!isSupportModeAdmin(admin)) {
    throw httpError(422, 'Nenhum modo suporte ativo nesta sessão.');
  }
  const cookies = parseCookies(req);
  const supportToken = cookies[ADMIN_COOKIE] || '';
  const restoreToken = admin.support_mode?.original_session_token || '';
  const restoreSession = restoreToken ? await readPersistentSession(restoreToken, 'admin').catch(() => null) : null;
  await audit('platform.support.impersonate.end', {
    req,
    actor_admin_id: admin.support_mode?.original_admin_id || admin.id,
    company_id: admin.company_id || null,
    store_id: admin.store_id || null,
    entity_type: 'support_session',
    severity: 'info',
    after_data: {
      target_company_id: admin.support_mode?.target_company_id || admin.company_id || null,
      target_store_id: admin.support_mode?.target_store_id || admin.store_id || null,
      original_admin_email: admin.support_mode?.original_admin_email || null,
      ended_at: new Date().toISOString()
    }
  });
  await deleteSession(supportToken);
  return { restore_token: restoreSession ? restoreToken : '' };
}

function clearSessionCacheToken(token) {
  for (const key of sessionCache.keys()) {
    if (key.endsWith(`:${token}`)) sessionCache.delete(key);
  }
}

function clearSessionCacheByOwner(type, ownerId) {
  for (const [key, entry] of sessionCache.entries()) {
    if (key.startsWith(`${type}:`) && entry.session?.owner_id === ownerId) {
      sessionCache.delete(key);
    }
  }
}

function clearAdminStoreAccessCache(adminId) {
  const cleanAdminId = cleanUuid(adminId);
  if (!cleanAdminId) {
    adminStoreAccessCache.clear();
    return;
  }
  for (const key of adminStoreAccessCache.keys()) {
    if (key.startsWith(`${cleanAdminId}:`)) adminStoreAccessCache.delete(key);
  }
}

async function cleanExpiredSessions() {
  if (!DATABASE_URL) return;
  try {
    await dbRequest('DELETE', 'app_sessions', {
      expires_at: `lte.${new Date().toISOString()}`
    }, undefined, ['Prefer: return=minimal']);
  } catch (error) {
    console.warn('Não foi possível limpar sessões expiradas:', error.message);
  }
}

function enforceRateLimit(req, method, pathname) {
  const rule = rateLimitRule(method, pathname);
  if (!rule) return;

  const now = Date.now();
  const client = clientKey(req);
  const key = `${rule.name}:${client}`;
  const bucket = rateLimitBuckets.get(key) || { count: 0, resetAt: now + rule.windowMs };

  if (bucket.resetAt <= now) {
    bucket.count = 0;
    bucket.resetAt = now + rule.windowMs;
  }

  bucket.count += 1;
  rateLimitBuckets.set(key, bucket);

  if (bucket.count > rule.max) {
    const retryAfter = Math.max(1, Math.ceil((bucket.resetAt - now) / 1000));
    throw httpError(429, `Muitas tentativas. Tente novamente em ${retryAfter} segundos.`);
  }

  if (rateLimitBuckets.size > 1000) {
    for (const [entryKey, entry] of rateLimitBuckets.entries()) {
      if (entry.resetAt <= now) rateLimitBuckets.delete(entryKey);
    }
  }
}

function enforceAuthenticatedRequestOrigin(req, method) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) return;
  const cookies = parseCookies(req);
  if (!cookies[ADMIN_COOKIE] && !cookies[CUSTOMER_COOKIE]) return;

  const fetchSite = cleanText(req.headers['sec-fetch-site'] || '').toLowerCase();
  if (fetchSite === 'cross-site') throw httpError(403, 'Origem da requisição não autorizada.');

  const source = cleanText(req.headers.origin || req.headers.referer || '');
  if (!source) return; // Clientes não-browser continuam suportados; cookies HttpOnly não ficam expostos a eles.
  let sourceOrigin = '';
  try {
    sourceOrigin = new URL(source).origin.toLowerCase();
  } catch {
    throw httpError(403, 'Origem da requisição inválida.');
  }
  const trusted = trustedRequestOrigins(req);
  if (!trusted.has(sourceOrigin)) throw httpError(403, 'Origem da requisição não autorizada.');
}

function trustedRequestOrigins(req) {
  const origins = new Set();
  const add = (value) => {
    const text = String(value || '').trim();
    if (!text) return;
    try { origins.add(new URL(text).origin.toLowerCase()); } catch {}
  };
  add(requestOrigin(req));
  add(process.env.APP_URL);
  add(process.env.PUBLIC_APP_URL);
  add(process.env.PANEL_BASE_URL);
  add(process.env.PLATFORM_BASE_URL);
  return origins;
}

function rateLimitRule(method, pathname) {
  if (method === 'POST' && pathname === '/api/admin/login') return limitRule('admin-login', 8, 120 * 1000);
  if (method === 'POST' && pathname === '/api/admin/login/2fa') return limitRule('admin-login-2fa', 8, 10 * 60 * 1000);
  if (method === 'POST' && pathname === '/api/customer/login') return limitRule('customer-login', 10, 15 * 60 * 1000);
  if (method === 'POST' && pathname === '/api/customer/reset-password') return limitRule('customer-reset', 5, 30 * 60 * 1000);
  if (method === 'POST' && pathname === '/api/portal/recover-password') return limitRule('admin-recover', 5, 30 * 60 * 1000);
  if (method === 'POST' && pathname === '/api/portal/resend-activation') return limitRule('activation-resend', 3, 15 * 60 * 1000);
  if (method === 'POST' && pathname === '/api/orders') return limitRule('order-create', 20, 10 * 60 * 1000);
  if (method === 'GET' && pathname === '/api/payments/order') return limitRule('payment-status', 120, 10 * 60 * 1000);
  if (method === 'POST' && pathname === '/api/payments/regenerate-pix') return limitRule('payment-regenerate', 5, 15 * 60 * 1000);
  if (method === 'POST' && pathname === '/api/payments/webhook') return limitRule('payment-webhook', 300, 60 * 1000);
  if (method === 'POST' && pathname === '/api/admin/setup') return limitRule('admin-setup', 3, 120 * 1000);
  if (method === 'POST' && pathname === '/api/portal/signup') return limitRule('portal-signup', 5, 120 * 1000);
  if (method === 'POST' && pathname === '/api/admin/uploads') return limitRule('admin-upload', 30, 10 * 60 * 1000);
  if (method === 'POST' && pathname === '/api/analytics/access') return limitRule('access-analytics', 60, 10 * 60 * 1000);
  return null;
}

function limitRule(name, max, windowMs) {
  return { name, max, windowMs };
}

function clientKey(req) {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return forwarded || req.socket.remoteAddress || 'local';
}

function absoluteUrl(req, relativePath) {
  const proto = String(req.headers['x-forwarded-proto'] || '').split(',')[0] || (COOKIE_SECURE ? 'https' : 'http');
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0] || `${HOST}:${PORT}`;
  return `${proto}://${host}${relativePath}`;
}

function absoluteFromBase(base, relativePath = '/') {
  const normalizedPath = String(relativePath || '/').startsWith('/') ? String(relativePath || '/') : `/${relativePath}`;
  return `${String(base || '').replace(/\/+$/, '')}${normalizedPath}`;
}

function absoluteAppUrl(req, relativePath = '/') {
  const base = panelBaseUrl() || process.env.APP_URL || process.env.PUBLIC_APP_URL || absoluteUrl(req, '/');
  return absoluteFromBase(base, relativePath);
}

function panelBaseUrl() {
  return subdomainBaseUrl('PANEL_BASE_URL', 'PANEL_HOSTS', 'app.taprontomenu.com.br');
}

function platformBaseUrl() {
  return subdomainBaseUrl('PLATFORM_BASE_URL', 'PLATFORM_HOSTS', 'central.taprontomenu.com.br');
}

function helpBaseUrl() {
  return subdomainBaseUrl('HELP_BASE_URL', 'HELP_HOSTS', 'ajuda.taprontomenu.com.br');
}

function guidesBaseUrl() {
  return subdomainBaseUrl('GUIDES_BASE_URL', 'GUIDES_HOSTS', 'guias.taprontomenu.com.br');
}

function subdomainBaseUrl(baseEnv, hostsEnv, fallbackHost) {
  const explicit = String(process.env[baseEnv] || '').trim().replace(/\/+$/, '');
  if (explicit) return explicit;
  const host = csvEnv(hostsEnv)[0] || fallbackHost;
  return /^https?:\/\//i.test(host) ? host.replace(/\/+$/, '') : `https://${host}`;
}

function absolutePublicUrl(relativePath = '/') {
  const base = process.env.PUBLIC_APP_URL || publicBaseUrl() || process.env.APP_URL || `http://${HOST}:${PORT}`;
  return absoluteFromBase(base, relativePath);
}

function absolutePanelUrl(relativePath = '/') {
  return absoluteFromBase(panelBaseUrl(), relativePath);
}

function absolutePlatformUrl(relativePath = '/') {
  return absoluteFromBase(platformBaseUrl(), relativePath);
}

function formatDateTimePt(value) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleString('pt-BR', {
    timeZone: 'America/Sao_Paulo',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

async function listCustomerOrders(customerId, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const orders = await db('GET', 'orders', {
    select: '*',
    customer_id: `eq.${customerId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    order: 'created_at.desc',
    limit: '30'
  });

  return (await attachOrderItems(orders, options)).map(stripPaymentAccessSecrets);
}

async function listOrders(storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const cacheKey = `${resolvedStoreId || 'default'}:${options.tenant?.id || 'central'}`;
  const reconciled = await reconcileRecentOnlinePaymentsForStore(resolvedStoreId, options);
  if (reconciled) adminOrdersCache.delete(cacheKey);
  const cached = adminOrdersCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.data;
  const orders = await db('GET', 'orders', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    archived_at: 'is.null',
    order: 'created_at.desc',
    limit: '100'
  });

  const withItems = await attachOrderItems(orders, options);
  const data = (await attachOrderIntegrationLogs(withItems, options))
    .filter((order) => !isOnlineOrderAwaitingRelease(order))
    .map(stripPaymentAccessSecrets);
  adminOrdersCache.set(cacheKey, {
    data,
    expiresAt: Date.now() + ADMIN_ORDERS_CACHE_MS
  });
  return data;
}

async function reconcileRecentOnlinePaymentsForStore(storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const cacheKey = `${resolvedStoreId || 'default'}:${options.tenant?.id || 'central'}`;
  const now = Date.now();
  const lastCheck = paymentReconciliationCache.get(cacheKey) || 0;
  if (now - lastCheck < 12000) return false;
  paymentReconciliationCache.set(cacheKey, now);
  const orders = await db('GET', 'orders', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    payment_provider: 'eq.abacatepay',
    payment_transaction_id: 'not.is.null',
    financial_status: 'in.(pending,failed,expired)',
    archived_at: 'is.null',
    order: 'created_at.desc',
    limit: '8'
  }).catch((error) => {
    console.warn('Falha ao buscar pedidos para conciliação:', error.message || error);
    return [];
  });
  let changed = false;
  for (const order of orders) {
    const updated = await reconcileOrderPaymentWithProvider(order, options).catch((error) => {
      console.warn('Falha ao conciliar pedido online:', error.message || error);
      return null;
    });
    if (updated && sanitizeFinancialStatus(updated.financial_status) !== sanitizeFinancialStatus(order.financial_status)) {
      changed = true;
    }
  }
  return changed;
}

function clearAdminOrdersCache(storeId) {
  const resolvedStoreId = cleanUuid(storeId);
  if (!resolvedStoreId) {
    adminOrdersCache.clear();
    return;
  }
  for (const key of adminOrdersCache.keys()) {
    if (key === resolvedStoreId || key.startsWith(`${resolvedStoreId}:`)) {
      adminOrdersCache.delete(key);
    }
  }
}

async function attachOrderIntegrationLogs(orders, options = {}) {
  const db = options.db || dbRequest;
  if (!orders.length) return orders;
  const ids = cleanUuidArray(orders.map((order) => order.id));
  if (!ids.length) return orders;
  const [whatsappLogs, paymentEvents] = await Promise.all([
    db('GET', 'order_whatsapp_logs', {
      select: 'id,order_id,order_status,delivery_status,provider,error_message,created_at',
      order_id: uuidInFilter(ids),
      order: 'created_at.desc',
      limit: String(Math.min(ids.length * 3, 180))
    }),
    db('GET', 'order_payment_events', {
      select: 'id,order_id,provider,financial_status,amount,created_at',
      order_id: uuidInFilter(ids),
      order: 'created_at.desc',
      limit: String(Math.min(ids.length * 3, 180))
    })
  ]);
  const whatsByOrder = new Map();
  const paymentsByOrder = new Map();
  for (const log of whatsappLogs) {
    if ((whatsByOrder.get(log.order_id) || []).length >= 2) continue;
    if (!whatsByOrder.has(log.order_id)) whatsByOrder.set(log.order_id, []);
    whatsByOrder.get(log.order_id).push(log);
  }
  for (const event of paymentEvents) {
    if ((paymentsByOrder.get(event.order_id) || []).length >= 2) continue;
    if (!paymentsByOrder.has(event.order_id)) paymentsByOrder.set(event.order_id, []);
    paymentsByOrder.get(event.order_id).push(event);
  }
  return orders.map((order) => ({
    ...order,
    whatsapp_logs: whatsByOrder.get(order.id) || [],
    payment_events: paymentsByOrder.get(order.id) || []
  }));
}

async function createPrintLog(data, options = {}) {
  const db = options.db || dbRequest;
  const payload = sanitizePrintLog(data);
  const [log] = await db('POST', 'order_print_logs', {}, payload, ['Prefer: return=representation']);
  return log;
}

async function sendOrderStatusWhatsapp(orderId, status, options = {}) {
  const db = options.db || dbRequest;
  const manual = Boolean(options.manual);
  const [order] = await db('GET', 'orders', {
    select: '*',
    id: `eq.${orderId}`,
    limit: '1'
  });
  if (!order) throw httpError(404, 'Pedido não encontrado.');
  const targetStatus = cleanText(status || order.status);
  const featureCode = manual ? 'manual_whatsapp' : 'automatic_whatsapp';
  if (manual && await storeHasFeature(order.store_id, 'automatic_whatsapp')) {
    throw httpError(403, 'Este plano usa WhatsApp automático. O envio manual fica disponível apenas no Teste grátis e no Essencial.', planErrorPayload('FEATURE_NOT_AVAILABLE', 'WhatsApp manual não disponível neste plano.', { feature: 'manual_whatsapp' }));
  }
  await assertPublicUsageLimitByStore(order.store_id, featureCode, 'whatsapp_messages');
  if (!manual) {
    const existing = await db('GET', 'order_whatsapp_logs', {
      select: 'id,delivery_status,created_at,error_message',
      order_id: `eq.${order.id}`,
      order_status: `eq.${targetStatus}`,
      is_manual: 'eq.false',
      limit: '1'
    });
    if (existing[0] && existing[0].delivery_status !== 'failed') return existing[0];
  }
  const store = await getStoreSettings(order.store_id, options);
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  if (!manual && targetStatus === 'new') {
    const storePhone = whatsappRecipientPhone(store.whatsapp_number || STORE_WHATSAPP_NUMBER || '');
    const integration = await getStoreWhatsappIntegration(order.store_id);
    if (integration && normalizeWhatsappIntegrationStatus(integration.status) === 'connected') {
      const storeOrderMessage = cleanText(order.whatsapp_message || '') || orderStatusWhatsappMessage(store, order, targetStatus);
      if (!storePhone) {
        return createWhatsappLogWithUsage(order, targetStatus, storeOrderMessage, featureCode, {
          recipient_phone: '',
          delivery_status: 'skipped',
          error_message: 'WhatsApp dos pedidos não configurado na loja.',
          is_manual: false,
          provider: 'evolution_go'
        }, options);
      }
      try {
        const providerResult = await sendEvolutionStoreMessage(store, integration, storePhone, storeOrderMessage, {
          orderId: order.id,
          messageType: 'order_created'
        });
        return createWhatsappLogWithUsage(order, targetStatus, storeOrderMessage, featureCode, {
          recipient_phone: storePhone,
          delivery_status: 'sent',
          provider: 'evolution_go',
          provider_message_id: providerResult.id,
          is_manual: false
        }, options);
      } catch (error) {
        return createWhatsappLogWithUsage(order, targetStatus, storeOrderMessage, featureCode, {
          recipient_phone: storePhone,
          delivery_status: 'failed',
          error_message: error.message || 'Falha no WhatsApp automático.',
          is_manual: false,
          provider: 'evolution_go'
        }, options);
      }
    }
    const platformWhatsapp = await getPlatformWhatsappSettings();
    if (platformWhatsapp.is_active && platformWhatsapp.has_api_key && platformWhatsapp.base_url && !integrations.whatsapp.enabled) {
      return createWhatsappLogWithUsage(order, targetStatus, cleanText(order.whatsapp_message || ''), featureCode, {
        recipient_phone: storePhone,
        delivery_status: 'skipped',
        error_message: 'WhatsApp automático ainda não conectado por QR Code.',
        is_manual: false,
        provider: 'evolution_go'
      }, options);
    }
  }
  const phone = whatsappRecipientPhone(order.customer_snapshot?.phone || '');
  const message = orderStatusWhatsappMessage(store, order, targetStatus);
  if (!phone) {
    return createWhatsappLogWithUsage(order, targetStatus, message, featureCode, {
      recipient_phone: '',
      delivery_status: 'skipped',
      error_message: 'Pedido sem telefone do cliente.',
      is_manual: manual,
      provider: integrations.whatsapp.provider
    }, options);
  }
  if (!manual) {
    const integration = await getStoreWhatsappIntegration(order.store_id);
    if (integration && normalizeWhatsappIntegrationStatus(integration.status) === 'connected') {
      try {
        const providerResult = await sendEvolutionStoreMessage(store, integration, phone, message, {
          orderId: order.id,
          messageType: 'order_status'
        });
        return createWhatsappLogWithUsage(order, targetStatus, message, featureCode, {
          recipient_phone: phone,
          delivery_status: 'sent',
          provider: 'evolution_go',
          provider_message_id: providerResult.id,
          is_manual: false
        }, options);
      } catch (error) {
        return createWhatsappLogWithUsage(order, targetStatus, message, featureCode, {
          recipient_phone: phone,
          delivery_status: 'failed',
          error_message: error.message || 'Falha no WhatsApp automático.',
          is_manual: false,
          provider: 'evolution_go'
        }, options);
      }
    }
    const platformWhatsapp = await getPlatformWhatsappSettings();
    if (platformWhatsapp.is_active && platformWhatsapp.has_api_key && platformWhatsapp.base_url && !integrations.whatsapp.enabled) {
      return createWhatsappLogWithUsage(order, targetStatus, message, featureCode, {
        recipient_phone: phone,
        delivery_status: 'skipped',
        error_message: 'WhatsApp automático ainda não conectado por QR Code.',
        is_manual: false,
        provider: 'evolution_go'
      }, options);
    }
  }
  if (manual) {
    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    const log = await createWhatsappLogWithUsage(order, targetStatus, message, featureCode, {
      recipient_phone: phone,
      delivery_status: 'manual',
      provider: 'wa.me',
      provider_message_id: `manual_${Date.now()}`,
      is_manual: true
    }, options);
    return { ...log, whatsapp_url: whatsappUrl };
  }
  if (!integrations.whatsapp.enabled) {
    return createWhatsappLogWithUsage(order, targetStatus, message, featureCode, {
      recipient_phone: phone,
      delivery_status: 'skipped',
      error_message: 'WhatsApp automático desativado.',
      is_manual: manual,
      provider: integrations.whatsapp.provider
    }, options);
  }

  try {
    const providerResult = await sendWhatsappViaProvider(integrations.whatsapp, phone, message);
    return createWhatsappLogWithUsage(order, targetStatus, message, featureCode, {
      recipient_phone: phone,
      delivery_status: 'sent',
      provider: integrations.whatsapp.provider,
      provider_message_id: providerResult.id,
      is_manual: manual
    }, options);
  } catch (error) {
    return createWhatsappLogWithUsage(order, targetStatus, message, featureCode, {
      recipient_phone: phone,
      delivery_status: 'failed',
      error_message: error.message || 'Falha no provedor de WhatsApp.',
      is_manual: manual,
      provider: integrations.whatsapp.provider
    }, options);
  }
}

async function createWhatsappLog(order, status, message, data, options = {}) {
  const db = options.db || dbRequest;
  const payload = {
    store_id: order.store_id || null,
    order_id: order.id,
    order_status: status,
    recipient_phone: data.recipient_phone || null,
    message,
    delivery_status: data.delivery_status || 'pending',
    provider: data.provider || null,
    provider_message_id: data.provider_message_id || null,
    error_message: data.error_message || null,
    is_manual: Boolean(data.is_manual)
  };
  const [log] = await db('POST', 'order_whatsapp_logs', {}, payload, ['Prefer: return=representation']);
  return log;
}

async function createWhatsappLogWithUsage(order, status, message, featureCode, data, options = {}) {
  const log = await createWhatsappLog(order, status, message, data, options);
  await recordUsageByStore(order.store_id, featureCode, 'whatsapp_messages', { entity_type: 'order', entity_id: order.id });
  return log;
}

async function sendWhatsappViaProvider(settings, phone, message) {
  if (settings.provider === 'whatsevolution' || isWhatsEvolutionUrl(settings.apiUrl)) {
    throw httpError(410, 'Configuração antiga de WhatsApp removida. Use Evolution Go pela Central e conecte a loja por QR Code.');
  }
  if (settings.provider === 'mock' || !settings.apiUrl) {
    return { id: `mock_${Date.now()}` };
  }
  if (settings.provider === 'official') {
    const url = settings.apiUrl || `https://graph.facebook.com/v19.0/${settings.phoneNumberId}/messages`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${settings.accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: phone,
        type: 'text',
        text: { body: message }
      })
    });
    const data = await safeResponse(response);
    if (!response.ok) throw httpError(response.status, whatsappProviderError('Erro no provedor de WhatsApp.', data), data);
    return { id: data?.messages?.[0]?.id || data?.id || `wa_${Date.now()}` };
  }
  const response = await fetch(settings.apiUrl, {
    method: 'POST',
    headers: {
      Authorization: settings.accessToken ? `Bearer ${settings.accessToken}` : '',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ phone, message })
  });
  const data = await safeResponse(response);
  if (!response.ok) throw httpError(response.status, whatsappProviderError('Erro no webhook de WhatsApp.', data), data);
  return { id: data?.id || `webhook_${Date.now()}` };
}

function isWhatsEvolutionUrl(url = '') {
  const value = String(url || '').toLowerCase();
  return value.includes('whatsevolution') || value.includes('relaxsolucoes');
}

function whatsappProviderError(fallback, data) {
  const message = data?.message || data?.error || data?.response?.message || data?.details || data?.detail;
  if (Array.isArray(message)) return `${fallback} ${message.join(' ')}`.slice(0, 500);
  if (message && typeof message === 'object') return `${fallback} ${JSON.stringify(message)}`.slice(0, 500);
  return message ? `${fallback} ${String(message)}`.slice(0, 500) : fallback;
}

function whatsappRecipientPhone(value) {
  const digits = onlyDigits(value);
  if (!digits) return '';
  if (digits.startsWith('55') && digits.length >= 12) return digits;
  if (digits.length === 10 || digits.length === 11) return `55${digits}`;
  return digits;
}

function orderStatusWhatsappMessage(store, order, status) {
  const name = firstName(order.customer_snapshot?.name || 'cliente');
  const code = order.public_code;
  const storeName = cleanText(store.name || 'Nossa loja') || 'Nossa loja';
  const origin = whatsappOrderOrigin(order);
  const total = formatMoney(order.total);
  const header = `Olá, ${name}! Aqui é ${storeName}.`;
  const footer = `\n\nResumo do pedido\nPedido: #${code}\nTipo: ${origin}\nTotal: ${total}`;
  const messages = {
    new: `${header}\n\nRecebemos seu pedido #${code}. Ele está aguardando confirmação da loja.${footer}`,
    accepted: `${header}\n\nSeu pedido #${code} foi aceito e já entrou na fila de preparo.${footer}`,
    preparing: `${header}\n\nSeu pedido #${code} está em preparo. Estamos cuidando de tudo por aqui.${footer}`,
    ready: `${header}\n\n${whatsappReadyText(order)}${footer}`,
    out_for_delivery: `${header}\n\n${whatsappOutForDeliveryText(order)}${footer}`,
    completed: `${header}\n\nSeu pedido #${code} foi concluído. Obrigado pela preferência!${footer}`,
    cancelled: `${header}\n\nSeu pedido #${code} foi cancelado. Se precisar, fale com a loja para conferir os detalhes.${footer}`
  };
  return messages[status] || `${header}\n\nStatus atualizado: ${status}.${footer}`;
}

function firstName(value) {
  return cleanText(value || '').split(/\s+/)[0] || 'cliente';
}

function whatsappOrderOrigin(order) {
  const method = order.fulfillment_method || 'delivery';
  if (method === 'delivery') return 'Delivery';
  if (method === 'pickup') return 'Retirada no balcão';
  if (method === 'counter') return 'Pedido no balcão';
  if (method === 'table') return order.table_snapshot?.name ? `Mesa ${order.table_snapshot.name}` : 'Pedido na mesa';
  if (method === 'tab') {
    const table = order.table_snapshot?.name ? `Mesa ${order.table_snapshot.name}` : 'Mesa não informada';
    const tab = order.tab_snapshot?.name ? ` - ${order.tab_snapshot.name}` : '';
    return `Comanda ${table}${tab}`;
  }
  return 'Pedido';
}

function whatsappReadyText(order) {
  const method = order.fulfillment_method || 'delivery';
  if (method === 'delivery') return `Seu pedido #${order.public_code} ficou pronto e será enviado para entrega em instantes.`;
  if (method === 'pickup') return `Seu pedido #${order.public_code} está pronto para retirada no estabelecimento.`;
  if (method === 'counter') return `Seu pedido #${order.public_code} está pronto para retirada no balcão.`;
  if (method === 'table' || method === 'tab') return `Seu pedido #${order.public_code} está pronto e será levado até sua mesa.`;
  return `Seu pedido #${order.public_code} está pronto.`;
}

function whatsappOutForDeliveryText(order) {
  const method = order.fulfillment_method || 'delivery';
  if (method === 'delivery') return `Seu pedido #${order.public_code} saiu para entrega. Fique de olho!`;
  if (method === 'pickup') return `Seu pedido #${order.public_code} está aguardando retirada no estabelecimento.`;
  if (method === 'counter') return `Seu pedido #${order.public_code} está aguardando retirada no balcão.`;
  if (method === 'table' || method === 'tab') return `Seu pedido #${order.public_code} saiu da cozinha e será entregue na mesa.`;
  return `Seu pedido #${order.public_code} saiu para entrega.`;
}

async function createPixPayment(order, options = {}) {
  const db = options.db || dbRequest;
  const store = await getStoreSettings(order.store_id, options);
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  if (!integrations.pix.enabled) throw httpError(422, 'Pix online não está ativo nesta loja.');
  if (order.status === 'cancelled') throw httpError(422, 'Pedido cancelado não aceita pagamento.');
  await assertPublicUsageLimitByStore(order.store_id, 'payment_transactions', 'payment_transactions');
  const expiresAt = new Date(Date.now() + integrations.pix.expirationMinutes * 60000).toISOString();
  let attempt = await findRetryablePaymentAttempt(order, db);
  if (attempt) {
    attempt = await updatePaymentAttempt(attempt.id, {
      status: 'created', failure_code: null, failure_message: null, expires_at: expiresAt
    }, db);
  } else {
    await supersedePendingPaymentAttempts(order.id, db);
    attempt = await createPaymentAttempt(order, expiresAt, db);
  }
  let providerPayment;
  try {
    providerPayment = await createProviderPayment({ store, order, type: 'pix', integrations, idempotencyKey: attempt.idempotency_key, paymentAccessToken: options.paymentAccessToken });
  } catch (error) {
    await updatePaymentAttempt(attempt.id, {
      status: 'failed',
      failure_code: cleanText(error.code || error.status || 'provider_error'),
      failure_message: cleanText(error.message || 'Falha ao criar pagamento.')
    }, db).catch(() => null);
    await db('PATCH', 'orders', { id: `eq.${order.id}` }, { financial_status: 'failed' }, ['Prefer: return=minimal']).catch(() => null);
    throw error;
  }
  const transactionId = cleanExternalId(providerPayment.transactionId || '');
  if (!transactionId) throw httpError(502, 'A Abacate Pay não retornou o identificador do pagamento.');
  const pixCode = providerPayment.pixCode || (providerPayment.checkoutUrl ? '' : buildMockPixCode(store, order, transactionId));
  const pixQrUrl = providerPayment.pixQrUrl || (pixCode
    ? `https://api.qrserver.com/v1/create-qr-code/?size=320x320&data=${encodeURIComponent(pixCode)}`
    : null);
  const [updated] = await db('PATCH', 'orders', { id: `eq.${order.id}` }, {
    financial_status: 'pending',
    payment_provider: integrations.pix.provider,
    payment_transaction_id: transactionId,
    payment_expires_at: expiresAt,
    payment_details: {
      ...(order.payment_details || {}),
      pix_code: pixCode,
      pix_qr_url: pixQrUrl,
      checkout_url: providerPayment.checkoutUrl || null
    }
  }, ['Prefer: return=representation']);
  await updatePaymentAttempt(attempt.id, {
    status: 'pending',
    transaction_id: transactionId,
    checkout_url: providerPayment.checkoutUrl || null
  }, db);
  await registerPaymentTransactionIndex(updated, integrations.pix.provider, transactionId, options);
  clearAdminOrdersCache(order.store_id);
  await recordUsageByStore(order.store_id, 'payment_transactions', 'payment_transactions', { entity_type: 'order', entity_id: order.id });
  return { order: updated, pix: publicPaymentPayload(updated) };
}

async function createPaymentAttempt(order, expiresAt, db = dbRequest) {
  const idempotencyKey = `order:${order.id}:pix:${randomUUID()}`;
  const [attempt] = await db('POST', 'payment_attempts', {}, {
    store_id: order.store_id || null,
    order_id: order.id,
    provider: 'abacatepay',
    idempotency_key: idempotencyKey,
    status: 'created',
    amount_cents: moneyCents(order.total),
    currency: 'BRL',
    expires_at: expiresAt,
    metadata: { order_code: order.public_code }
  }, ['Prefer: return=representation']);
  return attempt;
}

async function findRetryablePaymentAttempt(order, db = dbRequest) {
  const attempts = await db('GET', 'payment_attempts', {
    select: '*',
    order_id: `eq.${cleanUuid(order.id)}`,
    provider: 'eq.abacatepay',
    status: 'eq.failed',
    transaction_id: 'is.null',
    created_at: `gte.${new Date(Date.now() - 5 * 60000).toISOString()}`,
    order: 'created_at.desc',
    limit: '1'
  });
  const attempt = attempts[0];
  if (!attempt || !['502', '504', 'provider_error'].includes(String(attempt.failure_code || ''))) return null;
  return Number(attempt.amount_cents) === moneyCents(order.total) ? attempt : null;
}

async function updatePaymentAttempt(id, patch, db = dbRequest) {
  const [attempt] = await db('PATCH', 'payment_attempts', { id: `eq.${cleanUuid(id)}` }, patch, ['Prefer: return=representation']);
  return attempt || null;
}

async function supersedePendingPaymentAttempts(orderId, db = dbRequest) {
  await db('PATCH', 'payment_attempts', {
    order_id: `eq.${cleanUuid(orderId)}`,
    status: 'in.(created,pending)'
  }, { status: 'superseded' }, ['Prefer: return=minimal']);
}

async function createCardPayment(order, options = {}) {
  const db = options.db || dbRequest;
  const store = await getStoreSettings(order.store_id, options);
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  if (!integrations.card.enabled) throw httpError(422, 'Cartão online não está ativo nesta loja.');
  if (order.status === 'cancelled') throw httpError(422, 'Pedido cancelado não aceita pagamento.');
  const providerPayment = await createProviderPayment({ store, order, type: 'card', integrations, paymentAccessToken: options.paymentAccessToken });
  const transactionId = providerPayment.transactionId || `card_${order.public_code}_${Date.now()}`;
  const [updated] = await db('PATCH', 'orders', { id: `eq.${order.id}` }, {
    financial_status: 'pending',
    payment_provider: integrations.card.provider,
    payment_transaction_id: transactionId,
    payment_details: {
      ...(order.payment_details || {}),
      checkout_url: providerPayment.checkoutUrl || null,
      split: providerPayment.split || null
    }
  }, ['Prefer: return=representation']);
  await registerPaymentTransactionIndex(updated, integrations.card.provider, transactionId, options);
  return { order: updated, card: publicPaymentPayload(updated) };
}

async function registerPaymentTransactionIndex(order, provider, transactionId, options = {}) {
  const cleanProviderName = cleanProvider(provider || order.payment_provider || '');
  const cleanTransactionId = cleanExternalId(transactionId || order.payment_transaction_id || '');
  if (!cleanProviderName || !cleanTransactionId) return null;
  const store = await getCentralStoreRef(order.store_id).catch(() => null);
  const body = {
    provider: cleanProviderName,
    transaction_id: cleanTransactionId,
    order_id: order.id || null,
    order_public_code: cleanPublicCode(order.public_code || ''),
    company_id: store?.company_id || null,
    store_id: cleanUuid(order.store_id) || null,
    financial_status: sanitizeFinancialStatus(order.financial_status || 'pending'),
    amount: roundMoney(Number.parseFloat(order.total || order.paid_amount || 0) || 0),
    metadata: {
      payment_method: order.payment_method || null
    }
  };
  const existing = await dbRequest('GET', 'payment_transaction_index', {
    select: 'id',
    provider: `eq.${body.provider}`,
    transaction_id: `eq.${body.transaction_id}`,
    limit: '1'
  }).catch(() => []);
  if (existing[0]?.id) {
    const [updated] = await dbRequest('PATCH', 'payment_transaction_index', {
      id: `eq.${existing[0].id}`
    }, body, ['Prefer: return=representation']);
    return updated || null;
  }
  const [created] = await dbRequest('POST', 'payment_transaction_index', {}, body, ['Prefer: return=representation']);
  return created || null;
}

async function updatePaymentTransactionIndexStatus(index, status, amount) {
  if (!index?.id) return;
  await dbRequest('PATCH', 'payment_transaction_index', { id: `eq.${index.id}` }, {
    financial_status: sanitizeFinancialStatus(status),
    amount: roundMoney(Number.parseFloat(amount || index.amount || 0) || 0)
  }, ['Prefer: return=minimal']).catch((error) => {
    console.warn('Falha ao atualizar índice de pagamento:', error.message || error);
  });
}

async function getCentralStoreRef(storeId) {
  const resolvedStoreId = cleanUuid(storeId);
  if (!resolvedStoreId) return null;
  const [store] = await dbRequest('GET', 'stores', {
    select: 'id,company_id,name,slug,is_active',
    id: `eq.${resolvedStoreId}`,
    limit: '1'
  });
  return store || null;
}

async function createProviderPayment({ store, order, type, integrations, idempotencyKey, paymentAccessToken }) {
  const provider = type === 'card' ? integrations.card.provider : integrations.pix.provider;
  if (provider !== 'abacatepay') throw httpError(422, 'Gateway de pagamento não suportado. Configure a Abacate Pay.');
  return createAbacatePayPayment({ store, order, type, integrations, idempotencyKey, paymentAccessToken });
}

async function createAbacatePayPayment({ store, order, type, integrations, idempotencyKey, paymentAccessToken }) {
  const token = type === 'card' ? integrations.card.apiKey || integrations.pix.apiKey : integrations.pix.apiKey;
  if (!token) throw httpError(422, 'Configure a chave da Abacate Pay.');
  if (isMaskedSecretValue(token)) {
    throw httpError(422, 'A chave da Abacate Pay desta loja está salva apenas como máscara. Reconfigure a API key real em Integrações > Pagamento online.');
  }
  const customer = abacatePayCustomer(order);
  const amount = moneyCents(order.total);

  if (type === 'pix') {
    return createAbacateOrderCheckout({ store, order, token, amount, methods: ['PIX'], customer, idempotencyKey, paymentAccessToken });
  }

  return createAbacateOrderCheckout({ store, order, token, amount, methods: ['CARD'], customer, paymentAccessToken });
}

async function createAbacateOrderCheckout({ store, order, token, amount, methods, customer, idempotencyKey, paymentAccessToken }) {
  const productId = await ensureAbacateOrderProduct({ store, order, amount, token });
  const origin = cleanText(process.env.PUBLIC_APP_URL || process.env.APP_URL || '').replace(/\/+$/, '');
  const storeSlug = cleanSlug(store.slug || '');
  const paymentQuery = new URLSearchParams({ pedido: order.public_code });
  if (paymentAccessToken) paymentQuery.set('token', paymentAccessToken);
  const paymentPath = `${storeSlug ? `/${storeSlug}` : ''}/pagamento?${paymentQuery.toString()}`;
  const fallbackUrl = origin ? `${origin}${paymentPath}` : '';
  const externalSuffix = idempotencyKey
    ? createHash('sha256').update(idempotencyKey).digest('hex').slice(0, 20)
    : createHash('sha256').update(`${order.id}:${order.public_code}`).digest('hex').slice(0, 20);
  const externalId = cleanExternalId(`tapronto-order-${order.public_code}-${externalSuffix}`);
  const body = {
    items: [{ id: productId, quantity: 1 }],
    methods,
    externalId,
    metadata: { orderCode: order.public_code, storeId: order.store_id || null, kind: 'store_order' }
  };
  if (fallbackUrl) {
    body.returnUrl = fallbackUrl;
    body.completionUrl = fallbackUrl;
  }
  const customerId = await createAbacateOrderCustomer({ customer, order, token }).catch((error) => {
    console.warn('Falha ao pre-preencher cliente na Abacate Pay:', error.message || error);
    return '';
  });
  if (customerId) body.customerId = customerId;

  const data = await providerFetch(`${ABACATEPAY_API_BASE}/checkouts/create`, {
    method: 'POST',
    token,
    body,
    idempotencyKey
  });
  const payload = data.data || data;
  const checkoutUrl = payload.url || payload.checkoutUrl || payload.paymentUrl || '';
  if (!checkoutUrl) throw httpError(502, 'A Abacate Pay criou o pagamento, mas não retornou a URL de checkout.');
  return {
    transactionId: String(payload.id || payload.checkoutId || externalId),
    checkoutUrl
  };
}

async function ensureAbacateOrderProduct({ store, order, amount, token }) {
  // Reutiliza o produto por loja e valor para não criar um recurso remoto novo
  // a cada pedido. A identificação do pedido continua no metadata do checkout.
  const storeKey = cleanExternalId(order.store_id || store.id || store.slug || 'store');
  const externalId = cleanExternalId(`tapronto-store-${storeKey}-${amount}`);
  const existing = await findAbacateProductByExternalId(externalId, token).catch(() => null);
  if (existing?.id) return String(existing.id);
  const data = await providerFetch(`${ABACATEPAY_API_BASE}/products/create`, {
    method: 'POST',
    token,
    body: {
      externalId,
      name: `Pedido online - ${store.name || 'Cardápio'}`,
      description: 'Pagamento de pedido realizado pelo TáPronto',
      price: amount,
      currency: 'BRL'
    }
  });
  const payload = data.data || data;
  const productId = payload.id || payload.product?.id || '';
  if (!productId) throw httpError(502, 'A Abacate Pay não retornou o identificador do produto do pedido.');
  return String(productId);
}

async function createAbacateOrderCustomer({ customer, order, token }) {
  const customerPayload = abacatePayCustomer({ ...order, customer_snapshot: { ...(order.customer_snapshot || {}), ...customer } });
  const email = cleanEmail(customerPayload.email || order.customer_snapshot?.email || '');
  if (!email) return '';
  const data = await providerFetch(`${ABACATEPAY_API_BASE}/customers/create`, {
    method: 'POST',
    token,
    body: {
      ...customerPayload,
      email,
      metadata: { orderCode: order.public_code, storeId: order.store_id || null, kind: 'store_order' }
    }
  });
  const payload = data.data || data;
  return String(payload.id || payload.customer?.id || '');
}

async function createMercadoPagoPayment({ order, type, integrations }) {
  const token = type === 'card' ? integrations.card.apiKey || integrations.pix.apiKey : integrations.pix.apiKey;
  if (!token) throw httpError(422, 'Configure a chave do Mercado Pago.');
  if (type === 'pix') {
    const data = await providerFetch('https://api.mercadopago.com/v1/payments', {
      method: 'POST',
      token,
      body: {
        transaction_amount: moneyNumber(order.total),
        description: `Pedido #${order.public_code}`,
        payment_method_id: 'pix',
        external_reference: order.public_code,
        payer: { email: order.customer_snapshot?.email || `pedido-${order.public_code}@local.test` },
        ...(providerSplitPayload(integrations, 'mercadopago'))
      }
    });
    return {
      transactionId: String(data.id || ''),
      pixCode: data.point_of_interaction?.transaction_data?.qr_code || '',
      pixQrUrl: data.point_of_interaction?.transaction_data?.qr_code_base64
        ? `data:image/png;base64,${data.point_of_interaction.transaction_data.qr_code_base64}`
        : null
    };
  }
  const data = await providerFetch('https://api.mercadopago.com/checkout/preferences', {
    method: 'POST',
    token,
    body: {
      external_reference: order.public_code,
      items: [{ title: `Pedido #${order.public_code}`, quantity: 1, unit_price: moneyNumber(order.total), currency_id: 'BRL' }],
      back_urls: { success: integrations.card.returnUrl || '', pending: integrations.card.returnUrl || '', failure: integrations.card.returnUrl || '' },
      ...(providerSplitPayload(integrations, 'mercadopago'))
    }
  });
  return { transactionId: String(data.id || ''), checkoutUrl: data.init_point || data.sandbox_init_point || '' };
}

async function createAsaasPayment({ order, type, integrations }) {
  const token = type === 'card' ? integrations.card.apiKey || integrations.pix.apiKey : integrations.pix.apiKey;
  if (!token) throw httpError(422, 'Configure a chave do Asaas.');
  const data = await providerFetch('https://www.asaas.com/api/v3/payments', {
    method: 'POST',
    token,
    body: {
      billingType: type === 'pix' ? 'PIX' : 'CREDIT_CARD',
      value: moneyNumber(order.total),
      description: `Pedido #${order.public_code}`,
      externalReference: order.public_code,
      dueDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
      customer: order.customer_snapshot?.provider_customer_id || undefined,
      ...(providerSplitPayload(integrations, 'asaas'))
    }
  });
  return {
    transactionId: String(data.id || ''),
    pixCode: data.pixPayload || '',
    checkoutUrl: data.invoiceUrl || data.bankSlipUrl || ''
  };
}

async function createEfiPixPayment({ store, order }) {
  return {
    transactionId: `efi_pix_${order.public_code}_${Date.now()}`,
    pixCode: buildMockPixCode(store, order, `efi_${Date.now()}`)
  };
}

async function providerFetch(url, { method = 'GET', token, body, idempotencyKey, timeoutMs = 7000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), clampInteger(timeoutMs, 1000, 30000));
  let response;
  try {
    response = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(idempotencyKey ? { 'Idempotency-Key': idempotencyKey, 'X-Idempotency-Key': idempotencyKey } : {})
    },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: controller.signal
    });
  } catch (error) {
    if (error?.name === 'AbortError') throw httpError(504, 'A Abacate Pay demorou para responder. Tente novamente.');
    throw httpError(502, 'Não foi possível conectar à Abacate Pay. Tente novamente.');
  } finally {
    clearTimeout(timer);
  }
  const data = await safeResponse(response);
  if (!response.ok) throw httpError(response.status, providerErrorMessage(data), sanitizeProviderErrorDetail(data));
  return data;
}

function providerErrorMessage(data) {
  const detail = sanitizeProviderErrorDetail(data);
  const raw = detail?.message || detail?.error || detail?.code || '';
  return raw ? `Erro no provedor de pagamento: ${String(raw).slice(0, 180)}` : 'Erro no provedor de pagamento.';
}

function sanitizeProviderErrorDetail(data) {
  if (!data || typeof data !== 'object') return data;
  const error = data.error && typeof data.error === 'object' ? data.error : {};
  return {
    code: cleanText(data.code || error.code || ''),
    message: cleanText(data.message || error.message || (typeof data.error === 'string' ? data.error : '') || ''),
    status: cleanText(data.status || error.status || ''),
    success: data.success === true ? true : (data.success === false ? false : undefined)
  };
}

function providerSplitPayload(integrations, provider) {
  if (!integrations.split.enabled || !integrations.split.recipientId || !integrations.split.percentage) return {};
  if (provider === 'mercadopago') {
    return { marketplace_fee: 0, application_fee: 0, metadata: { split_recipient_id: integrations.split.recipientId, split_percentage: integrations.split.percentage } };
  }
  if (provider === 'asaas') {
    return { split: [{ walletId: integrations.split.recipientId, percentualValue: integrations.split.percentage }] };
  }
  return {};
}

async function publicPaymentStatus(code, options = {}) {
  const db = options.db || dbRequest;
  let order = await getOrderByPublicCode(code, options);
  if (!order) throw httpError(404, 'Pedido não encontrado.');
  assertPaymentAccessToken(order, options.accessToken);
  const reconciliationKey = `order:${order.id}`;
  const lastProviderCheck = paymentReconciliationCache.get(reconciliationKey) || 0;
  if (
    order.payment_provider === 'abacatepay'
    && order.payment_transaction_id
    && ['pending', 'failed', 'expired'].includes(sanitizeFinancialStatus(order.financial_status))
    && Date.now() - lastProviderCheck >= 8000
  ) {
    paymentReconciliationCache.set(reconciliationKey, Date.now());
    order = await reconcileOrderPaymentWithProvider(order, options).catch((error) => {
      console.warn('Falha ao consultar pagamento na Abacate Pay:', error.message || error);
      return order;
    });
  }
  if (order.financial_status === 'pending' && order.payment_expires_at && new Date(order.payment_expires_at).getTime() < Date.now()) {
    const [updated] = await db('PATCH', 'orders', { id: `eq.${order.id}`, financial_status: 'eq.pending' }, {
      financial_status: 'expired'
    }, ['Prefer: return=representation']);
    return { order: publicPaymentOrder(updated || order), payment: publicPaymentPayload(updated || order) };
  }
  const store = order.financial_status === 'paid'
    ? await getStoreSettings(order.store_id, options).catch(() => null)
    : null;
  return { order: publicPaymentOrder(order), payment: publicPaymentPayload(order, { store }) };
}

async function reconcileOrderPaymentWithProvider(order, options = {}) {
  if (!order?.payment_provider || !order.payment_transaction_id) return order;
  const db = options.db || dbRequest;
  const store = await getStoreSettings(order.store_id, options);
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  const providerStatus = await fetchProviderPaymentStatus(order, integrations);
  const expected = sanitizeFinancialStatus(providerStatus?.status || order.financial_status);
  const current = sanitizeFinancialStatus(order.financial_status);
  if (!expected || expected === current || expected === 'pending') return order;

  const amount = roundMoney(Number.parseFloat(providerStatus.amount || order.total) || 0);
  if (expected === 'paid' && moneyCents(amount) !== moneyCents(order.total)) {
    await db('PATCH', 'orders', { id: `eq.${order.id}` }, {
      reconciliation_status: 'divergent', reconciled_at: new Date().toISOString()
    }, ['Prefer: return=minimal']);
    return { ...order, reconciliation_status: 'divergent' };
  }
  const eventId = cleanExternalId(providerStatus.provider_event_id || `reconcile_${order.payment_provider}_${order.payment_transaction_id}_${expected}`);
  if (eventId) {
    const existing = await db('GET', 'order_payment_events', {
      select: 'id',
      provider: `eq.${cleanProvider(order.payment_provider)}`,
      provider_event_id: `eq.${eventId}`,
      limit: '1'
    }).catch(() => []);
    if (!existing[0]) {
      await db('POST', 'order_payment_events', {}, {
        order_id: order.id,
        store_id: order.store_id || null,
        provider: cleanProvider(order.payment_provider),
        provider_event_id: eventId,
        transaction_id: order.payment_transaction_id,
        financial_status: expected,
        amount,
        raw_payload: sanitizeProviderStatusPayload(providerStatus.raw || providerStatus)
      }, ['Prefer: return=minimal']).catch((error) => {
        console.warn('Falha ao registrar conciliação de pagamento:', error.message || error);
      });
    }
  }

  const patch = {
    financial_status: expected,
    paid_amount: expected === 'paid' ? amount : order.paid_amount,
    paid_at: expected === 'paid' ? (order.paid_at || new Date().toISOString()) : order.paid_at,
    ...(expected === 'paid' && isOnlinePaymentMethod(order.payment_method) ? { status: 'new', payment_access_expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString() } : {})
  };
  const [updated] = await db('PATCH', 'orders', { id: `eq.${order.id}` }, patch, ['Prefer: return=representation']);
  if (expected === 'paid') await updatePromotionRedemptionStatus(updated || order, 'consumed', db);
  await registerPaymentTransactionIndex(updated || { ...order, ...patch }, order.payment_provider, order.payment_transaction_id, options).catch(() => null);
  clearAdminOrdersCache(order.store_id);
  if (expected === 'paid' && updated?.id) {
    await sendOrderStatusWhatsapp(updated.id, 'new', { manual: false, db, tenant: options.tenant }).catch(() => null);
  }
  return updated || { ...order, ...patch };
}

function sanitizeProviderStatusPayload(payload) {
  if (!payload || typeof payload !== 'object') return {};
  return {
    id: cleanExternalId(payload.id || payload.checkoutId || payload.transactionId || ''),
    status: cleanText(payload.status || ''),
    amount: payload.amount || payload.value || payload.paidAmount || null,
    externalId: cleanExternalId(payload.externalId || '')
  };
}

async function regeneratePixPayment(data, options = {}) {
  const order = await getOrderByPublicCode(data.code || data.order, options);
  if (!order) throw httpError(404, 'Pedido não encontrado.');
  assertPaymentAccessToken(order, data.token || options.accessToken);
  if (order.status === 'cancelled') throw httpError(422, 'Pedido cancelado não aceita pagamento.');
  if (order.financial_status === 'paid') throw httpError(422, 'Pedido já pago.');
  const recentAttempts = await (options.db || dbRequest)('GET', 'payment_attempts', {
    select: 'id', order_id: `eq.${order.id}`, created_at: `gte.${new Date(Date.now() - 15 * 60000).toISOString()}`, limit: '6'
  });
  if (recentAttempts.length >= 5) throw httpError(429, 'Limite de regenerações atingido. Aguarde alguns minutos.');
  const payment = await createPixPayment(order, { ...options, paymentAccessToken: String(data.token || options.accessToken || '') });
  return { order: publicPaymentOrder(payment.order), payment: payment.pix };
}

function assertPaymentAccessToken(order, token) {
  const expected = String(order.payment_access_token_hash || '');
  const supplied = String(token || '');
  if (!expected || !supplied) throw httpError(403, 'Acesso ao pagamento não autorizado.');
  const actual = createHash('sha256').update(supplied).digest('hex');
  if (!safeSecretEquals(actual, expected)) throw httpError(403, 'Acesso ao pagamento não autorizado.');
  if (order.payment_access_expires_at && new Date(order.payment_access_expires_at).getTime() <= Date.now()) {
    throw httpError(410, 'O acesso a este pagamento expirou.');
  }
}

function stripPaymentAccessSecrets(order = {}) {
  const { payment_access_token_hash, payment_access_expires_at, ...safeOrder } = order;
  return safeOrder;
}

async function receivePaymentWebhook(data, options = {}) {
  const incoming = {
    ...data,
    provider: cleanText(options.provider || data.provider || '')
  };
  const normalized = await normalizeProviderWebhook(incoming);
  const provider = normalized.provider;
  const eventId = normalized.eventId;
  if (!eventId) throw httpError(422, 'Evento sem identificador.');
  const webhookContext = await resolvePaymentWebhookContext(normalized);
  await assertPaymentWebhookSecret(provider, options.webhookSecret, webhookContext);
  const db = webhookContext.db || dbRequest;
  const existing = await db('GET', 'order_payment_events', {
    select: 'id',
    provider: `eq.${provider}`,
    provider_event_id: `eq.${eventId}`,
    limit: '1'
  });
  if (existing[0]) return { ok: true, duplicate: true };
  const transactionId = normalized.transactionId;
  const status = normalized.status;
  let order = transactionId
    ? (await db('GET', 'orders', { select: '*', payment_transaction_id: `eq.${transactionId}`, limit: '1' }))[0]
    : null;
  if (!order && webhookContext.index?.order_id) {
    [order] = await db('GET', 'orders', { select: '*', id: `eq.${webhookContext.index.order_id}`, limit: '1' });
  }
  if (!order && normalized.orderCode) {
    order = await getOrderByPublicCode(normalized.orderCode, webhookContext);
  }
  if (!order) throw httpError(404, 'Pedido do pagamento não encontrado.');
  const amount = roundMoney(Number.parseFloat(normalized.amount) || 0);
  const amountMatches = moneyCents(amount) === moneyCents(order.total);
  const lateCancelledPayment = order.status === 'cancelled' && status === 'paid';
  try {
    await db('POST', 'order_payment_events', {}, {
      order_id: order.id,
      store_id: order.store_id || webhookContext.storeId || null,
      provider,
      provider_event_id: eventId,
      transaction_id: transactionId || order.payment_transaction_id,
      financial_status: status,
      amount,
      raw_payload: sanitizeAuditPayload(data)
    }, ['Prefer: return=minimal']);
  } catch (error) {
    if (String(error.code || error.detail?.code || '').includes('23505') || /duplicate|unique/i.test(String(error.message || ''))) {
      return { ok: true, duplicate: true };
    }
    throw error;
  }
  if (status === 'paid' && (!amountMatches || lateCancelledPayment)) {
    await db('PATCH', 'orders', { id: `eq.${order.id}` }, {
      reconciliation_status: 'divergent',
      reconciled_at: new Date().toISOString()
    }, ['Prefer: return=minimal']);
    if (transactionId) {
      await db('PATCH', 'payment_attempts', {
        provider: 'eq.abacatepay', transaction_id: `eq.${transactionId}`
      }, {
        status: 'review_required',
        failure_code: lateCancelledPayment ? 'late_cancelled_payment' : 'amount_mismatch',
        failure_message: lateCancelledPayment
          ? 'Pagamento recebido depois do cancelamento do pedido.'
          : `Valor recebido ${amount.toFixed(2)} difere do esperado ${moneyNumber(order.total).toFixed(2)}.`
      }, ['Prefer: return=minimal']).catch(() => null);
    }
    clearAdminOrdersCache(order.store_id);
    return { ok: true, review_required: true };
  }
  const patch = {
    financial_status: status,
    payment_provider: provider,
    payment_transaction_id: transactionId || order.payment_transaction_id,
    paid_amount: status === 'paid' ? amount : order.paid_amount,
    paid_at: status === 'paid' ? new Date().toISOString() : order.paid_at,
    ...(status === 'paid' && isOnlinePaymentMethod(order.payment_method) ? { status: 'new', payment_access_expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString() } : {}),
    ...(status === 'cancelled' ? { payment_access_expires_at: new Date().toISOString() } : {})
  };
  const [updated] = await db('PATCH', 'orders', { id: `eq.${order.id}` }, patch, ['Prefer: return=representation']);
  if (status === 'paid') await updatePromotionRedemptionStatus(updated || order, 'consumed', db);
  if (status === 'cancelled') await updatePromotionRedemptionStatus(updated || order, 'released', db);
  if (transactionId) {
    await db('PATCH', 'payment_attempts', {
      provider: 'eq.abacatepay', transaction_id: `eq.${transactionId}`
    }, { status }, ['Prefer: return=minimal']).catch(() => null);
  }
  await updatePaymentTransactionIndexStatus(webhookContext.index, status, amount);
  if (status === 'paid' && updated?.id) {
    await sendOrderStatusWhatsapp(updated.id, 'new', { manual: false, db, tenant: webhookContext.tenant }).catch(() => null);
  }
  clearAdminOrdersCache(order.store_id);
  return { ok: true, order: publicPaymentOrder(updated) };
}

async function updatePromotionRedemptionStatus(order, status, db = dbRequest) {
  if (!order?.id || !order.promotion_code) return null;
  const [redemption] = await db('GET', 'promotion_redemptions', {
    select: '*', order_id: `eq.${cleanUuid(order.id)}`, limit: '1'
  }).catch(() => []);
  if (!redemption || redemption.status === status) return redemption || null;
  const [updated] = await db('PATCH', 'promotion_redemptions', { id: `eq.${redemption.id}` }, {
    status, updated_at: new Date().toISOString()
  }, ['Prefer: return=representation']);
  if (status === 'released' && redemption.status !== 'released') {
    const [promotion] = await db('GET', 'promotions', { select: 'id,used_count', id: `eq.${redemption.promotion_id}`, limit: '1' });
    if (promotion) await db('PATCH', 'promotions', { id: `eq.${promotion.id}` }, {
      used_count: Math.max(0, Number(promotion.used_count || 0) - 1)
    }, ['Prefer: return=minimal']);
  }
  return updated || null;
}

async function resolvePaymentWebhookContext(normalized) {
  const provider = cleanProvider(normalized.provider || '');
  const transactionId = cleanExternalId(normalized.transactionId || '');
  const orderCode = cleanPublicCode(normalized.orderCode || '');
  let index = null;
  if (provider && transactionId) {
    [index] = await dbRequest('GET', 'payment_transaction_index', {
      select: '*',
      provider: `eq.${provider}`,
      transaction_id: `eq.${transactionId}`,
      limit: '1'
    }).catch(() => []);
  }
  if (!index && orderCode) {
    [index] = await dbRequest('GET', 'payment_transaction_index', {
      select: '*',
      order_public_code: `eq.${orderCode}`,
      order: 'created_at.desc',
      limit: '1'
    }).catch(() => []);
  }
  return {
    db: dbRequest,
    tenant: null,
    index: index || null,
    storeId: index?.store_id || null
  };
}

async function assertPaymentWebhookSecret(provider, incomingSecret, context = {}) {
  if (provider !== 'abacatepay') throw httpError(422, 'Gateway de webhook não suportado.');
  const store = await getStoreSettings(context.storeId, context);
  const settings = sanitizeIntegrationSettings(store.integration_settings || {});
  const expected = settings.pix.webhookSecret;
  if (!expected) throw httpError(503, 'Configure o segredo do webhook da Abacate Pay antes de receber pagamentos.');
  if (!incomingSecret || !safeSecretEquals(incomingSecret, expected)) {
    throw httpError(401, 'Webhook da Abacate Pay não autorizado.');
  }
}

async function normalizeProviderWebhook(data) {
  const provider = cleanProvider(data.provider || inferWebhookProvider(data) || '');
  if (provider === 'abacatepay') {
    const payload = data.data || data.payment || data.pixQrCode || data.billing || data;
    const eventIdentity = payload.id
      ? `${payload.id}_${data.event || payload.status || data.status || 'updated'}`
      : webhookPayloadHash(data);
    return {
      provider,
      eventId: cleanExternalId(data.id || data.eventId || eventIdentity),
      transactionId: cleanExternalId(payload.id || data.paymentId || data.transaction_id || ''),
      orderCode: abacatePayOrderCodeFromPayload(payload, data),
      status: abacatePayStatusToFinancial(payload.status || data.status || data.event),
      amount: centsToMoney(payload.amount || payload.value || data.amount || data.value)
    };
  }
  throw httpError(422, 'Webhook de gateway não suportado.');
}

function webhookPayloadHash(data) {
  return `payload_${createHash('sha256').update(JSON.stringify(data || {})).digest('hex').slice(0, 40)}`;
}

function safeSecretEquals(incoming, expected) {
  const left = Buffer.from(String(incoming || ''));
  const right = Buffer.from(String(expected || ''));
  return left.length === right.length && left.length > 0 && timingSafeEqual(left, right);
}

function abacatePayOrderCodeFromPayload(payload = {}, data = {}) {
  const metadata = {
    ...(isPlainObject(data.metadata) ? data.metadata : {}),
    ...(isPlainObject(payload.metadata) ? payload.metadata : {})
  };
  const candidates = [
    metadata.orderCode,
    metadata.order_code,
    data.order_code,
    data.code,
    payload.orderCode,
    payload.order_code,
    payload.code,
    payload.externalId,
    payload.external_id,
    payload.externalReference,
    payload.external_reference,
    data.externalId,
    data.external_id,
    data.externalReference,
    data.external_reference
  ];
  for (const candidate of candidates) {
    const value = cleanText(candidate || '');
    if (!value) continue;
    const match = value.match(/tapronto-order-([a-z0-9_-]+?)(?:-\d+)?$/i);
    if (match?.[1]) return cleanPublicCode(match[1]);
    const code = cleanPublicCode(value);
    if (code && !code.startsWith('TAPRONTO-ORDER-')) return code;
  }
  return '';
}

function inferWebhookProvider(data) {
  const event = String(data.event || '').toLowerCase();
  if (
    event.includes('abacate')
    || event.startsWith('billing.')
    || event.startsWith('pixqrcode.')
    || event.startsWith('checkout.')
    || event.startsWith('transparent.')
    || data.pixQrCode
    || data.billing
  ) return 'abacatepay';
  if (data.action || data.type === 'payment' || data.data?.id) return 'mercadopago';
  if (String(data.event || '').startsWith('PAYMENT_') || data.payment) return 'asaas';
  if (data.pix || data.txid) return 'efi';
  return '';
}

function abacatePayStatusToFinancial(status) {
  const value = String(status || '').toUpperCase();
  if (['PAID', 'APPROVED', 'COMPLETED', 'BILLING_PAID', 'PIXQRCODE_PAID'].includes(value)) return 'paid';
  if (['EXPIRED', 'PIXQRCODE_EXPIRED'].includes(value)) return 'expired';
  if (['CANCELLED', 'CANCELED', 'CANCELLED_BY_CUSTOMER'].includes(value)) return 'cancelled';
  if (['REFUNDED', 'CHARGEBACK'].includes(value)) return 'refunded';
  if (['FAILED', 'REJECTED'].includes(value)) return 'failed';
  if (value.includes('PAID')) return 'paid';
  if (value.includes('EXPIRED')) return 'expired';
  if (value.includes('CANCEL')) return 'cancelled';
  if (value.includes('REFUND')) return 'refunded';
  return 'pending';
}

function mercadoPagoStatusToFinancial(status) {
  return ({
    approved: 'paid',
    authorized: 'pending',
    in_process: 'pending',
    pending: 'pending',
    rejected: 'failed',
    cancelled: 'cancelled',
    refunded: 'refunded',
    charged_back: 'refunded'
  })[String(status || '').toLowerCase()] || 'pending';
}

function asaasStatusToFinancial(status) {
  const value = String(status || '').toUpperCase();
  if (['PAYMENT_RECEIVED', 'RECEIVED', 'CONFIRMED'].includes(value)) return 'paid';
  if (['PAYMENT_DELETED', 'DELETED', 'CANCELED', 'CANCELLED'].includes(value)) return 'cancelled';
  if (['PAYMENT_REFUNDED', 'REFUNDED'].includes(value)) return 'refunded';
  if (['OVERDUE'].includes(value)) return 'expired';
  return 'pending';
}

async function refundOrderPayment(orderId, data = {}, options = {}) {
  const db = options.db || dbRequest;
  const [order] = await db('GET', 'orders', { select: '*', id: `eq.${orderId}`, limit: '1' });
  if (!order) throw httpError(404, 'Pedido não encontrado.');
  if (order.financial_status !== 'paid') throw httpError(422, 'Apenas pedidos pagos podem ser estornados.');
  const amount = roundMoney(Number.parseFloat(data.amount || order.paid_amount || order.total) || 0);
  if (amount <= 0 || moneyCents(amount) > moneyCents(order.paid_amount || order.total)) {
    throw httpError(422, 'Valor de estorno inválido.');
  }
  const store = await getStoreSettings(order.store_id, options);
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  const idempotencyKey = `refund:${order.id}:${moneyCents(amount)}:${randomUUID()}`;
  const [refund] = await db('POST', 'payment_refunds', {}, {
    store_id: order.store_id || null,
    order_id: order.id,
    provider: 'abacatepay',
    idempotency_key: idempotencyKey,
    status: 'requested',
    amount_cents: moneyCents(amount),
    reason: cleanText(data.reason || 'Estorno manual')
  }, ['Prefer: return=representation']);
  let providerRefund;
  try {
    providerRefund = await refundProviderPayment(order, amount, integrations, idempotencyKey);
  } catch (error) {
    await db('PATCH', 'payment_refunds', { id: `eq.${refund.id}` }, {
      status: 'failed', failure_message: cleanText(error.message || 'Falha no estorno.')
    }, ['Prefer: return=minimal']).catch(() => null);
    throw error;
  }
  const [updated] = await db('PATCH', 'orders', { id: `eq.${order.id}` }, {
    financial_status: 'refunded',
    refunded_amount: amount,
    refunded_at: new Date().toISOString()
  }, ['Prefer: return=representation']);
  await db('PATCH', 'payment_refunds', { id: `eq.${refund.id}` }, {
    status: 'succeeded',
    provider_refund_id: cleanExternalId(providerRefund?.data?.id || providerRefund?.id || '') || null,
    completed_at: new Date().toISOString(),
    metadata: sanitizeAuditPayload(providerRefund || {})
  }, ['Prefer: return=minimal']);
  await db('POST', 'order_payment_events', {}, {
    order_id: order.id,
    provider: order.payment_provider || 'manual',
    provider_event_id: `refund_${order.id}_${Date.now()}`,
    transaction_id: order.payment_transaction_id,
    financial_status: 'refunded',
    amount,
    raw_payload: { reason: cleanText(data.reason || 'Estorno manual') }
  }, ['Prefer: return=minimal']);
  clearAdminOrdersCache(order.store_id);
  return updated;
}

async function refundProviderPayment(order, amount, integrations, idempotencyKey) {
  if (order.payment_provider !== 'abacatepay') throw httpError(422, 'Este pagamento não pertence à Abacate Pay e não pode ser estornado automaticamente.');
  if (order.payment_provider === 'abacatepay') {
    const token = integrations.pix.apiKey || integrations.card.apiKey;
    if (!token) throw httpError(422, 'Chave da Abacate Pay não configurada.');
    const endpoint = isOnlinePixPayment(order.payment_method) ? 'pixQrCode/refund' : 'billing/refund';
    return providerFetch(`https://api.abacatepay.com/v1/${endpoint}`, {
      method: 'POST',
      token,
      body: { id: order.payment_transaction_id, amount: moneyCents(amount) },
      idempotencyKey
    }).catch((error) => {
      throw httpError(error.status || 422, 'Estorno automático não disponível para este pagamento na Abacate Pay. Faça o estorno no painel do provedor e depois concilie o pedido.', error.detail);
    });
  }
  throw httpError(422, 'Estorno não suportado para este pagamento.');
}

async function reconcileOnlinePayments(data = {}, options = {}) {
  const db = options.db || dbRequest;
  const store = await getStoreSettings(data.storeId, options);
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  const days = clampInteger(data.days || integrations.reconciliation.days || 7, 1, 30);
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const orders = await db('GET', 'orders', {
    select: '*',
    created_at: `gte.${since}`,
    payment_transaction_id: 'not.is.null',
    ...(store.id ? { store_id: `eq.${store.id}` } : {}),
    order: 'created_at.desc',
    limit: '300'
  });
  let matched = 0;
  let divergent = 0;
  for (const order of orders) {
    const providerStatus = await fetchProviderPaymentStatus(order, integrations).catch(() => null);
    const expected = providerStatus?.status || order.financial_status;
    const isMatch = expected === order.financial_status;
    await db('PATCH', 'orders', { id: `eq.${order.id}` }, {
      reconciliation_status: isMatch ? 'matched' : 'divergent',
      reconciled_at: new Date().toISOString()
    }, ['Prefer: return=minimal']);
    if (isMatch) matched += 1;
    else divergent += 1;
  }
  return { checked: orders.length, matched, divergent };
}

async function fetchProviderPaymentStatus(order, integrations) {
  if (order.payment_provider === 'abacatepay') {
    const token = integrations.pix.apiKey || integrations.card.apiKey;
    if (!token) throw httpError(422, 'Chave da Abacate Pay não configurada.');
    const details = order.payment_details || {};
    const transactionId = cleanExternalId(order.payment_transaction_id || '');
    const checkoutUrl = String(details.checkout_url || '');
    const isHostedCheckout = transactionId.startsWith('bill_') || checkoutUrl.includes('app.abacatepay.com/pay/');
    const endpoint = isHostedCheckout ? 'checkouts/get' : 'transparents/check';
    let data = null;
    let payload = null;
    try {
      data = await providerFetch(`${ABACATEPAY_API_BASE}/${endpoint}?id=${encodeURIComponent(transactionId)}`, { token });
      payload = data.data || data;
    } catch (error) {
      if (!isHostedCheckout) throw error;
      const listed = await findAbacateCheckoutInList(transactionId, token, order.public_code).catch(() => null);
      if (!listed) throw error;
      payload = listed;
    }
    if (isHostedCheckout && abacatePayStatusToFinancial(payload.status) === 'pending') {
      const listed = await findAbacateCheckoutInList(transactionId, token, order.public_code).catch(() => null);
      if (listed && abacatePayStatusToFinancial(listed.status) !== 'pending') payload = listed;
    }
    const providerAmount = Number(payload.paidAmount ?? payload.amount ?? payload.value ?? moneyCents(order.total));
    return {
      status: abacatePayStatusToFinancial(payload.status),
      amount: Number.isFinite(providerAmount) ? roundMoney(providerAmount / 100) : moneyNumber(order.total),
      provider_event_id: cleanExternalId(`abacatepay_${payload.id || transactionId}_${payload.status || 'status'}`),
      raw: payload
    };
  }
  if (order.payment_provider === 'mercadopago') {
    const token = integrations.pix.apiKey || integrations.card.apiKey;
    const data = await providerFetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(order.payment_transaction_id)}`, { token });
    return { status: mercadoPagoStatusToFinancial(data.status), amount: data.transaction_amount };
  }
  if (order.payment_provider === 'asaas') {
    const token = integrations.pix.apiKey || integrations.card.apiKey;
    const data = await providerFetch(`https://www.asaas.com/api/v3/payments/${encodeURIComponent(order.payment_transaction_id)}`, { token });
    return { status: asaasStatusToFinancial(data.status), amount: data.value };
  }
  return { status: order.financial_status, amount: order.total };
}

async function findAbacateCheckoutInList(transactionId, token, orderCode = '') {
  if ((!transactionId && !orderCode) || !token) return null;
  const data = await providerFetch(`${ABACATEPAY_API_BASE}/checkouts/list?limit=100`, { token });
  const payload = data.data || data;
  const items = Array.isArray(payload) ? payload : (Array.isArray(payload.items) ? payload.items : []);
  const normalizedTransactionId = cleanExternalId(transactionId || '');
  const normalizedOrderCode = cleanPublicCode(orderCode || '');
  return items.find((item) => abacateCheckoutMatchesOrder(item, normalizedTransactionId, normalizedOrderCode)) || null;
}

function abacateCheckoutMatchesOrder(item = {}, transactionId = '', orderCode = '') {
  const nested = item.billing || item.checkout || item.payment || {};
  const metadata = {
    ...(isPlainObject(item.metadata) ? item.metadata : {}),
    ...(isPlainObject(nested.metadata) ? nested.metadata : {})
  };
  const ids = [
    item.id,
    item.checkoutId,
    item.checkout_id,
    item.billingId,
    item.billing_id,
    item.externalId,
    item.external_id,
    nested.id,
    nested.checkoutId,
    nested.checkout_id,
    nested.billingId,
    nested.billing_id,
    nested.externalId,
    nested.external_id,
    metadata.externalId,
    metadata.external_id
  ].map((value) => cleanExternalId(value || '')).filter(Boolean);
  if (transactionId && ids.includes(transactionId)) return true;
  if (!orderCode) return false;
  return abacatePayOrderCodeFromPayload({ ...nested, ...item, metadata }, item) === orderCode;
}

async function getOrderByPublicCode(code, options = {}) {
  const db = options.db || dbRequest;
  const cleanCode = cleanPublicCode(String(code || '').replace(/^#/, ''));
  if (!cleanCode) return null;
  const rows = await db('GET', 'orders', {
    select: '*',
    public_code: `eq.${cleanCode}`,
    limit: '1'
  });
  return rows[0] || null;
}

function publicPaymentOrder(order) {
  return {
    public_code: order.public_code,
    total: moneyNumber(order.total),
    status: order.status,
    financial_status: order.financial_status || 'pending',
    payment_method: order.payment_method,
    payment_transaction_id: order.payment_transaction_id || null,
    paid_amount: order.paid_amount || null,
    paid_at: order.paid_at || null,
    payment_expires_at: order.payment_expires_at || null
  };
}

function publicPaymentPayload(order, options = {}) {
  const details = order.payment_details || {};
  return {
    status: order.financial_status || 'pending',
    provider: order.payment_provider || null,
    transaction_id: order.payment_transaction_id || null,
    expires_at: order.payment_expires_at || null,
    pix_code: details.pix_code || '',
    pix_qr_url: details.pix_qr_url || '',
    checkout_url: details.checkout_url || '',
    whatsapp_url: ''
  };
}

function publicOrderStoreWhatsappUrl(order, options = {}) {
  if (!order || !isOnlinePaymentMethod(order.payment_method)) return '';
  const message = cleanText(order.whatsapp_message || '');
  if (!message) return '';
  return whatsappStoreUrlForOrder(order, message, options.store) || '';
}

function whatsappStoreUrlForOrder(order, message, store = null) {
  const storePhone = whatsappRecipientPhone(store?.whatsapp_number || STORE_WHATSAPP_NUMBER);
  return storePhone ? `https://wa.me/${storePhone}?text=${encodeURIComponent(message)}` : '';
}

function buildMockPixCode(store, order, transactionId) {
  return `PIXONLINE|${store.slug || 'loja'}|${order.public_code}|${formatMoney(order.total)}|${transactionId}`;
}

function abacatePayCustomer(order) {
  const customer = order.customer_snapshot || {};
  const address = order.address_snapshot || {};
  const payload = {
    name: customer.name || `Cliente ${order.public_code}`,
    email: customer.email || `pedido-${order.public_code}@cardapio.local`,
    cellphone: abacatePayPhone(customer.phone || ''),
    taxId: onlyDigits(customer.document || customer.taxId || ''),
    zipCode: cleanText(address.postal_code || address.zipCode || '')
  };
  return Object.fromEntries(Object.entries(payload).filter(([, value]) => value));
}

function abacatePayPhone(value) {
  const digits = onlyDigits(value);
  if (!digits) return '';
  if (digits.startsWith('55') && (digits.length === 12 || digits.length === 13)) return digits.slice(2);
  return digits.slice(0, 11);
}

function moneyCents(value) {
  return Math.round(moneyNumber(value) * 100);
}

function centsToMoney(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 0;
  return numeric > 999 ? roundMoney(numeric / 100) : roundMoney(numeric);
}

function normalizeQrImage(value) {
  const data = String(value || '').trim();
  if (!data) return '';
  if (data.startsWith('data:image')) return data;
  return `data:image/png;base64,${data}`;
}

function sanitizeFinancialStatus(status) {
  const value = String(status || '').toLowerCase();
  if (['pending', 'paid', 'failed', 'expired', 'cancelled', 'refunded'].includes(value)) return value;
  return 'pending';
}

function sanitizePrintLog(data) {
  return {
    order_id: cleanText(data.order_id || '') || null,
    print_type: ['kitchen', 'customer', 'both'].includes(data.print_type) ? data.print_type : 'kitchen',
    paper_width: ['58', '80'].includes(String(data.paper_width)) ? String(data.paper_width) : '80',
    copies: clampInteger(data.copies, 1, 10),
    reason: ['manual', 'auto', 'retry', 'preview'].includes(data.reason) ? data.reason : 'manual',
    status: ['attempted', 'blocked', 'completed'].includes(data.status) ? data.status : 'attempted'
  };
}

async function listDiningTables(existingTabs = null) {
  const tables = await dbRequest('GET', 'dining_tables', {
    select: '*',
    order: 'name.asc'
  });
  const tabs = existingTabs || await listCustomerTabs();
  return enrichDiningTables(tables, tabs);
}

function enrichDiningTables(tables, tabs) {
  return tables.map((table) => ({
    ...table,
    open_tabs: tabs.filter((tab) => tab.status === 'open' && tab.dining_table_id === table.id),
    open_tab: tabs.find((tab) => tab.status === 'open' && tab.dining_table_id === table.id) || null
  }));
}

async function listAdminTablesData(storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const now = Date.now();
  const cacheKey = `${resolvedStoreId || 'default'}:${options.tenant?.id || 'central'}`;
  if (adminTablesCache?.[cacheKey] && adminTablesCache[cacheKey].expiresAt > now) return adminTablesCache[cacheKey].data;
  const [tables, tabs] = await Promise.all([
    db('GET', 'dining_tables', {
      select: '*',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      order: 'name.asc'
    }),
    listCustomerTabs(resolvedStoreId, options)
  ]);
  const data = { tables: enrichDiningTables(tables, tabs), tabs };
  adminTablesCache = adminTablesCache || {};
  adminTablesCache[cacheKey] = {
    data,
    expiresAt: now + ADMIN_LIST_CACHE_MS
  };
  return data;
}

async function listCustomerTabs(storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const tabs = await db('GET', 'customer_tabs', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    order: 'opened_at.desc',
    limit: '200'
  });
  const openTabIds = cleanUuidArray(tabs.filter((tab) => tab.status === 'open').map((tab) => tab.id));
  let ordersByTab = new Map();
  if (openTabIds.length) {
    const orders = await db('GET', 'orders', {
      select: 'id,customer_tab_id,total,status,created_at',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      customer_tab_id: uuidInFilter(openTabIds),
      order: 'created_at.desc',
      limit: '500'
    });
    ordersByTab = orders.reduce((map, order) => {
      const list = map.get(order.customer_tab_id) || [];
      list.push(order);
      map.set(order.customer_tab_id, list);
      return map;
    }, new Map());
  }
  return tabs.map((tab) => {
    const orders = ordersByTab.get(tab.id) || [];
    const total = roundMoney(orders
      .filter((order) => order.status !== 'cancelled')
      .reduce((sum, order) => sum + moneyNumber(order.total), 0));
    return {
      ...tab,
      order_count: orders.length,
      current_total: total
    };
  });
}

async function resolveDiningTable(code, storeId, options = {}) {
  const db = options.db || dbRequest;
  const cleanCode = cleanSlug(code || '');
  const resolvedStoreId = cleanUuid(storeId);
  if (!cleanCode) throw httpError(404, 'Mesa não informada.');
  const rows = await db('GET', 'dining_tables', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    code: `eq.${cleanCode}`,
    is_active: 'eq.true',
    limit: '1'
  });
  const table = rows[0];
  if (!table) throw httpError(404, 'Mesa não encontrada ou inativa.');
  const tabs = await db('GET', 'customer_tabs', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    dining_table_id: `eq.${table.id}`,
    status: 'eq.open',
    order: 'opened_at.asc',
    limit: '50'
  });
  let enrichedTabs = tabs;
  if (tabs.length) {
    const tabIds = cleanUuidArray(tabs.map((tab) => tab.id));
    const orders = tabIds.length
      ? await db('GET', 'orders', {
        select: '*',
        ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
        customer_tab_id: uuidInFilter(tabIds),
        order: 'created_at.desc',
        limit: '500'
      })
      : [];
    const ordersByTab = orders.reduce((map, order) => {
      const list = map.get(order.customer_tab_id) || [];
      list.push(order);
      map.set(order.customer_tab_id, list);
      return map;
    }, new Map());
    enrichedTabs = tabs.map((tab) => {
      const tabOrders = ordersByTab.get(tab.id) || [];
      return {
        ...tab,
        current_total: roundMoney(tabOrders
          .filter((order) => order.status !== 'cancelled')
          .reduce((sum, order) => sum + moneyNumber(order.total), 0)),
        order_count: tabOrders.length
      };
    });
  }
  const openTab = enrichedTabs.length === 1 ? enrichedTabs[0] : null;
  return { ...table, open_tab: openTab, open_tabs: enrichedTabs };
}

async function createDiningTable(data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  if (!resolvedStoreId) throw httpError(422, 'Loja ativa não encontrada.');
  const payload = sanitizeDiningTable(data, true);
  const basePayload = {
    ...payload,
    store_id: resolvedStoreId
  };

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const code = payload.code || await nextDiningTableCode(resolvedStoreId, options);
    try {
      const [table] = await db('POST', 'dining_tables', {}, {
        ...basePayload,
        code
      }, ['Prefer: return=representation']);
      return table;
    } catch (error) {
      if (!isUniqueViolation(error) || payload.code || attempt === 4) {
        throw httpError(409, 'Já existe uma mesa com este código nesta loja.', error.detail || error);
      }
    }
  }
  throw httpError(409, 'Não foi possível gerar um código único para a mesa. Tente novamente.');
}

async function nextDiningTableCode(storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const rows = await db('GET', 'dining_tables', {
    select: 'code',
    store_id: `eq.${resolvedStoreId}`,
    order: 'created_at.desc',
    limit: '10000'
  });
  const highest = rows.reduce((max, table) => {
    const match = String(table.code || '').match(/^mesa-(\d+)$/);
    return match ? Math.max(max, Number.parseInt(match[1], 10) || 0) : max;
  }, 0);
  return `mesa-${highest + 1}`;
}

async function updateDiningTable(id, data, storeId, options = {}) {
  const db = options.db || dbRequest;
  let table;
  try {
    [table] = await db('PATCH', 'dining_tables', {
      id: `eq.${id}`,
      ...(cleanUuid(storeId) ? { store_id: `eq.${cleanUuid(storeId)}` } : {})
    }, sanitizeDiningTable(data, false), ['Prefer: return=representation']);
  } catch (error) {
    if (isUniqueViolation(error)) {
      throw httpError(409, 'Já existe uma mesa com este código nesta loja.', error.detail || error);
    }
    throw error;
  }
  if (!table) throw httpError(404, 'Mesa não encontrada nesta loja.');
  return table;
}

async function deleteDiningTable(id, storeId, options = {}) {
  const db = options.db || dbRequest;
  const removed = await db('DELETE', 'dining_tables', {
    id: `eq.${id}`,
    ...(cleanUuid(storeId) ? { store_id: `eq.${cleanUuid(storeId)}` } : {})
  }, undefined, ['Prefer: return=representation']);
  if (Array.isArray(removed) && removed.length === 0) throw httpError(404, 'Mesa não encontrada nesta loja.');
}

async function openCustomerTab(data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const tableId = cleanText(data.dining_table_id || '');
  if (tableId) await requireActiveDiningTable(tableId, storeId, options);
  const payload = {
    store_id: cleanUuid(storeId) || null,
    name: cleanText(data.name || `Comanda ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`),
    customer_name: cleanText(data.customer_name || '') || null,
    dining_table_id: tableId || null,
    status: 'open'
  };
  const [tab] = await db('POST', 'customer_tabs', {}, payload, ['Prefer: return=representation']);
  return tab;
}

async function closeCustomerTab(id, data = {}, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const orders = await db('GET', 'orders', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    customer_tab_id: `eq.${id}`,
    order: 'created_at.asc',
    limit: '500'
  });
  const total = roundMoney(orders
    .filter((order) => order.status !== 'cancelled')
    .reduce((sum, order) => sum + moneyNumber(order.total), 0));
  const discount = roundMoney(Number.parseFloat(data.discount) || 0);
  const [tab] = await db('PATCH', 'customer_tabs', {
    id: `eq.${id}`,
    status: 'eq.open',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {})
  }, {
    status: 'closed',
    closed_at: new Date().toISOString(),
    payment_method: cleanText(data.payment_method || ''),
    discount,
    total: roundMoney(Math.max(0, total - discount))
  }, ['Prefer: return=representation']);
  if (!tab) throw httpError(409, 'Comanda não encontrada ou já fechada.');
  return tab;
}

async function transferCustomerTab(id, data = {}, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const tableId = cleanText(data.dining_table_id || '');
  if (!tableId) throw httpError(422, 'Informe a mesa de destino.');
  if (resolvedStoreId) {
    const [table] = await db('GET', 'dining_tables', {
      select: 'id',
      id: `eq.${tableId}`,
      store_id: `eq.${resolvedStoreId}`,
      limit: '1'
    });
    if (!table) throw httpError(404, 'Mesa de destino não encontrada nesta loja.');
  }
  const [tab] = await db('PATCH', 'customer_tabs', {
    id: `eq.${id}`,
    status: 'eq.open',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {})
  }, {
    dining_table_id: tableId
  }, ['Prefer: return=representation']);
  if (!tab) throw httpError(409, 'Comanda não encontrada ou já fechada.');
  return tab;
}

async function addItemToCustomerTab(req, tabId, data = {}, storeId, options = {}) {
  const tab = await requireOpenTab(tabId, null, storeId, options);
  if (!tab.dining_table_id) throw httpError(422, 'Vincule a comanda a uma mesa antes de adicionar itens pelo admin.');
  const itemId = cleanText(data.item_id || '');
  if (!itemId) throw httpError(422, 'Selecione um item do cardápio.');
  const quantity = clampInteger(data.quantity, 1, 99);
  const result = await createOrder(req, {
    fulfillment_method: 'tab',
    dining_table_id: tab.dining_table_id,
    customer_tab_id: tab.id,
    customer: {
      name: tab.customer_name || tab.name || 'Cliente da mesa',
      phone: ''
    },
    payment_method: 'Pagamento no fechamento',
    payment_details: {},
    notes: cleanText(data.notes || 'Lançado pelo admin na comanda.'),
    items: [{
      id: itemId,
      quantity,
      modifier_ids: [],
      notes: cleanText(data.item_notes || '')
    }]
  }, {
    storeId,
    db: options.db,
    tenant: options.tenant,
    allowClosedStore: true,
    skipModifierValidation: true
  });
  return { order: result.order };
}

async function clearOrderQueue(data = {}, options = {}) {
  const db = options.db || dbRequest;
  const mode = ['close_open', 'archive_closed'].includes(data.mode) ? data.mode : 'close_open';
  const storeId = cleanUuid(data.storeId || data.store_id);
  const openStatuses = ['new', 'accepted', 'preparing', 'ready', 'out_for_delivery'];
  const archivedAt = new Date().toISOString();
  let openArchived = [];
  if (mode === 'close_open') {
    openArchived = await db('PATCH', 'orders', {
      ...(storeId ? { store_id: `eq.${storeId}` } : {}),
      status: `in.(${openStatuses.join(',')})`,
      archived_at: 'is.null'
    }, {
      status: 'completed',
      archived_at: archivedAt
    }, ['Prefer: return=representation']);
  }
  const closedArchived = await db('PATCH', 'orders', {
    ...(storeId ? { store_id: `eq.${storeId}` } : {}),
    status: 'in.(completed,cancelled)',
    archived_at: 'is.null'
  }, {
    archived_at: archivedAt
  }, ['Prefer: return=representation']);
  clearAdminOrdersCache(storeId);
  return {
    archived: openArchived.length + closedArchived.length,
    closed: openArchived.length,
    hidden: closedArchived.length,
    mode
  };
}

async function dailyOrderReport(dateValue, storeId, options = {}) {
  const day = validReportDate(dateValue);
  const start = reportDateStart(day);
  const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);
  return orderReportBetween(start, end, {
    date: day,
    label: `Dia ${formatReportDate(day)}`,
    start: day,
    end: day
  }, storeId, options);
}

async function rangeOrderReport({ days, start, end, storeId, db, tenant } = {}) {
  const options = { db, tenant };
  const today = validReportDate(new Date().toISOString().slice(0, 10));
  const parsedDays = Number.parseInt(days, 10);

  if ([7, 15, 30].includes(parsedDays)) {
    const endDay = today;
    const startDate = reportDateStart(endDay);
    startDate.setDate(startDate.getDate() - parsedDays + 1);
    const startDay = localReportDate(startDate);
    const endExclusive = reportDateStart(endDay);
    endExclusive.setDate(endExclusive.getDate() + 1);
    return orderReportBetween(reportDateStart(startDay), endExclusive, {
      label: `Últimos ${parsedDays} dias`,
      start: startDay,
      end: endDay,
      days: parsedDays
    }, storeId, options);
  }

  const startDay = validReportDate(start || today);
  const endDay = validReportDate(end || today);
  const startDate = reportDateStart(startDay);
  const endExclusive = reportDateStart(endDay);
  endExclusive.setDate(endExclusive.getDate() + 1);
  const label = startDay === endDay
    ? `Dia ${formatReportDate(startDay)}`
    : `${formatReportDate(startDay)} a ${formatReportDate(endDay)}`;
  return orderReportBetween(startDate, endExclusive, {
    label,
    start: startDay,
    end: endDay
  }, storeId, options);
}

async function orderReportBetween(start, end, period, storeId, options = {}) {
  const db = options.db || dbRequest;
  const spanMs = end.getTime() - start.getTime();
  const previousStart = new Date(start.getTime() - spanMs);
  const resolvedStoreId = cleanUuid(storeId);
  const orders = await db('GET', 'orders', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    and: `(created_at.gte.${previousStart.toISOString()},created_at.lt.${end.toISOString()})`,
    order: 'created_at.desc',
    limit: '5000'
  });
  const currentOrders = orders.filter((order) => {
    const createdAt = new Date(order.created_at);
    return createdAt >= start && createdAt < end;
  });
  const previousOrders = orders.filter((order) => {
    const createdAt = new Date(order.created_at);
    return createdAt >= previousStart && createdAt < start;
  });
  const withItems = await attachOrderItems(currentOrders, options);
  const totals = reportTotals(withItems);
  const previousTotals = reportTotals(previousOrders);

  return {
    date: period.start,
    period,
    totals,
    comparison: {
      label: 'Período anterior',
      totals: previousTotals,
      revenue_delta: roundMoney(totals.gross_revenue - previousTotals.gross_revenue),
      orders_delta: totals.orders - previousTotals.orders
    },
    by_status: groupOrderTotals(withItems, 'status'),
    by_payment: groupOrderTotals(withItems.filter((order) => order.status !== 'cancelled'), 'payment_method'),
    by_origin: groupOrderTotals(withItems.filter((order) => order.status !== 'cancelled'), 'fulfillment_method'),
    by_hour: hourlyOrderTotals(withItems.filter((order) => order.status !== 'cancelled')),
    cash_closing: cashClosingTotals(withItems),
    top_products: topProductTotals(withItems.filter((order) => order.status !== 'cancelled')),
    orders: withItems
  };
}

async function applyReportPlanAccess(report, companyId) {
  const access = companyId ? await getCompanyPlanAccess(companyId).catch(() => ({})) : {};
  const summary = reportAccessSummary(access);
  const enriched = {
    ...report,
    report_access: summary
  };
  if (summary.level === 'advanced') {
    return {
      ...enriched,
      report_locks: [
        {
          feature: 'business_insights',
          title: 'Insights avançados',
          message: featureBlockedMessage('business_insights')
        }
      ]
    };
  }
  if (summary.level !== 'basic') return enriched;
  return {
    ...enriched,
    by_origin: [],
    by_hour: [],
    top_products: [],
    orders: [],
    report_locks: [
      {
        feature: 'advanced_reports',
        title: 'Relatórios completos',
        message: featureBlockedMessage('advanced_reports')
      },
      {
        feature: 'business_insights',
        title: 'Insights avançados',
        message: featureBlockedMessage('business_insights')
      }
    ]
  };
}

function reportAccessSummary(access = {}) {
  const hasBasic = access.basic_reports?.enabled === true;
  const hasAdvanced = access.advanced_reports?.enabled === true;
  const hasInsights = access.business_insights?.enabled === true;
  const level = hasInsights ? 'insights' : hasAdvanced ? 'advanced' : hasBasic ? 'basic' : 'none';
  return {
    level,
    label: ({
      none: 'Sem relatórios',
      basic: 'Relatório simples',
      advanced: 'Relatório completo',
      insights: 'Insights avançados'
    })[level],
    basic_reports: hasBasic,
    advanced_reports: hasAdvanced,
    business_insights: hasInsights
  };
}

function reportTotals(orders) {
  const billable = orders.filter((order) => order.status !== 'cancelled');
  const completed = orders.filter((order) => order.status === 'completed');
  const grossRevenue = roundMoney(billable.reduce((sum, order) => sum + moneyNumber(order.total), 0));
  return {
    orders: orders.length,
    billable_orders: billable.length,
    completed_orders: completed.length,
    cancelled_orders: orders.filter((order) => order.status === 'cancelled').length,
    gross_revenue: grossRevenue,
    completed_revenue: roundMoney(completed.reduce((sum, order) => sum + moneyNumber(order.total), 0)),
    average_ticket: billable.length ? roundMoney(grossRevenue / billable.length) : 0
  };
}

function reportDateStart(value) {
  return new Date(`${validReportDate(value)}T00:00:00.000-03:00`);
}

function localReportDate(date) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(date);
  const value = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${value.year}-${value.month}-${value.day}`;
}

function formatReportDate(value) {
  const [year, month, day] = validReportDate(value).split('-');
  return `${day}/${month}/${year}`;
}

function groupOrderTotals(orders, field) {
  const grouped = new Map();
  for (const order of orders) {
    const key = order[field] || 'Não informado';
    const current = grouped.get(key) || { key, count: 0, total: 0, average_ticket: 0 };
    current.count += 1;
    current.total = roundMoney(current.total + moneyNumber(order.total));
    current.average_ticket = roundMoney(current.total / current.count);
    grouped.set(key, current);
  }
  return [...grouped.values()];
}

function cashClosingTotals(orders) {
  const billable = orders.filter((order) => order.status !== 'cancelled');
  const completed = orders.filter((order) => order.status === 'completed');
  const expectedRevenue = roundMoney(billable.reduce((sum, order) => sum + moneyNumber(order.total), 0));
  const completedRevenue = roundMoney(completed.reduce((sum, order) => sum + moneyNumber(order.total), 0));
  return {
    expected_revenue: expectedRevenue,
    completed_revenue: completedRevenue,
    pending_revenue: roundMoney(billable
      .filter((order) => order.status !== 'completed')
      .reduce((sum, order) => sum + moneyNumber(order.total), 0)),
    delivery_fees: roundMoney(billable.reduce((sum, order) => sum + moneyNumber(order.delivery_fee), 0)),
    discounts: roundMoney(billable.reduce((sum, order) => sum + moneyNumber(order.discount), 0)),
    coupons: billable.filter((order) => order.promotion_code).length,
    divergence: roundMoney(expectedRevenue - completedRevenue),
    by_payment: groupOrderTotals(completed, 'payment_method'),
    order_count: billable.length
  };
}

function hourlyOrderTotals(orders) {
  const grouped = new Map();
  for (const order of orders) {
    const hour = new Intl.DateTimeFormat('pt-BR', {
      timeZone: 'America/Sao_Paulo',
      hour: '2-digit',
      hour12: false
    }).format(new Date(order.created_at));
    const key = `${hour}:00`;
    const current = grouped.get(key) || { key, count: 0, total: 0 };
    current.count += 1;
    current.total = roundMoney(current.total + moneyNumber(order.total));
    grouped.set(key, current);
  }
  return [...grouped.values()].sort((a, b) => a.key.localeCompare(b.key));
}

function topProductTotals(orders) {
  const grouped = new Map();
  for (const order of orders) {
    for (const item of order.items || []) {
      const name = item.item_snapshot?.name || 'Item removido';
      const current = grouped.get(name) || { name, quantity: 0, total: 0 };
      current.quantity += Number(item.quantity || 0);
      current.total = roundMoney(current.total + moneyNumber(item.total));
      grouped.set(name, current);
    }
  }
  return [...grouped.values()]
    .sort((a, b) => b.quantity - a.quantity || b.total - a.total)
    .slice(0, 8);
}

function validReportDate(value) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  return localReportDate(new Date());
}

async function attachOrderItems(orders, options = {}) {
  const db = options.db || dbRequest;
  if (orders.length === 0) return [];

  const ids = cleanUuidArray(orders.map((order) => order.id));
  if (ids.length === 0) return orders.map((order) => ({ ...order, items: [] }));
  const items = await db('GET', 'order_items', {
    select: '*',
    order_id: uuidInFilter(ids),
    order: 'created_at.asc'
  });

  const byOrder = new Map(orders.map((order) => [order.id, { ...order, items: [] }]));
  for (const item of items) {
    byOrder.get(item.order_id)?.items.push(item);
  }

  return [...byOrder.values()];
}

async function assertOrderBelongsToStore(orderId, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedOrderId = cleanUuid(orderId, 'pedido');
  const resolvedStoreId = cleanUuid(storeId);
  const [order] = await db('GET', 'orders', {
    select: 'id,store_id',
    id: `eq.${resolvedOrderId}`,
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    limit: '1'
  });
  if (!order) throw httpError(404, 'Pedido não encontrado nesta loja.');
  return order;
}

async function listCustomers(storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const cacheKey = `${resolvedStoreId || 'default'}:${options.tenant?.id || 'central'}`;
  const now = Date.now();
  if (adminCustomersCache?.[cacheKey] && adminCustomersCache[cacheKey].expiresAt > now) return adminCustomersCache[cacheKey].data;
  const customers = await db('GET', 'customers', {
    select: 'id,store_id,name,phone,email,birth_date,notes,created_at,updated_at,last_login_at',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    order: 'created_at.desc',
    limit: '100'
  });
  if (!customers.length) {
    adminCustomersCache = adminCustomersCache || {};
    adminCustomersCache[cacheKey] = {
      data: [],
      expiresAt: now + ADMIN_LIST_CACHE_MS
    };
    return [];
  }
  const ids = cleanUuidArray(customers.map((customer) => customer.id));
  const addresses = ids.length
    ? await db('GET', 'customer_addresses', {
      select: '*',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      customer_id: uuidInFilter(ids),
      order: 'is_default.desc,created_at.desc'
    })
    : [];
  const byCustomer = new Map();
  for (const address of addresses) {
    if (!byCustomer.has(address.customer_id)) byCustomer.set(address.customer_id, []);
    byCustomer.get(address.customer_id).push(address);
  }
  const data = customers.map((customer) => ({
    ...customer,
    addresses: byCustomer.get(customer.id) || []
  }));
  adminCustomersCache = adminCustomersCache || {};
  adminCustomersCache[cacheKey] = {
    data,
    expiresAt: now + ADMIN_LIST_CACHE_MS
  };
  return data;
}

async function listPromotions(storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const cacheKey = `${resolvedStoreId || 'default'}:${options.tenant?.id || 'central'}`;
  const now = Date.now();
  if (adminPromotionsCache?.[cacheKey] && adminPromotionsCache[cacheKey].expiresAt > now) return adminPromotionsCache[cacheKey].data;
  try {
    const data = await db('GET', 'promotions', {
      select: '*',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      order: 'created_at.desc'
    });
    adminPromotionsCache = adminPromotionsCache || {};
    adminPromotionsCache[cacheKey] = {
      data,
      expiresAt: now + ADMIN_LIST_CACHE_MS
    };
    return data;
  } catch (error) {
    const detail = JSON.stringify(error.detail || '');
    if (error.status === 404 || detail.includes('promotions')) return [];
    throw error;
  }
}

async function previewCoupon(req, data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const code = cleanText(data.code || '').toUpperCase().replace(/[^A-Z0-9_-]/g, '');
  const subtotal = roundMoney(Number.parseFloat(data.subtotal) || 0);
  const deliveryFee = roundMoney(Number.parseFloat(data.delivery_fee) || 0);
  if (!code) throw httpError(422, 'Informe o cupom.');
  const coupon = await findActivePromotion(code, {
    db,
    storeId,
    subtotal,
    deliveryFee,
    customer: await promotionCustomerContext(req, data, storeId, options),
    items: await promotionItemsContext(data.items || [], storeId, options)
  });
  const discount = couponDiscountAmount(coupon, subtotal, deliveryFee);
  return {
    code: coupon.code,
    name: coupon.name,
    description: coupon.description || null,
    discount,
    discount_type: coupon.discount_type,
    promotion_type: coupon.promotion_type || 'general'
  };
}

async function promotionCustomerContext(req, data, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const session = await readPersistentSession(parseCookies(req)[CUSTOMER_COOKIE], 'customer');
  if (session?.data?.id) return getCustomerProfile(session.data.id, resolvedStoreId, options);

  const phone = onlyDigits(data.phone || data.customer?.phone || '');
  if (!phone) return null;
  const rows = await db('GET', 'customers', {
    select: 'id,store_id,name,phone,email,birth_date,notes,created_at,updated_at',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    phone: `eq.${phone}`,
    limit: '1'
  });
  return rows[0] || null;
}

async function promotionItemsContext(rawItems, storeId, options = {}) {
  const db = options.db || dbRequest;
  const resolvedStoreId = cleanUuid(storeId);
  const requestedItems = Array.isArray(rawItems) ? rawItems : [];
  const itemIds = cleanUuidArray(requestedItems.map((item) => item.id));
  if (itemIds.length === 0) return [];
  const items = await db('GET', 'menu_items', {
    select: 'id,name,category_id,price',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    id: uuidInFilter(itemIds)
  });
  const byId = new Map(items.map((item) => [item.id, item]));
  return requestedItems.map((requested) => {
    const item = byId.get(cleanUuid(requested.id));
    if (!item) return null;
    return {
      menu_item_id: item.id,
      quantity: clampInteger(requested.quantity, 1, 99),
      item_snapshot: {
        id: item.id,
        name: item.name,
        category_id: item.category_id,
        price: moneyNumber(item.price)
      }
    };
  }).filter(Boolean);
}

async function findActivePromotion(code, context) {
  const db = context.db || dbRequest;
  const subtotal = roundMoney(Number(context.subtotal || 0));
  const deliveryFee = roundMoney(Number(context.deliveryFee || 0));
  const resolvedStoreId = cleanUuid(context.storeId);
  const rows = await db('GET', 'promotions', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    code: `eq.${code}`,
    is_active: 'eq.true',
    limit: '1'
  });
  const coupon = rows[0];
  if (!coupon) throw httpError(404, 'Cupom não encontrado ou inativo.');
  const now = Date.now();
  if (coupon.starts_at && new Date(coupon.starts_at).getTime() > now) throw httpError(422, 'Cupom ainda não começou.');
  if (coupon.ends_at && new Date(coupon.ends_at).getTime() < now) throw httpError(422, 'Cupom expirado.');
  if (coupon.max_uses && Number(coupon.used_count || 0) >= Number(coupon.max_uses)) throw httpError(422, 'Cupom esgotado.');
  if (subtotal < moneyNumber(coupon.minimum_order)) {
    throw httpError(422, `Pedido mínimo para este cupom: ${formatMoney(coupon.minimum_order)}.`);
  }
  if ((coupon.discount_type === 'free_delivery' || coupon.promotion_type === 'free_delivery') && deliveryFee <= 0) {
    throw httpError(422, 'Este cupom é para pedidos com entrega.');
  }
  await assertPromotionAudience(coupon, { ...context, db, subtotal, deliveryFee });
  return coupon;
}

async function assertPromotionAudience(coupon, context) {
  const promotionType = coupon.promotion_type || 'general';
  const items = Array.isArray(context.items) ? context.items : [];
  const itemIds = new Set(items.map((item) => item.menu_item_id || item.item_snapshot?.id).filter(Boolean));
  const categoryIds = new Set(items.map((item) => item.item_snapshot?.category_id).filter(Boolean));
  const allowedCategoryIds = cleanIdArray(coupon.allowed_category_ids);
  const comboItemIds = cleanIdArray(coupon.combo_item_ids);

  if (allowedCategoryIds.length && !allowedCategoryIds.some((categoryId) => categoryIds.has(categoryId))) {
    throw httpError(422, 'Este cupom não vale para as categorias escolhidas.');
  }

  if (promotionType === 'combo' && comboItemIds.length && !comboItemIds.every((itemId) => itemIds.has(itemId))) {
    throw httpError(422, 'Este combo precisa dos produtos configurados na promoção.');
  }

  const customer = context.customer || null;
  await assertPromotionUseLimitPerCustomer(coupon, customer, context);

  if (!['first_order', 'recurring', 'birthday'].includes(promotionType)) return;

  const orderCount = customer?.id ? await customerOrderCount(customer.id, context) : 0;

  if (promotionType === 'first_order' && orderCount > 0) {
    throw httpError(422, 'Este cupom é válido apenas para a primeira compra.');
  }

  if (promotionType === 'recurring') {
    const minOrders = Math.max(1, Number(coupon.recurring_min_orders || 2));
    if (!customer?.id || orderCount < minOrders) {
      throw httpError(422, `Este cupom é para clientes com pelo menos ${minOrders} pedido(s).`);
    }
  }

  if (promotionType === 'birthday') {
    if (!customer?.birth_date) throw httpError(422, 'Informe a data de aniversário no cadastro para usar este cupom.');
    const windowDays = Math.max(0, Number(coupon.birthday_window_days || 7));
    if (!isBirthdayWithinWindow(customer.birth_date, windowDays)) {
      throw httpError(422, 'Este cupom só vale perto da data de aniversário.');
    }
  }
}

async function assertPromotionUseLimitPerCustomer(coupon, customer, context = {}) {
  const db = context.db || dbRequest;
  const limit = Math.max(1, Number(coupon.max_uses_per_customer || 1));
  if (!customer?.id) return;
  const uses = await db('GET', 'orders', {
    select: 'id',
    customer_id: `eq.${customer.id}`,
    promotion_code: `eq.${coupon.code}`
  });
  if (uses.length >= limit) {
    throw httpError(422, `Este cupom já atingiu o limite de ${limit} uso(s) para sua conta.`);
  }
}

async function customerOrderCount(customerId, context = {}) {
  const db = context.db || dbRequest;
  const orders = await db('GET', 'orders', {
    select: 'id',
    customer_id: `eq.${customerId}`
  });
  return orders.length;
}

function isBirthdayWithinWindow(birthDate, windowDays) {
  const birthday = new Date(`${String(birthDate).slice(0, 10)}T12:00:00`);
  if (Number.isNaN(birthday.getTime())) return false;
  const now = new Date();
  const thisYear = new Date(now.getFullYear(), birthday.getMonth(), birthday.getDate(), 12, 0, 0);
  const nextYear = new Date(now.getFullYear() + 1, birthday.getMonth(), birthday.getDate(), 12, 0, 0);
  const previousYear = new Date(now.getFullYear() - 1, birthday.getMonth(), birthday.getDate(), 12, 0, 0);
  const diffDays = Math.min(
    Math.abs(thisYear.getTime() - now.getTime()),
    Math.abs(nextYear.getTime() - now.getTime()),
    Math.abs(previousYear.getTime() - now.getTime())
  ) / 86400000;
  return diffDays <= windowDays;
}

function cleanIdArray(value) {
  if (!Array.isArray(value)) return [];
  return cleanUuidArray(value);
}

function couponDiscountAmount(coupon, subtotal, deliveryFee) {
  if (!coupon) return 0;
  if (coupon.discount_type === 'free_delivery' || coupon.promotion_type === 'free_delivery') return roundMoney(deliveryFee);
  if (coupon.discount_type === 'percent') return roundMoney(subtotal * Math.min(100, moneyNumber(coupon.discount_value)) / 100);
  return roundMoney(Math.min(subtotal, moneyNumber(coupon.discount_value)));
}

function defaultBusinessHours() {
  return {
    monday: { open: '18:00', close: '23:00', closed: false },
    tuesday: { open: '18:00', close: '23:00', closed: false },
    wednesday: { open: '18:00', close: '23:00', closed: false },
    thursday: { open: '18:00', close: '23:00', closed: false },
    friday: { open: '18:00', close: '23:30', closed: false },
    saturday: { open: '18:00', close: '23:30', closed: false },
    sunday: { open: '18:00', close: '23:00', closed: false }
  };
}

function defaultNeighborhoodFees() {
  return {
    Centro: 5,
    'Bela Vista': 8,
    Interior: 12
  };
}

function defaultLoyaltyProgram() {
  return {
    is_active: false,
    mode: 'orders_reward',
    reward: 'Item grátis',
    orders_required: 5,
    points_per_currency: 1,
    points_target: 500
  };
}

function defaultThemeSettings() {
  return {
    primaryColor: '#d71920',
    secondaryColor: '#18181b',
    backgroundColor: '#f5f5f4',
    buttonColor: '#d71920',
    buttonTextColor: '#ffffff',
    selectionColor: '#d71920',
    selectionTextColor: '#ffffff'
  };
}

function defaultPrintSettings() {
  return {
    paperWidth: '80',
    kitchenCopies: 1,
    customerCopies: 1,
    autoPrintKitchen: false,
    autoPrintKitchenStatus: 'accepted',
    showKitchenPrices: false,
    highlightNotes: true
  };
}

function defaultIntegrationSettings() {
  return {
    whatsapp: {
      enabled: false,
      provider: 'official',
      phoneNumberId: '',
      accessToken: '',
      apiUrl: ''
    },
    pix: {
      enabled: false,
      provider: 'abacatepay',
      apiKey: '',
      webhookSecret: '',
      expirationMinutes: 15
    },
    card: {
      enabled: false,
      provider: 'mock',
      apiKey: '',
      returnUrl: ''
    },
    split: {
      enabled: false,
      recipientId: '',
      percentage: 0
    },
    reconciliation: {
      enabled: false,
      days: 7
    }
  };
}

function sanitizePrintSettings(value) {
  const defaults = defaultPrintSettings();
  const data = isPlainObject(value) ? value : {};
  return {
    paperWidth: ['58', '80'].includes(String(data.paperWidth)) ? String(data.paperWidth) : defaults.paperWidth,
    kitchenCopies: clampInteger(data.kitchenCopies, 1, 5),
    customerCopies: clampInteger(data.customerCopies, 1, 5),
    autoPrintKitchen: Boolean(data.autoPrintKitchen),
    autoPrintKitchenStatus: ['new', 'accepted', 'preparing'].includes(String(data.autoPrintKitchenStatus))
      ? String(data.autoPrintKitchenStatus)
      : defaults.autoPrintKitchenStatus,
    showKitchenPrices: Boolean(data.showKitchenPrices),
    highlightNotes: data.highlightNotes === undefined ? defaults.highlightNotes : Boolean(data.highlightNotes)
  };
}

function sanitizeIntegrationSettings(value) {
  const defaults = defaultIntegrationSettings();
  const data = isPlainObject(value) ? value : {};
  const whatsapp = isPlainObject(data.whatsapp) ? data.whatsapp : {};
  const pix = isPlainObject(data.pix) ? data.pix : {};
  const card = isPlainObject(data.card) ? data.card : {};
  const split = isPlainObject(data.split) ? data.split : {};
  const reconciliation = isPlainObject(data.reconciliation) ? data.reconciliation : {};
  return {
    whatsapp: {
      enabled: Boolean(whatsapp.enabled),
      provider: ['official', 'webhook', 'whatsevolution', 'mock'].includes(String(whatsapp.provider)) ? String(whatsapp.provider) : defaults.whatsapp.provider,
      phoneNumberId: cleanText(whatsapp.phoneNumberId || '').slice(0, 120),
      accessToken: cleanText(whatsapp.accessToken || '').slice(0, 500),
      apiUrl: cleanText(whatsapp.apiUrl || '').slice(0, 500)
    },
    pix: {
      enabled: Boolean(pix.enabled),
      provider: pix.enabled === false ? defaults.pix.provider : 'abacatepay',
      apiKey: cleanText(revealPaymentSecret(pix.apiKey || '')).slice(0, 500),
      webhookSecret: cleanText(revealPaymentSecret(pix.webhookSecret || '')).slice(0, 500),
      expirationMinutes: clampInteger(pix.expirationMinutes || defaults.pix.expirationMinutes, 5, 120)
    },
    card: {
      enabled: false,
      provider: defaults.card.provider,
      apiKey: '',
      returnUrl: ''
    },
    split: {
      enabled: false,
      recipientId: '',
      percentage: 0
    },
    reconciliation: {
      enabled: false,
      days: clampInteger(reconciliation.days || defaults.reconciliation.days, 1, 30)
    }
  };
}

function protectIntegrationSettings(settings) {
  const next = structuredClone(settings || defaultIntegrationSettings());
  if (next.pix?.enabled && !paymentSecretsKey()) {
    throw httpError(503, 'Configure PAYMENT_SECRETS_KEY no servidor antes de salvar credenciais de pagamento.');
  }
  if (next.pix?.enabled && (!next.pix.apiKey || !next.pix.webhookSecret)) {
    throw httpError(422, 'Para ativar o Pix online, informe a API key e o segredo do webhook da Abacate Pay.');
  }
  if (next.pix) {
    next.pix.apiKey = protectPaymentSecret(next.pix.apiKey || '');
    next.pix.webhookSecret = protectPaymentSecret(next.pix.webhookSecret || '');
  }
  return next;
}

function paymentSecretsKey() {
  const secret = String(process.env.PAYMENT_SECRETS_KEY || '').trim();
  return secret ? createHash('sha256').update(secret).digest() : null;
}

function protectPaymentSecret(value) {
  const plain = String(value || '');
  if (!plain || plain.startsWith('enc:v1:')) return plain;
  const key = paymentSecretsKey();
  if (!key) return plain;
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  return `enc:v1:${iv.toString('base64url')}:${cipher.getAuthTag().toString('base64url')}:${encrypted.toString('base64url')}`;
}

function revealPaymentSecret(value) {
  const stored = String(value || '');
  if (!stored.startsWith('enc:v1:')) return stored;
  const key = paymentSecretsKey();
  if (!key) throw httpError(503, 'PAYMENT_SECRETS_KEY ausente ou inválida para ler as credenciais de pagamento.');
  try {
    const [, , ivValue, tagValue, encryptedValue] = stored.split(':');
    const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(ivValue, 'base64url'));
    decipher.setAuthTag(Buffer.from(tagValue, 'base64url'));
    return Buffer.concat([decipher.update(Buffer.from(encryptedValue, 'base64url')), decipher.final()]).toString('utf8');
  } catch {
    throw httpError(503, 'Não foi possível descriptografar as credenciais de pagamento. Verifique PAYMENT_SECRETS_KEY.');
  }
}

function mergeIntegrationSettings(currentValue, nextValue) {
  const current = sanitizeIntegrationSettings(currentValue || {});
  const next = sanitizeIntegrationSettings(nextValue || {});
  const rawNext = isPlainObject(nextValue) ? nextValue : {};
  const rawWhatsapp = isPlainObject(rawNext.whatsapp) ? rawNext.whatsapp : {};
  const rawPix = isPlainObject(rawNext.pix) ? rawNext.pix : {};

  if (shouldKeepExistingSecret(rawWhatsapp.accessToken)) {
    next.whatsapp.accessToken = current.whatsapp.accessToken;
  }
  if (shouldKeepExistingSecret(rawPix.apiKey)) {
    next.pix.apiKey = current.pix.apiKey;
  }
  if (shouldKeepExistingSecret(rawPix.webhookSecret)) {
    next.pix.webhookSecret = current.pix.webhookSecret;
  }

  return next;
}

function shouldKeepExistingSecret(value) {
  const text = String(value || '').trim();
  return !text || isMaskedSecretValue(text);
}

function isMaskedSecretValue(value) {
  return /^\*{4,}/.test(String(value || '').trim());
}

function maskedSecret(value) {
  const text = String(value || '');
  if (!text) return '';
  const tail = text.slice(-4);
  return `****${tail}`;
}

function adminStore(store) {
  const copy = {
    ...store,
    loyalty_program: sanitizeLoyaltyProgram(store.loyalty_program || {}),
    theme_settings: sanitizeThemeSettings(store.theme_settings || {}),
    print_settings: sanitizePrintSettings(store.print_settings || {})
  };
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  copy.integration_settings = {
    ...integrations,
    whatsapp: {
      ...integrations.whatsapp,
      accessToken: maskedSecret(integrations.whatsapp.accessToken),
      hasAccessToken: Boolean(integrations.whatsapp.accessToken)
    },
    pix: {
      ...integrations.pix,
      apiKey: maskedSecret(integrations.pix.apiKey),
      webhookSecret: maskedSecret(integrations.pix.webhookSecret),
      hasApiKey: Boolean(integrations.pix.apiKey),
      hasWebhookSecret: Boolean(integrations.pix.webhookSecret)
    }
  };
  return copy;
}

function publicStore(store) {
  const copy = { ...store };
  const integrations = sanitizeIntegrationSettings(store.integration_settings || {});
  copy.integration_settings = {
    whatsapp: { enabled: integrations.whatsapp.enabled },
    pix: {
      enabled: integrations.pix.enabled,
      provider: integrations.pix.enabled ? integrations.pix.provider : 'mock',
      expirationMinutes: integrations.pix.expirationMinutes
    },
    card: { enabled: false },
    split: { enabled: false },
    reconciliation: { enabled: false }
  };
  return copy;
}

function sanitizeThemeSettings(value) {
  const defaults = defaultThemeSettings();
  const data = isPlainObject(value) ? value : {};
  return Object.fromEntries(Object.entries(defaults).map(([key, fallback]) => {
    const color = String(data[key] || '').trim();
    return [key, /^#[0-9a-fA-F]{6}$/.test(color) ? color.toLowerCase() : fallback];
  }));
}

function sanitizeLoyaltyProgram(value) {
  const defaults = defaultLoyaltyProgram();
  const data = isPlainObject(value) ? value : {};
  const mode = data.mode === 'points' ? 'points' : 'orders_reward';
  return {
    is_active: data.is_active === true || data.is_active === 'true' || data.is_active === 'on' || data.is_active === '1',
    mode,
    reward: cleanText(data.reward || defaults.reward) || defaults.reward,
    orders_required: clampInteger(data.orders_required, 1, 999),
    points_per_currency: Math.max(0.01, roundMoney(Number.parseFloat(data.points_per_currency) || defaults.points_per_currency)),
    points_target: clampInteger(data.points_target, 1, 999999)
  };
}

function deliveryFeeForAddress(store, address) {
  const fallback = moneyNumber(store.delivery_fee);
  const rules = isPlainObject(store.delivery_neighborhood_fees) ? store.delivery_neighborhood_fees : {};
  const neighborhood = normalizeName(address?.neighborhood || '');
  if (!neighborhood) return fallback;
  for (const [name, value] of Object.entries(rules)) {
    if (normalizeName(name) === neighborhood) return moneyNumber(value);
  }
  return fallback;
}

async function uploadImage(data) {
  const fileName = cleanFileName(data.fileName || 'produto.jpg');
  const contentType = cleanText(data.contentType || 'image/jpeg').split(';')[0].toLowerCase();
  const base64 = String(data.dataBase64 || '').replace(/^data:[^;]+;base64,/, '');
  const folder = uploadFolder(data.usage);

  if (!base64) throw httpError(422, 'Arquivo de imagem ausente.');
  if (!allowedUploadTypes.has(contentType)) {
    throw httpError(422, 'Envie apenas imagens JPG, PNG ou WebP.');
  }

  const buffer = Buffer.from(base64, 'base64');
  if (buffer.length > 5 * 1024 * 1024) throw httpError(422, 'Imagem muito grande. Limite de 5 MB.');
  if (detectImageContentType(buffer) !== contentType) {
    throw httpError(422, 'O conteúdo do arquivo não corresponde ao tipo de imagem informado.');
  }

  const objectPath = `${folder}/${Date.now()}-${randomBytes(6).toString('hex')}-${fileName}`;
  const fullPath = path.join(UPLOAD_DIR, objectPath);
  if (!fullPath.startsWith(UPLOAD_DIR)) throw httpError(400, 'Caminho de upload inválido.');
  await mkdir(path.dirname(fullPath), { recursive: true });
  await writeFile(fullPath, buffer, { flag: 'wx' });

  return {
    path: objectPath,
    url: `/uploads/${objectPath.replaceAll(path.sep, '/')}`
  };
}
function uploadFolder(usage) {
  return ({
    logo: 'store/logo',
    favicon: 'store/favicon',
    cover: 'store/cover',
    product: 'products'
  })[cleanText(usage || '').toLowerCase()] || 'products';
}

async function dbRequest(method, table, query = {}, payload, extraHeaders = []) {
  if (method !== 'GET') {
    return localDbRequest({ scope: 'local-postgres' }, method, table, query, payload, extraHeaders);
  }
  const key = `${table}:${JSON.stringify(query)}`;
  const existing = inflightDbReads.get(key);
  if (existing) return existing;
  const pending = localDbRequest({ scope: 'local-postgres' }, method, table, query, payload, extraHeaders);
  inflightDbReads.set(key, pending);
  try {
    return await pending;
  } finally {
    if (inflightDbReads.get(key) === pending) inflightDbReads.delete(key);
  }
}

async function localDbRequest(config, method, table, query = {}, payload, extraHeaders = []) {
  try {
    return await localPostgrestRequest(method, table, query, payload, extraHeaders);
  } catch (error) {
    console.error(JSON.stringify({
      scope: config.scope || 'local-postgres',
      method,
      table,
      status: error.status || 500,
      message: error.message,
      code: error.code,
      details: error.detail || undefined
    }));
    throw httpError(error.status || 500, `Banco local: ${error.message}`, error.detail || error);
  }
}
async function serveStatic(req, res, requestPath, hostHeader = '', requestSearch = '') {
  const guidesRedirectUrl = guidesHostRedirectUrl(requestPath, hostHeader, requestSearch);
  if (guidesRedirectUrl) {
    res.writeHead(301, { Location: guidesRedirectUrl, 'Cache-Control': 'public, max-age=3600' });
    res.end();
    return;
  }
  if (await serveSeoResource(req, res, requestPath, hostHeader)) return;

  const seoLanding = seoLandingByPath.get(guidesLandingPath(requestPath, hostHeader));
  if (seoLanding && !isPrivateSeoHost(String(hostHeader || '').split(':')[0].toLowerCase())) {
    sendSeoLandingPage(req, res, seoLanding);
    return;
  }

  if (requestPath.startsWith('/uploads/')) {
    await serveUpload(req, res, requestPath);
    return;
  }

  const canonicalRedirectUrl = canonicalHostRedirectUrl(requestPath, hostHeader, requestSearch);
  if (canonicalRedirectUrl) {
    res.writeHead(302, {
      Location: canonicalRedirectUrl,
      'Cache-Control': 'no-store'
    });
    res.end();
    return;
  }

  const helpRedirectUrl = helpHostRedirectUrl(requestPath, hostHeader);
  if (helpRedirectUrl) {
    res.writeHead(302, {
      Location: helpRedirectUrl,
      'Cache-Control': 'no-store'
    });
    res.end();
    return;
  }

  const storeSlug = seoStoreSlugCandidate(requestPath, hostHeader);
  if (storeSlug) {
    const store = await getStoreBySlug(storeSlug);
    if (!store) {
      await sendFile(req, res, path.join(publicDir, '404.html'), { status: 404, headers: { 'X-Robots-Tag': 'noindex, follow' } });
      return;
    }
    await sendSeoStorePage(req, res, store);
    return;
  }

  const routedPath = routePath(requestPath, hostHeader);
  const filePath = path.normalize(path.join(publicDir, routedPath));

  if (!filePath.startsWith(publicDir) || !existsSync(filePath)) {
    await sendFile(req, res, path.join(publicDir, '404.html'), { status: 404, headers: { 'X-Robots-Tag': 'noindex, follow' } });
    return;
  }

  await sendFile(req, res, filePath);
}

const SEO_PUBLIC_PAGES = [
  { path: '/', file: 'home.html', priority: '1.0', changefreq: 'weekly' },
  { path: '/planos', file: 'plans.html', priority: '0.9', changefreq: 'weekly' },
  { path: '/cardapio', file: 'app.html', priority: '0.7', changefreq: 'monthly' },
  { path: '/termos', file: 'terms.html', priority: '0.2', changefreq: 'yearly' },
  { path: '/privacidade', file: 'privacy.html', priority: '0.2', changefreq: 'yearly' },
  ...seoLandingPages.map((page) => ({ path: `/${page.slug}`, priority: '0.8', changefreq: 'monthly' }))
];

async function serveSeoResource(req, res, requestPath, hostHeader = '') {
  const hostname = String(hostHeader || '').split(':')[0].toLowerCase();
  if (requestPath === '/robots.txt') {
    const privateHost = isPrivateSeoHost(hostname);
    const helpHost = isHelpHostname(hostname);
    const guidesHost = isGuidesHostname(hostname);
    const origin = helpHost ? (helpBaseUrl() || requestOrigin(req)) : guidesHost ? guidesBaseUrl() : (publicBaseUrl() || 'https://taprontomenu.com.br');
    const body = privateHost
      ? 'User-agent: *\nDisallow: /\n'
      : [
          'User-agent: *',
          'Allow: /',
          'Disallow: /api/',
          'Disallow: /pagamento',
          'Disallow: /conta',
          'Disallow: /pedidos',
          'Disallow: /cadastro',
          'Disallow: /confirmar-email',
          'Disallow: /ativar-conta',
          'Disallow: /redefinir-senha',
          'Disallow: /convite',
          `Sitemap: ${origin}/sitemap.xml`,
          ''
        ].join('\n');
    seoTextResponse(req, res, 200, body, 'text/plain; charset=utf-8', { 'Cache-Control': 'public, max-age=3600' });
    return true;
  }
  if (!['/sitemap.xml', '/sitemap-pages.xml', '/sitemap-stores.xml'].includes(requestPath)) return false;
  if (isPrivateSeoHost(hostname)) {
    seoTextResponse(req, res, 404, '', 'application/xml; charset=utf-8', { 'X-Robots-Tag': 'noindex' });
    return true;
  }
  if (isHelpHostname(hostname)) {
    const origin = helpBaseUrl() || requestOrigin(req);
    const body = xmlUrlSet([{ loc: `${origin}/`, changefreq: 'weekly', priority: '0.6' }]);
    seoTextResponse(req, res, 200, body, 'application/xml; charset=utf-8', { 'Cache-Control': 'public, max-age=900' });
    return true;
  }
  if (isGuidesHostname(hostname)) {
    if (requestPath !== '/sitemap.xml') return false;
    const rows = seoLandingPages.filter((page) => page.slug.startsWith('guias/')).map((page) => ({ loc: `${guidesBaseUrl()}/${page.slug.replace(/^guias\//, '')}`, changefreq: 'monthly', priority: '0.8' }));
    rows.unshift({ loc: `${guidesBaseUrl()}/`, changefreq: 'weekly', priority: '0.9' });
    seoTextResponse(req, res, 200, xmlUrlSet(rows), 'application/xml; charset=utf-8', { 'Cache-Control': 'public, max-age=900' });
    return true;
  }
  const origin = publicBaseUrl() || 'https://taprontomenu.com.br';
  if (requestPath === '/sitemap.xml') {
    const body = `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <sitemap><loc>${seoEscapeXml(origin)}/sitemap-pages.xml</loc></sitemap>\n  <sitemap><loc>${seoEscapeXml(origin)}/sitemap-stores.xml</loc></sitemap>\n  <sitemap><loc>${seoEscapeXml(guidesBaseUrl())}/sitemap.xml</loc></sitemap>\n</sitemapindex>\n`;
    seoTextResponse(req, res, 200, body, 'application/xml; charset=utf-8', { 'Cache-Control': 'public, max-age=900' });
    return true;
  }
  if (requestPath === '/sitemap-pages.xml') {
    const rows = await Promise.all(SEO_PUBLIC_PAGES.filter((page) => !page.path.startsWith('/guias')).map(async (page) => {
      const fileStat = page.file ? await stat(path.join(publicDir, page.file)).catch(() => null) : await stat(path.join(__dirname, 'src', 'data', 'seo-pages.js')).catch(() => null);
      return { loc: `${origin}${page.path}`, lastmod: fileStat?.mtime?.toISOString(), changefreq: page.changefreq, priority: page.priority };
    }));
    seoTextResponse(req, res, 200, xmlUrlSet(rows), 'application/xml; charset=utf-8', { 'Cache-Control': 'public, max-age=900' });
    return true;
  }
  const stores = await dbRequest('GET', 'stores', {
    select: 'slug,updated_at', seo_index_enabled: 'eq.true', is_active: 'eq.true', order: 'updated_at.desc', limit: '10000'
  }).catch(() => []);
  seoTextResponse(req, res, 200, xmlUrlSet(stores.map((store) => ({
    loc: `${origin}/${encodeURIComponent(store.slug)}`,
    lastmod: store.updated_at,
    changefreq: 'weekly',
    priority: '0.6'
  }))), 'application/xml; charset=utf-8', { 'Cache-Control': 'public, max-age=900' });
  return true;
}

function sendSeoLandingPage(req, res, page) {
  if (page.slug === 'guias') {
    sendSeoGuidesHubPage(req, res, page);
    return;
  }
  if (page.slug.startsWith('guias/')) {
    sendSeoGuideArticlePage(req, res, page);
    return;
  }
  const origin = publicBaseUrl() || 'https://taprontomenu.com.br';
  const canonical = `${origin}/${page.slug}`;
  const structured = {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'WebPage', name: page.heading, description: page.description, url: canonical, inLanguage: 'pt-BR' },
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Início', item: `${origin}/` },
        { '@type': 'ListItem', position: 2, name: page.heading, item: canonical }
      ] },
      { '@type': 'FAQPage', mainEntity: page.faq.map(([question, answer]) => ({
        '@type': 'Question', name: question, acceptedAnswer: { '@type': 'Answer', text: answer }
      })) }
    ]
  };
  const related = seoLandingPages
    .filter((entry) => entry.slug !== page.slug)
    .sort((a, b) => page.slug === 'guias' ? Number(b.slug.startsWith('guias/')) - Number(a.slug.startsWith('guias/')) : 0)
    .slice(0, page.slug === 'guias' ? 12 : 4);
  const html = `<!doctype html>
<html lang="pt-BR"><head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${emailEscapeHtml(page.title)}</title>
  <meta name="description" content="${emailEscapeAttribute(page.description)}">
  <link rel="canonical" href="${emailEscapeAttribute(canonical)}">
  <meta property="og:type" content="website"><meta property="og:title" content="${emailEscapeAttribute(page.title)}">
  <meta property="og:description" content="${emailEscapeAttribute(page.description)}"><meta property="og:url" content="${emailEscapeAttribute(canonical)}">
  <meta property="og:image" content="${origin}/assets/sistema-cardapio-preview.png"><meta name="twitter:card" content="summary_large_image">
  <link rel="icon" href="/assets/tapronto-favicon.svg"><link rel="stylesheet" href="/home.css">
  <script type="application/ld+json">${safeJsonForHtml(structured)}</script>
  <style>.seo-main{color:#172033}.seo-hero{padding:72px 0 52px;display:grid;grid-template-columns:1.1fr .9fr;gap:42px;align-items:center}.seo-hero h1{font-size:clamp(2.3rem,5vw,4.6rem);line-height:1.02;margin:14px 0}.seo-hero p,.seo-copy p{font-size:1.08rem;line-height:1.7;color:#596277}.seo-shot{width:100%;border-radius:24px;box-shadow:0 24px 70px #17203324}.seo-section{padding:56px 0}.seo-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.seo-card{padding:24px;border:1px solid #e5e7eb;border-radius:18px;background:#fff}.seo-card strong{display:block;font-size:1.08rem;margin-bottom:8px}.seo-faq details{padding:18px 0;border-bottom:1px solid #e5e7eb}.seo-faq summary{font-weight:750;cursor:pointer}.seo-related{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.seo-related a{padding:16px;border:1px solid #e5e7eb;border-radius:14px;text-decoration:none;color:#172033;font-weight:700}@media(max-width:800px){.seo-hero,.seo-grid{grid-template-columns:1fr}.seo-related{grid-template-columns:1fr}}</style>
</head><body class="seo-main">
  <header class="home-header"><div class="home-container home-nav-shell"><a class="home-brand" href="/" aria-label="TáPronto"><img src="/assets/tapronto-logo.png" alt="TáPronto" width="300" height="82"></a><nav class="home-nav" aria-label="Navegação principal"><a href="/#recursos">Recursos</a><a href="${guidesBaseUrl()}/">Guias</a><a href="/planos">Planos</a><a href="/#comparativo">Comparativo</a><a href="/#faq">FAQ</a><a href="https://ajuda.taprontomenu.com.br/">Ajuda</a></nav><div class="home-nav-actions"><a class="home-login" href="https://app.taprontomenu.com.br/">Entrar</a><a class="home-button small" href="/cadastro">Criar meu Cardápio</a></div></div></header>
  <main>
    <section class="home-container seo-hero"><div><p class="home-badge">TáPronto para vender</p><h1>${emailEscapeHtml(page.heading)}</h1><p>${emailEscapeHtml(page.intro)}</p><div class="home-actions"><a class="home-button" href="/cadastro">Criar meu cardápio</a><a class="home-button ghost" href="/cardapio">Ver demonstração</a></div><ul class="home-trust"><li>Teste grátis</li><li>Sem taxa por pedido</li><li>Cancele quando quiser</li></ul></div><img class="seo-shot" src="/assets/sistema-cardapio-preview.png" alt="Exemplo do cardápio digital TáPronto no celular" width="1440" height="980"></section>
    <section class="seo-section" style="background:#f7f8fb"><div class="home-container"><p class="home-badge">Benefícios</p><h2>Menos atrito para o cliente. Mais controle para sua equipe.</h2><div class="seo-grid">${page.benefits.map((benefit) => `<article class="seo-card"><strong>${emailEscapeHtml(benefit)}</strong><p>Configure pelo painel e publique as mudanças sem depender de aplicativo ou material impresso.</p></article>`).join('')}</div></div></section>
    <section class="home-container seo-section seo-copy"><p class="home-badge">Como começar</p><h2>Publique em três etapas</h2><div class="seo-grid">${page.steps.map((step, index) => `<article class="seo-card"><strong>${index + 1}. ${emailEscapeHtml(step)}</strong><p>O onboarding orienta cada configuração importante antes da publicação.</p></article>`).join('')}</div></section>
    <section class="seo-section" style="background:#fff5f5"><div class="home-container"><h2>Experimente com a sua operação</h2><p>Cadastre produtos reais, teste o pedido no celular e escolha o plano apenas depois de validar o fluxo.</p><div class="home-actions"><a class="home-button" href="/cadastro">Começar teste grátis</a><a class="home-button ghost" href="/planos">Comparar planos</a></div></div></section>
    <section class="home-container seo-section seo-faq"><p class="home-badge">Dúvidas frequentes</p><h2>O que você precisa saber</h2>${page.faq.map(([question, answer]) => `<details><summary>${emailEscapeHtml(question)}</summary><p>${emailEscapeHtml(answer)}</p></details>`).join('')}</section>
    <section class="home-container seo-section"><h2>Veja também</h2><div class="seo-related">${related.map((entry) => `<a href="/${entry.slug}">${emailEscapeHtml(entry.heading)}</a>`).join('')}</div></section>
  </main>
  <footer class="home-container seo-section"><strong>TáPronto</strong><p>Cardápio digital e pedidos organizados para restaurantes.</p><nav><a href="/">Início</a> · <a href="/planos">Planos</a> · <a href="/privacidade">Privacidade</a> · <a href="/termos">Termos</a></nav></footer>
  <script src="/seo-landing.js" type="module"></script>
</body></html>`;
  seoTextResponse(req, res, 200, html, 'text/html; charset=utf-8', { 'Cache-Control': 'public, max-age=300, stale-while-revalidate=3600' });
}

function sendSeoGuideArticlePage(req, res, page) {
  const origin = publicBaseUrl() || 'https://taprontomenu.com.br';
  const guideOrigin = guidesBaseUrl();
  const canonical = `${guideOrigin}/${page.slug.replace(/^guias\//, '')}`;
  const article = page.article || { sections: [], category: 'Guia prático', readTime: '5 min', author: 'Equipe TáPronto', updatedAt: '11 de agosto de 2026', takeaway: '' };
  const sections = Array.isArray(article.sections) ? article.sections : [];
  const related = seoLandingPages.filter((entry) => entry.slug.startsWith('guias/') && entry.slug !== page.slug).slice(0, 3);
  const structured = {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'Article', headline: page.heading, description: page.description, url: canonical, inLanguage: 'pt-BR', dateModified: '2026-08-11', author: { '@type': 'Organization', name: 'TáPronto', url: origin }, publisher: { '@type': 'Organization', name: 'TáPronto', url: origin } },
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Início', item: `${origin}/` },
        { '@type': 'ListItem', position: 2, name: 'Guias', item: `${guideOrigin}/` },
        { '@type': 'ListItem', position: 3, name: page.heading, item: canonical }
      ] },
      { '@type': 'FAQPage', mainEntity: page.faq.map(([question, answer]) => ({ '@type': 'Question', name: question, acceptedAnswer: { '@type': 'Answer', text: answer } })) }
    ]
  };
  const renderSection = (section, index) => {
    const id = cleanSlug(section.title) || `passo-${index + 1}`;
    const paragraphs = (section.paragraphs || []).map((text) => `<p>${emailEscapeHtml(text)}</p>`).join('');
    const bullets = section.bullets?.length ? `<ul class="article-list">${section.bullets.map((text) => `<li><span aria-hidden="true">✓</span>${emailEscapeHtml(text)}</li>`).join('')}</ul>` : '';
    const checklist = section.checklist?.length ? `<div class="article-checklist"><strong>Confira antes de continuar</strong>${section.checklist.map((text) => `<span><i aria-hidden="true"></i>${emailEscapeHtml(text)}</span>`).join('')}</div>` : '';
    const example = section.example ? `<div class="article-example"><strong>Exemplo prático</strong><div><span class="example-bad">Evite</span><p>${emailEscapeHtml(section.example.bad)}</p></div><div><span class="example-good">Prefira</span><p>${emailEscapeHtml(section.example.good)}</p></div></div>` : '';
    const middleCta = index === 2 ? `<aside class="article-inline-cta"><div><small>Quer montar enquanto aprende?</small><strong>Cadastre os três produtos mais vendidos e teste pelo celular.</strong></div><a href="${origin}/cadastro">Começar grátis →</a></aside>` : '';
    return `<section class="article-section" id="${emailEscapeAttribute(id)}"><span class="article-step">${String(index + 1).padStart(2, '0')}</span><h2>${emailEscapeHtml(section.title)}</h2>${paragraphs}${bullets}${example}${checklist}</section>${middleCta}`;
  };
  const html = `<!doctype html>
<html lang="pt-BR"><head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${emailEscapeHtml(page.title)}</title>
  <meta name="description" content="${emailEscapeAttribute(page.description)}"><link rel="canonical" href="${emailEscapeAttribute(canonical)}">
  <meta property="og:type" content="article"><meta property="og:title" content="${emailEscapeAttribute(page.title)}"><meta property="og:description" content="${emailEscapeAttribute(page.description)}"><meta property="og:url" content="${emailEscapeAttribute(canonical)}"><meta property="og:image" content="${origin}/assets/sistema-cardapio-preview.png"><meta name="twitter:card" content="summary_large_image">
  <link rel="icon" href="/assets/tapronto-favicon.svg"><link rel="stylesheet" href="/home.css"><script type="application/ld+json">${safeJsonForHtml(structured)}</script>
  <style>
    .article-page{color:#172033;background:#fff}.article-page *{box-sizing:border-box}.article-nav{border-bottom:1px solid #edf0f3;background:#fff}.article-breadcrumb{display:flex;gap:8px;align-items:center;padding-top:30px;color:#858c9b;font-size:.86rem}.article-breadcrumb a{color:#667085;text-decoration:none}.article-hero{max-width:900px;padding:52px 0 38px}.article-category{display:inline-flex;padding:7px 11px;border-radius:999px;background:#fff1f1;color:#d31820;font-size:.74rem;font-weight:850;letter-spacing:.07em;text-transform:uppercase}.article-hero h1{font-size:clamp(2.5rem,6vw,5rem);line-height:1.02;letter-spacing:-.045em;margin:17px 0 20px}.article-lead{font-size:1.18rem;line-height:1.72;color:#596277;max-width:760px}.article-meta{display:flex;gap:10px;align-items:center;flex-wrap:wrap;color:#858c9b;font-size:.86rem;margin-top:24px}.article-visual{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;padding:30px;border-radius:26px;background:linear-gradient(140deg,#ed1c24,#a8070d);color:#fff;box-shadow:0 24px 60px #9c08152b}.article-visual-card{padding:22px;border-radius:18px;background:#fff;color:#172033;box-shadow:0 12px 30px #59000622}.article-visual-card>span{display:grid;place-items:center;width:38px;height:38px;border-radius:12px;background:#fff0f1;color:#d31820;font-weight:900}.article-visual-card strong{display:block;margin:14px 0 6px}.article-visual-card small{color:#667085;line-height:1.45}.article-layout{display:grid;grid-template-columns:240px minmax(0,720px);gap:70px;align-items:start;padding:68px 0}.article-toc{position:sticky;top:24px;padding:20px;border:1px solid #e7e9ee;border-radius:17px}.article-toc strong{display:block;margin-bottom:13px}.article-toc a{display:block;padding:8px 0;color:#667085;text-decoration:none;font-size:.86rem;line-height:1.35;border-bottom:1px solid #f0f1f3}.article-toc a:last-child{border:0}.article-summary{padding:24px;border-left:4px solid #ed1c24;border-radius:0 15px 15px 0;background:#fff5f5;margin-bottom:52px}.article-summary strong{display:block;margin-bottom:8px}.article-summary p{margin:0;color:#596277;line-height:1.65}.article-section{scroll-margin-top:25px;margin-bottom:56px}.article-step{font-size:.75rem;font-weight:900;letter-spacing:.1em;color:#d31820}.article-section h2{font-size:clamp(1.7rem,3vw,2.35rem);line-height:1.15;margin:8px 0 18px}.article-section>p{font-size:1.03rem;line-height:1.78;color:#4f596d;margin:0 0 15px}.article-list{display:grid;gap:9px;padding:0;margin:22px 0;list-style:none}.article-list li{display:flex;gap:10px;align-items:flex-start;padding:13px 15px;border-radius:12px;background:#f7f8fa}.article-list li span{color:#159455;font-weight:900}.article-checklist{display:grid;gap:10px;padding:22px;border-radius:16px;background:#f7f8fa;margin-top:22px}.article-checklist strong{margin-bottom:4px}.article-checklist span{display:flex;gap:10px;color:#4f596d}.article-checklist i{width:18px;height:18px;border:2px solid #c8cdd7;border-radius:5px;background:#fff}.article-example{display:grid;gap:12px;padding:22px;border:1px solid #e7e9ee;border-radius:16px;margin-top:22px}.article-example>strong{font-size:1.05rem}.article-example>div{display:grid;grid-template-columns:60px 1fr;gap:10px;align-items:start}.article-example p{margin:0;color:#4f596d}.example-bad,.example-good{font-size:.7rem;font-weight:850;text-transform:uppercase}.example-bad{color:#c73b42}.example-good{color:#15834d}.article-inline-cta{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:24px;border-radius:17px;background:#1d2433;color:#fff;margin:-15px 0 55px}.article-inline-cta div{display:grid;gap:5px}.article-inline-cta small{color:#c9ced8}.article-inline-cta a{white-space:nowrap;color:#fff;text-decoration:none;font-weight:850}.article-faq{padding:55px 0;border-top:1px solid #edf0f3}.article-faq h2,.article-related h2{font-size:2rem}.article-faq details{padding:18px 0;border-bottom:1px solid #e7e9ee}.article-faq summary{font-weight:800;cursor:pointer}.article-faq p{color:#596277;line-height:1.65}.article-related{padding:55px 0;background:#f7f8fa}.article-related-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.article-related a{display:flex;flex-direction:column;gap:10px;padding:22px;border:1px solid #e3e6eb;border-radius:16px;background:#fff;color:#172033;text-decoration:none}.article-related small{color:#d31820;font-weight:800;text-transform:uppercase}.article-final{padding:70px 0}.article-final-box{display:flex;align-items:center;justify-content:space-between;gap:25px;padding:42px;border-radius:24px;background:#fff1f1}.article-final h2{margin:0 0 8px;font-size:2rem}.article-final p{margin:0;color:#596277}.article-footer{border-top:1px solid #edf0f3;padding:34px 0}.article-footer-row{display:flex;justify-content:space-between;gap:20px;flex-wrap:wrap}.article-footer a{color:#667085;text-decoration:none;margin-left:15px}
    @media(max-width:850px){.article-layout{grid-template-columns:1fr;gap:30px}.article-toc{position:static}.article-visual{grid-template-columns:1fr}.article-related-grid{grid-template-columns:1fr}.article-final-box{display:block}.article-final .home-button{margin-top:22px}.home-nav{display:none}}
    @media(max-width:560px){.article-hero{padding:40px 0 30px}.article-layout{padding:45px 0}.article-visual{padding:18px}.article-inline-cta{display:block}.article-inline-cta a{display:inline-block;margin-top:16px}.article-final-box{padding:28px}}
  </style>
</head><body class="article-page">
  <header class="home-header article-nav"><div class="home-container home-nav-shell"><a class="home-brand" href="${origin}/" aria-label="TáPronto"><img src="/assets/tapronto-logo.png" alt="TáPronto" width="300" height="82"></a><nav class="home-nav" aria-label="Navegação principal"><a href="${origin}/#recursos">Recursos</a><a href="${guideOrigin}/" aria-current="page">Guias</a><a href="${origin}/planos">Planos</a><a href="${origin}/#comparativo">Comparativo</a><a href="${origin}/#faq">FAQ</a><a href="https://ajuda.taprontomenu.com.br/">Ajuda</a></nav><div class="home-nav-actions"><a class="home-login" href="https://app.taprontomenu.com.br/">Entrar</a><a class="home-button small" href="${origin}/cadastro">Criar meu Cardápio</a></div></div></header>
  <main>
    <div class="home-container article-breadcrumb"><a href="${origin}/">Início</a><span>/</span><a href="${guideOrigin}/">Guias</a><span>/</span><span>${emailEscapeHtml(article.category)}</span></div>
    <section class="home-container article-hero"><span class="article-category">${emailEscapeHtml(article.category)}</span><h1>${emailEscapeHtml(page.heading)}</h1><p class="article-lead">${emailEscapeHtml(page.intro)}</p><div class="article-meta"><span>${emailEscapeHtml(article.author)}</span><span>•</span><span>Atualizado em ${emailEscapeHtml(article.updatedAt)}</span><span>•</span><span>${emailEscapeHtml(article.readTime)} de leitura</span></div></section>
    <section class="home-container article-visual" role="img" aria-label="Principais etapas deste guia">${sections.slice(0, 3).map((section, index) => `<div class="article-visual-card"><span>${index + 1}</span><strong>${emailEscapeHtml(section.title)}</strong><small>${emailEscapeHtml((section.paragraphs?.[0] || section.bullets?.[0] || '').slice(0, 105))}</small></div>`).join('')}</section>
    <div class="home-container article-layout"><aside class="article-toc"><strong>Neste guia</strong>${sections.map((section, index) => `<a href="#${emailEscapeAttribute(cleanSlug(section.title) || `passo-${index + 1}`)}">${index + 1}. ${emailEscapeHtml(section.title)}</a>`).join('')}</aside><article><div class="article-summary"><strong>Resumo rápido</strong><p>${emailEscapeHtml(article.takeaway)}</p></div>${sections.map(renderSection).join('')}</article></div>
    <section class="article-faq"><div class="home-container" style="max-width:760px"><span class="article-category">Dúvidas comuns</span><h2>Perguntas frequentes</h2>${page.faq.map(([question, answer]) => `<details><summary>${emailEscapeHtml(question)}</summary><p>${emailEscapeHtml(answer)}</p></details>`).join('')}</div></section>
    <section class="article-related"><div class="home-container"><span class="article-category">Continue aprendendo</span><h2>Guias relacionados</h2><div class="article-related-grid">${related.map((entry) => `<a href="/${entry.slug.replace(/^guias\//, '')}"><small>${emailEscapeHtml(entry.article?.category || 'Guia prático')}</small><strong>${emailEscapeHtml(entry.heading)}</strong><span>Ler guia →</span></a>`).join('')}</div></div></section>
    <section class="home-container article-final"><div class="article-final-box"><div><h2>Monte o cardápio da sua loja</h2><p>Comece pelos produtos mais vendidos e teste o pedido antes de divulgar.</p></div><a class="home-button" href="${origin}/cadastro">Criar meu cardápio</a></div></section>
  </main><footer class="article-footer"><div class="home-container article-footer-row"><strong>TáPronto · Cardápio digital, pedidos organizados.</strong><nav><a href="${guideOrigin}/">Guias</a><a href="${origin}/planos">Planos</a><a href="${origin}/privacidade">Privacidade</a><a href="${origin}/termos">Termos</a></nav></div></footer><script src="/seo-landing.js" type="module"></script>
</body></html>`;
  seoTextResponse(req, res, 200, html, 'text/html; charset=utf-8', { 'Cache-Control': 'public, max-age=300, stale-while-revalidate=3600' });
}

function sendSeoGuidesHubPage(req, res, page) {
  const origin = publicBaseUrl() || 'https://taprontomenu.com.br';
  const guideOrigin = guidesBaseUrl();
  const canonical = `${guideOrigin}/`;
  const guides = seoLandingPages.filter((entry) => entry.slug.startsWith('guias/'));
  const guideMeta = {
    'guias/como-criar-cardapio-digital': { category: 'Cardápio digital', icon: '▤', time: '6 min', color: 'coral' },
    'guias/como-criar-qr-code-cardapio': { category: 'QR Code e salão', icon: '▦', time: '5 min', color: 'violet' },
    'guias/como-organizar-pedidos-delivery': { category: 'Pedidos e delivery', icon: '☰', time: '7 min', color: 'blue' },
    'guias/como-tirar-fotos-para-cardapio': { category: 'Cardápio digital', icon: '◉', time: '5 min', color: 'amber' },
    'guias/como-divulgar-cardapio-digital': { category: 'Marketing da loja', icon: '↗', time: '6 min', color: 'green' },
    'guias/como-aumentar-pedidos-restaurante': { category: 'Vendas e operação', icon: '↑', time: '7 min', color: 'red' }
  };
  const cards = guides.map((guide) => ({ ...guide, ...(guideMeta[guide.slug] || { category: 'Guia prático', icon: '•', time: '5 min', color: 'coral' }) }));
  const featured = cards[0];
  const structured = {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'CollectionPage', name: page.heading, description: page.description, url: canonical, inLanguage: 'pt-BR' },
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Início', item: `${origin}/` },
        { '@type': 'ListItem', position: 2, name: 'Guias', item: canonical }
      ] },
      { '@type': 'ItemList', itemListElement: cards.map((guide, index) => ({ '@type': 'ListItem', position: index + 1, name: guide.heading, url: `${origin}/${guide.slug}` })) }
    ]
  };
  const topics = [
    ['Cardápio digital', 'Monte um menu claro, bonito e fácil de atualizar.', '▤'],
    ['Pedidos e delivery', 'Reduza pedido incompleto e organize a rotina.', '☰'],
    ['Marketing da loja', 'Leve mais clientes ao seu link de pedidos.', '↗'],
    ['QR Code e salão', 'Facilite o acesso pelo celular na mesa.', '▦']
  ];
  const html = `<!doctype html>
<html lang="pt-BR"><head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${emailEscapeHtml(page.title)}</title><meta name="description" content="${emailEscapeAttribute(page.description)}">
  <link rel="canonical" href="${emailEscapeAttribute(canonical)}"><meta property="og:type" content="website">
  <meta property="og:title" content="${emailEscapeAttribute(page.title)}"><meta property="og:description" content="${emailEscapeAttribute(page.description)}"><meta property="og:url" content="${emailEscapeAttribute(canonical)}">
  <meta property="og:image" content="${origin}/assets/sistema-cardapio-preview.png"><meta name="twitter:card" content="summary_large_image">
  <link rel="icon" href="/assets/tapronto-favicon.svg"><link rel="stylesheet" href="/home.css">
  <script type="application/ld+json">${safeJsonForHtml(structured)}</script>
  <style>
    .guides-page{color:#172033;background:#fff}.guides-page *{box-sizing:border-box}.guides-nav{border-bottom:1px solid #edf0f3;background:#fff}.guides-hero{padding:72px 0 48px;text-align:center;max-width:820px}.guides-hero h1{font-size:clamp(2.45rem,6vw,4.8rem);line-height:1.02;letter-spacing:-.045em;margin:15px 0 20px}.guides-hero>p{font-size:1.16rem;line-height:1.7;color:#667085;max-width:680px;margin:0 auto}.guides-eyebrow{display:inline-flex;padding:8px 13px;border-radius:999px;background:#fff1f1;color:#d31820;font-size:.78rem;font-weight:850;letter-spacing:.08em;text-transform:uppercase}.guides-topics{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;padding-bottom:64px}.guides-topic{padding:20px;border:1px solid #e7e9ee;border-radius:18px;text-decoration:none;color:#172033;background:#fff;transition:.2s ease}.guides-topic:hover{transform:translateY(-3px);border-color:#efb1b4;box-shadow:0 12px 34px #1720330d}.guides-topic b{display:block;margin:10px 0 6px}.guides-topic span:last-child{display:block;color:#667085;font-size:.9rem;line-height:1.45}.guides-topic-icon{width:38px;height:38px;display:grid;place-items:center;border-radius:11px;background:#fff1f1;color:#d31820;font-size:1.25rem}.guides-feature-wrap{background:#f7f8fa;padding:64px 0}.guides-section-head{display:flex;align-items:end;justify-content:space-between;gap:20px;margin-bottom:24px}.guides-section-head h2{font-size:clamp(1.8rem,3vw,2.6rem);margin:6px 0}.guides-section-head p{margin:0;color:#667085}.guides-feature{display:grid;grid-template-columns:.9fr 1.1fr;min-height:350px;border-radius:26px;overflow:hidden;background:#fff;box-shadow:0 20px 60px #17203310;border:1px solid #e7e9ee}.guides-feature-art{display:grid;place-items:center;background:linear-gradient(145deg,#ef2029,#a9070e);padding:50px;position:relative}.guides-feature-phone{width:190px;padding:13px;border-radius:29px;background:#1b1f2a;box-shadow:0 25px 55px #47000455;transform:rotate(-5deg)}.guides-feature-phone img{width:100%;display:block;border-radius:19px}.guides-feature-copy{padding:48px;display:flex;flex-direction:column;justify-content:center}.guides-category{font-size:.75rem;font-weight:850;letter-spacing:.08em;text-transform:uppercase;color:#d31820}.guides-feature-copy h2{font-size:clamp(2rem,4vw,3rem);line-height:1.08;margin:12px 0 16px}.guides-feature-copy p{color:#667085;line-height:1.65}.guides-read{display:flex;gap:10px;align-items:center;color:#858c9b;font-size:.86rem;margin:4px 0 24px}.guides-link{font-weight:800;color:#d31820;text-decoration:none}.guides-library{padding:70px 0}.guides-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}.guide-card{display:flex;flex-direction:column;border:1px solid #e7e9ee;border-radius:20px;overflow:hidden;text-decoration:none;color:#172033;background:#fff;transition:.2s ease}.guide-card:hover{transform:translateY(-4px);box-shadow:0 18px 44px #17203312;border-color:#d9dce3}.guide-card-art{height:128px;display:grid;place-items:center;font-size:2.4rem}.guide-card-art.coral{background:#fff0ee;color:#e23a32}.guide-card-art.violet{background:#f4efff;color:#7556c9}.guide-card-art.blue{background:#edf6ff;color:#2672bb}.guide-card-art.amber{background:#fff7e7;color:#c87a12}.guide-card-art.green{background:#edf9f2;color:#228957}.guide-card-art.red{background:#fff0f1;color:#d31820}.guide-card-copy{padding:22px;display:flex;flex-direction:column;flex:1}.guide-card h3{font-size:1.22rem;line-height:1.28;margin:9px 0}.guide-card p{color:#667085;line-height:1.55;font-size:.94rem;margin:0 0 18px}.guide-card .guides-read{margin-top:auto;margin-bottom:0}.guides-cta{padding:0 0 72px}.guides-cta-box{display:grid;grid-template-columns:1.1fr .9fr;align-items:center;gap:30px;padding:48px;border-radius:26px;background:#1d2433;color:#fff;overflow:hidden}.guides-cta h2{font-size:clamp(1.8rem,4vw,3rem);margin:8px 0 13px}.guides-cta p{color:#c9ced8;line-height:1.6}.guides-cta-actions{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap}.guides-cta .home-button.ghost{color:#fff;border-color:#ffffff55}.guides-footer{border-top:1px solid #edf0f3;padding:35px 0 48px}.guides-footer-row{display:flex;justify-content:space-between;gap:20px;flex-wrap:wrap}.guides-footer a{color:#667085;text-decoration:none;margin-left:18px}
    .guides-feature-art{background:linear-gradient(145deg,#f4212a,#b50b12);padding:48px;overflow:hidden}.guides-feature-art:before,.guides-feature-art:after{content:"";position:absolute;border-radius:999px;background:#ffffff12}.guides-feature-art:before{width:260px;height:260px;top:-110px;right:-70px}.guides-feature-art:after{width:180px;height:180px;bottom:-80px;left:-40px}.guides-menu-mock{position:relative;z-index:1;width:min(100%,330px);padding:13px;border-radius:28px;background:#171c29;box-shadow:0 28px 60px #62000655;transform:rotate(-2deg)}.guides-menu-screen{border-radius:19px;background:#fff;overflow:hidden}.guides-menu-top{display:flex;align-items:center;justify-content:space-between;padding:14px 15px;border-bottom:1px solid #edf0f3}.guides-menu-brand{display:flex;gap:8px;align-items:center;font-size:.72rem;font-weight:850}.guides-menu-brand i{display:grid;place-items:center;width:25px;height:25px;border-radius:8px;background:#ed1c24;color:#fff;font-style:normal}.guides-menu-cart{padding:6px 9px;border-radius:8px;background:#fff1f1;color:#d31820;font-size:.62rem;font-weight:850}.guides-menu-cover{padding:16px;background:#fff7f4}.guides-menu-cover b{display:block;font-size:1rem}.guides-menu-cover span{font-size:.65rem;color:#667085}.guides-menu-chips{display:flex;gap:6px;padding:12px 14px}.guides-menu-chips span{padding:6px 8px;border-radius:999px;background:#f3f4f6;font-size:.56rem;font-weight:750}.guides-menu-chips span:first-child{background:#ed1c24;color:#fff}.guides-menu-products{display:grid;gap:8px;padding:0 14px 15px}.guides-menu-product{display:grid;grid-template-columns:1fr 52px;gap:10px;padding:10px;border:1px solid #e8eaf0;border-radius:12px}.guides-menu-product b{display:block;font-size:.7rem}.guides-menu-product p{margin:3px 0;color:#858c9b;font-size:.55rem;line-height:1.25}.guides-menu-product strong{color:#d31820;font-size:.66rem}.guides-food-thumb{display:grid;place-items:center;border-radius:9px;background:linear-gradient(145deg,#ffd59f,#f59b45);font-size:1.35rem}
    @media(max-width:850px){.guides-topics,.guides-grid{grid-template-columns:repeat(2,1fr)}.guides-feature,.guides-cta-box{grid-template-columns:1fr}.guides-feature-art{min-height:340px}.guides-cta-actions{justify-content:flex-start}.home-nav{display:none}}
    @media(max-width:560px){.guides-hero{padding:48px 20px 35px}.guides-topics,.guides-grid{grid-template-columns:1fr}.guides-feature-copy,.guides-cta-box{padding:30px}.guides-section-head{display:block}.guides-feature-wrap,.guides-library{padding:48px 0}.guides-topic{padding:17px}}
  </style>
</head><body class="guides-page">
  <header class="home-header guides-nav"><div class="home-container home-nav-shell"><a class="home-brand" href="${origin}/" aria-label="TáPronto"><img src="/assets/tapronto-logo.png" alt="TáPronto" width="300" height="82"></a><nav class="home-nav" aria-label="Navegação principal"><a href="${origin}/#recursos">Recursos</a><a href="${guideOrigin}/" aria-current="page">Guias</a><a href="${origin}/planos">Planos</a><a href="${origin}/#comparativo">Comparativo</a><a href="${origin}/#faq">FAQ</a><a href="https://ajuda.taprontomenu.com.br/">Ajuda</a></nav><div class="home-nav-actions"><a class="home-login" href="https://app.taprontomenu.com.br/">Entrar</a><a class="home-button small" href="${origin}/cadastro">Criar meu Cardápio</a></div></div></header>
  <main>
    <section class="home-container guides-hero"><span class="guides-eyebrow">Conteúdo prático para sua loja</span><h1>Menos bagunça.<br>Mais pedidos organizados.</h1><p>Guias diretos para montar seu cardápio, divulgar a loja e melhorar o atendimento sem complicação.</p></section>
    <section class="home-container guides-topics" aria-label="Navegue por assunto">${topics.map(([title, description, icon]) => `<a class="guides-topic" href="#todos"><span class="guides-topic-icon" aria-hidden="true">${icon}</span><b>${emailEscapeHtml(title)}</b><span>${emailEscapeHtml(description)}</span></a>`).join('')}</section>
    <section class="guides-feature-wrap"><div class="home-container"><div class="guides-section-head"><div><span class="guides-eyebrow">Comece por aqui</span><h2>Guia em destaque</h2></div><p>Leitura rápida e aplicável hoje.</p></div><article class="guides-feature"><div class="guides-feature-art"><div class="guides-menu-mock" role="img" aria-label="Exemplo de cardápio digital organizado no celular"><div class="guides-menu-screen"><div class="guides-menu-top"><span class="guides-menu-brand"><i>T</i>Sabor da Casa</span><span class="guides-menu-cart">Pedido · 2</span></div><div class="guides-menu-cover"><b>Seu pedido começa aqui</b><span>Escolha, personalize e finalize pelo celular.</span></div><div class="guides-menu-chips"><span>Destaques</span><span>Lanches</span><span>Combos</span></div><div class="guides-menu-products"><div class="guides-menu-product"><div><b>Combo da Casa</b><p>Hambúrguer, fritas e bebida</p><strong>R$ 29,90</strong></div><span class="guides-food-thumb">🍔</span></div><div class="guides-menu-product"><div><b>Monte do seu jeito</b><p>Escolha adicionais sem confusão</p><strong>A partir de R$ 18,90</strong></div><span class="guides-food-thumb">🍟</span></div></div></div></div></div><div class="guides-feature-copy"><span class="guides-category">${emailEscapeHtml(featured.category)}</span><h2>${emailEscapeHtml(featured.heading)}</h2><p>${emailEscapeHtml(featured.intro)}</p><div class="guides-read"><span>${emailEscapeHtml(featured.time)} de leitura</span><span>•</span><span>Passo a passo</span></div><a class="guides-link" href="/${featured.slug}">Ler guia completo →</a></div></article></div></section>
    <section class="home-container guides-library" id="todos"><div class="guides-section-head"><div><span class="guides-eyebrow">Biblioteca TáPronto</span><h2>Todos os guias</h2><p>Escolha uma dor da sua operação e veja como resolver.</p></div></div><div class="guides-grid">${cards.map((guide) => `<a class="guide-card" href="/${guide.slug.replace(/^guias\//, '')}"><span class="guide-card-art ${guide.color}" aria-hidden="true">${guide.icon}</span><span class="guide-card-copy"><span class="guides-category">${emailEscapeHtml(guide.category)}</span><h3>${emailEscapeHtml(guide.heading)}</h3><p>${emailEscapeHtml(guide.intro)}</p><span class="guides-read">${emailEscapeHtml(guide.time)} de leitura · Guia prático</span></span></a>`).join('')}</div></section>
    <section class="home-container guides-cta"><div class="guides-cta-box"><div><span class="guides-eyebrow">Coloque em prática</span><h2>Seu cardápio pode ficar pronto hoje.</h2><p>Cadastre os produtos mais vendidos, teste um pedido pelo celular e publique quando estiver seguro.</p></div><div class="guides-cta-actions"><a class="home-button" href="/cadastro">Criar meu cardápio</a><a class="home-button ghost" href="/cardapio">Ver demonstração</a></div></div></section>
  </main>
  <footer class="guides-footer"><div class="home-container guides-footer-row"><div><strong>TáPronto</strong><p>Cardápio digital, pedidos organizados.</p></div><nav><a href="/">Início</a><a href="/planos">Planos</a><a href="/privacidade">Privacidade</a><a href="/termos">Termos</a></nav></div></footer>
  <script src="/seo-landing.js" type="module"></script>
</body></html>`;
  seoTextResponse(req, res, 200, html, 'text/html; charset=utf-8', { 'Cache-Control': 'public, max-age=300, stale-while-revalidate=3600' });
}

function isPrivateSeoHost(hostname = '') {
  const panelHosts = csvEnv('PANEL_HOSTS');
  const platformHosts = csvEnv('PLATFORM_HOSTS');
  return panelHosts.includes(hostname) || platformHosts.includes(hostname) || /^(app|painel|central|platform)\./.test(hostname);
}

function seoStoreSlugCandidate(requestPath = '', hostHeader = '') {
  const hostname = String(hostHeader || '').split(':')[0].toLowerCase();
  if (isPrivateSeoHost(hostname) || isHelpHostname(hostname)) return '';
  const parts = String(requestPath || '').split('/').filter(Boolean);
  if (parts.length !== 1 || path.extname(parts[0])) return '';
  const slug = cleanSlug(parts[0]);
  return slug && !reservedPublicSlugs().has(slug) ? slug : '';
}

async function sendSeoStorePage(req, res, store) {
  const [settings] = await dbRequest('GET', 'store_settings', {
    select: 'name,description,address,page_title,logo_url,cover_url,business_hours,updated_at',
    store_id: `eq.${store.id}`, limit: '1'
  }).catch(() => []);
  const origin = publicBaseUrl() || 'https://taprontomenu.com.br';
  const canonical = `${origin}/${encodeURIComponent(store.slug)}`;
  const name = cleanText(settings?.name || store.name || 'Cardápio');
  const description = cleanText(settings?.description || store.description || `Confira o cardápio online de ${name} e faça seu pedido.`).slice(0, 240);
  const title = cleanText(settings?.page_title || `Cardápio de ${name} | TáPronto`).slice(0, 90);
  const image = absoluteSeoAssetUrl(settings?.cover_url || settings?.logo_url || '/assets/tapronto-logo.png', origin);
  const structured = {
    '@context': 'https://schema.org',
    '@type': 'Restaurant',
    name,
    description,
    url: canonical,
    image,
    ...(cleanText(settings?.address || '') ? { address: cleanText(settings.address) } : {})
  };
  let html = await readFile(path.join(publicDir, 'app.html'), 'utf8');
  html = html
    .replace(/<title>[\s\S]*?<\/title>/i, `<title>${emailEscapeHtml(title)}</title>`)
    .replace(/<meta name="description"[^>]*>/i, `<meta name="description" content="${emailEscapeAttribute(description)}">`)
    .replace('</head>', `${store.seo_index_enabled ? '' : '<meta name="robots" content="noindex, follow">'}\n    <link rel="canonical" href="${emailEscapeAttribute(canonical)}">\n    <meta property="og:type" content="website">\n    <meta property="og:title" content="${emailEscapeAttribute(title)}">\n    <meta property="og:description" content="${emailEscapeAttribute(description)}">\n    <meta property="og:url" content="${emailEscapeAttribute(canonical)}">\n    <meta property="og:image" content="${emailEscapeAttribute(image)}">\n    <meta name="twitter:card" content="summary_large_image">\n    <script type="application/ld+json">${safeJsonForHtml(structured)}</script>\n  </head>`);
  seoTextResponse(req, res, 200, html, 'text/html; charset=utf-8', {
    'Cache-Control': 'public, max-age=60, stale-while-revalidate=300',
    ...(!store.seo_index_enabled ? { 'X-Robots-Tag': 'noindex, follow' } : {})
  });
}

function xmlUrlSet(rows = []) {
  const entries = rows.map((row) => `  <url>\n    <loc>${seoEscapeXml(row.loc)}</loc>${row.lastmod ? `\n    <lastmod>${seoEscapeXml(new Date(row.lastmod).toISOString())}</lastmod>` : ''}${row.changefreq ? `\n    <changefreq>${seoEscapeXml(row.changefreq)}</changefreq>` : ''}${row.priority ? `\n    <priority>${seoEscapeXml(row.priority)}</priority>` : ''}\n  </url>`).join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${entries}\n</urlset>\n`;
}

function seoEscapeXml(value = '') {
  return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

function absoluteSeoAssetUrl(value = '', origin = '') {
  const text = String(value || '');
  if (/^https?:\/\//i.test(text)) return text;
  return absoluteFromBase(origin, text || '/assets/tapronto-logo.png');
}

function safeJsonForHtml(value) {
  return JSON.stringify(value).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');
}

function seoTextResponse(req, res, status, body, contentType, headers = {}) {
  const raw = Buffer.from(String(body || ''), 'utf8');
  const acceptsGzip = /(?:^|,)\s*gzip\s*(?:,|$)/i.test(String(req.headers['accept-encoding'] || ''));
  const compressed = acceptsGzip && raw.length >= 1024 ? gzipSync(raw, { level: 6 }) : null;
  const responseBody = compressed || raw;
  res.writeHead(status, {
    ...securityHeaders({ allowSameOriginFrame: contentType.startsWith('text/html') }),
    'Content-Type': contentType,
    'Content-Length': responseBody.length,
    Vary: 'Accept-Encoding',
    ...(compressed ? { 'Content-Encoding': 'gzip' } : {}),
    ...headers
  });
  if (req.method === 'HEAD') res.end();
  else res.end(responseBody);
}

function shouldNoIndexResponse(req, filePath = '') {
  const hostname = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].split(':')[0].toLowerCase();
  if (isPrivateSeoHost(hostname)) return true;
  const privateFiles = new Set([
    'admin.html', 'platform.html', 'kitchen.html', 'payment.html', 'account.html', 'orders.html',
    'signup.html', 'confirm-email.html', 'activate-account.html', 'reset-password.html', 'invite.html'
  ]);
  return privateFiles.has(path.basename(filePath));
}

function canonicalHostRedirectUrl(requestPath, hostHeader = '', requestSearch = '') {
  const hostname = String(hostHeader || '').split(':')[0].toLowerCase();
  if (!hostname || ['localhost', '127.0.0.1', '0.0.0.0'].includes(hostname)) return '';
  if (requestPath.startsWith('/api/') || requestPath.startsWith('/assets/') || requestPath.startsWith('/uploads/')) return '';
  if (path.extname(requestPath)) return '';

  const panelAliases = new Set(['/painel', '/admin', '/entrar', '/onboarding', '/redefinir-senha', '/ativar-conta', '/convite']);
  const platformAliases = new Set(['/central', '/platform', '/plataform']);
  const helpAliases = new Set(['/ajuda', '/help']);
  const querylessPath = requestPath || '/';
  const panelHosts = csvEnv('PANEL_HOSTS');
  const platformHosts = csvEnv('PLATFORM_HOSTS');
  const isPanelHost = panelHosts.includes(hostname) || hostname.startsWith('painel.') || hostname.startsWith('app.');
  const isPlatformHost = platformHosts.includes(hostname) || hostname.startsWith('central.') || hostname.startsWith('platform.');
  const panelRootAliases = new Set(['/painel', '/admin', '/entrar', '/onboarding']);

  if (panelRootAliases.has(querylessPath) && isPanelHost) {
    return absoluteFromBase(panelBaseUrl(), `/${requestSearch || ''}`);
  }
  if (platformAliases.has(querylessPath) && isPlatformHost) {
    return absoluteFromBase(platformBaseUrl(), `/${requestSearch || ''}`);
  }
  if (helpAliases.has(querylessPath)) {
    return absoluteFromBase(helpBaseUrl(), `/${requestSearch || ''}`);
  }
  if (panelAliases.has(querylessPath) && !isPanelHost) {
    return absoluteFromBase(panelBaseUrl(), `${panelCanonicalPath(querylessPath)}${requestSearch || ''}`);
  }
  if (platformAliases.has(querylessPath) && !isPlatformHost) {
    return absoluteFromBase(platformBaseUrl(), `/${requestSearch || ''}`);
  }
  return '';
}

function panelCanonicalPath(requestPath = '/') {
  if (requestPath === '/redefinir-senha' || requestPath === '/ativar-conta' || requestPath === '/convite') return requestPath;
  return '/';
}

function helpHostRedirectUrl(requestPath, hostHeader = '') {
  const hostname = String(hostHeader || '').split(':')[0].toLowerCase();
  const isHelpHost = isHelpHostname(hostname);
  if (!isHelpHost) return '';

  const allowedHelpPaths = new Set([
    '/',
    '/ajuda',
    '/help',
    '/ajuda.html',
    '/ajuda.css',
    '/ajuda.js',
    '/assets/tapronto-favicon.svg',
    '/favicon.ico',
    '/robots.txt',
    '/sitemap.xml'
  ]);
  const isAssetPath = requestPath.startsWith('/assets/');
  if (allowedHelpPaths.has(requestPath) || isAssetPath) return '';

  const baseUrl = publicAppBaseUrl({ headers: {} }) || 'https://taprontomenu.com.br';
  return `${baseUrl}${requestPath || '/'}`;
}

function isHelpHostname(hostname = '') {
  const helpHosts = csvEnv('HELP_HOSTS');
  return helpHosts.includes(hostname) || hostname.startsWith('ajuda.');
}

function isGuidesHostname(hostname = '') {
  const guidesHosts = csvEnv('GUIDES_HOSTS');
  return guidesHosts.includes(hostname) || hostname.startsWith('guias.');
}

function guidesLandingPath(requestPath = '/', hostHeader = '') {
  const hostname = String(hostHeader || '').split(':')[0].toLowerCase();
  if (!isGuidesHostname(hostname)) return requestPath;
  if (requestPath === '/') return '/guias';
  return `/guias${requestPath}`.replace(/\/{2,}/g, '/');
}

function guidesHostRedirectUrl(requestPath = '/', hostHeader = '', requestSearch = '') {
  const hostname = String(hostHeader || '').split(':')[0].toLowerCase();
  if (!hostname || ['localhost', '127.0.0.1', '0.0.0.0'].includes(hostname)) return '';
  if (requestPath.startsWith('/api/') || requestPath.startsWith('/assets/') || requestPath.startsWith('/uploads/') || path.extname(requestPath)) return '';
  const isGuidesHost = isGuidesHostname(hostname);
  const legacyGuidesPath = requestPath === '/guias' || requestPath.startsWith('/guias/');
  const publicSitePaths = ['/cadastro', '/planos', '/cardapio', '/privacidade', '/termos', '/recursos', '/demonstracao'];
  if (isGuidesHost && publicSitePaths.includes(requestPath)) return `${publicBaseUrl() || 'https://taprontomenu.com.br'}${requestPath}${requestSearch || ''}`;
  if (!isGuidesHost && !legacyGuidesPath) return '';
  if (isGuidesHost && !legacyGuidesPath) return '';
  const cleanPath = requestPath.replace(/^\/guias/, '') || '/';
  return `${guidesBaseUrl()}${cleanPath === '/' ? '/' : cleanPath}${requestSearch || ''}`;
}

async function serveUpload(req, res, requestPath) {
  const relative = decodeURIComponent(requestPath.replace(/^\/uploads\//, ''));
  const filePath = path.normalize(path.join(UPLOAD_DIR, relative));
  if (!filePath.startsWith(UPLOAD_DIR) || !existsSync(filePath)) {
    json(res, 404, { error: 'Arquivo não encontrado.' });
    return;
  }
  await sendFile(req, res, filePath);
}

function routePath(requestPath, hostHeader = '') {
  const hostname = String(hostHeader || '').split(':')[0].toLowerCase();
  const panelHosts = csvEnv('PANEL_HOSTS');
  const platformHosts = csvEnv('PLATFORM_HOSTS');
  const isPanelHost = panelHosts.includes(hostname) || hostname.startsWith('painel.') || hostname.startsWith('app.');
  const isPlatformHost = platformHosts.includes(hostname) || hostname.startsWith('platform.') || hostname.startsWith('central.');
  const isHelpHost = isHelpHostname(hostname);

  if (requestPath === '/' && isPanelHost) return '/admin.html';
  if (requestPath === '/' && isPlatformHost) return '/platform.html';
  if (requestPath === '/' && isHelpHost) return '/ajuda.html';
  if (requestPath === '/') return '/home.html';
  if (requestPath === '/ajuda' || requestPath === '/help') return '/ajuda.html';
  if (requestPath === '/cardapio') return '/app.html';
  if (requestPath === '/planos') return '/plans.html';
  if (['/recursos', '/demonstracao'].includes(requestPath)) return '/home.html';
  if (requestPath === '/termos') return '/terms.html';
  if (requestPath === '/privacidade') return '/privacy.html';
  if (requestPath === '/entrar') return '/admin.html';
  if (requestPath === '/criar-conta' || requestPath === '/cadastro') return '/signup.html';
  if (requestPath === '/confirmar-email') return '/confirm-email.html';
  if (requestPath === '/ativar-conta') return '/activate-account.html';
  if (requestPath === '/redefinir-senha') return '/reset-password.html';
  if (requestPath === '/onboarding') return '/admin.html';
  if (requestPath === '/convite') return '/invite.html';
  if (requestPath === '/painel' || requestPath === '/admin') return '/admin.html';
  if (requestPath === '/platform' || requestPath === '/plataform' || requestPath === '/central') return '/platform.html';
  if (requestPath === '/cozinha') return '/kitchen.html';
  if (requestPath === '/pagamento') return '/payment.html';
  if (requestPath === '/conta' || requestPath === '/cliente') return '/account.html';
  if (requestPath === '/pedidos') return '/orders.html';
  if (path.extname(requestPath)) return decodeURIComponent(requestPath);
  const parts = String(requestPath || '').split('/').filter(Boolean);
  if (parts.length === 1 && cleanSlug(parts[0])) return '/app.html';
  if (parts.length === 2 && cleanSlug(parts[0])) {
    if (parts[1] === 'pedidos') return '/orders.html';
    if (parts[1] === 'conta' || parts[1] === 'cliente') return '/account.html';
    if (parts[1] === 'pagamento') return '/payment.html';
  }
  return decodeURIComponent(requestPath);
}

function csvEnv(name) {
  return String(process.env[name] || '')
    .split(',')
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean);
}

async function sendFile(req, res, filePath, options = {}) {
  const ext = path.extname(filePath);
  const fileStat = await stat(filePath);
  const cacheableInMemory = filePath.startsWith(publicDir) && fileStat.size <= 2 * 1024 * 1024;
  let entry = cacheableInMemory ? staticFileCache.get(filePath) : null;
  if (!entry || entry.mtimeMs !== fileStat.mtimeMs || entry.size !== fileStat.size) {
    const content = await readFile(filePath);
    entry = {
      content,
      gzip: compressibleStaticExtensions.has(ext) && content.length >= 1024 ? gzipSync(content, { level: 6 }) : null,
      etag: `W/"${createHash('sha256').update(content).digest('base64url').slice(0, 24)}"`,
      mtimeMs: fileStat.mtimeMs,
      size: fileStat.size
    };
    if (cacheableInMemory) staticFileCache.set(filePath, entry);
  }
  const cacheControl = ext === '.html'
    ? 'no-cache'
    : ['.js', '.css'].includes(ext)
      ? 'public, max-age=300, stale-while-revalidate=60'
      : 'public, max-age=86400, stale-while-revalidate=3600';
  const baseHeaders = {
    ...securityHeaders({ allowSameOriginFrame: ext === '.html' }),
    'Cache-Control': cacheControl,
    ETag: entry.etag,
    Vary: 'Accept-Encoding',
    'Content-Type': mimeTypes.get(ext) || 'application/octet-stream',
    ...(shouldNoIndexResponse(req, filePath) ? { 'X-Robots-Tag': 'noindex, nofollow' } : {}),
    ...(options.headers || {})
  };
  if (req.headers['if-none-match'] === entry.etag) {
    res.writeHead(304, baseHeaders);
    res.end();
    return;
  }
  const acceptsGzip = /(?:^|,)\s*gzip\s*(?:,|$)/i.test(String(req.headers['accept-encoding'] || ''));
  const body = acceptsGzip && entry.gzip ? entry.gzip : entry.content;
  res.writeHead(options.status || 200, {
    ...baseHeaders,
    ...(body === entry.gzip ? { 'Content-Encoding': 'gzip' } : {}),
    'Content-Length': body.length
  });
  res.end(body);
}

async function readJson(req) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (body.length > MAX_JSON_BYTES) throw httpError(413, 'Payload muito grande.');
  }

  if (!body) return {};
  try {
    return JSON.parse(body);
  } catch {
    throw httpError(400, 'JSON inválido.');
  }
}

function sanitizeAdminUser(data) {
  const admin = sanitize(data, {
    name: 'string',
    email: 'email'
  }, ['name', 'email']);
  return admin;
}

function sanitizeAdminRole(role) {
  const value = String(role || '').trim();
  if (['superadmin', 'admin', 'waiter', 'attendant', 'delivery', 'kitchen'].includes(value)) return value;
  return 'admin';
}

function sanitizeStore(data) {
  const store = sanitize(data, {
    name: 'string',
    slug: 'string',
    description: 'nullable_string',
    whatsapp_number: 'phone',
    address: 'nullable_string',
    page_title: 'nullable_string',
    favicon_url: 'nullable_string',
    logo_url: 'nullable_string',
    cover_url: 'nullable_string',
    is_open: 'boolean',
    accepts_delivery: 'boolean',
    accepts_pickup: 'boolean',
    delivery_fee: 'float',
    delivery_neighborhood_fees: 'object',
    minimum_order: 'float',
    payment_methods: 'array',
    business_hours: 'object',
    loyalty_program: 'object',
    theme_settings: 'object',
    print_settings: 'object',
    integration_settings: 'object',
    seo_index_enabled: 'boolean',
    onboarding_completed: 'boolean'
  }, ['name']);
  if ('whatsapp_number' in store) store.whatsapp_number = normalizeBrazilLocalPhone(store.whatsapp_number);
  if ('whatsapp_number' in store && store.whatsapp_number && !isBrazilLocalPhone(store.whatsapp_number)) {
    throw httpError(422, 'Informe o WhatsApp dos pedidos com DDD + telefone, sem +55. Ex: 55936191201.');
  }
  if ('delivery_neighborhood_fees' in store) {
    store.delivery_neighborhood_fees = sanitizeNeighborhoodFees(store.delivery_neighborhood_fees);
  }
  if ('loyalty_program' in store) {
    store.loyalty_program = sanitizeLoyaltyProgram(store.loyalty_program);
  }
  if ('theme_settings' in store) {
    store.theme_settings = sanitizeThemeSettings(store.theme_settings);
  }
  if ('print_settings' in store) {
    store.print_settings = sanitizePrintSettings(store.print_settings);
  }
  if ('integration_settings' in store) {
    store.integration_settings = sanitizeIntegrationSettings(store.integration_settings);
  }
  return store;
}

function sanitizeDiningTable(data, creating) {
  const table = sanitize(data, {
    name: 'string',
    code: 'string',
    is_active: 'boolean'
  }, creating ? ['name'] : []);
  if ('code' in table) table.code = cleanSlug(table.code || table.name);
  return table;
}

function sanitizeNeighborhoodFees(value) {
  if (!isPlainObject(value)) return {};
  return Object.fromEntries(Object.entries(value)
    .map(([name, price]) => [cleanText(name), roundMoney(Number.parseFloat(price) || 0)])
    .filter(([name, price]) => name && price >= 0));
}

function sanitizeCategory(data, creating) {
  return sanitize(data, {
    name: 'string',
    description: 'nullable_string',
    sort_order: 'integer',
    is_active: 'boolean'
  }, creating ? ['name'] : []);
}

function sanitizeItem(data, creating) {
  return sanitize(data, {
    category_id: 'string',
    name: 'string',
    description: 'nullable_string',
    price: 'float',
    image_url: 'nullable_string',
    tags: 'array',
    is_featured: 'boolean',
    is_available: 'boolean',
    sort_order: 'integer'
  }, creating ? ['category_id', 'name', 'price'] : []);
}

function sanitizeModifierGroup(data, creating) {
  const clean = sanitize(data, {
    name: 'string',
    description: 'nullable_string',
    min_choices: 'integer',
    max_choices: 'integer',
    is_required: 'boolean',
    sort_order: 'integer'
  }, creating ? ['name'] : []);
  if ('min_choices' in clean) clean.min_choices = Math.max(0, clean.min_choices);
  if ('max_choices' in clean) clean.max_choices = Math.max(1, clean.max_choices);
  if (clean.is_required && (!('min_choices' in clean) || clean.min_choices < 1)) {
    clean.min_choices = 1;
  }
  if ('min_choices' in clean && 'max_choices' in clean && clean.max_choices < clean.min_choices) {
    clean.max_choices = clean.min_choices || 1;
  }
  return clean;
}

function sanitizeModifier(data, creating) {
  return sanitize(data, {
    name: 'string',
    price_delta: 'float',
    is_available: 'boolean',
    sort_order: 'integer'
  }, creating ? ['name'] : []);
}

function sanitizePromotion(data, creating) {
  const promotion = sanitize(data, {
    name: 'string',
    code: 'string',
    description: 'nullable_string',
    promotion_type: 'string',
    discount_type: 'string',
    discount_value: 'float',
    minimum_order: 'float',
    starts_at: 'nullable_string',
    ends_at: 'nullable_string',
    max_uses: 'nullable_integer',
    max_uses_per_customer: 'integer',
    allowed_category_ids: 'array',
    combo_item_ids: 'array',
    recurring_min_orders: 'integer',
    birthday_window_days: 'integer',
    is_active: 'boolean'
  }, creating ? ['name', 'code'] : []);

  if ('code' in promotion) {
    promotion.code = promotion.code.toUpperCase().replace(/[^A-Z0-9_-]/g, '');
    if (!promotion.code) throw httpError(422, 'Informe um código de cupom válido.');
  }
  if ('discount_type' in promotion && !['fixed', 'percent', 'free_delivery'].includes(promotion.discount_type)) {
    throw httpError(422, 'Tipo de desconto inválido.');
  }
  if ('promotion_type' in promotion && !['general', 'first_order', 'free_delivery', 'fixed', 'percent', 'combo', 'birthday', 'recurring'].includes(promotion.promotion_type)) {
    throw httpError(422, 'Tipo de promoção inválido.');
  }
  if (promotion.promotion_type === 'free_delivery') promotion.discount_type = 'free_delivery';
  if (promotion.promotion_type === 'fixed') promotion.discount_type = 'fixed';
  if (promotion.promotion_type === 'percent') promotion.discount_type = 'percent';
  if (promotion.discount_type === 'percent' && promotion.discount_value > 100) promotion.discount_value = 100;
  if ('discount_value' in promotion) promotion.discount_value = Math.max(0, promotion.discount_value);
  if ('minimum_order' in promotion) promotion.minimum_order = Math.max(0, promotion.minimum_order);
  if ('max_uses' in promotion && promotion.max_uses !== null) promotion.max_uses = Math.max(1, promotion.max_uses);
  if ('max_uses_per_customer' in promotion) promotion.max_uses_per_customer = Math.max(1, promotion.max_uses_per_customer);
  if ('allowed_category_ids' in promotion) promotion.allowed_category_ids = cleanIdArray(promotion.allowed_category_ids);
  if ('combo_item_ids' in promotion) promotion.combo_item_ids = cleanIdArray(promotion.combo_item_ids);
  if ('recurring_min_orders' in promotion) promotion.recurring_min_orders = Math.max(1, promotion.recurring_min_orders);
  if ('birthday_window_days' in promotion) promotion.birthday_window_days = Math.max(0, promotion.birthday_window_days);
  if ('starts_at' in promotion) promotion.starts_at = cleanOptionalDate(promotion.starts_at);
  if ('ends_at' in promotion) promotion.ends_at = cleanOptionalDate(promotion.ends_at);
  return promotion;
}

function sanitizeCustomer(data) {
  const customer = sanitize(data, {
    name: 'string',
    phone: 'phone',
    email: 'nullable_email',
    document: 'nullable_string',
    birth_date: 'nullable_date',
    notes: 'nullable_string'
  }, ['name', 'phone']);

  if (customer.phone.length < 10) throw httpError(422, 'Informe um telefone válido.');
  if (customer.document) customer.document = onlyDigits(customer.document).slice(0, 14);
  return customer;
}

function sanitizeOrderCustomer(data, fulfillmentMethod) {
  if (fulfillmentMethod === 'delivery' || fulfillmentMethod === 'pickup') return sanitizeCustomer(data);
  if (fulfillmentMethod === 'table' || fulfillmentMethod === 'tab') {
    const customer = sanitize(data, {
      name: 'nullable_string',
      phone: 'phone',
      email: 'nullable_email',
      document: 'nullable_string'
    }, []);
    if (customer.phone && customer.phone.length < 10) throw httpError(422, 'Informe um telefone válido ou deixe em branco.');
    if (customer.document) customer.document = onlyDigits(customer.document).slice(0, 14);
    customer.name = cleanText(customer.name || 'Cliente da mesa');
    return customer;
  }
  const customer = sanitize(data, {
    name: 'string',
    phone: 'phone',
    email: 'nullable_email',
    document: 'nullable_string'
  }, ['name']);
  if (customer.phone && customer.phone.length < 10) throw httpError(422, 'Informe um telefone válido ou deixe em branco.');
  if (customer.document) customer.document = onlyDigits(customer.document).slice(0, 14);
  return customer;
}

async function requireActiveDiningTable(idOrCode, storeId, options = {}) {
  const db = options.db || dbRequest;
  const value = cleanText(idOrCode || '');
  const resolvedStoreId = cleanUuid(storeId);
  if (!value) throw httpError(422, 'Mesa não informada.');
  const query = {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    is_active: 'eq.true',
    limit: '1'
  };
  if (/^[a-f0-9-]{36}$/i.test(value)) query.id = `eq.${cleanUuid(value, 'mesa')}`;
  else query.code = `eq.${cleanSlug(value)}`;
  const rows = await db('GET', 'dining_tables', query);
  if (!rows[0]) throw httpError(422, 'Mesa não encontrada ou inativa.');
  return rows[0];
}

async function requireOpenTab(tabId, tableId, storeId, options = {}) {
  const db = options.db || dbRequest;
  const id = tabId ? cleanUuid(tabId, 'comanda') : '';
  const resolvedStoreId = cleanUuid(storeId);
  let rows = [];
  if (id) {
    rows = await db('GET', 'customer_tabs', {
      select: '*',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      id: `eq.${id}`,
      status: 'eq.open',
      limit: '1'
    });
    if (rows[0] && tableId && rows[0].dining_table_id !== tableId) {
      throw httpError(422, 'A comanda selecionada não pertence a esta mesa.');
    }
  } else if (tableId) {
    rows = await db('GET', 'customer_tabs', {
      select: '*',
      ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
      dining_table_id: `eq.${tableId}`,
      status: 'eq.open',
      order: 'opened_at.asc',
      limit: '2'
    });
    if (rows.length > 1) throw httpError(422, 'Escolha qual comanda desta mesa receberá o pedido.');
  }
  if (!rows[0]) throw httpError(422, 'Comanda aberta não encontrada.');
  return rows[0];
}

async function findOpenTabForTable(tableId, storeId, options = {}) {
  const db = options.db || dbRequest;
  const id = cleanText(tableId || '');
  const resolvedStoreId = cleanUuid(storeId);
  if (!id) return null;
  const rows = await db('GET', 'customer_tabs', {
    select: '*',
    ...(resolvedStoreId ? { store_id: `eq.${resolvedStoreId}` } : {}),
    dining_table_id: `eq.${id}`,
    status: 'eq.open',
    order: 'opened_at.asc',
    limit: '2'
  });
  return rows.length === 1 ? rows[0] : null;
}

function sanitizeAddress(data) {
  return sanitize(data, {
    label: 'string',
    postal_code: 'nullable_string',
    street: 'string',
    number: 'string',
    complement: 'nullable_string',
    neighborhood: 'nullable_string',
    city: 'nullable_string',
    reference: 'nullable_string'
  }, ['street', 'number', 'neighborhood', 'city']);
}

function sanitizeAddressWithDefault(data, requireStreet) {
  return sanitize(data, {
    label: 'string',
    postal_code: 'nullable_string',
    street: 'string',
    number: requireStreet ? 'string' : 'nullable_string',
    complement: 'nullable_string',
    neighborhood: 'nullable_string',
    city: 'nullable_string',
    reference: 'nullable_string',
    is_default: 'boolean'
  }, requireStreet ? ['street', 'number', 'neighborhood', 'city'] : []);
}

function sanitizePaymentDetails(data, paymentMethod) {
  const details = {};
  if (isCashPayment(paymentMethod) && 'change_for' in data) {
    details.change_for = roundMoney(Number.parseFloat(String(data.change_for).replace(',', '.')) || 0);
  }
  return details;
}

function validatePaymentDetails(details, paymentMethod, total) {
  if (!isCashPayment(paymentMethod) || !details.change_for) return;
  if (moneyNumber(details.change_for) < moneyNumber(total)) {
    throw httpError(422, 'O valor para troco precisa ser maior ou igual ao total do pedido.');
  }
}

function isCashPayment(paymentMethod) {
  return normalizeName(paymentMethod).includes('dinheiro');
}

function isOnlinePixPayment(paymentMethod) {
  const normalized = normalizeName(paymentMethod);
  return normalized === 'pagamento online' || (normalized.includes('pix') && (normalized.includes('online') || normalized.includes('pagamento online')));
}

function isOnlineCardPayment(paymentMethod) {
  const normalized = normalizeName(paymentMethod);
  return normalized.includes('cartao') && (normalized.includes('online') || normalized.includes('pagamento online'));
}

function isOnlinePaymentMethod(paymentMethod) {
  return isOnlinePixPayment(paymentMethod) || isOnlineCardPayment(paymentMethod);
}

function isOnlineOrderAwaitingRelease(order) {
  if (!order || !isOnlinePaymentMethod(order.payment_method)) return false;
  return !['paid', 'refunded'].includes(String(order.financial_status || 'pending'));
}

function validateOnlinePaymentAmount(paymentMethod, integrations, total) {
  if (!isOnlinePaymentMethod(paymentMethod)) return;
  const provider = onlinePaymentProviderFor(paymentMethod, integrations);
  if (provider === 'abacatepay' && moneyCents(total) < 100) {
    throw httpError(422, 'Pagamento online via Abacate Pay exige valor mínimo de R$ 1,00.');
  }
}

function onlinePaymentProviderFor(paymentMethod, integrations) {
  if (isOnlinePixPayment(paymentMethod)) return integrations.pix.provider;
  if (isOnlineCardPayment(paymentMethod)) return integrations.card.provider;
  return null;
}

function sanitize(data, allowed, required) {
  for (const field of required) {
    if (!(field in data) || data[field] === '') {
      throw httpError(422, `Campo obrigatorio ausente: ${fieldLabel(field)}`);
    }
  }

  const clean = {};
  for (const [field, type] of Object.entries(allowed)) {
    if (!(field in data)) continue;
    const value = data[field];

    if (type === 'string') clean[field] = cleanText(value);
    if (type === 'nullable_string') clean[field] = value === null || value === '' ? null : cleanText(value);
    if (type === 'integer') clean[field] = Number.parseInt(value, 10) || 0;
    if (type === 'nullable_integer') clean[field] = value === null || value === '' ? null : Number.parseInt(value, 10) || null;
    if (type === 'float') clean[field] = roundMoney(Number.parseFloat(value) || 0);
    if (type === 'boolean') clean[field] = value === true || value === 'true' || value === 'on' || value === '1';
    if (type === 'array') clean[field] = Array.isArray(value) ? value.map(cleanText).filter(Boolean) : [];
    if (type === 'object') clean[field] = isPlainObject(value) ? value : {};
    if (type === 'phone') clean[field] = onlyDigits(value);
    if (type === 'email') clean[field] = cleanEmail(value);
    if (type === 'nullable_email') clean[field] = value ? cleanEmail(value) : null;
    if (type === 'nullable_date') clean[field] = value ? cleanOptionalDate(value).slice(0, 10) : null;
  }

  return clean;
}

function cleanOptionalDate(value) {
  if (value === null || value === '') return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw httpError(422, 'Data inválida.');
  return date.toISOString();
}

function fieldLabel(field) {
  return ({
    name: 'nome',
    phone: 'telefone',
    email: 'e-mail',
    postal_code: 'CEP',
    street: 'rua',
    number: 'número',
    neighborhood: 'bairro',
    city: 'cidade',
    payment_method: 'forma de pagamento',
    id: 'identificador'
  })[field] || field;
}

function buildWhatsappMessage(store, order, items, customer, address) {
  const origin = orderOriginLabel(order);
  const lines = [
    `Novo pedido #${order.public_code}`,
    '',
    `Cliente: ${customer.name}`,
    customer.phone ? `Telefone: ${customer.phone}` : null,
    `Tipo: ${origin}`,
    order.table_snapshot?.name ? `Mesa: ${order.table_snapshot.name}` : null,
    order.tab_snapshot?.name ? `Comanda: ${order.tab_snapshot.name}` : null,
    `Pagamento: ${order.payment_method}`,
    ''
  ].filter(Boolean);

  if (address) {
    lines.push('Endereço:');
    if (address.postal_code) lines.push(`CEP: ${address.postal_code}`);
    lines.push(`${address.street}${address.number ? `, ${address.number}` : ''}`);
    if (address.neighborhood) lines.push(`Bairro: ${address.neighborhood}`);
    if (address.city) lines.push(`Cidade: ${address.city}`);
    if (address.complement) lines.push(`Complemento: ${address.complement}`);
    if (address.reference) lines.push(`Referência: ${address.reference}`);
    lines.push('');
  }

  lines.push('Itens:');
  for (const item of items) {
    lines.push(`${item.quantity}x ${item.item_snapshot.name} - ${formatMoney(item.total)}`);
    for (const modifier of item.item_snapshot.modifiers || []) {
      lines.push(`  - ${modifierWhatsappLine(modifier)}`);
    }
    if (item.notes) lines.push(`Obs: ${item.notes}`);
  }

  lines.push('');
  lines.push(`Subtotal: ${formatMoney(order.subtotal)}`);
  if (Number(order.delivery_fee) > 0) lines.push(`Entrega: ${formatMoney(order.delivery_fee)}`);
  if (Number(order.discount) > 0) {
    lines.push(`Desconto${order.promotion_code ? ` (${order.promotion_code})` : ''}: -${formatMoney(order.discount)}`);
  }
  lines.push(`Total: ${formatMoney(order.total)}`);
  if (isCashPayment(order.payment_method) && order.payment_details?.change_for) {
    lines.push(`Troco para: ${formatMoney(order.payment_details.change_for)}`);
  }
  if (order.notes) lines.push(`Observações: ${order.notes}`);
  if (store.name) lines.push('', store.name);

  return lines.join('\n');
}

function orderOriginLabel(order) {
  return ({
    delivery: 'Delivery',
    pickup: 'Retirada',
    counter: 'Balcão',
    table: 'Mesa',
    tab: 'Comanda'
  })[order.fulfillment_method] || order.fulfillment_method || 'Pedido';
}

function modifierWhatsappLine(modifier) {
  const delta = moneyNumber(modifier.price_delta);
  const group = modifier.group_name ? `${modifier.group_name}: ` : '';
  return `${group}${modifier.name}${delta > 0 ? ` (+ ${formatMoney(delta)})` : ''}`;
}

function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const iterations = 310000;
  const digest = pbkdf2Sync(password, salt, iterations, 32, 'sha256').toString('hex');
  return `pbkdf2_sha256$${iterations}$${salt}$${digest}`;
}

function verifyPassword(password, stored) {
  if (!stored) return false;
  const [algorithm, iterations, salt, digest] = String(stored).split('$');
  if (algorithm !== 'pbkdf2_sha256' || !iterations || !salt || !digest) return false;
  const actual = pbkdf2Sync(password, salt, Number(iterations), 32, 'sha256');
  const expected = Buffer.from(digest, 'hex');
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function validatePassword(value) {
  const password = String(value || '');
  if (password.length < PASSWORD_MIN_LENGTH) {
    throw httpError(422, `A senha deve ter pelo menos ${PASSWORD_MIN_LENGTH} caracteres.`);
  }
  return password;
}

function parseCookies(req) {
  const cookies = {};
  const raw = req.headers.cookie || '';
  for (const part of raw.split(';')) {
    const index = part.indexOf('=');
    if (index === -1) continue;
    cookies[part.slice(0, index).trim()] = decodeURIComponent(part.slice(index + 1).trim());
  }
  return cookies;
}

function sessionCookie(name, value) {
  const secure = COOKIE_SECURE ? '; Secure' : '';
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_MAX_AGE}${secure}`;
}

function clearCookie(name) {
  const secure = COOKIE_SECURE ? '; Secure' : '';
  return `${name}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`;
}

function publicAdmin(admin) {
  return {
    id: admin.id,
    name: admin.name,
    email: admin.email,
    role: normalizeAdminRole(admin.role),
    role_label: adminRoleLabel(admin.role),
    permissions: adminPermissions(admin),
    company_id: admin.company_id || null,
    store_id: admin.store_id || admin.active_store?.id || null,
    active_store: admin.active_store || null,
    stores: Array.isArray(admin.stores) ? admin.stores : [],
    plan_access: admin.plan_access || {},
    is_active: admin.is_active !== false,
    last_login_at: admin.last_login_at || null,
    created_at: admin.created_at || null,
    support_mode: publicSupportMode(admin.support_mode)
  };
}

function publicSupportMode(supportMode) {
  if (!supportMode?.active) return null;
  return {
    active: true,
    started_at: supportMode.started_at || null,
    expires_at: supportMode.expires_at || null,
    original_admin_id: supportMode.original_admin_id || null,
    original_admin_email: supportMode.original_admin_email || null,
    target_company_id: supportMode.target_company_id || null,
    target_company_name: supportMode.target_company_name || null,
    target_store_id: supportMode.target_store_id || null,
    target_store_name: supportMode.target_store_name || null,
    target_store_slug: supportMode.target_store_slug || null
  };
}

function isSupportModeAdmin(admin) {
  return Boolean(admin?.support_mode?.active);
}

function isSupportModeExpired(admin) {
  if (!isSupportModeAdmin(admin)) return false;
  const expiresAt = new Date(admin.support_mode.expires_at || 0).getTime();
  return !expiresAt || expiresAt <= Date.now();
}

function supportModeRestrictedPermission(permission) {
  return ['account', 'admin_users', 'plan', 'platform'].includes(permission);
}

function publicStoreRef(store) {
  if (!store) return null;
  return {
    id: store.id,
    company_id: store.company_id || null,
    name: store.name,
    slug: store.slug,
    public_url: store.public_url || `/${store.slug}`,
    is_active: store.is_active !== false
  };
}

function adminRoleLabel(role) {
  return ({
    superadmin: 'Superadmin',
    admin: 'Administrador',
    owner: 'Administrador',
    manager: 'Administrador',
    waiter: 'Garcom',
    attendant: 'Atendimento',
    delivery: 'Entrega',
    kitchen: 'Cozinha'
  })[role] || 'Administrador';
}

function publicCustomer(customer) {
  return {
    id: customer.id,
    name: customer.name,
    phone: customer.phone,
    email: customer.email || null
  };
}

function json(res, status, data, headers = {}) {
  res.writeHead(status, { ...securityHeaders(), 'Cache-Control': 'no-store', 'Content-Type': 'application/json; charset=utf-8', ...headers });
  res.end(JSON.stringify(data));
}

function securityHeaders(options = {}) {
  const frameAncestors = options.allowSameOriginFrame ? "frame-ancestors 'self'" : "frame-ancestors 'none'";
  return {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': options.allowSameOriginFrame ? 'SAMEORIGIN' : 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'Content-Security-Policy': [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob: https:",
      "font-src 'self' data:",
      "connect-src 'self'",
      "frame-src 'self'",
      "base-uri 'self'",
      "form-action 'self'",
      frameAncestors,
      "object-src 'none'"
    ].join('; ')
  };
}

async function safeResponse(response) {
  const text = await response.text();
  if (!text) return [];
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function httpError(status, message, detail) {
  const error = new Error(message);
  error.status = status;
  error.detail = detail;
  return error;
}

function isUniqueViolation(error) {
  const detail = error?.detail || {};
  return error?.code === '23505'
    || detail?.code === '23505'
    || /unique|duplicate key/i.test(String(error?.message || ''))
    || /unique|duplicate key/i.test(String(detail?.message || detail?.detail || ''));
}

function localDbErrorMessage(data) {
  if (typeof data === 'string' && data.trim()) return data.trim().slice(0, 500);
  if (isPlainObject(data)) {
    return String(data.message || data.error || data.details || data.hint || 'Erro retornado pelo banco local.').slice(0, 500);
  }
  return 'Erro retornado pelo banco local.';
}

function logServerError(error, req) {
  const status = error.status || 500;
  if (status < 500 && !String(error.message || '').startsWith('Banco local:')) return;
  console.error(JSON.stringify({
    scope: 'server',
    method: req?.method,
    url: req?.url,
    status,
    message: error.message,
    detail: sanitizeErrorDetailForLog(error.detail)
  }));
}

function sanitizeErrorDetailForLog(detail) {
  if (!detail) return undefined;
  if (typeof detail === 'string') return detail.slice(0, 500);
  if (isPlainObject(detail)) {
    const { message, code, details, hint, error } = detail;
    return { message, code, details, hint, error };
  }
  return undefined;
}

function createPublicCode() {
  return randomBytes(6).toString('base64url').replace(/[^A-Z0-9]/gi, '').slice(0, 10).toUpperCase();
}

function cleanText(value) {
  return String(value ?? '').trim().slice(0, 500);
}

function cleanUuid(value, field = 'id') {
  const text = cleanText(value).toLowerCase();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(text)) {
    throw httpError(422, `${fieldLabel(field)} inválido.`);
  }
  return text;
}

function cleanOptionalUuid(value, field = 'id') {
  const text = cleanText(value).toLowerCase();
  return text ? cleanUuid(text, field) : '';
}

function cleanUuidArray(value, field = 'id') {
  if (!Array.isArray(value)) return [];
  const unique = new Set();
  for (const item of value) {
    if (item === null || item === undefined || item === '') continue;
    unique.add(cleanUuid(item, field));
  }
  return [...unique];
}

function uuidInFilter(ids) {
  const cleanIds = cleanUuidArray(ids);
  if (!cleanIds.length) throw httpError(422, 'Lista de identificadores inválida.');
  return `in.(${cleanIds.join(',')})`;
}

function cleanPublicCode(value) {
  return cleanText(value).toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 40);
}

function cleanProvider(value) {
  const provider = cleanText(value).toLowerCase().replace(/[^a-z0-9_-]/g, '');
  return ['abacatepay', 'mercadopago', 'asaas', 'efi', 'mock'].includes(provider) ? provider : 'mock';
}

function cleanPlanCode(value) {
  return String(value ?? '')
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '')
    .slice(0, 80);
}

function cleanExternalId(value) {
  return cleanText(value).replace(/[^a-zA-Z0-9._:-]/g, '').slice(0, 180);
}

function cleanSlug(value) {
  return String(value ?? '')
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\b([a-z0-9])[\s._-]+(?=[a-z0-9]\b)/g, '$1')
    .replace(/\b([a-z0-9])[\s._-]+(?=[a-z0-9]\b)/g, '$1')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 80);
}

function cleanAddonCode(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '')
    .slice(0, 80);
}

function normalizeDomain(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/\/.*$/, '')
    .replace(/:\d+$/, '')
    .replace(/^www\./, '');
}

function normalizeServiceUrl(value) {
  const text = String(value || '').trim().replace(/\/rest\/v1\/?$/i, '').replace(/\/+$/, '');
  if (!text) return '';
  try {
    const parsed = new URL(text);
    const isLocal = ['localhost', '127.0.0.1', '0.0.0.0'].includes(parsed.hostname);
    if (parsed.protocol !== 'https:' && !(isLocal && parsed.protocol === 'http:')) return '';
    return parsed.origin;
  } catch {
    return '';
  }
}

function isValidDomain(value) {
  const domain = normalizeDomain(value);
  return /^(?!-)(?:[a-z0-9-]{1,63}\.)+[a-z]{2,63}$/.test(domain) && !domain.includes('..');
}

function normalizeName(value) {
  return cleanText(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .toLowerCase();
}

function addressKey(address) {
  return [
    address.street,
    address.number,
    address.complement,
    address.neighborhood,
    address.city
  ].map((value) => cleanText(value).toLowerCase()).join('|');
}

function cleanEmail(value) {
  const email = cleanText(value).toLowerCase();
  if (!email || !email.includes('@')) throw httpError(422, 'Informe um e-mail válido.');
  return email;
}

function onlyDigits(value) {
  return String(value ?? '').replace(/\D/g, '');
}

function isBrazilLocalPhone(value) {
  const digits = onlyDigits(value);
  return digits.length === 10 || digits.length === 11;
}

function normalizeBrazilLocalPhone(value) {
  const digits = onlyDigits(value);
  if ((digits.length === 12 || digits.length === 13) && digits.startsWith('55')) return digits.slice(2);
  return digits;
}

function parseBoolean(value, fallback = false) {
  if (value === undefined || value === null || value === '') return fallback;
  return ['1', 'true', 'yes', 'sim', 'on'].includes(String(value).trim().toLowerCase());
}

function clampNumber(value, min, max) {
  if (!Number.isFinite(value)) return min;
  return Math.max(min, Math.min(max, value));
}

function clampInteger(value, min, max) {
  const number = Number.parseInt(value, 10);
  if (Number.isNaN(number)) return min;
  return Math.max(min, Math.min(max, number));
}

function moneyNumber(value) {
  return roundMoney(Number(value || 0));
}

function moneyToCents(value) {
  return Math.round(moneyNumber(value) * 100);
}

function parseMoneyInput(value) {
  const normalized = String(value ?? '')
    .replace(/[^\d,.-]/g, '')
    .replace(/\./g, '')
    .replace(',', '.');
  if (!normalized) return null;
  const number = Number.parseFloat(normalized);
  return Number.isFinite(number) ? roundMoney(number) : null;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function formatMoney(value) {
  return moneyNumber(value).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function cleanFileName(value) {
  return String(value)
    .toLowerCase()
    .replace(/[^a-z0-9._-]/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 90) || 'imagem.jpg';
}

function detectImageContentType(buffer) {
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return 'image/jpeg';
  }
  if (
    buffer.length >= 8
    && buffer[0] === 0x89
    && buffer[1] === 0x50
    && buffer[2] === 0x4e
    && buffer[3] === 0x47
    && buffer[4] === 0x0d
    && buffer[5] === 0x0a
    && buffer[6] === 0x1a
    && buffer[7] === 0x0a
  ) {
    return 'image/png';
  }
  if (
    buffer.length >= 12
    && buffer.toString('ascii', 0, 4) === 'RIFF'
    && buffer.toString('ascii', 8, 12) === 'WEBP'
  ) {
    return 'image/webp';
  }
  return null;
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function loadEnv(filePath) {
  if (!existsSync(filePath)) return;
  const content = readFileSync(filePath, 'utf8');
  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#') || !trimmed.includes('=')) continue;
    const [key, ...rest] = trimmed.split('=');
    const value = rest.join('=').trim().replace(/^["']|["']$/g, '');
    if (!process.env[key.trim()]) process.env[key.trim()] = value;
  }
}




